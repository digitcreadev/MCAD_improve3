# MCAD-NH-R1 Report - Safe-Pruning Semantics, Proof Obligations & Reference Model

## Gate

`PASS_SAFE_PRUNING_SEMANTICS_PROOF_OBLIGATIONS_REFERENCE_MODEL_READY_R2_NO_RESOURCE_CLAIMS`

## Parent admission

The exact MCAD-NH-R0 freeze was admitted at SHA-256:

`b80fdce7807e4f7ca0f1961ea31f9498ff648243436e000614c34cef32c14035`

R0 internal checksums: **20/20 PASS**. The frozen human-validation track remains nested and untouched.

## Scientific result

R1 replaces the unsafe shortcut `Delta_phi=0 => useless` with a five-way semantic partition:

- INADMISSIBLE;
- IMMEDIATE_CONTRIBUTOR;
- DEFERRED_SUPPORT_CONTRIBUTOR;
- REDUNDANT_DISPENSABLE;
- DISTRACTOR_DISPENSABLE.

Let `U(E)` be the union of all evidence atoms still missing from every sufficient support of every unresolved objective constraint. Let `N_E(q)=Real(q)\E`.

For an admissible query, the sufficient R1 pruning condition is:

`N_E(q) intersection U(E) = empty`.

Under the frozen assumptions, this implies that for every possible future evidence continuation `F`:

`Comp(E union F) = Comp(E union Real(q) union F)`.

Thus the candidate is future-irrelevant to objective computability. This is a semantic-preservation result, not yet a resource-saving result.

## Reference-model validation

- classification fixtures: **20/20 PASS**;
- exhaustive finite-model future-irrelevance verification: **7,560** safe candidate states, **60,480** future-continuation comparisons, **0 failures**;
- adversarial multi-query scenarios: SAFE_PRUNING preserves permissive final computability in **5/5**;
- STRICT_IMMEDIATE loses final completion in **4/5** scenarios;
- semantic-contract uncertainty fail-open fixtures: **4/4 PASS**.

The fifth adversarial case is intentionally informative: with alternative supports, strict-immediate pruning can succeed because a later singleton alternative completes the constraint. R1 nevertheless retains the earlier deferred contributor because the safe rule is conservative, not a global subsequence optimizer.

## Fail-open governance

Safe pruning requires a validated objective/support/Real(q) semantic contract. If support completeness or query-realization mapping is unverified, the operational wrapper uses `EXECUTE_FAIL_OPEN`, never optimistic pruning. `SAT=false` remains a separate inadmissibility rejection.

## Frozen handoff to R2/R3

The measurement interface now requires candidate-level semantic decision fields plus paired backend measurements for later resource claims. R2 must first establish objective-preserving pruning over a larger controlled campaign. R3 may then measure CPU, memory-time, I/O, bytes scanned, materialization/streaming, network transfer, backend time and time-to-objective under paired permissive versus safe-pruning runs.

No claim of CPU/memory/I/O/time savings is promoted at R1.

## Implementation identities

- `reference_model.py`: `df568b444201c4dd5ee291680aa4e4e037bb0e715ee7878f52fb197bda75f024`
- `run_r1_gate.py`: `0754cce7fe5ec45b555be84ff04f45990cc4198661fa4dc23392b70875bb683d`
