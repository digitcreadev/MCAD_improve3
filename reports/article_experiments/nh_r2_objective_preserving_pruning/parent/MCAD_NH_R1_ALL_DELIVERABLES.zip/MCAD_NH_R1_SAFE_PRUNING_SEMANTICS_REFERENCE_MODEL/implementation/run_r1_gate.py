from __future__ import annotations
import csv, itertools, json, os, sys, hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
from reference_model import *


def fs(x=()): return frozenset(x)

def spec1(*supports): return {"c1": tuple(fs(s) for s in supports)}

def dump_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def fixture_cases():
    cases=[]
    def add(cid,spec,e,q,expected, note):
        cases.append({"case_id":cid,"spec":{c:[sorted(S) for S in ss] for c,ss in spec.items()},"evidence":sorted(e),"query":{"query_id":q.query_id,"sat":q.sat,"real":sorted(q.real)},"expected":expected,"note":note})
    add("F01", spec1({"a"}), fs(), Query("q",True,fs({"a"})), IMMEDIATE, "single-atom immediate completion")
    add("F02", spec1({"a","b"}), fs(), Query("q",True,fs({"a"})), DEFERRED, "first half of two-query support")
    add("F03", spec1({"a","b"}), fs({"a"}), Query("q",True,fs({"b"})), IMMEDIATE, "second half completes support")
    add("F04", spec1({"a"}), fs({"a"}), Query("q",True,fs({"a"})), REDUNDANT, "exact repeated evidence")
    add("F05", spec1({"a"}), fs(), Query("q",True,fs({"x"})), DISTRACTOR, "novel but objective-irrelevant")
    add("F06", spec1({"a"}), fs(), Query("q",False,fs({"a"})), INADMISSIBLE, "useful-looking evidence but SAT false")
    add("F07", spec1({"a","b"},{"c"}), fs(), Query("q",True,fs({"a"})), DEFERRED, "advances one alternative support")
    add("F08", spec1({"a","b"},{"c"}), fs(), Query("q",True,fs({"c"})), IMMEDIATE, "completes alternative singleton support")
    add("F09", {"c1":(fs({"a","b"}),),"c2":(fs({"c"}),)}, fs({"c"}), Query("q",True,fs({"a"})), DEFERRED, "resolved constraint ignored; unresolved frontier retained")
    add("F10", {"c1":(fs({"a"}),),"c2":(fs({"b"}),)}, fs(), Query("q",True,fs({"a","x"})), IMMEDIATE, "immediate contributor may also carry distractor evidence")
    add("F11", spec1({"a","b","c"}), fs({"a"}), Query("q",True,fs({"b"})), DEFERRED, "middle step of three-query support")
    add("F12", spec1({"a","b","c"}), fs({"a","b"}), Query("q",True,fs({"c"})), IMMEDIATE, "final step of three-query support")
    add("F13", spec1({"a","b"}), fs({"a"}), Query("q",True,fs({"a","x"})), DISTRACTOR, "only novel atom is outside residual frontier")
    add("F14", spec1({"a","b"}), fs({"a"}), Query("q",True,fs({"a"})), REDUNDANT, "no novel evidence while objective unresolved")
    add("F15", spec1({"a"}), fs({"a"}), Query("q",True,fs({"x"})), DISTRACTOR, "objective already resolved; novel evidence cannot reduce computability")
    add("F16", {"c1":(fs({"a","b"}),),"c2":(fs({"b","c"}),)}, fs(), Query("q",True,fs({"b"})), DEFERRED, "one atom advances two unresolved supports")
    add("F17", {"c1":(fs({"a","b"}),),"c2":(fs({"b","c"}),)}, fs({"a","c"}), Query("q",True,fs({"b"})), IMMEDIATE, "one atom completes two constraints")
    add("F18", {"c1":(fs({"a"}),),"c2":(fs({"b","c"}),)}, fs({"a","b"}), Query("q",True,fs({"c"})), IMMEDIATE, "resolved c1 plus immediate c2")
    add("F19", {"c1":(fs({"a"}),),"c2":(fs({"b","c"}),)}, fs({"a"}), Query("q",True,fs({"x","y"})), DISTRACTOR, "novel atoms outside sole unresolved support")
    add("F20", {"c1":(fs({"a"}),),"c2":(fs({"b","c"}),)}, fs({"a"}), Query("q",True,fs({"b","x"})), DEFERRED, "mixed useful and distractor novel evidence: keep conservatively")
    return cases


def parse_case(c):
    spec={k:tuple(fs(S) for S in v) for k,v in c["spec"].items()}
    e=fs(c["evidence"])
    q=Query(c["query"]["query_id"], c["query"]["sat"], fs(c["query"]["real"]))
    return spec,e,q


def classification_gate(cases):
    rows=[]; ok=True
    for c in cases:
        spec,e,q=parse_case(c); r=classify(spec,e,q)
        passed=r["class"]==c["expected"]
        ok &= passed
        rows.append({"case_id":c["case_id"],"expected":c["expected"],"observed":r["class"],"safe_to_prune":r["safe_to_prune"],"delta_phi":f'{r["delta_phi"]:.6f}',"novel":"|".join(sorted(r["novel"])),"frontier_gain":"|".join(sorted(r["frontier_gain"])),"pass":str(passed).upper(),"note":c["note"]})
    return ok,rows


def future_irrelevance_exhaustive():
    atoms=("a","b","c")
    subsets=[fs(s) for n in range(0,4) for s in itertools.combinations(atoms,n)]
    nonempty=[s for s in subsets if s]
    # Every nonempty support family over A for one constraint: 2^7 - 1 = 127.
    families=[]
    for mask in range(1,1<<len(nonempty)):
        families.append(tuple(nonempty[i] for i in range(len(nonempty)) if mask & (1<<i)))
    checked_safe=0; future_comparisons=0; failures=[]
    for fam in families:
        spec={"c1":fam}
        for E in subsets:
            U=residual_frontier(spec,E)
            for R in subsets:
                q=Query("q",True,R)
                rr=classify(spec,E,q)
                if rr["class"] not in (REDUNDANT,DISTRACTOR):
                    continue
                checked_safe += 1
                for F in subsets:
                    future_comparisons += 1
                    lhs=computable_constraints(spec, fs(set(E)|set(F)))
                    rhs=computable_constraints(spec, fs(set(E)|set(R)|set(F)))
                    if lhs != rhs:
                        failures.append((fam,E,R,F,lhs,rhs,U))
                        if len(failures)>10: return checked_safe,future_comparisons,failures
    # two-constraint cross-check with one support per constraint
    for S1 in nonempty:
      for S2 in nonempty:
        spec={"c1":(S1,),"c2":(S2,)}
        for E in subsets:
          for R in subsets:
            q=Query("q",True,R); rr=classify(spec,E,q)
            if rr["class"] not in (REDUNDANT,DISTRACTOR): continue
            checked_safe += 1
            for F in subsets:
              future_comparisons += 1
              lhs=computable_constraints(spec, fs(set(E)|set(F)))
              rhs=computable_constraints(spec, fs(set(E)|set(R)|set(F)))
              if lhs != rhs:
                failures.append(((S1,S2),E,R,F,lhs,rhs,residual_frontier(spec,E)))
                if len(failures)>10: return checked_safe,future_comparisons,failures
    return checked_safe,future_comparisons,failures


def strict_policy_adversarial():
    scenarios=[
      ("A01_TWO_STEP", spec1({"a","b"}), [Query("q1",True,fs({"a"})),Query("q2",True,fs({"b"}))]),
      ("A02_THREE_STEP", spec1({"a","b","c"}), [Query("q1",True,fs({"a"})),Query("q2",True,fs({"b"})),Query("q3",True,fs({"c"}))]),
      ("A03_OVERLAP", {"c1":(fs({"a","b"}),),"c2":(fs({"b","c"}),)}, [Query("q1",True,fs({"b"})),Query("q2",True,fs({"a"})),Query("q3",True,fs({"c"}))]),
      ("A04_DISTRACTOR_REDUNDANT", spec1({"a","b"}), [Query("qd",True,fs({"x"})),Query("q1",True,fs({"a"})),Query("qr",True,fs({"a"})),Query("q2",True,fs({"b"}))]),
      ("A05_ALT_SUPPORT_CONSERVATIVE", spec1({"a","b"},{"c"}), [Query("q1",True,fs({"a"})),Query("q2",True,fs({"c"}))]),
    ]
    rows=[]
    for sid,spec,qs in scenarios:
      p=run_sequence(spec,fs(),qs,"PERMISSIVE")
      s=run_sequence(spec,fs(),qs,"SAFE_PRUNING")
      x=run_sequence(spec,fs(),qs,"STRICT_IMMEDIATE")
      rows.append({"scenario_id":sid,"permissive_final_phi":p["final_phi"],"safe_final_phi":s["final_phi"],"strict_final_phi":x["final_phi"],"safe_preserves":s["final_phi"]==p["final_phi"],"strict_preserves":x["final_phi"]==p["final_phi"],"permissive_executed":sum(t["keep"] for t in p["trace"]),"safe_executed":sum(t["keep"] for t in s["trace"]),"strict_executed":sum(t["keep"] for t in x["trace"]),"safe_trace":json.dumps(s["trace"],sort_keys=True),"strict_trace":json.dumps(x["trace"],sort_keys=True)})
    return rows


def fail_open_checks():
    checks=[]
    examples=[
      ("U01_DISTRACTOR_UNVERIFIED", spec1({"a","b"}), fs(), Query("q",True,fs({"x"}))),
      ("U02_REDUNDANT_UNVERIFIED", spec1({"a","b"}), fs({"a"}), Query("q",True,fs({"a"}))),
      ("U03_DEFERRED_UNVERIFIED", spec1({"a","b"}), fs(), Query("q",True,fs({"a"}))),
      ("U04_INADMISSIBLE_UNVERIFIED", spec1({"a"}), fs(), Query("q",False,fs({"a"}))),
    ]
    for cid,spec,e,q in examples:
      r=operational_prune_decision(spec,e,q,semantic_contract_valid=False)
      expected = "REJECT_INADMISSIBLE" if not q.sat else "EXECUTE_FAIL_OPEN"
      checks.append({"case_id":cid,"semantic_class":r["class"],"observed_action":r["operational_action"],"expected_action":expected,"pass":r["operational_action"]==expected})
    return checks


def measurement_interface():
    return {
      "schema_id":"MCAD-NH-R1-MEASUREMENT-INTERFACE-1",
      "decision_record_required":["session_id","candidate_index","query_id","sat","semantic_contract_valid","class","safe_to_prune","operational_action","proof_status","reason","phi_before","delta_phi","novel_evidence_count","frontier_gain_count","gate_latency_ns","gate_cpu_ns"],
      "backend_if_executed":["backend_path","backend_wall_ms","backend_cpu_ms","worker_ms","peak_memory_bytes","memory_byte_ms","logical_reads","physical_reads","bytes_scanned","spill_bytes","result_rows","result_bytes","network_bytes"],
      "session_aggregates":["candidates","executed","pruned","immediate_executed","deferred_executed","redundant_pruned","distractor_pruned","inadmissible_rejected","false_prunes","phi_final","first_full_phi_candidate_index","first_full_phi_backend_execution_index","backend_wall_ms_total","gate_wall_ms_total","net_wall_ms_saved"],
      "mandatory_pairing":"Every pruned candidate must have a permissive counterfactual backend-cost observation from controlled replay or a separately declared estimator; semantic-core timing alone cannot support resource-saving claims.",
      "primary_R2_correctness":"phi_final_SAFE_PRUNING == phi_final_PERMISSIVE and false_prunes_of_IMMEDIATE_or_DEFERRED == 0",
      "primary_R3_systems":"net resource/time savings under paired end-to-end execution"
    }


def main():
    cases=fixture_cases(); dump_json(ROOT/"fixtures"/"R1_CLASSIFICATION_FIXTURES.json", cases)
    cpass,crows=classification_gate(cases)
    with open(ROOT/"analysis"/"R1_CLASSIFICATION_RESULTS.csv","w",newline="",encoding="utf-8") as f:
      w=csv.DictWriter(f,fieldnames=crows[0].keys()); w.writeheader(); w.writerows(crows)
    safe_states,future_checks,failures=future_irrelevance_exhaustive()
    summary={"safe_query_states_checked":safe_states,"future_continuations_checked":future_checks,"failures":len(failures),"pass":not failures,"universe_atoms":3,"one_constraint_support_families":127,"two_constraint_cross_check":"all one-support-per-constraint pairs"}
    dump_json(ROOT/"analysis"/"R1_EXHAUSTIVE_FUTURE_IRRELEVANCE_CHECK.json", summary)
    rows=strict_policy_adversarial()
    with open(ROOT/"analysis"/"R1_STRICT_IMMEDIATE_COMPARISON.csv","w",newline="",encoding="utf-8") as f:
      w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    uchecks=fail_open_checks()
    with open(ROOT/"analysis"/"R1_FAIL_OPEN_SEMANTIC_CONTRACT.csv","w",newline="",encoding="utf-8") as f:
      w=csv.DictWriter(f,fieldnames=uchecks[0].keys()); w.writeheader(); w.writerows(uchecks)
    dump_json(ROOT/"protocol"/"R1_MEASUREMENT_INTERFACE.json", measurement_interface())
    strict_losses=sum(not r["strict_preserves"] for r in rows)
    safe_losses=sum(not r["safe_preserves"] for r in rows)
    gate={
      "classification_fixtures": {"pass":cpass,"passed":sum(r["pass"]=="TRUE" for r in crows),"total":len(crows)},
      "future_irrelevance_exhaustive":summary,
      "adversarial_sequences":{"pass":safe_losses==0 and strict_losses>=3,"safe_completion_losses":safe_losses,"strict_immediate_completion_losses":strict_losses,"scenarios":len(rows)},
      "fail_open_semantic_contract":{"pass":all(r["pass"] for r in uchecks),"passed":sum(r["pass"] for r in uchecks),"total":len(uchecks)},
      "measurement_interface_present":True,
      "overall_pass":bool(cpass and not failures and safe_losses==0 and strict_losses>=3 and all(r["pass"] for r in uchecks))
    }
    dump_json(ROOT/"logs"/"R1_GATE_RESULTS.json",gate)
    print(json.dumps(gate,indent=2,sort_keys=True))
    if not gate["overall_pass"]: raise SystemExit(2)

if __name__=="__main__": main()
