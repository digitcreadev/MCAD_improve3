# MCAD-NH-R1 Proof Obligations

The safe-pruning theorem is claimed only under the following frozen assumptions.

- **A1 Fixed objective:** the active objective and constraint set do not change inside the evaluated segment.
- **A2 Fixed support semantics:** `Sigma(c)` does not change inside the segment.
- **A3 Support completeness:** every evidence atom that can make an unresolved constraint computable is represented in at least one declared sufficient support. If this is uncertain, pruning fails open.
- **A4 Sound query realization contract:** pre-execution `Real(q)` correctly identifies the evidence atoms the query can acquire for the objective-level semantics. If this is uncertain, pruning fails open.
- **A5 Monotone evidence:** execution adds evidence by union; evidence is not invalidated, expired, or negated inside the segment.
- **A6 Extensional computability:** constraint computability depends only on evidence membership in sufficient supports, as frozen in `Comp(E)`.
- **A7 Future-query independence:** skipping a candidate does not alter the semantic availability, `Real(.)`, or admissibility of later candidates except through the explicit evidence state represented in this model.
- **A8 No hidden objective side effects:** cache warming, UI learning, organizational effects, and other non-evidence side effects are outside the semantic preservation theorem.
- **A9 Sequential re-evaluation:** every candidate is classified against the evidence state actually retained by the pruning policy, not against a permissive shadow state.

## PO1 - Classification partition

For a validated contract, every candidate belongs to exactly one of the five R1 classes.

## PO2 - Immediate/deferred retention

No `IMMEDIATE_CONTRIBUTOR` or `DEFERRED_SUPPORT_CONTRIBUTOR` is marked `SAFE_TO_PRUNE`.

## PO3 - Future irrelevance of dispensable evidence

For admissible `q`, if `N_E(q) intersection U(E)=empty`, then for **every** possible future evidence set `F`:

`Comp(E union F) = Comp(E union Real(q) union F)`.

Hence executing `q` cannot change present or future objective computability under A1-A8.

## PO4 - Objective-completion preservation under repeated safe pruning

For a fixed candidate sequence, sequentially pruning only candidates satisfying PO3, while retaining immediate/deferred contributors, preserves the final computable-constraint set achievable by permissive execution under the same admissibility outcomes.

## PO5 - Strict-immediate policy is not generally safe

A policy that keeps only `Delta_phi>0` candidates can discard a first partial-support acquisition and thereby make all later steps non-contributive. R1 therefore treats `DEFERRED_SUPPORT_CONTRIBUTOR` as execution-worthy.

## PO6 - Fail-open specification uncertainty

If A3 or A4 is not established, the system may not claim PO3. It must execute rather than prune on semantic-dispensability grounds.

## PO7 - Resource claims remain separate

PO3/PO4 establish semantic preservation only. They do not establish CPU, memory, I/O, latency, throughput, or end-to-end savings. Those require paired backend instrumentation in NH-R3/NH-R4.
