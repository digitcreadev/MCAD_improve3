# MCAD-NH-R1 Safe-Pruning Semantics

## 1. Objects

Let `A` be the finite universe of evidence atoms. An active strategic objective `O` has a finite constraint set `C(O)`. For each constraint `c`, `Sigma(c)` is a non-empty family of sufficient supports; each support `S in Sigma(c)` is a finite subset of `A`.

Let `E_t subseteq A` be the evidence acquired before candidate query `q_t`. The pre-execution semantic contract provides:

- `SAT(q_t) in {true,false}`;
- `Real(q_t) subseteq A`, the evidence atoms the query is semantically capable of acquiring if executed;
- the fixed objective/support specification.

A constraint is computable under evidence `E` iff at least one sufficient support is contained in `E`:

`Comp(E) = { c in C(O) | exists S in Sigma(c): S subseteq E }`.

`phi(E) = |Comp(E)| / |C(O)|`.

For an admissible query, `Delta_phi_t(q) = phi(E_t union Real(q)) - phi(E_t)`.

## 2. Residual objective frontier

For every unresolved constraint, the residual of a support is `R_E(S) = S \ E`.

The **residual objective frontier** is

`U(E) = union_{c notin Comp(E)} union_{S in Sigma(c)} (S \ E)`.

It contains every evidence atom that is still missing from at least one sufficient support of at least one unresolved constraint.

Novel evidence from a candidate query is

`N_E(q) = Real(q) \ E`.

The query's **frontier gain** is `G_E(q) = N_E(q) intersection U(E)`.

## 3. Frozen five-way classification

The R1 reference model partitions candidates as follows.

1. `INADMISSIBLE`: `SAT(q)=false`.
2. `IMMEDIATE_CONTRIBUTOR`: `SAT(q)=true` and `Delta_phi(q)>0`.
3. `DEFERRED_SUPPORT_CONTRIBUTOR`: `SAT(q)=true`, `Delta_phi(q)=0`, and `G_E(q)` is non-empty.
4. `REDUNDANT_DISPENSABLE`: admissible, `Delta_phi(q)=0`, and `N_E(q)` is empty.
5. `DISTRACTOR_DISPENSABLE`: admissible, `Delta_phi(q)=0`, `N_E(q)` is non-empty, and `G_E(q)` is empty.

This classification deliberately rejects the false equivalence `Delta_phi=0 => useless`. Deferred contributors can be necessary for later multi-query support completion.

## 4. Safe-pruning rule

Under the proof assumptions in `PROOF_OBLIGATIONS.md`, an admissible query is **strategically dispensable** when

`N_E(q) intersection U(E) = empty`.

The operational candidate set is therefore:

`SAFE_TO_PRUNE = {REDUNDANT_DISPENSABLE, DISTRACTOR_DISPENSABLE}`.

`INADMISSIBLE` is also not sent to the backend, but remains a separate admissibility rejection and is not relabelled as redundancy.

`IMMEDIATE_CONTRIBUTOR` and `DEFERRED_SUPPORT_CONTRIBUTOR` are retained.

## 5. Conservative fail-open rule

The theorem is conditional on a validated semantic contract. If objective/support completeness or the `q -> Real(q)` mapping cannot be trusted, semantic dispensability is **unproven** and the system must choose `EXECUTE_FAIL_OPEN`, not `PRUNE`.

Thus an uncertain CKG cannot create an optimistic resource-saving decision.

## 6. Scope boundary

The R1 rule is sufficient for safety but not maximally aggressive. A deferred contributor may later prove unnecessary because another alternative support completes the same constraint. R1 deliberately keeps such a query unless a separate planning theorem can prove its dispensability. The current claim is therefore **safe pruning**, not globally minimum query subsequence selection.
