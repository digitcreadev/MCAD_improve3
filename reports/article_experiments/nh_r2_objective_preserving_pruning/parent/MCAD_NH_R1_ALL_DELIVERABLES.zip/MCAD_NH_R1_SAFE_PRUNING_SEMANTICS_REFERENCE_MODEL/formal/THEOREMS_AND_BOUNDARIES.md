# Theorems, proof sketches, and boundaries

## Theorem T1 - Future-irrelevance lemma

Let `q` be admissible at evidence state `E`. If `N_E(q) intersection U(E)=empty`, then for any future evidence set `F`,

`Comp(E union F) = Comp(E union Real(q) union F)`.

### Proof sketch

Every constraint already in `Comp(E)` remains computable on both sides by monotonicity. Consider an unresolved constraint `c` and any support `S in Sigma(c)`. Every missing atom `S \ E` belongs to `U(E)`. Since no novel atom from `q` intersects `U(E)`, `q` contributes no atom that was missing from `S`. Therefore `S subseteq E union Real(q) union F` iff `S subseteq E union F`. This holds for every support of every unresolved constraint, so computability is identical.

## Corollary C1 - Safe objective-preserving omission

Under A1-A9, `REDUNDANT_DISPENSABLE` and `DISTRACTOR_DISPENSABLE` candidates can be omitted without changing the future computability trajectory for any continuation evidence.

## Corollary C2 - Immediate contribution implies frontier gain

If `Delta_phi(q)>0`, at least one previously unresolved support becomes complete, so at least one newly supplied atom must have belonged to `U(E)`. Immediate contributors therefore cannot satisfy the dispensability condition.

## Proposition P1 - Deferred support can be necessary

For support `{a,b}`, starting with empty evidence, a query realizing `{a}` has `Delta_phi=0` but non-empty frontier gain. If it is removed, a later query realizing `{b}` no longer completes the support. Therefore `Delta_phi=0` alone is not a safe pruning criterion.

## Proposition P2 - Safe rule is conservative, not globally minimal

With alternative supports `{a,b}` and `{c}`, a query acquiring `{a}` is deferred and retained, even if a later query acquiring `{c}` independently completes the constraint. The R1 rule does not use future-plan knowledge to prove that `{a}` is unnecessary. It prioritizes objective preservation over maximal pruning.

## Boundary B1 - CKG correctness

If a support is missing from the CKG, a query classified as distractor may actually be useful. No production pruning claim is allowed without specification-validity handling; the R1 operational wrapper fails open.

## Boundary B2 - Semantic versus physical redundancy

A strategically dispensable query may still be useful for caching, diagnostics, exploration, learning, or another objective. R1 only establishes dispensability relative to the frozen active strategic objective.

## Boundary B3 - Semantics versus action policy

The classifier is a semantic decision primitive. Whether the application physically rejects, delays, caches, or executes a dispensable query is an implementation policy. Resource savings are measured only when a concrete pre-backend pruning action is applied.
