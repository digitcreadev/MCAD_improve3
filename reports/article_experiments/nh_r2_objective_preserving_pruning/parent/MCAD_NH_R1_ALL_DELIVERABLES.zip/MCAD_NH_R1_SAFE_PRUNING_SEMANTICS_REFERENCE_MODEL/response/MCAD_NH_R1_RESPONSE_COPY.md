# MCAD-NH-R1 - Safe-Pruning Semantics, Proof Obligations & Reference Model

**Gate:** `PASS_SAFE_PRUNING_SEMANTICS_PROOF_OBLIGATIONS_REFERENCE_MODEL_READY_R2_NO_RESOURCE_CLAIMS`

R1 is closed. The safe-pruning semantics now distinguishes immediate contributors, deferred-support contributors, redundant-dispensable queries, distractor-dispensable queries, and inadmissible candidates.

The frozen sufficient condition is based on the residual objective frontier `U(E)`: for an admissible query, if its novel evidence has empty intersection with all still-missing atoms of all sufficient supports of unresolved constraints, then under the frozen assumptions the query is future-irrelevant to objective computability for every continuation evidence set. It can therefore be pruned without sacrificing objective completion.

Validation: 20/20 classification fixtures PASS; 7,560 safe candidate states and 60,480 future continuations exhaustively checked with 0 failures; SAFE_PRUNING preserves final computability in 5/5 adversarial multi-query scenarios; STRICT_IMMEDIATE loses completion in 4/5; semantic-contract uncertainty fails open in 4/4 cases.

The rule is conservative rather than globally minimal: deferred contributors are kept even when a later alternative support might make them unnecessary. If support completeness or `q -> Real(q)` validity is unverified, the operational action is `EXECUTE_FAIL_OPEN`, not optimistic pruning.

No backend CPU, memory, I/O, network, latency, acceleration, human-utility, or global-optimality claim is promoted at R1.

Next station: **MCAD-NH-R2 - Objective-Preserving Pruning Campaign**.
