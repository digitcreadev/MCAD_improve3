# Exact R1 -> R2 handoff

Next station: **MCAD-NH-R2 - Objective-Preserving Pruning Campaign**.

R2 must execute the frozen R1 reference model on controlled multi-query sessions and establish, before any resource-saving interpretation:

1. zero false prune of `IMMEDIATE_CONTRIBUTOR` and `DEFERRED_SUPPORT_CONTRIBUTOR` under the reference specification;
2. equality of final objective computability between `SAFE_PRUNING` and permissive execution;
3. explicit quantification of candidates pruned as redundant, distractor, and inadmissible;
4. comparison against `STRICT_IMMEDIATE` to expose completion loss from pruning deferred contributors;
5. useful-execution density and sequence compression without claiming global minimality;
6. robustness subcases with invalid/unverified semantic contracts that must fail open;
7. production of paired replay manifests for NH-R3 backend resource measurement.

R2 is a semantic/objective-preservation gate. CPU/memory/I/O/end-to-end savings remain unpromoted until NH-R3.
