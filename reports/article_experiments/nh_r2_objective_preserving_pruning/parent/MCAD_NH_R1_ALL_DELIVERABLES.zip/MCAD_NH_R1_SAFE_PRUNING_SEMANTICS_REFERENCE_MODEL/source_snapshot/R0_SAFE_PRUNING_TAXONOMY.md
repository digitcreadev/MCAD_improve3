# Query-utility taxonomy for the non-human track

Let `E_t` be evidence acquired before candidate query `q`. Let `Real(q)` be the evidence potentially acquired by `q`. For every unresolved constraint `c`, let `Sigma(c)` be its sufficient supports.

Define novel evidence: `N_t(q) = Real(q) \ E_t`.

For support `S`, define residual support: `R_t(S) = S \ E_t`.

Define future-relevant acquisition if there exists an unresolved constraint and still-viable support `S` such that `N_t(q)` intersects `R_t(S)`.

The frozen taxonomy is:

- **INADMISSIBLE**: `SAT(q)=false`; do not conflate with redundancy.
- **IMMEDIATE_CONTRIBUTOR**: `SAT=true` and `Delta phi > 0`.
- **DEFERRED_SUPPORT_CONTRIBUTOR**: `SAT=true`, `Delta phi = 0`, but `q` adds novel evidence to at least one residual sufficient support. It must not be called useless solely because immediate `Delta phi` is zero.
- **REDUNDANT_DISPENSABLE**: admissible, `Delta phi = 0`, and the relevant evidence it could add is already present.
- **DISTRACTOR_DISPENSABLE**: admissible, `Delta phi = 0`, and any novel evidence does not advance a residual support for the active objective.

`SAFE_TO_PRUNE = INADMISSIBLE OR REDUNDANT_DISPENSABLE OR DISTRACTOR_DISPENSABLE`, subject to the frozen acquisition semantics and CKG correctness assumptions.

This classification is the operational bridge from MCAD semantics to resource avoidance. The scientific semantics and the pruning policy remain separate objects.
