# R1 prohibited claims

R1 does **not** support any claim that:

- every `Delta_phi=0` query is useless;
- the R1 rule finds the globally shortest or optimal query sequence;
- a deferred contributor is always necessary in the realized future;
- CKG/support specifications are automatically correct or complete;
- safe pruning has already saved CPU, memory, I/O, network traffic, backend time, or end-to-end time;
- semantic-core latency is backend or end-to-end performance;
- pruning improves human decision quality, satisfaction, learning, or business outcomes;
- MCAD universally dominates database optimizers, workload managers, or external analytical operators.

R1 establishes a conditional semantic safety rule and an executable reference model only.
