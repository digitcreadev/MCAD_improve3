# MCAD-NH-R1 - Safe-Pruning Semantics, Proof Obligations & Reference Model

This package closes the first technical station of the non-human validation track.

The key correction is that `Delta phi = 0` is **not** equated with uselessness. MCAD-NH-R1 distinguishes deferred multi-query support acquisition from evidence that is truly dispensable for the frozen active objective.

The safe-pruning criterion uses the residual objective frontier `U(E)`. Under the frozen assumptions, an admissible query whose novel evidence does not intersect `U(E)` is future-irrelevant to objective computability for any continuation evidence. The reference model is conservative and fails open when the semantic contract is unverified.

No backend resource-saving, end-to-end acceleration, human-utility, or global-minimum-sequence claim is promoted at R1.
