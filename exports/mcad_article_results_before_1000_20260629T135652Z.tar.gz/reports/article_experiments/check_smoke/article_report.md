# MCAD-Gate evaluation campaigns

Generated at: `2026-06-26T18:02:23+00:00`

Total sessions: **200**
Total queries: **1600**

## Main summary by campaign and policy

| campaign | policy | sessions | queries | mean_phi_final | false_allow_rate | false_block_rate | precision_block | recall_block | F1_block | non_contributive_execution_rate | explanation_coverage_rate | decision_latency_p95_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A_core_foodmart_mcad_gate | mcad_gate | 10 | 80 | 1.0000 | 0.0000 | 0.0000 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 0.2490 |
| A_core_foodmart_mcad_gate | measure_overlap | 10 | 80 | 1.0000 | 0.9333 | 0.0000 | 1.0000 | 0.0667 | 0.1250 | 0.7368 | 1.0000 | 0.1083 |
| A_core_foodmart_mcad_gate | naive | 10 | 80 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.7500 | 0.0000 | 0.0785 |
| A_core_foodmart_mcad_gate | random_matched | 10 | 80 | 0.4000 | 0.2000 | 0.6000 | 0.8000 | 0.8000 | 0.8000 | 0.6000 | 1.0000 | 0.0951 |
| B_multidataset_generalization | mcad_gate | 30 | 240 | 1.0000 | 0.0000 | 0.0000 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 0.2489 |
| B_multidataset_generalization | measure_overlap | 30 | 240 | 1.0000 | 0.9333 | 0.0000 | 1.0000 | 0.0667 | 0.1250 | 0.7368 | 1.0000 | 0.1068 |
| B_multidataset_generalization | naive | 30 | 240 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.7500 | 0.0000 | 0.0794 |
| B_multidataset_generalization | random_matched | 30 | 240 | 0.3500 | 0.2389 | 0.6500 | 0.7784 | 0.7611 | 0.7697 | 0.6719 | 1.0000 | 0.0918 |
| C_backend_portability | mcad_gate | 40 | 320 | 1.0000 | 0.0000 | 0.0000 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 1.0000 | 0.2493 |

## Interpretation

The experimental evaluation treats MCAD-Gate as a contribution-aware control layer. The positive class is the non-contributive query to be intercepted. Therefore, precision_block, recall_block, F1_block, false_allow_rate and false_block_rate are the central detection metrics. The campaign also reports strategic contribution metrics, execution-control metrics, explanation coverage and decision latency.

Campaign A evaluates the core model on FoodMart in MCAD-only mode. Campaign B evaluates multi-dataset generalization. Campaign C evaluates the portability of the ALLOW/BLOCK contract across SQL Direct and XMLA/eMondrian execution paths at the decision-contract level.
