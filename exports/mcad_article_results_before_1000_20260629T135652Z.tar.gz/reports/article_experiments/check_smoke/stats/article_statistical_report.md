# MCAD-Gate paired statistical analysis

Generated at: `2026-06-26T18:02:23+00:00`
Input run: `/workspaces/MCAD_improve3/reports/article_experiments/check_smoke`
Bootstrap resamples: `50`

## Paired comparison summary

| campaign | baseline | paired_traces | coverage_preservation_ratio_mean | coverage_preservation_ratio_ci95_low | coverage_preservation_ratio_ci95_high | coverage_gain_mean | execution_reduction_ratio_mean | non_contrib_execution_reduction_ratio_mean | false_allow_reduction_ratio_mean | false_block_diff_mean | cohens_dz_phi_diff | sign_test_pvalue_phi_diff |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A_core_foodmart_mcad_gate | naive | 10 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 0.7100 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 1.0000 |
| A_core_foodmart_mcad_gate | measure_overlap | 10 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 0.7025 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 1.0000 |
| A_core_foodmart_mcad_gate | random_matched | 10 | 1.0000 | 1.0000 | 1.0000 | 0.6000 | -0.2000 | 1.0000 | 1.0000 | -1.2000 | 1.5213 | 0.0133 |
| B_multidataset_generalization | naive | 30 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 0.7100 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 1.0000 |
| B_multidataset_generalization | measure_overlap | 30 | 1.0000 | 1.0000 | 1.0000 | 0.0000 | 0.7025 | 1.0000 | 1.0000 | 0.0000 | 0.0000 | 1.0000 |
| B_multidataset_generalization | random_matched | 30 | 1.0000 | 1.0000 | 1.0000 | 0.6500 | 0.0722 | 1.0000 | 1.0000 | -1.3000 | 1.8513 | 0.0000 |

## Interpretation

The analysis compares MCAD-Gate against each baseline on the same analytical traces using `trace_id`. The most important indicators are coverage preservation, execution reduction, non-contributive execution reduction, false-allow reduction, and false-block difference.

A coverage preservation ratio equal to 1 means that MCAD-Gate preserves at least the useful final contribution reached by the baseline. The coverage gain reports whether MCAD-Gate exceeds or falls below the baseline. A high non-contributive execution reduction ratio means that MCAD-Gate avoids useless analytical executions. A false-block difference close to 0 indicates that MCAD-Gate does not sacrifice useful queries.
