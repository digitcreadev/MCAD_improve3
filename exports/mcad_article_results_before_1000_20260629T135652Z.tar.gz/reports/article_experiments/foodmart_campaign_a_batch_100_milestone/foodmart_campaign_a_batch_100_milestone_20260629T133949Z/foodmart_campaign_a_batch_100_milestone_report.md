# FoodMart Campaign A Runtime-Feasible — Batch 100 Milestone

## Status

PASS.

## Source run

`reports/article_experiments/foodmart_campaign_a_batches/foodmart_campaign_a_batch_100_20260629T113653Z`

## Key results

- Campaign: `A_foodmart_deep_runtime_feasible`
- Dataset: `foodmart`
- Sampling: `stratified`
- Raw policy: `none`
- Executed sessions: `100`
- Executed query decisions: `796`
- Session-context match rate: `1.0`
- Mismatches: `0`
- HTTP errors: `0`
- Canonical gate violations: `0`

## Gate/execution contract

- ALLOW decisions: `218`
- ALLOW with business physical execution: `218`
- BLOCK decisions: `578`
- BLOCK with business physical execution: `0`
- BLOCK stopped before business execution: `578`

## Interpretation

This milestone validates the runtime-feasible FoodMart Campaign A library on a stratified batch of 100 sessions. The decision semantics are correct under session context, and the canonical gate contract is fully respected: allowed queries are executed physically, while blocked queries are stopped before final business execution.
