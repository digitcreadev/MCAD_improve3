# FoodMart Campaign A — Smoke Runtime Validation Milestone

## Status

**Milestone status:** PASS

This milestone validates a representative FoodMart Campaign A runtime smoke sample. It does not claim that the full 3000-session Campaign A has already been executed.

## Library

- Scenario templates: 96
- Objectives: 96
- Candidate queries: 1152
- Planned sessions: 3000
- Planned query decisions: 24000
- Planned session length: 4..12, mean=8.0
- Cross-scenario exact duplicate hashes: 0
- Within-scenario redundancy probes: 96

## Runtime smoke sample

- Runtime backend: foodmart
- Sample scenarios: 4
- Executed queries: 28
- Strict decision match: 28 / 28
- Strict decision match rate: 1.0
- Session-context match rate: 1.0
- ALLOW decisions: 8
- BLOCK decisions: 20
- HTTP errors: 0
- Mismatches: 0

## Canonical gate/execution contract

- ALLOW final business executions: 8 / 8
- BLOCK final business executions: 0 / 20
- BLOCK stopped before final business execution: 20 / 20
- Gate contract violations: 0
- BLOCK rows with auxiliary NVAC probe execution: 9

## Interpretation

The final BI/business query gate contract is satisfied. ALLOW queries have final business execution traces; BLOCK queries are blocked before final business execution. NVAC probe executions are auxiliary evidence probes and are reported separately.

## Conclusion

FoodMart Campaign A library is generated, hardened, smoke-tested, and canonically validated on a representative runtime sample. The full 3000-session campaign is not executed yet.
