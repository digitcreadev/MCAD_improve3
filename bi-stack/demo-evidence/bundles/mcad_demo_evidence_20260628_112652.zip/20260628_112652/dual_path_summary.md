# MCAD V9.4.5a Dual-Path Demo Validation Pack

Generated at: `2026-06-28T11:27:08+0000`
Base URL: `http://127.0.0.1:9000`

## Summary

- Overall status: **PASS**
- Passed steps: **4 / 4**
- Output directory: `/app/demo-evidence/runs/20260628_112652`

## Validation Steps

| Step | Pass | Decision | Reason | Path | Adapter | Physical | Rows | XMLA type | Digest |
|---|---:|---|---|---|---|---:|---:|---|---|
| FoodMart XMLA/eMondrian Q1 ALLOW | ✅ | ALLOW | ALLOW_NEW_TOTAL | xmla_mondrian | xmla_mondrian | True | 12 | ExecuteResponse | 71845b58dee1560f… |
| FoodMart Direct BI Q1 ALLOW | ✅ | ALLOW | ALLOW_NEW_TOTAL | sql_direct | foodmart_direct | True | 12 | — | d1c9f7ebd23d62c0… |
| MCAD BLOCK no physical execution | ✅ | BLOCK | BLOCK_OUT_OF_OBJECTIVE_SCOPE | — | — | False | — | — | — |
| Scenario/DW compatibility guard | ✅ | BLOCK | HTTP_REJECTED_DISABLED_OR_INCOMPATIBLE_DW | not_executed | — | False | — | — | sha256:d1b90d253f6635929… |

## Interpretation

This pack is intended for the live BI demonstrator, not for replacing the article reproducibility campaign.
It proves that the same MCAD objective can gate two selectable physical execution paths: XMLA/eMondrian and Direct BI.
For BLOCK cases, `physical_execution=false` is expected and confirms that MCAD prevents physical execution.
