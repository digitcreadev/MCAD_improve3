# MCAD policy benchmark report

- Scenario config: `backend/harness/scenarios.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.333**
- MCAD mean AUC φ(t): **0.211**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.215 / 0.406 / 1.370**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.333333|0.211111|0.1|0.0|0.1|0.2282|0.494084|0.761183|
|ablation_no_real|0.333333|0.211111|0.1|0.0|0.1|0.2296|0.409337|0.619434|
|ablation_no_sat|0.333333|0.211111|0.0|0.0|0.0|0.27145|0.378987|0.583136|
|baseline_measure_overlap|0.333333|0.211111|0.566667|0.0|0.566667|0.017|0.028615|0.03031|
|baseline_naive|0.333333|0.211111|0.666667|0.0|0.666667|0.0012|0.002017|0.002234|
|baseline_random_matched|0.18|0.106667|0.453333|0.153333|0.453333|0.00325|0.004855|0.113772|
|mcad|0.333333|0.211111|0.0|0.0|0.0|0.2155|0.406435|1.370135|