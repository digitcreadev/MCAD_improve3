import { Route, Routes, Navigate } from "react-router-dom";
import AppLayout from "./components/layout/AppLayout";
import ObjectiveManagerPage from "./pages/ObjectiveManagerPage";
import SessionMdxLabPage from "./pages/SessionMdxLabPage";
import CkgExplorerPage from "./pages/CkgExplorerPage";
import PerformanceDashboardPage from "./pages/PerformanceDashboardPage";

function App() {
  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/objectives" replace />} />
        <Route path="/objectives" element={<ObjectiveManagerPage />} />
        <Route path="/sessions" element={<SessionMdxLabPage />} />
        <Route path="/ckg" element={<CkgExplorerPage />} />
        <Route path="/analytics" element={<PerformanceDashboardPage />} />
      </Routes>
    </AppLayout>
  );
}

export default App;
