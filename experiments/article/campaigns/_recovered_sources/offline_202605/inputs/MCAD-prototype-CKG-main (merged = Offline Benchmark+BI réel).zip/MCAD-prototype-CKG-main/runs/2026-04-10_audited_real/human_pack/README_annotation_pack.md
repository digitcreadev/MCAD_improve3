# Human validation annotation pack

This pack was generated from the MCAD scenario harness.

Contents:
- `annotation_items.csv`: file to send to annotators.
- `annotation_items.jsonl`: JSONL version with the same items.
- `adjudication_template.csv`: file to consolidate disagreements.

Summary:
- Items: 30
- Datasets: ADVENTUREWORKS, FOODMART
- Objectives: OAW_BIKES_EUROPE, OHF_NORD
- Blind oracle hidden: no

Recommended protocol:
1. Give `annotation_items.csv` to at least 2 annotators.
2. Ask them to label `label_allow` as 1 or 0.
3. If `label_allow=1`, ask them to fill `label_ceval` with the calculable constraints separated by `|`.
4. Consolidate disagreements in `adjudication_template.csv`.
5. Score agreement and system-vs-human metrics with `score_human_validation.py`.
