# MCAD multi-dataset benchmark report

## Configurations

- `backend/harness/scenarios.yaml`
- `/workspaces/MCAD_UP/backend/harness/scenarios_adventureworks.yaml`

## Aggregate summary across datasets

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|
|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.296296|0.191358|0.111111|0.0|0.111111|
|ablation_no_real|0.296296|0.191358|0.111111|0.0|0.111111|
|ablation_no_sat|0.296296|0.191358|0.0|0.0|0.0|
|baseline_measure_overlap|0.296296|0.191358|0.592593|0.0|0.592593|
|baseline_naive|0.296296|0.191358|0.703704|0.0|0.703704|
|baseline_random_matched|0.151852|0.093827|0.418519|0.144444|0.418519|
|mcad|0.296296|0.191358|0.0|0.0|0.0|

## By dataset and policy

|dw_id|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|
|---|---|---|---|---|---|---|
|ADVENTUREWORKS|ablation_ceval_any_intersection|0.25|0.166667|0.125|0.0|0.125|
|ADVENTUREWORKS|ablation_no_real|0.25|0.166667|0.125|0.0|0.125|
|ADVENTUREWORKS|ablation_no_sat|0.25|0.166667|0.0|0.0|0.0|
|ADVENTUREWORKS|baseline_measure_overlap|0.25|0.166667|0.625|0.0|0.625|
|ADVENTUREWORKS|baseline_naive|0.25|0.166667|0.75|0.0|0.75|
|ADVENTUREWORKS|baseline_random_matched|0.116667|0.077778|0.375|0.133333|0.375|
|ADVENTUREWORKS|mcad|0.25|0.166667|0.0|0.0|0.0|
|FOODMART|ablation_ceval_any_intersection|0.333333|0.211111|0.1|0.0|0.1|
|FOODMART|ablation_no_real|0.333333|0.211111|0.1|0.0|0.1|
|FOODMART|ablation_no_sat|0.333333|0.211111|0.0|0.0|0.0|
|FOODMART|baseline_measure_overlap|0.333333|0.211111|0.566667|0.0|0.566667|
|FOODMART|baseline_naive|0.333333|0.211111|0.666667|0.0|0.666667|
|FOODMART|baseline_random_matched|0.18|0.106667|0.453333|0.153333|0.453333|
|FOODMART|mcad|0.333333|0.211111|0.0|0.0|0.0|