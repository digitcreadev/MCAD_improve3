import type { ObjectivePerformanceResponse } from "../../api/types";

interface PhiCurveChartProps {
  performance: ObjectivePerformanceResponse | null;
}

const COLORS = ["#0f766e", "#f97316", "#1d4ed8", "#a855f7", "#dc2626"];

function PhiCurveChart({ performance }: PhiCurveChartProps) {
  if (!performance || !performance.phiCurves.length) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Aucune courbe φ≤t(O) disponible pour l&apos;instant.
      </div>
    );
  }

  const { phiCurves, sessionIds } = performance;
  const width = 360;
  const height = 180;
  const padding = 28;

  const maxT =
    phiCurves.length > 0
      ? Math.max(...phiCurves.map((r) => (r.t ?? 0))) || 1
      : 1;

  const xForT = (t: number) => {
    if (maxT <= 1) return padding;
    return padding + ((width - 2 * padding) * (t - 1)) / (maxT - 1);
  };

  const yForPhi = (phi: number) => {
    const clamped = Math.max(0, Math.min(1, phi));
    return height - padding - (height - 2 * padding) * clamped;
  };

  return (
    <div className="mcad-card">
      <h3 className="mcad-section-title mb-2">Courbes φ≤t(O) par session</h3>
      <div className="flex gap-4 items-start">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full max-w-md border border-slate-100 rounded-xl bg-white"
        >
          {/* Axe X */}
          <line
            x1={padding}
            y1={height - padding}
            x2={width - padding}
            y2={height - padding}
            stroke="#cbd5f5"
            strokeWidth={1}
          />
          {/* Axe Y */}
          <line
            x1={padding}
            y1={padding}
            x2={padding}
            y2={height - padding}
            stroke="#cbd5f5"
            strokeWidth={1}
          />

          {/* graduation φ=0 et φ=1 */}
          {[0, 0.5, 1].map((phi) => (
            <g key={phi}>
              <line
                x1={padding}
                y1={yForPhi(phi)}
                x2={width - padding}
                y2={yForPhi(phi)}
                stroke="#e5e7eb"
                strokeWidth={0.5}
                strokeDasharray="2,2"
              />
              <text
                x={padding - 6}
                y={yForPhi(phi) + 3}
                textAnchor="end"
                fontSize={9}
                fill="#6b7280"
              >
                {phi.toFixed(1)}
              </text>
            </g>
          ))}

          {/* ticks t */}
          phiCurves.forEach
          {phiCurves.map((row) => (
            <g key={row.t}>
              <line
                x1={xForT(row.t)}
                y1={height - padding}
                x2={xForT(row.t)}
                y2={height - padding + 4}
                stroke="#9ca3af"
                strokeWidth={0.5}
              />
              <text
                x={xForT(row.t)}
                y={height - padding + 12}
                textAnchor="middle"
                fontSize={9}
                fill="#6b7280"
              >
                {row.t}
              </text>
            </g>
          ))}

          {/* courbes */}
          {sessionIds.map((sid, idx) => {
            const color = COLORS[idx % COLORS.length];
            const path = phiCurves
              .map((row, i) => {
                const t = row.t;
                const v = (row as any)[sid] ?? 0;
                const x = xForT(t);
                const y = yForPhi(v);
                return `${i === 0 ? "M" : "L"} ${x} ${y}`;
              })
              .join(" ");
            return (
              <path
                key={sid}
                d={path}
                fill="none"
                stroke={color}
                strokeWidth={2}
              />
            );
          })}
        </svg>

        <div className="flex flex-col gap-1 text-xs">
          <p className="text-[11px] text-slate-500 mb-1">
            Chaque courbe correspond à une session d&apos;analyse. La valeur
            φ≤t(O) agrège la contribution cumulative des requêtes successives
            vers l&apos;objectif stratégique.
          </p>
          <div className="space-y-1">
            {performance.sessionIds.map((sid, idx) => {
              const color = COLORS[idx % COLORS.length];
              return (
                <div key={sid} className="flex items-center gap-2">
                  <span
                    className="h-2 w-4 rounded-full"
                    style={{ backgroundColor: color }}
                  />
                  <span className="text-[11px] text-slate-600">
                    {sid} (session {idx + 1})
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default PhiCurveChart;
