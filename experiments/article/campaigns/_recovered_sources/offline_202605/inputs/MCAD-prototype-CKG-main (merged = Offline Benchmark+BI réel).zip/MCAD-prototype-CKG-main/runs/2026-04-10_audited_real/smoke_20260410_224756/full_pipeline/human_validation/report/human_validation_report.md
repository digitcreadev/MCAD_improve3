# Human validation report

- Reference items: 30
- Annotators: 0
- Note: no human annotation CSV was provided; the scenario oracle was used as a dry-run reference only.

## System vs reference

- mcad: F1=1.0, accuracy=1.0, ceval_exact_match=1.0, ceval_avg_jaccard=1.0
- baseline_naive: F1=0.695652, accuracy=0.533333, ceval_exact_match=0.466667, ceval_avg_jaccard=0.466667
- baseline_measure_overlap: F1=0.727273, accuracy=0.6, ceval_exact_match=0.466667, ceval_avg_jaccard=0.466667
