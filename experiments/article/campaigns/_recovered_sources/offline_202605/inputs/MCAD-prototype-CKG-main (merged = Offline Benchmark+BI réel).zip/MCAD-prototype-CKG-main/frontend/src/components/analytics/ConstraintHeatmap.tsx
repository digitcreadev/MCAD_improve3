import type { ObjectivePerformanceResponse } from "../../api/types";

interface ConstraintHeatmapProps {
  performance: ObjectivePerformanceResponse | null;
}

function valueToColor(v: number): string {
  const clamped = Math.max(0, Math.min(1, v));
  const r = 239 - Math.round(80 * clamped);
  const g = 246 - Math.round(150 * clamped);
  const b = 255 - Math.round(120 * clamped);
  return `rgb(${r}, ${g}, ${b})`;
}

function ConstraintHeatmap({ performance }: ConstraintHeatmapProps) {
  if (
    !performance ||
    !performance.constraintIds.length ||
    !performance.sessionIds.length
  ) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Aucune heatmap disponible pour l&apos;instant.
      </div>
    );
  }

  const { constraintIds, sessionIds, constraintCoverageHeatmap } = performance;
  const cellMap = new Map<string, number>();
  constraintCoverageHeatmap.forEach((cell) => {
    const key = `${cell.constraintId}::${cell.sessionId}`;
    cellMap.set(key, cell.value);
  });

  return (
    <div className="mcad-card">
      <h3 className="mcad-section-title mb-2">
        Heatmap de couverture des contraintes (précocité)
      </h3>
      <div className="text-[11px] text-slate-500 mb-2">
        Les cases les plus foncées correspondent aux contraintes couvertes
        précocement dans la session (valeur proche de 1). Les cases claires ou
        blanches signalent des contraintes couvertes tardivement ou jamais.
      </div>
      <div className="overflow-auto">
        <table className="min-w-max border border-slate-200 text-[11px]">
          <thead>
            <tr className="bg-slate-50">
              <th className="border border-slate-200 px-2 py-1 text-left">
                Contrainte \ Session
              </th>
              {sessionIds.map((sid) => (
                <th
                  key={sid}
                  className="border border-slate-200 px-2 py-1 text-center"
                  title={sid}
                >
                  {sid}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {constraintIds.map((cid) => (
              <tr key={cid}>
                <td className="border border-slate-200 px-2 py-1 text-left">
                  {cid}
                </td>
                {sessionIds.map((sid) => {
                  const key = `${cid}::${sid}`;
                  const v = cellMap.get(key) ?? 0;
                  const color = valueToColor(v);
                  return (
                    <td
                      key={sid}
                      className="border border-slate-200 px-1 py-1 text-center"
                      style={{
                        backgroundColor: color
                      }}
                      title={`${cid} / ${sid} : ${v.toFixed(2)}`}
                    >
                      {v > 0 ? v.toFixed(2) : ""}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ConstraintHeatmap;
