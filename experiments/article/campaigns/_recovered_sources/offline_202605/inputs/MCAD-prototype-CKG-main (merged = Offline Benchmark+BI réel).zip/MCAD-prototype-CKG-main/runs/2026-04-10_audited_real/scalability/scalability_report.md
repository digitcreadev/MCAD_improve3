# MCAD scalability and CKG growth-control report

## Catalog scalability summary

|scale_factor|n_objectives|n_constraints|n_virtual_nodes|n_nodes|n_edges|p50_eval_ms|p95_eval_ms|p99_eval_ms|snapshot_ms|snapshot_bytes|peak_total_kib|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1|2|6|8|48|60|1.141743|1.512982|1.722833|8.143871|39489|193.776|
|5|10|30|40|216|300|1.159582|2.054499|7.415796|41.476903|199793|592.438|
|10|20|60|80|426|600|1.163019|2.67473|5.370709|74.550941|401113|1109.4|
|20|40|120|160|846|1200|1.142923|1.528044|2.248172|148.648861|802813|2176.195|
|40|80|240|320|1686|2400|1.173421|1.573016|2.697612|306.359963|1606213|4316.122|

## Runtime growth control (keep-last = 8 query-plan nodes)

|mode|step_idx|n_nodes|n_edges|history_len|removed_qp_nodes|eval_ms|
|---|---|---|---|---|---|---|
|no_compaction|1|648|803|0|0|0.360966|
|no_compaction|10|657|817|0|0|0.256241|
|no_compaction|20|667|830|0|0|0.256088|
|no_compaction|30|677|844|0|0|0.354297|
|no_compaction|40|687|857|0|0|0.257139|
|no_compaction|50|697|870|0|0|0.253868|
|no_compaction|60|707|884|0|0|0.343115|
|no_compaction|70|717|897|0|0|0.256807|
|no_compaction|80|727|910|0|0|0.25365|
|no_compaction|90|737|924|0|0|0.336108|
|no_compaction|100|747|937|0|0|0.267213|
|no_compaction|110|757|950|0|0|0.263418|
|no_compaction|120|767|964|0|0|0.344028|
|keep_last|1|648|803|0|0|0.374071|
|keep_last|10|655|815|0|1|0.266796|
|keep_last|20|655|814|0|1|0.26499|
|keep_last|30|655|815|0|1|0.344816|
|keep_last|40|655|815|0|1|0.271009|
|keep_last|50|655|814|0|1|0.252925|
|keep_last|60|655|815|0|1|0.351884|
|keep_last|70|655|815|0|1|0.259784|
|keep_last|80|655|814|0|1|0.265017|
|keep_last|90|655|815|0|1|0.346089|
|keep_last|100|655|815|0|1|0.265912|
|keep_last|110|655|814|0|1|0.257981|
|keep_last|120|655|815|0|1|0.351831|