import { ReactNode } from "react";
import NavBar from "./NavBar";
import SideNav from "./SideNav";

interface AppLayoutProps {
  children: ReactNode;
}

function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="h-screen flex flex-col">
      <NavBar />
      <div className="flex flex-1 overflow-hidden">
        <SideNav />
        <main className="flex-1 overflow-auto bg-slate-50">
          <div className="max-w-6xl mx-auto py-6 px-4 space-y-4">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export default AppLayout;
