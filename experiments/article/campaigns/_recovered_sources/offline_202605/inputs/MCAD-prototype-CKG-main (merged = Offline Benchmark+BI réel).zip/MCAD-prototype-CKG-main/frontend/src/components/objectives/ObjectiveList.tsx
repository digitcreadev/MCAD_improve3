import type { Objective } from "../../api/types";
import { Plus, Copy } from "lucide-react";

interface ObjectiveListProps {
  objectives: Objective[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onCreate: () => void;
  onClone: (id: string) => void;
}

function ObjectiveList({
  objectives,
  selectedId,
  onSelect,
  onCreate,
  onClone
}: ObjectiveListProps) {
  return (
    <div className="mcad-card h-full flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="mcad-section-title">Objectifs</h3>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCreate}
            className="inline-flex items-center gap-1 rounded-full bg-slate-900 text-white px-3 py-1 text-xs shadow-sm hover:bg-black"
          >
            <Plus className="h-3 w-3" />
            Nouveau
          </button>
        </div>
      </div>
      <div className="space-y-1 max-h-[480px] overflow-auto pr-1">
        {objectives.map((obj) => {
          const active = obj.id === selectedId;
          return (
            <div
              key={obj.id}
              className={`rounded-xl border px-3 py-2 text-xs cursor-pointer flex items-start justify-between gap-2 transition-colors ${
                active
                  ? "border-mcad-primary bg-mcad-primary-soft"
                  : "border-slate-200 bg-white hover:bg-slate-50"
              }`}
              onClick={() => onSelect(obj.id)}
            >
              <div>
                <div className="font-semibold text-slate-800">{obj.name}</div>
                <div className="text-[11px] text-slate-500">
                  {obj.id} · {obj.kpis.length} KPI · {obj.constraints.length}{" "}
                  contraintes
                </div>
              </div>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onClone(obj.id);
                }}
                className="text-slate-400 hover:text-slate-700"
                title="Dupliquer l'objectif"
              >
                <Copy className="h-3 w-3" />
              </button>
            </div>
          );
        })}

        {objectives.length === 0 && (
          <div className="text-xs text-slate-400">
            Aucun objectif pour le moment. Créez un premier objectif pour
            commencer à modéliser votre MCAD.
          </div>
        )}
      </div>
    </div>
  );
}

export default ObjectiveList;
