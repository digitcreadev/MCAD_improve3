import { useState } from "react";
import type { Constraint, VisualMdxQP } from "../../api/types";
import { Play, RefreshCw } from "lucide-react";

const DIMENSION_LEVELS = [
  "Produit.Catégorie",
  "Produit.Sous-catégorie",
  "Temps.Mois",
  "Temps.Trimestre",
  "Région",
  "Canal"
];

const MEASURES = ["Marge %", "Rupture %", "Volume", "CA"];

interface MdxVisualBuilderProps {
  objectiveId: string | null;
  sessionId: string | null;
  constraints: Constraint[];
  loading: boolean;
  onEvaluate: (qp: VisualMdxQP) => Promise<void> | void;
}

function MdxVisualBuilder({
  objectiveId,
  sessionId,
  constraints,
  loading,
  onEvaluate
}: MdxVisualBuilderProps) {
  const [cube, setCube] = useState("Sales");
  const [rows, setRows] = useState<string[]>(["Produit.Catégorie"]);
  const [columns, setColumns] = useState<string[]>(["Temps.Mois"]);
  const [filters, setFilters] = useState<string[]>(["Région=Nord", "Année=1998"]);
  const [measures, setMeasures] = useState<string[]>(["Marge %"]);
  const [forceSat, setForceSat] = useState<boolean>(true);
  const [targetConstraints, setTargetConstraints] = useState<string[]>(
    constraints.map((c) => c.id)
  );
  const [mdxHint, setMdxHint] = useState<string>(
    "SELECT {[Measures].[Marge %]} ON COLUMNS,\n" +
      "       {[Produit].[Catégorie].Members} ON ROWS\n" +
      "FROM [Sales]\n" +
      "WHERE ([Région].[Nord], [Temps].[1998])"
  );
  const [stepName, setStepName] = useState<string>("Q1_overview_margin");
  const [stepDescription, setStepDescription] = useState<string>(
    "Vue initiale de la marge par catégorie et mois, région Nord, année 1998."
  );

  const toggleItem = (value: string, array: string[], setFn: (v: string[]) => void) => {
    if (array.includes(value)) {
      setFn(array.filter((x) => x !== value));
    } else {
      setFn([...array, value]);
    }
  };

  const toggleConstraint = (id: string) => {
    toggleItem(id, targetConstraints, setTargetConstraints);
  };

  const handleEvaluate = async () => {
    if (!objectiveId || !sessionId) {
      return;
    }
    const qp: VisualMdxQP = {
      cube,
      rows,
      columns,
      filters,
      measures,
      force_sat: forceSat,
      target_constraints: targetConstraints,
      mdx_hint: mdxHint,
      step_name: stepName,
      step_description: stepDescription
    };
    await onEvaluate(qp);
  };

  const handleReset = () => {
    setRows(["Produit.Catégorie"]);
    setColumns(["Temps.Mois"]);
    setFilters(["Région=Nord", "Année=1998"]);
    setMeasures(["Marge %"]);
    setForceSat(true);
    setTargetConstraints(constraints.map((c) => c.id));
  };

  const disabled = !objectiveId || !sessionId || loading;

  return (
    <div className="mcad-card flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="mcad-section-title">Builder de requêtes MDX (visuel)</h3>
          <p className="text-[11px] text-slate-500">
            Construis le plan QP de la requête : dimensions, mesures, indications
            MCAD (force_sat, target_constraints, mdx_hint).
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-1 rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 hover:bg-slate-100"
          >
            <RefreshCw className="h-3 w-3" />
            Réinitialiser
          </button>
          <button
            type="button"
            onClick={handleEvaluate}
            disabled={disabled}
            className="inline-flex items-center gap-1 rounded-full bg-mcad-primary text-white px-3 py-1 text-xs shadow-sm hover:bg-emerald-800 disabled:opacity-60"
          >
            <Play className="h-3 w-3" />
            {loading ? "Évaluation…" : "Évaluer QP"}
          </button>
        </div>
      </div>

      {!sessionId && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] text-amber-800">
          Crée ou sélectionne une session à gauche avant d&apos;évaluer une
          requête.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="space-y-3">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Cube
            </label>
            <input
              type="text"
              value={cube}
              onChange={(e) => setCube(e.target.value)}
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Dimensions – Lignes
            </label>
            <div className="flex flex-wrap gap-1">
              {DIMENSION_LEVELS.map((d) => {
                const active = rows.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => toggleItem(d, rows, setRows)}
                    className={`mcad-chip ${
                      active
                        ? "bg-mcad-primary text-white border-mcad-primary"
                        : ""
                    }`}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Dimensions – Colonnes
            </label>
            <div className="flex flex-wrap gap-1">
              {DIMENSION_LEVELS.map((d) => {
                const active = columns.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => toggleItem(d, columns, setColumns)}
                    className={`mcad-chip ${
                      active
                        ? "bg-mcad-primary text-white border-mcad-primary"
                        : ""
                    }`}
                  >
                    {d}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Filtres (slicers)
            </label>
            <input
              type="text"
              value={filters.join(", ")}
              onChange={(e) =>
                setFilters(
                  e.target.value
                    .split(",")
                    .map((x) => x.trim())
                    .filter(Boolean)
                )
              }
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
              placeholder="Région=Nord, Année=1998"
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Mesures
            </label>
            <div className="flex flex-wrap gap-1">
              {MEASURES.map((m) => {
                const active = measures.includes(m);
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => toggleItem(m, measures, setMeasures)}
                    className={`mcad-chip ${
                      active
                        ? "bg-mcad-primary text-white border-mcad-primary"
                        : ""
                    }`}
                  >
                    {m}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Contraintes ciblées (target_constraints)
            </label>
            <div className="flex flex-wrap gap-1">
              {constraints.map((c) => {
                const active = targetConstraints.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => toggleConstraint(c.id)}
                    className={`mcad-chip ${
                      active
                        ? "bg-mcad-primary text-white border-mcad-primary"
                        : ""
                    }`}
                    title={c.description}
                  >
                    {c.id}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <label className="inline-flex items-center gap-2">
              <input
                type="checkbox"
                checked={forceSat}
                onChange={(e) => setForceSat(e.target.checked)}
                className="rounded border-slate-300 text-mcad-primary focus:ring-mcad-primary"
              />
            </label>
            <span className="text-slate-600">
              Forcer SAT(QP) (force_sat) – utile pour rejouer les scénarios
              « happy / border / adversarial »
            </span>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Identifiant de la requête (step_name)
            </label>
            <input
              type="text"
              value={stepName}
              onChange={(e) => setStepName(e.target.value)}
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-medium text-slate-600">
              Description courte de la requête
            </label>
            <input
              type="text"
              value={stepDescription}
              onChange={(e) => setStepDescription(e.target.value)}
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
            />
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-1">
        <label className="text-[11px] font-medium text-slate-600">
          mdx_hint (facultatif)
        </label>
        <textarea
          value={mdxHint}
          onChange={(e) => setMdxHint(e.target.value)}
          className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary resize-none h-24 font-mono"
        />
      </div>
    </div>
  );
}

export default MdxVisualBuilder;
