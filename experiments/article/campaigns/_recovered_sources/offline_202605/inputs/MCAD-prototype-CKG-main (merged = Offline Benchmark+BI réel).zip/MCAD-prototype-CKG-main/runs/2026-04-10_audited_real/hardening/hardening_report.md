# Phase 9 hardening report

- health_ok: `True`
- decision audit rows: `2`
- contract versions: `mcad.decision.contract.v1`
- config sources match: `True`
- replay supported: `True`
- replay exact match: `True`
- explainability reasons coverage on BLOCK cases: `1`

## Audit stats

```json
{
  "n_records": 2,
  "by_decision": {
    "ALLOW": 1,
    "BLOCK": 1
  },
  "contract_versions": {
    "mcad.decision.contract.v1": 2
  },
  "engine_versions": {
    "mcad-phase9": 2
  },
  "with_retained_evidence": 1,
  "with_decision_reasons": 2,
  "records_path": "runs/2026-04-10_audited_real/hardening/decision_audit/records.jsonl"
}
```

## Governance excerpt

```json
{
  "n_records": 1,
  "n_replay_ready": 1,
  "n_duplicate_groups": 0,
  "latest_engine_versions": [
    "mcad-phase9"
  ]
}
```