# MCAD Prototype — Codex Instructions

## Goal
Align the implementation with the MCAD paper:
- Intercept MDX (XMLA Execute)
- Compute SAT/Real/Ceval/phi using the **real backend engine**
- Execute only if contributive
- Update CKG from execution results (real updater)
- Keep Pivot4J UI working (Discover must pass through)

## Hard constraints
- DO NOT invent heuristics for SAT/Real/Ceval/phi.
- Use these modules for real logic:
  - backend/mcad/engine.py
  - backend/mcad/objectives.py + objectives.yaml
  - backend/ckg/ckg_updater.py
- Proxy must forward Discover requests unchanged; MCAD gating applies to Execute only.
- Preserve existing harness scripts in backend/harness/ unless explicitly asked.
- Changes must be minimal and incremental; avoid sweeping refactors.

## Architecture target
Pivot4J -> XMLA driver -> mcad-proxy (/xmla) -> (eval) mcad-api (/eval) -> eMondrian (/emondrian/xmla)
If ALLOW:
  mcad-proxy forwards to eMondrian, then calls mcad-api (/ckg/update) to persist results.
If BLOCK:
  mcad-proxy returns a SOAP Fault.

## Commands to validate (must run)
- docker compose up -d --build
- docker compose ps
- docker compose logs --tail=200 mcad-proxy mcad-api pivot4j emondrian
- From Pivot4J UI: run 2 MDX queries; ensure results render.
- Ensure mcad-proxy logs show:
  - MDX extracted for Execute
  - Decision ALLOW/BLOCK
  - CKG update called after ALLOW

## Deliverables
1) A short mapping doc: paper concepts -> code locations.
2) Patched files + docker-compose.yml.
3) A runbook (for dummies) to reproduce end-to-end.