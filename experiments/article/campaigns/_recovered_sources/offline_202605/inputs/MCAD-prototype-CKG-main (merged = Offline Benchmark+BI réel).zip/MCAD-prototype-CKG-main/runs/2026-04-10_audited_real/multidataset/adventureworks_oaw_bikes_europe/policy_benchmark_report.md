# MCAD policy benchmark report

- Scenario config: `backend/harness/scenarios_adventureworks.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.250**
- MCAD mean AUC φ(t): **0.167**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.232 / 0.406 / 0.763**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.25|0.166667|0.125|0.0|0.125|0.23115|0.388192|0.658873|
|ablation_no_real|0.25|0.166667|0.125|0.0|0.125|0.23965|0.412887|0.767375|
|ablation_no_sat|0.25|0.166667|0.0|0.0|0.0|0.2898|0.67862|0.939437|
|baseline_measure_overlap|0.25|0.166667|0.625|0.0|0.625|0.0187|0.0286|0.031114|
|baseline_naive|0.25|0.166667|0.75|0.0|0.75|0.0014|0.0022|0.002304|
|baseline_random_matched|0.151667|0.101111|0.4|0.098333|0.4|0.0037|0.005105|0.006624|
|mcad|0.25|0.166667|0.0|0.0|0.0|0.2316|0.406113|0.763287|