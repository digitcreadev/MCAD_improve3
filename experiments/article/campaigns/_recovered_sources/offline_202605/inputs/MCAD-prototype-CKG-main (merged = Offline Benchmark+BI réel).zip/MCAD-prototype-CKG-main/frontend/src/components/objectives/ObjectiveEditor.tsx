import { useEffect, useMemo, useState } from "react";
import { DndContext, DragEndEvent, DragStartEvent } from "@dnd-kit/core";
import type { Constraint, KpiDefinition, Objective } from "../../api/types";
import KpiPalette from "./KpiPalette";
import ObjectiveKpiDropZone from "./ObjectiveKpiDropZone";
import ConstraintEditor from "./ConstraintEditor";
import { RotateCcw, Save } from "lucide-react";

interface ObjectiveEditorProps {
  objective: Objective | null;
  baseKpiCatalog: KpiDefinition[];
  onSave: (objective: Objective) => Promise<void> | void;
}

function ObjectiveEditor({
  objective,
  baseKpiCatalog,
  onSave
}: ObjectiveEditorProps) {
  const [draft, setDraft] = useState<Objective | null>(objective);
  const [activeKpiId, setActiveKpiId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setDraft(objective);
  }, [objective]);

  const effectiveKpiCatalog = useMemo<KpiDefinition[]>(() => {
    const catalogMap = new Map<string, KpiDefinition>();
    baseKpiCatalog.forEach((k) => catalogMap.set(k.id, k));

    if (draft) {
      draft.kpis.forEach((id) => {
        if (!catalogMap.has(id)) {
          catalogMap.set(id, { id, label: id });
        }
      });
    }
    return Array.from(catalogMap.values());
  }, [baseKpiCatalog, draft]);

  if (!draft) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Sélectionnez un objectif à gauche pour l&apos;éditer, ou créez-en un
        nouveau.
      </div>
    );
  }

  const handleFieldChange = (
    field: keyof Objective,
    value: string | string[] | Constraint[]
  ) => {
    setDraft((prev) => (prev ? { ...prev, [field]: value } : prev));
  };

  const handleConstraintsChange = (constraints: Constraint[]) => {
    handleFieldChange("constraints", constraints);
  };

  const handleAddKpi = (kpiId: string) => {
    setDraft((prev) => {
      if (!prev) return prev;
      if (prev.kpis.includes(kpiId)) return prev;
      return { ...prev, kpis: [...prev.kpis, kpiId] };
    });
  };

  const handleRemoveKpi = (kpiId: string) => {
    setDraft((prev) => {
      if (!prev) return prev;
      return { ...prev, kpis: prev.kpis.filter((id) => id !== kpiId) };
    });
    setDraft((prev) => {
      if (!prev) return prev;
      const filteredConstraints = prev.constraints.filter(
        (c) => c.kpi_id !== kpiId
      );
      return { ...prev, constraints: filteredConstraints };
    });
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveKpiId(String(event.active.id));
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { over, active } = event;
    if (over && over.id === "objective-kpi-dropzone") {
      handleAddKpi(String(active.id));
    }
    setActiveKpiId(null);
  };

  const handleReset = () => {
    setDraft(objective);
  };

  const handleSaveClick = async () => {
    if (!draft) return;
    setIsSaving(true);
    try {
      await onSave(draft);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="mcad-card flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">
              Édition de l&apos;objectif
            </h2>
            <p className="text-xs text-slate-500">
              Aligné avec la définition formelle du modèle MCAD dans l&apos;article.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1 rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 hover:bg-slate-100"
            >
              <RotateCcw className="h-3 w-3" />
              Réinitialiser
            </button>
            <button
              type="button"
              onClick={handleSaveClick}
              disabled={isSaving}
              className="inline-flex items-center gap-1 rounded-full bg-mcad-primary text-white px-3 py-1 text-xs shadow-sm hover:bg-emerald-800 disabled:opacity-60"
            >
              <Save className="h-3 w-3" />
              {isSaving ? "Enregistrement…" : "Enregistrer"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-medium text-slate-600">
              Nom de l&apos;objectif
            </label>
            <input
              type="text"
              className="rounded-md border border-slate-200 bg-white px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-mcad-primary"
              value={draft.name}
              onChange={(e) => handleFieldChange("name", e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-[11px] font-medium text-slate-600">
              Identifiant technique
            </label>
            <input
              type="text"
              className="rounded-md border border-slate-200 bg-slate-100 px-2 py-1 text-sm text-slate-500"
              value={draft.id}
              readOnly
            />
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <label className="text-[11px] font-medium text-slate-600">
            Description
          </label>
          <textarea
            className="rounded-md border border-slate-200 bg-white px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-mcad-primary resize-none h-20"
            value={draft.description}
            onChange={(e) => handleFieldChange("description", e.target.value)}
          />
        </div>
      </div>

      <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-stretch">
          <div className="lg:col-span-1 h-72">
            <KpiPalette
              kpis={effectiveKpiCatalog}
              onAddClick={handleAddKpi}
            />
          </div>
          <div className="lg:col-span-2 h-72">
            <ObjectiveKpiDropZone
              selectedKpiIds={draft.kpis}
              allKpis={effectiveKpiCatalog}
              onRemoveKpi={handleRemoveKpi}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          <ConstraintEditor
            constraints={draft.constraints}
            kpiDefs={effectiveKpiCatalog}
            onChange={handleConstraintsChange}
          />
        </div>
      </DndContext>

      {activeKpiId && (
        <p className="text-[11px] text-slate-400">
          KPI en cours de glisser-déposer : <strong>{activeKpiId}</strong>
        </p>
      )}
    </div>
  );
}

export default ObjectiveEditor;
