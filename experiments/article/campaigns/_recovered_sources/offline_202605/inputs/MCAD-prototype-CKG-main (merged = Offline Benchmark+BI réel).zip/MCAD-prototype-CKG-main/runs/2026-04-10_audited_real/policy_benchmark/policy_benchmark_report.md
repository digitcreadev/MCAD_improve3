# MCAD policy benchmark report

- Scenario config: `backend/harness/scenarios.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.333**
- MCAD mean AUC φ(t): **0.211**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.224 / 0.385 / 0.649**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.333333|0.211111|0.1|0.0|0.1|0.2191|0.41571|0.653531|
|ablation_no_real|0.333333|0.211111|0.1|0.0|0.1|0.2292|0.41398|0.738001|
|ablation_no_sat|0.333333|0.211111|0.0|0.0|0.0|0.2764|0.448997|0.667414|
|baseline_measure_overlap|0.333333|0.211111|0.566667|0.0|0.566667|0.0164|0.025043|0.0293|
|baseline_naive|0.333333|0.211111|0.666667|0.0|0.666667|0.0011|0.0019|0.002401|
|baseline_random_matched|0.190667|0.121333|0.400667|0.142667|0.427667|0.0033|0.0049|0.006296|
|mcad|0.333333|0.211111|0.0|0.0|0.0|0.2237|0.385239|0.648675|