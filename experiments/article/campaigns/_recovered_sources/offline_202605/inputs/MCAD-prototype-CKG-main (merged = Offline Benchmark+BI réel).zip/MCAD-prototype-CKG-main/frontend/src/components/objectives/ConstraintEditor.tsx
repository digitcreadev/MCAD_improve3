import type { Constraint, KpiDefinition } from "../../api/types";
import { Plus, Trash2 } from "lucide-react";
import { ChangeEvent } from "react";

interface ConstraintEditorProps {
  constraints: Constraint[];
  kpiDefs: KpiDefinition[];
  onChange: (constraints: Constraint[]) => void;
}

function ConstraintEditor({
  constraints,
  kpiDefs,
  onChange
}: ConstraintEditorProps) {
  const handleFieldChange = (
    idx: number,
    field: keyof Constraint,
    value: any
  ) => {
    const next = constraints.map((c, i) =>
      i === idx ? { ...c, [field]: value } : c
    );
    onChange(next);
  };

  const handleWeightChange = (idx: number, e: ChangeEvent<HTMLInputElement>) => {
    const v = parseFloat(e.target.value);
    const weight = Number.isNaN(v) ? 0 : v;
    handleFieldChange(idx, "weight", weight);
  };

  const handleAddConstraint = () => {
    const newId = `c_${constraints.length + 1}_${Date.now()}`;
    const next: Constraint[] = [
      ...constraints,
      {
        id: newId,
        kpi_id: kpiDefs[0]?.id || "",
        description: "",
        weight: 1.0,
        virtual_nodes: []
      }
    ];
    onChange(next);
  };

  const handleDeleteConstraint = (idx: number) => {
    const next = constraints.filter((_, i) => i !== idx);
    onChange(next);
  };

  return (
    <div className="mcad-card flex flex-col gap-2">
      <div className="flex items-center justify-between mb-1">
        <h3 className="mcad-section-title">Contraintes</h3>
        <button
          type="button"
          onClick={handleAddConstraint}
          className="inline-flex items-center gap-1 rounded-full bg-mcad-primary text-white px-3 py-1 text-xs shadow-sm hover:bg-emerald-800"
        >
          <Plus className="h-3 w-3" />
          Ajouter une contrainte
        </button>
      </div>

      {constraints.length === 0 && (
        <div className="text-xs text-slate-400">
          Aucune contrainte définie. Ajoutez-en au moins une pour exprimer
          l&apos;objectif stratégique.
        </div>
      )}

      <div className="space-y-3 max-h-80 overflow-auto pr-1">
        {constraints.map((c, idx) => (
          <div
            key={c.id}
            className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2"
          >
            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                className="flex-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
                placeholder="Description de la contrainte…"
                value={c.description}
                onChange={(e) =>
                  handleFieldChange(idx, "description", e.target.value)
                }
              />
              <button
                type="button"
                onClick={() => handleDeleteConstraint(idx)}
                className="text-slate-400 hover:text-red-500"
                title="Supprimer la contrainte"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <div className="flex items-center gap-3 text-xs">
              <div className="flex flex-col flex-1">
                <span className="text-[11px] text-slate-500 mb-0.5">
                  KPI cible
                </span>
                <select
                  className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
                  value={c.kpi_id}
                  onChange={(e) =>
                    handleFieldChange(idx, "kpi_id", e.target.value)
                  }
                >
                  {kpiDefs.map((k) => (
                    <option key={k.id} value={k.id}>
                      {k.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col w-28">
                <span className="text-[11px] text-slate-500 mb-0.5">
                  Poids
                </span>
                <input
                  type="number"
                  step="0.1"
                  min={0}
                  max={1}
                  className="rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
                  value={c.weight}
                  onChange={(e) => handleWeightChange(idx, e)}
                />
              </div>
              <div className="flex-1 text-[11px] text-slate-500">
                <span className="block mb-1">Nœuds virtuels</span>
                <span className="inline-flex items-center rounded-full border border-slate-200 px-2 py-0.5 bg-white">
                  {c.virtual_nodes.length} NV
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ConstraintEditor;
