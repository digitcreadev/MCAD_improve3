import type { SessionState } from "../../api/types";
import { Plus, XCircle } from "lucide-react";

interface SessionListProps {
  sessions: SessionState[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onCreate: () => void;
  onClose: (id: string) => void;
}

function formatDate(value: string): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString();
}

function SessionList({
  sessions,
  selectedId,
  onSelect,
  onCreate,
  onClose
}: SessionListProps) {
  return (
    <div className="mcad-card h-full flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="mcad-section-title">Sessions d&apos;analyse</h3>
        <button
          type="button"
          onClick={onCreate}
          className="inline-flex items-center gap-1 rounded-full bg-slate-900 text-white px-3 py-1 text-xs shadow-sm hover:bg-black"
        >
          <Plus className="h-3 w-3" />
          Nouvelle session
        </button>
      </div>
      <div className="space-y-1 max-h-[480px] overflow-auto pr-1">
        {sessions.map((s) => {
          const active = s.session_id === selectedId;
          const statusColor =
            s.status === "open"
              ? "bg-emerald-50 text-emerald-700 border-emerald-100"
              : "bg-slate-100 text-slate-500 border-slate-200";

          return (
            <div
              key={s.session_id}
              className={`rounded-xl border px-3 py-2 text-xs cursor-pointer flex items-start justify-between gap-2 transition-colors ${
                active
                  ? "border-mcad-primary bg-mcad-primary-soft"
                  : "border-slate-200 bg-white hover:bg-slate-50"
              }`}
              onClick={() => onSelect(s.session_id)}
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="font-semibold text-slate-800">
                    {s.session_id}
                  </div>
                  <span
                    className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] ${statusColor}`}
                  >
                    {s.status === "open" ? "Ouverte" : "Fermée"}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500">
                  Créée le {formatDate(s.created_at)} · t = {s.step_index} ·
                  &nbsp;φ≤t = {s.phi_leq_t.toFixed(2)}
                </div>
                {s.covered_constraints.length > 0 && (
                  <div className="text-[11px] text-slate-500">
                    Contraintes couvertes:{" "}
                    <span className="text-slate-700">
                      {s.covered_constraints.join(", ")}
                    </span>
                  </div>
                )}
              </div>
              {s.status === "open" && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose(s.session_id);
                  }}
                  className="text-slate-400 hover:text-red-500"
                  title="Fermer la session"
                >
                  <XCircle className="h-4 w-4" />
                </button>
              )}
            </div>
          );
        })}

        {sessions.length === 0 && (
          <div className="text-xs text-slate-400">
            Aucune session pour cet objectif. Créez une session pour simuler une
            trajectoire d&apos;analyse décisionnelle (Q1, Q2, Q3, …).
          </div>
        )}
      </div>
    </div>
  );
}

export default SessionList;
