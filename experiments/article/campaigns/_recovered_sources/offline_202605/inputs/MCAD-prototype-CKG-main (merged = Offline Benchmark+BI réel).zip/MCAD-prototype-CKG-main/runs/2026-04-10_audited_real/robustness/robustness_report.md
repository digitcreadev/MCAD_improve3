# MCAD robustness and adversarial workload report

## Configurations

- `backend/harness/scenarios_robustness_foodmart.yaml`
- `backend/harness/scenarios_robustness_adventureworks.yaml`

## Aggregate policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|
|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.5|0.145139|0.08125|0.0|0.1875|
|ablation_no_real|0.5|0.145139|0.08125|0.0|0.1875|
|ablation_no_sat|0.5|0.145139|0.041667|0.0|0.125|
|baseline_measure_overlap|0.5|0.145139|0.660417|0.0|0.73125|
|baseline_naive|0.5|0.145139|0.752083|0.0|0.752083|
|baseline_random_matched|0.119444|0.0325|0.211597|0.185833|0.650556|
|mcad|0.5|0.145139|0.0|0.0|0.0|

## Breakdown by scenario type and policy

|scenario_type|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|
|---|---|---|---|---|---|---|
|adversarial_sat|ablation_ceval_any_intersection|0.333333|0.055556|0.0|0.0|0.0|
|adversarial_sat|ablation_no_real|0.333333|0.055556|0.0|0.0|0.0|
|adversarial_sat|ablation_no_sat|0.333333|0.055556|0.166667|0.0|0.5|
|adversarial_sat|baseline_measure_overlap|0.333333|0.055556|0.666667|0.0|0.8|
|adversarial_sat|baseline_naive|0.333333|0.055556|0.833333|0.0|0.833333|
|adversarial_sat|baseline_random_matched|0.1|0.016667|0.255556|0.116667|0.791667|
|adversarial_sat|mcad|0.333333|0.055556|0.0|0.0|0.0|
|adversarial_semantic|ablation_ceval_any_intersection|0.333333|0.066667|0.2|0.0|0.5|
|adversarial_semantic|ablation_no_real|0.333333|0.066667|0.2|0.0|0.5|
|adversarial_semantic|ablation_no_sat|0.333333|0.066667|0.0|0.0|0.0|
|adversarial_semantic|baseline_measure_overlap|0.333333|0.066667|0.6|0.0|0.75|
|adversarial_semantic|baseline_naive|0.333333|0.066667|0.8|0.0|0.8|
|adversarial_semantic|baseline_random_matched|0.066667|0.013333|0.253333|0.16|0.666667|
|adversarial_semantic|mcad|0.333333|0.066667|0.0|0.0|0.0|
|noisy_borderline|ablation_ceval_any_intersection|0.333333|0.083333|0.0|0.0|0.0|
|noisy_borderline|ablation_no_real|0.333333|0.083333|0.0|0.0|0.0|
|noisy_borderline|ablation_no_sat|0.333333|0.083333|0.0|0.0|0.0|
|noisy_borderline|baseline_measure_overlap|0.333333|0.083333|0.75|0.0|0.75|
|noisy_borderline|baseline_naive|0.333333|0.083333|0.75|0.0|0.75|
|noisy_borderline|baseline_random_matched|0.111111|0.027778|0.191667|0.166667|0.577778|
|noisy_borderline|mcad|0.333333|0.083333|0.0|0.0|0.0|
|stress_long|ablation_ceval_any_intersection|1.0|0.375|0.125|0.0|0.25|
|stress_long|ablation_no_real|1.0|0.375|0.125|0.0|0.25|
|stress_long|ablation_no_sat|1.0|0.375|0.0|0.0|0.0|
|stress_long|baseline_measure_overlap|1.0|0.375|0.625|0.0|0.625|
|stress_long|baseline_naive|1.0|0.375|0.625|0.0|0.625|
|stress_long|baseline_random_matched|0.2|0.072222|0.145833|0.3|0.566111|
|stress_long|mcad|1.0|0.375|0.0|0.0|0.0|

## MCAD explainability on blocked steps

|scenario_type|n_steps|n_blocked|n_explainable_blocks|explainable_block_rate|mean_missing_requirements_when_blocked|dominant_block_reason|
|---|---|---|---|---|---|---|
|adversarial_sat|12|10|10|1.0|0.0|measures_present|
|adversarial_semantic|10|8|8|1.0|0.75|slc_ok|
|noisy_borderline|8|6|6|1.0|0.0|grain_ok|
|stress_long|16|10|10|1.0|0.6|grain_ok|

### Dominant block reasons overall

- **slc_ok**: 12 blocked steps
- **grain_ok**: 10 blocked steps
- **missing_requirement_set**: 4 blocked steps
- **measures_present**: 2 blocked steps
- **time_ok**: 2 blocked steps
- **unit_ok**: 2 blocked steps
- **agg_ok**: 2 blocked steps