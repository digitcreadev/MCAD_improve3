import { useEffect, useMemo, useState } from "react";
import type {
  Objective,
  ObjectivePerformanceResponse
} from "../api/types";
import {
  fetchObjectives,
  fetchObjectivePerformance
} from "../api/client";
import PhiCurveChart from "../components/analytics/PhiCurveChart";
import AucBarChart from "../components/analytics/AucBarChart";
import ConstraintHeatmap from "../components/analytics/ConstraintHeatmap";
import { AlertCircle, RefreshCw } from "lucide-react";

function PerformanceDashboardPage() {
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [selectedObjectiveId, setSelectedObjectiveId] = useState<string | null>(
    null
  );
  const [performance, setPerformance] =
    useState<ObjectivePerformanceResponse | null>(null);
  const [loadingInit, setLoadingInit] = useState(true);
  const [loadingPerf, setLoadingPerf] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedObjective = useMemo(
    () => objectives.find((o) => o.id === selectedObjectiveId) || null,
    [objectives, selectedObjectiveId]
  );

  useEffect(() => {
    const load = async () => {
      try {
        setLoadingInit(true);
        const objs = await fetchObjectives();
        setObjectives(objs);
        if (objs.length > 0) {
          setSelectedObjectiveId(objs[0].id);
        }
      } catch (e: any) {
        console.error(e);
        setErrorMsg("Impossible de charger les objectifs.");
      } finally {
        setLoadingInit(false);
      }
    };
    load();
  }, []);

  const loadPerf = async (objectiveId: string) => {
    try {
      setLoadingPerf(true);
      const perf = await fetchObjectivePerformance(objectiveId);
      setPerformance(perf);
      setErrorMsg(null);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Impossible de charger les métriques de performance MCAD.");
    } finally {
      setLoadingPerf(false);
    }
  };

  useEffect(() => {
    if (selectedObjectiveId) {
      loadPerf(selectedObjectiveId);
    } else {
      setPerformance(null);
    }
  }, [selectedObjectiveId]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-slate-900">
          Tableau de bord de performance MCAD
        </h1>
        <p className="text-xs text-slate-500 max-w-3xl">
          Ce tableau de bord agrège les résultats des sessions d&apos;analyse
          (φ≤t(O), AUC, heatmap de couverture) pour un objectif stratégique O
          donné. Il fournit les figures directement exploitables dans les
          sections &laquo; Étude de cas &raquo; et &laquo; Validation
          expérimentale &raquo; de l&apos;article.
        </p>
      </div>

      {errorMsg && (
        <div className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          <AlertCircle className="h-4 w-4" />
          <span>{errorMsg}</span>
        </div>
      )}

      {loadingInit ? (
        <div className="text-xs text-slate-500">
          Chargement des objectifs…
        </div>
      ) : objectives.length === 0 ? (
        <div className="text-xs text-slate-500">
          Aucun objectif défini. Va d&apos;abord dans &laquo; Objectifs & KPI
          &raquo;.
        </div>
      ) : (
        <>
          <div className="mcad-card flex flex-col md:flex-row gap-3 md:items-center">
            <div className="flex flex-col gap-1 flex-1">
              <span className="text-[11px] font-medium text-slate-600">
                Objectif
              </span>
              <select
                value={selectedObjectiveId ?? ""}
                onChange={(e) => setSelectedObjectiveId(e.target.value)}
                className="w-full md:w-80 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
              >
                {objectives.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name} ({o.id})
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={() => selectedObjectiveId && loadPerf(selectedObjectiveId)}
              disabled={!selectedObjectiveId || loadingPerf}
              className="inline-flex items-center gap-1 rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 hover:bg-slate-100 disabled:opacity-60"
            >
              <RefreshCw className="h-3 w-3" />
              {loadingPerf ? "Raffraîchissement…" : "Rafraîchir les métriques"}
            </button>
          </div>

          {selectedObjective && (
            <div className="mcad-card text-[11px] text-slate-600">
              <span className="font-semibold text-slate-800 mr-1">
                Rappel de l&apos;objectif :
              </span>
              {selectedObjective.description}
            </div>
          )}

          {loadingPerf && (
            <div className="text-xs text-slate-500">
              Calcul / chargement des métriques MCAD…
            </div>
          )}

          {!loadingPerf && performance && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
              <PhiCurveChart performance={performance} />
              <AucBarChart performance={performance} />
              <div className="lg:col-span-2">
                <ConstraintHeatmap performance={performance} />
              </div>
            </div>
          )}

          {!loadingPerf &&
            (!performance ||
              (!performance.sessionIds.length &&
                !performance.phiCurves.length)) && (
              <div className="mcad-card text-xs text-slate-400">
                Aucune session n&apos;est encore enregistrée pour cet objectif.
                Lance quelques scénarios dans &laquo; Sessions & MDX &raquo;
                puis reviens ici pour visualiser les courbes et heatmaps.
              </div>
            )}
        </>
      )}
    </div>
  );
}

export default PerformanceDashboardPage;
