import type { EvaluateVisualMdxResponse } from "../../api/types";
import { AlertTriangle, CheckCircle2, Info } from "lucide-react";

interface MdxResultPanelProps {
  result: EvaluateVisualMdxResponse | null;
}

function MdxResultPanel({ result }: MdxResultPanelProps) {
  if (!result) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Aucune évaluation pour le moment. Construis une requête et clique sur
        &laquo; Évaluer QP &raquo;.
      </div>
    );
  }

  const sat = result.sat;

  return (
    <div className="mcad-card flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h3 className="mcad-section-title">Résultat MCAD pour la requête</h3>
        <span className="text-[11px] text-slate-500">
          t = {result.step_index ?? "-"}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1">
          <div className="flex items-center gap-2">
            {sat ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-red-500" />
            )}
            <span className="font-semibold text-slate-800">SAT(QP)</span>
          </div>
          <div className="text-slate-600">
            {sat ? "Requête satisfaisable" : "Requête non satisfaisable"}
          </div>
          <ul className="mt-1 space-y-0.5">
            {result.clauses.map((c) => (
              <li key={c.name}>
                <span
                  className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] border ${
                    c.ok
                      ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                      : "bg-red-50 text-red-700 border-red-100"
                  }`}
                >
                  {c.name}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-mcad-primary" />
            <span className="font-semibold text-slate-800">
              Contribution instantanée φ(QP,O)
            </span>
          </div>
          <div className="text-slate-700">
            φ(QP,O) = {result.phi.toFixed(2)} · φ<sub>pondérée</sub> ={" "}
            {result.phi_weighted.toFixed(2)}
          </div>
          <div className="mt-1 text-slate-600">
            Contraintes calculables (Ceval) :
            {result.calculable_constraints.length === 0 ? (
              <span className="italic"> aucune</span>
            ) : (
              <ul className="mt-1 list-disc list-inside space-y-0.5">
                {result.calculable_constraints.map((cid) => (
                  <li key={cid}>{cid}</li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs space-y-1">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-mcad-primary" />
            <span className="font-semibold text-slate-800">
              Contribution cumulative φ≤t(O)
            </span>
          </div>
          <div className="text-slate-700">
            φ≤t(O) ={" "}
            {result.phi_leq_t !== null
              ? result.phi_leq_t.toFixed(2)
              : "—"}{" "}
            · Δφ<sub>t</sub> ={" "}
            {result.delta_phi_t !== null
              ? result.delta_phi_t.toFixed(2)
              : "—"}
          </div>
          <div className="mt-1 text-slate-600">
            Couverture cumulée :
            {result.covered_constraints.length === 0 ? (
              <span className="italic"> aucune</span>
            ) : (
              <span className="ml-1">
                {result.covered_constraints.join(", ")}
              </span>
            )}
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-3 text-xs space-y-1">
        <div className="font-semibold text-slate-800">Nœuds virtuels réels</div>
        {result.real_node_ids.length === 0 ? (
          <div className="text-slate-500 text-[11px]">
            Aucun nœud virtuel explicitement activé.
          </div>
        ) : (
          <div className="flex flex-wrap gap-1 text-[11px]">
            {result.real_node_ids.map((id) => (
              <span
                key={id}
                className="inline-flex items-center rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5"
              >
                {id}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default MdxResultPanel;
