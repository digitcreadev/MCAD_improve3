import { useEffect, useMemo, useState } from "react";
import type { Objective } from "../api/types";
import { fetchObjectives } from "../api/client";
import CkgGraphView from "../components/ckg/CkgGraphView";
import { AlertCircle } from "lucide-react";

function CkgExplorerPage() {
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedObjective = useMemo(
    () => objectives.find((o) => o.id === selectedId) || null,
    [objectives, selectedId]
  );

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await fetchObjectives();
        setObjectives(data);
        if (data.length > 0) {
          setSelectedId(data[0].id);
        }
      } catch (e: any) {
        console.error(e);
        setErrorMsg("Impossible de charger les objectifs.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-slate-900">
          CKG Explorer (Contexte & objectif stratégique)
        </h1>
        <p className="text-xs text-slate-500 max-w-3xl">
          Cette vue permet de visualiser comment un objectif stratégique O est
          décomposé en contraintes et nœuds virtuels dans le graphe de
          connaissances contextuelles (CKG). Elle fait le lien entre la
          formalisation du MCAD dans l&apos;article et l&apos;implémentation
          concrète dans le prototype.
        </p>
      </div>

      {errorMsg && (
        <div className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          <AlertCircle className="h-4 w-4" />
          <span>{errorMsg}</span>
        </div>
      )}

      {loading ? (
        <div className="text-xs text-slate-500">Chargement des objectifs…</div>
      ) : objectives.length === 0 ? (
        <div className="text-xs text-slate-500">
          Aucun objectif défini. Va d&apos;abord dans &laquo; Objectifs & KPI
          &raquo;.
        </div>
      ) : (
        <>
          <div className="mcad-card flex flex-col md:flex-row gap-3 md:items-center">
            <div className="flex flex-col gap-1 flex-1">
              <span className="text-[11px] font-medium text-slate-600">
                Objectif
              </span>
              <select
                value={selectedId ?? ""}
                onChange={(e) => setSelectedId(e.target.value)}
                className="w-full md:w-80 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
              >
                {objectives.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name} ({o.id})
                  </option>
                ))}
              </select>
            </div>
            {selectedObjective && (
              <div className="text-[11px] text-slate-500 max-w-md">
                {selectedObjective.description}
              </div>
            )}
          </div>

          <CkgGraphView objective={selectedObjective} />
        </>
      )}
    </div>
  );
}

export default CkgExplorerPage;
