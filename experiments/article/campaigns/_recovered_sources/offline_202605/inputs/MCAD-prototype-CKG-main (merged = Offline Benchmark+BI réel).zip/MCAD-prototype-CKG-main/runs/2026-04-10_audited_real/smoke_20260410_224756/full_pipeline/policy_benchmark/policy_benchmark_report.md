# MCAD policy benchmark report

- Scenario config: `backend/harness/scenarios.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.333**
- MCAD mean AUC φ(t): **0.211**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.223 / 0.523 / 0.735**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.333333|0.211111|0.1|0.0|0.1|0.2115|0.382917|0.536117|
|ablation_no_real|0.333333|0.211111|0.1|0.0|0.1|0.2215|0.513285|0.705286|
|ablation_no_sat|0.333333|0.211111|0.0|0.0|0.0|0.27465|0.6791|1.125164|
|baseline_measure_overlap|0.333333|0.211111|0.566667|0.0|0.566667|0.0166|0.026695|0.029459|
|baseline_naive|0.333333|0.211111|0.666667|0.0|0.666667|0.0012|0.002065|0.008582|
|baseline_random_matched|0.18|0.106667|0.453333|0.153333|0.453333|0.00295|0.004791|0.008648|
|mcad|0.333333|0.211111|0.0|0.0|0.0|0.22265|0.52337|0.735372|