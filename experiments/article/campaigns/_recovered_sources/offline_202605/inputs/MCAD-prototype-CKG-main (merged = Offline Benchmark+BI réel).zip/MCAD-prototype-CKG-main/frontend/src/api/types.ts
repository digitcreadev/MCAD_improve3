export interface VirtualNode {
  id: string;
  fact: string;
  grain: string[];
  measure: string;
  aggregator: string;
  unit: string;
  slicers: Record<string, string>;
  window_start?: string | null;
  window_end?: string | null;
}

export interface Constraint {
  id: string;
  kpi_id: string;
  description: string;
  weight: number;
  virtual_nodes: VirtualNode[];
}

export interface Objective {
  id: string;
  name: string;
  description: string;
  kpis: string[];
  constraints: Constraint[];
}

export interface KpiDefinition {
  id: string;
  label: string;
  description?: string;
}

/* --- Sessions & MDX Lab --- */

export interface SessionState {
  session_id: string;
  objective_id: string;
  dw_id: string;
  created_at: string;
  status: "open" | "closed";
  step_index: number;
  phi_leq_t: number;
  covered_constraints: string[];
}

export interface SatClauseResult {
  name: string;
  ok: boolean;
  details?: Record<string, string>;
}

export interface EvaluateVisualMdxResponse {
  sat: boolean;
  clauses: SatClauseResult[];
  phi: number;
  phi_weighted: number;
  real_node_ids: string[];
  calculable_constraints: string[];
  phi_leq_t: number | null;
  delta_phi_t: number | null;
  step_index: number | null;
  covered_constraints: string[];
}

export interface VisualMdxQP {
  cube?: string;
  rows?: string[];
  columns?: string[];
  filters?: string[];
  measures?: string[];
  force_sat?: boolean;
  target_constraints?: string[];
  mdx_hint?: string;
  step_name?: string;
  step_description?: string;
}

/* --- Analytics: timeline & performance --- */

export interface SessionTimelineStep {
  t: number;
  timestamp: string;
  phi: number;
  phi_weighted?: number | null;
  phi_leq_t?: number | null;
  delta_phi_t?: number | null;
  sat: boolean;
  calculable_constraints: string[];
  clauses: SatClauseResult[];
}

export interface SessionTimelineResponse {
  session_id: string;
  objective_id: string;
  steps: SessionTimelineStep[];
}

export interface ObjectivePerformanceResponse {
  objective_id: string;
  sessionIds: string[];
  phiCurves: { t: number; [sessionId: string]: number }[];
  aucBySession: { sessionId: string; auc: number }[];
  constraintIds: string[];
  constraintCoverageHeatmap: {
    constraintId: string;
    sessionId: string;
    value: number;
  }[];
}
