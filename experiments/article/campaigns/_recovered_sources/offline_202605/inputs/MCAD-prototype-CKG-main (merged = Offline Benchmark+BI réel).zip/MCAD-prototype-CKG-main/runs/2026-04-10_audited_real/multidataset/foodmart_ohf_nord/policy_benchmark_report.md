# MCAD policy benchmark report

- Scenario config: `backend/harness/scenarios.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.333**
- MCAD mean AUC φ(t): **0.211**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.218 / 0.406 / 0.751**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.333333|0.211111|0.1|0.0|0.1|0.2217|0.397288|0.674082|
|ablation_no_real|0.333333|0.211111|0.1|0.0|0.1|0.2294|0.41303|0.68359|
|ablation_no_sat|0.333333|0.211111|0.0|0.0|0.0|0.27325|0.553486|0.873374|
|baseline_measure_overlap|0.333333|0.211111|0.566667|0.0|0.566667|0.0164|0.025955|0.028569|
|baseline_naive|0.333333|0.211111|0.666667|0.0|0.666667|0.0011|0.002086|0.002451|
|baseline_random_matched|0.204|0.128889|0.42|0.129333|0.444|0.0032|0.00516|0.0067|
|mcad|0.333333|0.211111|0.0|0.0|0.0|0.21845|0.406459|0.750753|