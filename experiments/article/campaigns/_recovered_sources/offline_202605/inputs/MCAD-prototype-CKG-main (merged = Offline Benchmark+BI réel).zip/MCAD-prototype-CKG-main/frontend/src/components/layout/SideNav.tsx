import { NavLink } from "react-router-dom";
import { Target, ListChecks, Share2, Activity } from "lucide-react";

const linkBase =
  "flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors";
const linkInactive = "text-slate-600 hover:bg-slate-100";
const linkActive = "bg-mcad-primary text-white";

function SideNav() {
  return (
    <nav className="w-56 border-r border-slate-200 bg-white/80 px-3 py-4 space-y-1">
      <div className="px-2 mb-2">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
          Navigation
        </p>
      </div>

      <NavLink
        to="/objectives"
        className={({ isActive }) =>
          `${linkBase} ${isActive ? linkActive : linkInactive}`
        }
      >
        <Target className="h-4 w-4" />
        <span>Objectifs & KPI</span>
      </NavLink>

      <NavLink
        to="/sessions"
        className={({ isActive }) =>
          `${linkBase} ${isActive ? linkActive : linkInactive}`
        }
      >
        <ListChecks className="h-4 w-4" />
        <span>Sessions & MDX</span>
      </NavLink>

      <NavLink
        to="/ckg"
        className={({ isActive }) =>
          `${linkBase} ${isActive ? linkActive : linkInactive}`
        }
      >
        <Share2 className="h-4 w-4" />
        <span>CKG Explorer</span>
      </NavLink>

      <NavLink
        to="/analytics"
        className={({ isActive }) =>
          `${linkBase} ${isActive ? linkActive : linkInactive}`
        }
      >
        <Activity className="h-4 w-4" />
        <span>Performance MCAD</span>
      </NavLink>
    </nav>
  );
}

export default SideNav;
