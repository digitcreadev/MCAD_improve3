/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        "mcad-primary": "#0f766e",
        "mcad-primary-soft": "#ccfbf1"
      }
    }
  },
  plugins: []
};
