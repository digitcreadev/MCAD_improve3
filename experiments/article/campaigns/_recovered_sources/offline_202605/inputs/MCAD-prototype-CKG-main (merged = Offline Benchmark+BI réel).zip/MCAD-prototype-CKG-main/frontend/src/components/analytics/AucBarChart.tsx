import type { ObjectivePerformanceResponse } from "../../api/types";

interface AucBarChartProps {
  performance: ObjectivePerformanceResponse | null;
}

function AucBarChart({ performance }: AucBarChartProps) {
  if (!performance || !performance.aucBySession.length) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Aucune AUC disponible pour l&apos;instant.
      </div>
    );
  }

  const entries = performance.aucBySession;
  const maxVal =
    entries.length > 0 ? Math.max(...entries.map((e) => e.auc || 0)) || 1 : 1;

  return (
    <div className="mcad-card">
      <h3 className="mcad-section-title mb-2">
        AUC (φ≤t(O)) par session d&apos;analyse
      </h3>
      <div className="text-[11px] text-slate-500 mb-2">
        Plus l&apos;AUC est élevée, plus la trajectoire d&apos;analyse
        converge rapidement et fortement vers l&apos;objectif global O.
      </div>
      <div className="flex items-end gap-3 h-40">
        {entries.map((e) => {
          const heightPct = maxVal > 0 ? (e.auc / maxVal) * 100 : 0;
          return (
            <div
              key={e.sessionId}
              className="flex flex-col items-center flex-1 gap-1"
            >
              <div
                className="w-full max-w-[36px] rounded-t-lg bg-mcad-primary/80"
                style={{ height: `${heightPct}%` }}
              />
              <div className="text-[11px] text-slate-600 truncate max-w-[60px]">
                {e.sessionId}
              </div>
              <div className="text-[10px] text-slate-500">
                {e.auc.toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default AucBarChart;
