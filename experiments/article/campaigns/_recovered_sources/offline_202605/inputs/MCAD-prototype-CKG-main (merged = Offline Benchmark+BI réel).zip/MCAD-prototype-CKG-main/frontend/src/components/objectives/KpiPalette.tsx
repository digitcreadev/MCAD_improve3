import { useDraggable } from "@dnd-kit/core";
import type { KpiDefinition } from "../../api/types";
import { GripVertical } from "lucide-react";

interface KpiPaletteProps {
  kpis: KpiDefinition[];
  onAddClick?: (kpiId: string) => void;
}

function DraggableKpiItem({
  kpi,
  onAddClick
}: {
  kpi: KpiDefinition;
  onAddClick?: (id: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: kpi.id
  });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`
      }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs shadow-sm cursor-grab active:cursor-grabbing"
      {...attributes}
      {...listeners}
    >
      <div className="flex items-center gap-2">
        <GripVertical className="h-3 w-3 text-slate-400" />
        <div>
          <div className="font-semibold text-slate-800">{kpi.label}</div>
          {kpi.description && (
            <div className="text-[11px] text-slate-500 mt-0.5">
              {kpi.description}
            </div>
          )}
        </div>
      </div>
      {onAddClick && (
        <button
          type="button"
          className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700"
          onClick={() => onAddClick(kpi.id)}
        >
          Ajouter
        </button>
      )}
    </div>
  );
}

function KpiPalette({ kpis, onAddClick }: KpiPaletteProps) {
  return (
    <div className="mcad-card h-full flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <h3 className="mcad-section-title">Palette de KPI</h3>
        <span className="text-[11px] text-slate-400">
          Glisser-déposer ou cliquer pour les ajouter
        </span>
      </div>
      <div className="space-y-2 overflow-auto pr-1">
        {kpis.map((kpi) => (
          <DraggableKpiItem
            key={kpi.id}
            kpi={kpi}
            onAddClick={onAddClick}
          />
        ))}
      </div>
    </div>
  );
}

export default KpiPalette;
