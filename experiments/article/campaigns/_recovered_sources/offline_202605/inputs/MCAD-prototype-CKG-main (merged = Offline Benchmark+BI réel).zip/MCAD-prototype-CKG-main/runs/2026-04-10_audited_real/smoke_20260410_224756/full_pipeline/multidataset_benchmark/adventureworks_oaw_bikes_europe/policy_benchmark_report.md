# MCAD policy benchmark report

- Scenario config: `/workspaces/MCAD_UP/backend/harness/scenarios_adventureworks.yaml`
- Policies: ablation_ceval_any_intersection, ablation_no_real, ablation_no_sat, baseline_measure_overlap, baseline_naive, baseline_random_matched, mcad

## Key takeaways

- MCAD mean final coverage: **0.250**
- MCAD mean AUC φ(t): **0.167**
- MCAD false allow rate: **0.000**
- MCAD false block rate: **0.000**
- MCAD latency p50/p95/p99 (ms): **0.225 / 0.405 / 0.669**

## Policy summary

|policy|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|latency_p50_ms|latency_p95_ms|latency_p99_ms|
|---|---|---|---|---|---|---|---|---|
|ablation_ceval_any_intersection|0.25|0.166667|0.125|0.0|0.125|0.2221|0.379781|0.39392|
|ablation_no_real|0.25|0.166667|0.125|0.0|0.125|0.2344|0.390475|0.637196|
|ablation_no_sat|0.25|0.166667|0.0|0.0|0.0|0.28525|0.397054|0.760363|
|baseline_measure_overlap|0.25|0.166667|0.625|0.0|0.625|0.0176|0.027095|0.059644|
|baseline_naive|0.25|0.166667|0.75|0.0|0.75|0.00115|0.001905|0.002244|
|baseline_random_matched|0.116667|0.077778|0.375|0.133333|0.375|0.0033|0.004405|0.004829|
|mcad|0.25|0.166667|0.0|0.0|0.0|0.22495|0.405431|0.668682|