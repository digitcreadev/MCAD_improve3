import { Brain } from "lucide-react";

function NavBar() {
  return (
    <header className="h-14 border-b border-slate-200 bg-white/70 backdrop-blur flex items-center px-4 justify-between">
      <div className="flex items-center gap-2">
        <div className="h-8 w-8 rounded-xl bg-mcad-primary-soft flex items-center justify-center">
          <Brain className="h-4 w-4 text-mcad-primary" />
        </div>
        <div className="flex flex-col">
          <span className="text-sm font-semibold text-slate-800">
            MCAD Prototype v2
          </span>
          <span className="text-xs text-slate-500">
            Contextual mask for OLAP analysis
          </span>
        </div>
      </div>
      <div className="text-xs text-slate-500">
        Article: <span className="font-medium">MCAD – Brouillon 5</span>
      </div>
    </header>
  );
}

export default NavBar;
