import { useEffect, useMemo, useState } from "react";
import type { KpiDefinition, Objective } from "../api/types";
import {
  fetchObjectives,
  createObjective,
  updateObjective,
  cloneObjective
} from "../api/client";
import ObjectiveList from "../components/objectives/ObjectiveList";
import ObjectiveEditor from "../components/objectives/ObjectiveEditor";
import { AlertCircle } from "lucide-react";

const BASE_KPI_CATALOG: KpiDefinition[] = [
  {
    id: "KPI_MARGIN_RATE_MONTH_CAT",
    label: "Taux de marge (%) par mois & catégorie",
    description: "Marge moyenne mensuelle par catégorie produit."
  },
  {
    id: "KPI_STOCKOUT_RATE_MONTH_CAT",
    label: "Taux de rupture (%) par mois & catégorie",
    description: "Fréquence des ruptures de stock par catégorie."
  },
  {
    id: "KPI_CORR_MARGIN_STOCKOUT_12M",
    label: "Corr(marge, rupture) sur 12 mois",
    description:
      "Corrélation entre marge et ruptures sur une fenêtre glissante de 12 mois."
  }
];

function ObjectiveManagerPage() {
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedObjective = useMemo(
    () => objectives.find((o) => o.id === selectedId) || null,
    [objectives, selectedId]
  );

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const data = await fetchObjectives();
        setObjectives(data);
        if (data.length > 0) {
          setSelectedId(data[0].id);
        }
      } catch (e: any) {
        console.error(e);
        setErrorMsg("Impossible de charger les objectifs depuis l'API MCAD.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleCreateObjective = async () => {
    const id = `OBJ_${Date.now()}`;
    const newObj: Objective = {
      id,
      name: "Nouvel objectif",
      description: "",
      kpis: [],
      constraints: []
    };
    try {
      const created = await createObjective(newObj);
      setObjectives((prev) => [...prev, created]);
      setSelectedId(created.id);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de la création de l'objectif.");
    }
  };

  const handleCloneObjective = async (id: string) => {
    try {
      const cloned = await cloneObjective(id);
      setObjectives((prev) => [...prev, cloned]);
      setSelectedId(cloned.id);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de la duplication de l'objectif.");
    }
  };

  const handleSaveObjective = async (obj: Objective) => {
    try {
      const exists = objectives.some((o) => o.id === obj.id);
      const saved = exists ? await updateObjective(obj) : await createObjective(obj);
      setObjectives((prev) => {
        const others = prev.filter((o) => o.id !== saved.id);
        return [...others, saved];
      });
      setSelectedId(saved.id);
      setErrorMsg(null);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de l'enregistrement de l'objectif.");
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-slate-900">
          Gestion des objectifs & KPI
        </h1>
        <p className="text-xs text-slate-500 max-w-3xl">
          Cet écran te permet de définir les objectifs stratégiques/métier, les
          KPI associés et les contraintes (nœuds virtuels du CKG) qui seront
          utilisés par le MCAD pour évaluer les requêtes MDX et tracer les
          courbes φ(t), AUC et heatmaps dans ton article.
        </p>
      </div>

      {errorMsg && (
        <div className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          <AlertCircle className="h-4 w-4" />
          <span>{errorMsg}</span>
        </div>
      )}

      {loading ? (
        <div className="text-xs text-slate-500">Chargement des objectifs…</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
          <div className="lg:col-span-1 h-[520px]">
            <ObjectiveList
              objectives={objectives}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onCreate={handleCreateObjective}
              onClone={handleCloneObjective}
            />
          </div>
          <div className="lg:col-span-2">
            <ObjectiveEditor
              objective={selectedObjective}
              baseKpiCatalog={BASE_KPI_CATALOG}
              onSave={handleSaveObjective}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default ObjectiveManagerPage;
