import { useDroppable } from "@dnd-kit/core";
import type { KpiDefinition } from "../../api/types";
import { X, Target } from "lucide-react";

interface ObjectiveKpiDropZoneProps {
  selectedKpiIds: string[];
  allKpis: KpiDefinition[];
  onRemoveKpi: (kpiId: string) => void;
}

function ObjectiveKpiDropZone({
  selectedKpiIds,
  allKpis,
  onRemoveKpi
}: ObjectiveKpiDropZoneProps) {
  const { isOver, setNodeRef } = useDroppable({
    id: "objective-kpi-dropzone"
  });

  const selectedKpis = selectedKpiIds
    .map((id) => allKpis.find((k) => k.id === id) || { id, label: id })
    .map((k) => ({
      id: k.id,
      label: k.label,
      description: k.description
    }));

  return (
    <div className="mcad-card h-full flex flex-col">
      <div className="flex items-center justify-between mb-2">
        <h3 className="mcad-section-title">KPI de l&apos;objectif</h3>
        <div className="flex items-center gap-1 text-[11px] text-slate-500">
          <Target className="h-3 w-3" />
          <span>{selectedKpiIds.length} KPI sélectionné(s)</span>
        </div>
      </div>
      <div
        ref={setNodeRef}
        className={`flex-1 rounded-xl border-2 border-dashed p-3 overflow-auto ${
          isOver
            ? "border-mcad-primary bg-mcad-primary-soft/60"
            : "border-slate-200 bg-slate-50"
        }`}
      >
        {selectedKpis.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-xs text-slate-400">
            Déposez ici les KPI pertinents pour cet objectif…
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {selectedKpis.map((kpi) => (
              <span key={kpi.id} className="mcad-chip">
                {kpi.label}
                <button
                  type="button"
                  className="ml-1 text-slate-400 hover:text-slate-700"
                  onClick={() => onRemoveKpi(kpi.id)}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ObjectiveKpiDropZone;
