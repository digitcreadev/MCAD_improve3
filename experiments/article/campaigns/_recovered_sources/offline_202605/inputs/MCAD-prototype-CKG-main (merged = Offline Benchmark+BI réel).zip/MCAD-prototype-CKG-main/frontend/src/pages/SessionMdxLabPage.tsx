import { useEffect, useMemo, useState } from "react";
import type {
  Constraint,
  Objective,
  SessionState,
  EvaluateVisualMdxResponse,
  VisualMdxQP
} from "../api/types";
import {
  fetchObjectives,
  listSessions,
  createSession,
  closeSession,
  evaluateVisualMdx
} from "../api/client";
import SessionList from "../components/sessions/SessionList";
import MdxVisualBuilder from "../components/sessions/MdxVisualBuilder";
import MdxResultPanel from "../components/sessions/MdxResultPanel";
import { AlertCircle } from "lucide-react";

function SessionMdxLabPage() {
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [selectedObjectiveId, setSelectedObjectiveId] = useState<string | null>(
    null
  );
  const [sessions, setSessions] = useState<SessionState[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(
    null
  );
  const [lastResult, setLastResult] = useState<EvaluateVisualMdxResponse | null>(
    null
  );
  const [loadingInit, setLoadingInit] = useState(true);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [evaluating, setEvaluating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const selectedObjective = useMemo(
    () => objectives.find((o) => o.id === selectedObjectiveId) || null,
    [objectives, selectedObjectiveId]
  );

  const constraints: Constraint[] = selectedObjective?.constraints ?? [];

  // Chargement initial des objectifs
  useEffect(() => {
    const load = async () => {
      try {
        setLoadingInit(true);
        const objs = await fetchObjectives();
        setObjectives(objs);
        if (objs.length > 0) {
          setSelectedObjectiveId(objs[0].id);
        }
      } catch (e: any) {
        console.error(e);
        setErrorMsg("Impossible de charger les objectifs depuis l'API MCAD.");
      } finally {
        setLoadingInit(false);
      }
    };
    load();
  }, []);

  // Chargement des sessions dès qu'un objectif est sélectionné
  useEffect(() => {
    const loadSessions = async () => {
      if (!selectedObjectiveId) return;
      try {
        setLoadingSessions(true);
        const sess = await listSessions(selectedObjectiveId);
        setSessions(sess);
        if (sess.length > 0) {
          setSelectedSessionId(sess[0].session_id);
        } else {
          setSelectedSessionId(null);
        }
      } catch (e: any) {
        console.error(e);
        setErrorMsg("Impossible de charger les sessions.");
      } finally {
        setLoadingSessions(false);
      }
    };
    loadSessions();
  }, [selectedObjectiveId]);

  const handleCreateSession = async () => {
    if (!selectedObjectiveId) return;
    try {
      const s = await createSession(selectedObjectiveId, "FOODMART");
      setSessions((prev) => [...prev, s]);
      setSelectedSessionId(s.session_id);
      setErrorMsg(null);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de la création de la session.");
    }
  };

  const handleCloseSession = async (id: string) => {
    try {
      const closed = await closeSession(id);
      setSessions((prev) =>
        prev.map((s) => (s.session_id === id ? closed : s))
      );
      if (selectedSessionId === id) {
        setSelectedSessionId(id);
      }
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de la fermeture de la session.");
    }
  };

  const handleEvaluate = async (qp: VisualMdxQP) => {
    if (!selectedObjectiveId || !selectedSessionId) return;
    try {
      setEvaluating(true);
      const res = await evaluateVisualMdx(
        selectedSessionId,
        selectedObjectiveId,
        qp
      );
      setLastResult(res);
      // Rafraîchir la liste des sessions (step_index, phi_leq_t, …)
      const sess = await listSessions(selectedObjectiveId);
      setSessions(sess);
      setErrorMsg(null);
    } catch (e: any) {
      console.error(e);
      setErrorMsg("Échec de l'évaluation MCAD de la requête.");
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-semibold text-slate-900">
          Sessions d&apos;analyse & MDX Lab
        </h1>
        <p className="text-xs text-slate-500 max-w-3xl">
          Ici tu peux simuler des trajectoires d&apos;analyse décisionnelle :
          création de sessions, enchaînement de requêtes (Q1, Q2, Q3, …), et
          observation de la contribution MCAD φ(QP,O) et φ≤t(O). Ces données
          serviront à générer les courbes φ(t), les AUC et les heatmaps
          présentées dans l&apos;article.
        </p>
      </div>

      {errorMsg && (
        <div className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
          <AlertCircle className="h-4 w-4" />
          <span>{errorMsg}</span>
        </div>
      )}

      {loadingInit ? (
        <div className="text-xs text-slate-500">
          Chargement des objectifs et des sessions…
        </div>
      ) : objectives.length === 0 ? (
        <div className="text-xs text-slate-500">
          Aucun objectif défini. Va d&apos;abord dans &laquo; Objectifs & KPI
          &raquo; pour en créer un.
        </div>
      ) : (
        <>
          <div className="mcad-card flex flex-col md:flex-row gap-3 md:items-center">
            <div className="flex flex-col gap-1 flex-1">
              <span className="text-[11px] font-medium text-slate-600">
                Objectif courant
              </span>
              <select
                value={selectedObjectiveId ?? ""}
                onChange={(e) => setSelectedObjectiveId(e.target.value)}
                className="w-full md:w-80 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-mcad-primary"
              >
                {objectives.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.name} ({o.id})
                  </option>
                ))}
              </select>
            </div>
            <div className="text-[11px] text-slate-500">
              Contraintes:{" "}
              <span className="font-medium">
                {constraints.length} contrainte(s)
              </span>
              {constraints.length > 0 && (
                <span> · exemple: {constraints[0].id}</span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
            <div className="lg:col-span-1 h-[520px]">
              <SessionList
                sessions={sessions}
                selectedId={selectedSessionId}
                onSelect={setSelectedSessionId}
                onCreate={handleCreateSession}
                onClose={handleCloseSession}
              />
            </div>
            <div className="lg:col-span-2 space-y-3">
              <MdxVisualBuilder
                objectiveId={selectedObjectiveId}
                sessionId={selectedSessionId}
                constraints={constraints}
                loading={evaluating || loadingSessions}
                onEvaluate={handleEvaluate}
              />
              <MdxResultPanel result={lastResult} />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default SessionMdxLabPage;
