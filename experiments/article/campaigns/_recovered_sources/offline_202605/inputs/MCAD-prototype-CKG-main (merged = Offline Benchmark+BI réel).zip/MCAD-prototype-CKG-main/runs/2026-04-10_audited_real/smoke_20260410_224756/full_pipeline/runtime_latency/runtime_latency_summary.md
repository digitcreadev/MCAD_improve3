# MCAD runtime latency summary

This file consolidates the policy-level runtime indicators needed for the article and reproducibility pack.

## MCAD highlights

- `single_dataset` / `N/A`: p50/p95/p99 = **0.22265 / 0.52337 / 0.735372 ms**, cold p50 = **0.22265 ms**, warm p50 = **0.0 ms**, mean φ final = **0.333333**, false allow = **0.0**
- `multidataset_aggregate` / `ALL`: p50/p95/p99 = **0.2206 / 0.406435 / 0.863797 ms**, cold p50 = **0.2206 ms**, warm p50 = **0.0 ms**, mean φ final = **0.296296**, false allow = **0.0**
- `multidataset_per_dataset` / `adventureworks_oaw_bikes_europe`: p50/p95/p99 = **0.22495 / 0.405431 / 0.668682 ms**, cold p50 = **0.22495 ms**, warm p50 = **0.0 ms**, mean φ final = **0.25**, false allow = **0.0**
- `multidataset_per_dataset` / `foodmart_ohf_nord`: p50/p95/p99 = **0.2155 / 0.406435 / 1.370135 ms**, cold p50 = **0.2155 ms**, warm p50 = **0.0 ms**, mean φ final = **0.333333**, false allow = **0.0**

## Consolidated table

|scope|dataset|policy|latency_p50_ms|latency_p95_ms|latency_p99_ms|latency_cold_p50_ms|latency_warm_p50_ms|mean_phi_final|mean_auc_phi|mean_false_allow_rate|mean_false_block_rate|mean_non_contrib_exec_rate|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|single_dataset|N/A|ablation_ceval_any_intersection|0.2115|0.382917|0.536117|0.2115|0.0|0.333333|0.211111|0.1|0.0|0.1|
|single_dataset|N/A|ablation_no_real|0.2215|0.513285|0.705286|0.2215|0.0|0.333333|0.211111|0.1|0.0|0.1|
|single_dataset|N/A|ablation_no_sat|0.27465|0.6791|1.125164|0.2799|0.0|0.333333|0.211111|0.0|0.0|0.0|
|single_dataset|N/A|baseline_measure_overlap|0.0166|0.026695|0.029459|0.01795|0.0|0.333333|0.211111|0.566667|0.0|0.566667|
|single_dataset|N/A|baseline_naive|0.0012|0.002065|0.008582|0.0014|0.0|0.333333|0.211111|0.666667|0.0|0.666667|
|single_dataset|N/A|baseline_random_matched|0.00295|0.004791|0.008648|0.0034|0.0|0.18|0.106667|0.453333|0.153333|0.453333|
|single_dataset|N/A|mcad|0.22265|0.52337|0.735372|0.22265|0.0|0.333333|0.211111|0.0|0.0|0.0|
|multidataset_aggregate|ALL|ablation_ceval_any_intersection|0.22305|0.400316|0.650787|0.22305|0.0|0.296296|0.191358|0.111111|0.0|0.111111|
|multidataset_aggregate|ALL|ablation_no_real|0.22995|0.395225|0.6473|0.22995|0.0|0.296296|0.191358|0.111111|0.0|0.111111|
|multidataset_aggregate|ALL|ablation_no_sat|0.2733|0.389104|0.664898|0.29125|0.0|0.296296|0.191358|0.0|0.0|0.0|
|multidataset_aggregate|ALL|baseline_measure_overlap|0.0175|0.02845|0.036135|0.0181|0.0|0.296296|0.191358|0.592593|0.0|0.592593|
|multidataset_aggregate|ALL|baseline_naive|0.0012|0.002|0.002311|0.0013|0.0|0.296296|0.191358|0.703704|0.0|0.703704|
|multidataset_aggregate|ALL|baseline_random_matched|0.0033|0.004755|0.028853|0.0036|0.0|0.151852|0.093827|0.418519|0.144444|0.418519|
|multidataset_aggregate|ALL|mcad|0.2206|0.406435|0.863797|0.2206|0.0|0.296296|0.191358|0.0|0.0|0.0|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|ablation_ceval_any_intersection|0.2221|0.379781|0.39392|0.2221|0.0|0.25|0.166667|0.125|0.0|0.125|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|ablation_no_real|0.2344|0.390475|0.637196|0.2344|0.0|0.25|0.166667|0.125|0.0|0.125|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|ablation_no_sat|0.28525|0.397054|0.760363|0.29705|0.0|0.25|0.166667|0.0|0.0|0.0|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|baseline_measure_overlap|0.0176|0.027095|0.059644|0.0179|0.0|0.25|0.166667|0.625|0.0|0.625|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|baseline_naive|0.00115|0.001905|0.002244|0.0013|0.0|0.25|0.166667|0.75|0.0|0.75|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|baseline_random_matched|0.0033|0.004405|0.004829|0.00365|0.0|0.116667|0.077778|0.375|0.133333|0.375|
|multidataset_per_dataset|adventureworks_oaw_bikes_europe|mcad|0.22495|0.405431|0.668682|0.22495|0.0|0.25|0.166667|0.0|0.0|0.0|
|multidataset_per_dataset|foodmart_ohf_nord|ablation_ceval_any_intersection|0.2282|0.494084|0.761183|0.2282|0.0|0.333333|0.211111|0.1|0.0|0.1|
|multidataset_per_dataset|foodmart_ohf_nord|ablation_no_real|0.2296|0.409337|0.619434|0.2296|0.0|0.333333|0.211111|0.1|0.0|0.1|
|multidataset_per_dataset|foodmart_ohf_nord|ablation_no_sat|0.27145|0.378987|0.583136|0.2861|0.0|0.333333|0.211111|0.0|0.0|0.0|
|multidataset_per_dataset|foodmart_ohf_nord|baseline_measure_overlap|0.017|0.028615|0.03031|0.01835|0.0|0.333333|0.211111|0.566667|0.0|0.566667|
|multidataset_per_dataset|foodmart_ohf_nord|baseline_naive|0.0012|0.002017|0.002234|0.0013|0.0|0.333333|0.211111|0.666667|0.0|0.666667|
|multidataset_per_dataset|foodmart_ohf_nord|baseline_random_matched|0.00325|0.004855|0.113772|0.0036|0.0|0.18|0.106667|0.453333|0.153333|0.453333|
|multidataset_per_dataset|foodmart_ohf_nord|mcad|0.2155|0.406435|1.370135|0.2155|0.0|0.333333|0.211111|0.0|0.0|0.0|