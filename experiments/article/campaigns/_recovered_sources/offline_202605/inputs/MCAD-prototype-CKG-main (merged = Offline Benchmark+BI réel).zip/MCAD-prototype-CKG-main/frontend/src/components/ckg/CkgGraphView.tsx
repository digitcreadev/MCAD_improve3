import type { Objective } from "../../api/types";
import { Network, Target } from "lucide-react";

interface CkgGraphViewProps {
  objective: Objective | null;
}

function CkgGraphView({ objective }: CkgGraphViewProps) {
  if (!objective) {
    return (
      <div className="mcad-card text-xs text-slate-400">
        Sélectionne un objectif pour visualiser sa projection dans le CKG
        (objectif, contraintes, nœuds virtuels).
      </div>
    );
  }

  const allVirtualNodes = objective.constraints.flatMap((c) => c.virtual_nodes);

  return (
    <div className="mcad-card">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Network className="h-4 w-4 text-mcad-primary" />
          <h3 className="mcad-section-title mb-0">
            Vue conceptuelle du graphe de connaissances contextuelles (CKG)
          </h3>
        </div>
        <span className="text-[11px] text-slate-500">
          Objectif : {objective.id}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Colonne KPI */}
        <div className="space-y-2">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide flex items-center gap-1">
            <Target className="h-3 w-3" />
            KPI de l&apos;objectif
          </div>
          <div className="space-y-1">
            {objective.kpis.map((kpiId) => (
              <div
                key={kpiId}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-[11px]"
              >
                <div className="font-medium text-slate-800">{kpiId}</div>
                <div className="text-[10px] text-slate-500">
                  KPI implicite utilisé par au moins une contrainte de
                  l&apos;objectif.
                </div>
              </div>
            ))}
            {objective.kpis.length === 0 && (
              <div className="text-[11px] text-slate-400">
                Aucun KPI défini pour cet objectif.
              </div>
            )}
          </div>
        </div>

        {/* Colonne Objectif + Contraintes */}
        <div className="space-y-3">
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs">
            <div className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wide">
              Objectif stratégique O
            </div>
            <div className="font-medium text-slate-900 mt-1">
              {objective.name}
            </div>
            <div className="text-[11px] text-slate-700 mt-1">
              {objective.description}
            </div>
            <div className="mt-2 text-[11px] text-slate-600">
              O est défini comme une combinaison pondérée de contraintes
              {objective.constraints.length > 0 && (
                <>
                  {" "}
                  (|C| = {objective.constraints.length}) avec des poids{" "}
                  <em>w(c<sub>i</sub>)</em> tels que{" "}
                  <strong>φ(QP,O)</strong> mesure la part du poids total
                  couverte par Ceval(QP,O).
                </>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide">
              Contraintes C = {"{"} c<sub>1</sub>, …, c<sub>n</sub> {"}"}
            </div>
            <div className="space-y-1 max-h-60 overflow-auto pr-1">
              {objective.constraints.map((c) => (
                <div
                  key={c.id}
                  className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-[11px]"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-800">
                      {c.id}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      KPI: {c.kpi_id} · w={c.weight.toFixed(2)}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 mt-1">
                    {c.description}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {c.virtual_nodes.length} nœud(s) virtuel(s) associé(s).
                  </div>
                </div>
              ))}
              {objective.constraints.length === 0 && (
                <div className="text-[11px] text-slate-400">
                  Aucune contrainte n&apos;est encore définie.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Colonne Nœuds virtuels */}
        <div className="space-y-2">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide">
            Nœuds virtuels NV (points d&apos;accès OLAP)
          </div>
          <div className="space-y-1 max-h-72 overflow-auto pr-1">
            {allVirtualNodes.length === 0 && (
              <div className="text-[11px] text-slate-400">
                Aucune définition explicite de nœud virtuel ; le mapping vers
                l&apos;entrepôt est implicite.
              </div>
            )}
            {allVirtualNodes.map((nv) => (
              <div
                key={nv.id}
                className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-[11px]"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-800">
                    {nv.id}
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {nv.fact} · {nv.measure} ({nv.aggregator})
                  </span>
                </div>
                <div className="text-[10px] text-slate-600 mt-1">
                  Grain: {nv.grain.join(" × ")}
                </div>
                {Object.keys(nv.slicers || {}).length > 0 && (
                  <div className="text-[10px] text-slate-500 mt-1">
                    Filtres:{" "}
                    {Object.entries(nv.slicers)
                      .map(([k, v]) => `${k}=${v}`)
                      .join(", ")}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <p className="text-[11px] text-slate-500 mt-3">
        Cette vue illustre la structure du CKG au-dessus de l&apos;entrepôt :
        l&apos;objectif O, les contraintes C, et les nœuds virtuels NV
        correspondant à des points de calcul OLAP. Ce graphe est utilisé par le
        MCAD pour vérifier la calculabilité Ceval(QP,O) d&apos;une requête QP et
        mesurer φ(QP,O).
      </p>
    </div>
  );
}

export default CkgGraphView;