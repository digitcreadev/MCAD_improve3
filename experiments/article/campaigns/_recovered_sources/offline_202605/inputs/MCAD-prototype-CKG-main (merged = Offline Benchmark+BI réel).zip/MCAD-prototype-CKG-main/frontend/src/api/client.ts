import axios from "axios";
import type {
  Objective,
  SessionState,
  EvaluateVisualMdxResponse,
  VisualMdxQP,
  SessionTimelineResponse,
  ObjectivePerformanceResponse
} from "./types";

const API_BASE_URL =
  import.meta.env.VITE_MCAD_API_URL || "http://127.0.0.1:8000";

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json"
  }
});

/* --- Objectifs --- */

export async function fetchObjectives(): Promise<Objective[]> {
  const res = await api.get<Objective[]>("/objectives");
  return res.data;
}

export async function createObjective(obj: Objective): Promise<Objective> {
  const res = await api.post<Objective>("/objectives", obj);
  return res.data;
}

export async function updateObjective(obj: Objective): Promise<Objective> {
  const res = await api.put<Objective>(`/objectives/${obj.id}`, obj);
  return res.data;
}

export async function cloneObjective(id: string): Promise<Objective> {
  const res = await api.post<Objective>(`/objectives/${id}/clone`);
  return res.data;
}

/* --- Sessions & MDX --- */

export async function listSessions(
  objectiveId?: string
): Promise<SessionState[]> {
  const res = await api.get<SessionState[]>("/sessions", {
    params: objectiveId ? { objective_id: objectiveId } : undefined
  });
  return res.data;
}

export async function createSession(
  objectiveId: string,
  dwId = "FOODMART"
): Promise<SessionState> {
  const res = await api.post<SessionState>("/sessions", {
    objective_id: objectiveId,
    dw_id: dwId
  });
  return res.data;
}

export async function closeSession(sessionId: string): Promise<SessionState> {
  const res = await api.post<SessionState>(`/sessions/${sessionId}/close`);
  return res.data;
}

export async function evaluateVisualMdx(
  sessionId: string,
  objectiveId: string,
  qp: VisualMdxQP
): Promise<EvaluateVisualMdxResponse> {
  const res = await api.post<EvaluateVisualMdxResponse>(
    `/sessions/${sessionId}/evaluate_visual_mdx`,
    {
      objective_id: objectiveId,
      qp
    }
  );
  return res.data;
}

/* --- Analytics --- */

export async function fetchSessionTimeline(
  sessionId: string
): Promise<SessionTimelineResponse> {
  const res = await api.get<SessionTimelineResponse>(
    `/analytics/sessions/${sessionId}/timeline`
  );
  return res.data;
}

export async function fetchObjectivePerformance(
  objectiveId: string
): Promise<ObjectivePerformanceResponse> {
  const res = await api.get<ObjectivePerformanceResponse>(
    `/analytics/objectives/${objectiveId}/performance`
  );
  return res.data;
}
