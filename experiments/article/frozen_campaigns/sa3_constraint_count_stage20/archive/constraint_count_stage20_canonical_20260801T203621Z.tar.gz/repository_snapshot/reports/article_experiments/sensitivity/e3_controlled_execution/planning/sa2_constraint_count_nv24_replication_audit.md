# SA2 constraint-count NV24 replication audit

## Candidate design

- Factor: `constraint_count`
- Levels: `2, 4, 8, 12, 16`
- Fixed virtual-node count: `24`
- Pilot seeds: `101, 202`
- Scientific freeze: no

## Per-replication audit

| Replication | Seed | Instances | Common query specs | Usable |
|---:|---:|---:|---:|---|
| 0 | 101 | 5 | 2 | True |
| 1 | 202 | 5 | 2 | True |

## Decision signal

- All replications usable: `True`
- Status: `nv24_candidate_supported_by_replication_common_workloads`

The sensitivity campaign remains open. This audit does not constitute a scientific freeze.
