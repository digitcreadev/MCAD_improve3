# SA3 stage-20 precision analysis

## Bootstrap contract

- Structural seed clusters: `20`
- Measurements per seed and cell: `100`
- Bootstrap repetitions: `10000`
- Confidence level: `95%`
- Median precision target: `10%`
- p95 precision target: `15%`

| Level | Step | Median | Median RHW | p95 | p95 RHW | Pass |
|---:|---:|---:|---:|---:|---:|---|
| 2 | 1 | 0.688225 | 1.68% | 1.309281 | 2.99% | True |
| 2 | 2 | 0.641389 | 1.50% | 1.237807 | 1.52% | True |
| 4 | 1 | 0.528427 | 1.51% | 0.982493 | 2.42% | True |
| 4 | 2 | 0.479175 | 1.01% | 0.930733 | 1.83% | True |
| 8 | 1 | 0.468394 | 1.47% | 0.849878 | 1.42% | True |
| 8 | 2 | 0.412898 | 0.89% | 0.785628 | 1.47% | True |
| 12 | 1 | 0.486799 | 1.60% | 0.906219 | 2.42% | True |
| 12 | 2 | 0.434046 | 0.90% | 0.842558 | 1.80% | True |
| 16 | 1 | 0.489721 | 1.36% | 0.906273 | 1.41% | True |
| 16 | 2 | 0.437358 | 0.70% | 0.838160 | 1.91% | True |

## Gate result

- All median targets met: `True`
- All p95 targets met: `True`
- Stage sufficient: `True`
- Extension required: `False`
- Next stage: `SA4_membership_density_design`

Scientific freeze and final latency claims remain disabled.
