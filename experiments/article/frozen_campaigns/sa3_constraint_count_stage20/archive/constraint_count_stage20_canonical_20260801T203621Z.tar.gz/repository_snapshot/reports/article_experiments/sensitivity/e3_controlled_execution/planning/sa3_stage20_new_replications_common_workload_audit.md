# SA3 stage-20 new-replication workload audit

## Scope

- Preserved replications: `0–9`
- Newly audited replications: `10–19`
- New instances: `50`
- Required common queries per replication: `2`
- Scientific freeze: `false`

| Replication | Seed | Common queries | Raw occurrences | Usable | State |
|---:|---:|---:|---|---|---|
| 10 | 630497049 | 2 | [5, 5] | True | created |
| 11 | 1826704550 | 2 | [5, 5] | True | created |
| 12 | 668799093 | 2 | [5, 5] | True | created |
| 13 | 1989792316 | 2 | [5, 5] | True | created |
| 14 | 625293714 | 2 | [5, 5] | True | created |
| 15 | 578407288 | 2 | [5, 5] | True | created |
| 16 | 1347026516 | 2 | [5, 5] | True | created |
| 17 | 1457944287 | 2 | [5, 5] | True | created |
| 18 | 134577186 | 2 | [5, 5] | True | created |
| 19 | 1985010596 | 2 | [5, 5] | True | created |

## Gate result

- Usable new replications: `10/10`
- All new replications usable: `True`
- Total strict-common queries: `20`
- Next stage: `SA3_stage_20_new_execution_preparation`

No controlled execution or timing execution was performed.
