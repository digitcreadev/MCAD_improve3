# SA2 constraint-count NV24 pilot execution

## Design

- Levels: `2, 4, 8, 12, 16`
- Fixed virtual-node count: `24`
- Pilot seeds: `101, 202`
- Common workload steps per replication: `2`

## Execution summary

- Successful runs: `2`
- Executed instances: `10`
- Executed steps: `20`
- Failed instances: `0`
- Failed steps: `0`

| Replication | Seed | Instances | Steps | Status |
|---:|---:|---:|---:|---|
| 0 | 101 | 5 | 10 | success |
| 1 | 202 | 5 | 10 | success |

## Scientific status

The NV24 constraint-count candidate passed its pilot execution gate.
The sensitivity campaign remains open. Two structural replications do not authorize final latency, percentile, effect-size or confidence-interval claims.

## Next gate

SA3 — extended independent seeds and temporal repetition protocol.
