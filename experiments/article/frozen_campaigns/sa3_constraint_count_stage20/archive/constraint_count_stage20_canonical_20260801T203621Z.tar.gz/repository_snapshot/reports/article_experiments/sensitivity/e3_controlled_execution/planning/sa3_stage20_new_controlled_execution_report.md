# SA3 stage-20 new controlled execution

## New evidence

- New runs: `10/10`
- New instance results: `50`
- New executed steps: `100`
- New timelines: `50`
- New failed instances: `0`
- New failed steps: `0`

## Preserved evidence

- Preserved stage-10 runs: `10`
- Preserved stage-10 evidence unchanged: `true`

## Combined controlled evidence

- Structural seeds: `20`
- Controlled runs: `20`
- Instance results: `100`
- Executed steps: `200`
- Timelines: `100`

## New runs

| Replication | Seed | State | Instances | Steps | Timelines |
|---:|---:|---|---:|---:|---:|
| 10 | 630497049 | executed | 5 | 10 | 5 |
| 11 | 1826704550 | executed | 5 | 10 | 5 |
| 12 | 668799093 | executed | 5 | 10 | 5 |
| 13 | 1989792316 | executed | 5 | 10 | 5 |
| 14 | 625293714 | executed | 5 | 10 | 5 |
| 15 | 578407288 | executed | 5 | 10 | 5 |
| 16 | 1347026516 | executed | 5 | 10 | 5 |
| 17 | 1457944287 | executed | 5 | 10 | 5 |
| 18 | 134577186 | executed | 5 | 10 | 5 |
| 19 | 1985010596 | executed | 5 | 10 | 5 |

## Next stage

`SA3_stage_20_new_formal_timing_execution`

No stage-10 controlled run must be rerun during the next stage.
