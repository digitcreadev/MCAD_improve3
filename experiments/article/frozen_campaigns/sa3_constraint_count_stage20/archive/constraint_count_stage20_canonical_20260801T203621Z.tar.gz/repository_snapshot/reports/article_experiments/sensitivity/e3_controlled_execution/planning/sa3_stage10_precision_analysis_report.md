# SA3 stage-10 precision analysis

## Bootstrap contract

- Resampling unit: structural seed
- Seed clusters: `10`
- Measurements per seed and cell: `100`
- Bootstrap repetitions: `10000`
- Confidence level: `95%`
- Median precision target: `10%`
- p95 precision target: `15%`

## Cell results

| Level | Step | Median | Median RHW | p95 | p95 RHW | Pass |
|---:|---:|---:|---:|---:|---:|---|
| 2 | 1 | 0.669318 | 1.75% | 1.072513 | 21.35% | False |
| 2 | 2 | 0.637768 | 2.53% | 1.067574 | 23.39% | False |
| 4 | 1 | 0.514997 | 1.37% | 0.887026 | 19.42% | False |
| 4 | 2 | 0.475992 | 1.29% | 0.891346 | 1.66% | True |
| 8 | 1 | 0.452954 | 1.53% | 0.792720 | 8.40% | True |
| 8 | 2 | 0.410146 | 1.08% | 0.640447 | 21.81% | False |
| 12 | 1 | 0.472386 | 1.07% | 0.715513 | 20.13% | False |
| 12 | 2 | 0.431642 | 1.26% | 0.787884 | 18.31% | False |
| 16 | 1 | 0.476087 | 0.97% | 0.848778 | 11.01% | True |
| 16 | 2 | 0.434281 | 0.89% | 0.815105 | 6.48% | True |

## Gate result

- All median targets met: `True`
- All p95 targets met: `False`
- Stage 10 sufficient: `False`
- Extension to stage 20 required: `True`
- Next stage: `SA3_stage_20_generation`

Scientific freeze and final latency claims remain disabled until the complete sensitivity programme is audited and frozen.
