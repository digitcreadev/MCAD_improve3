# SA3 stage-10 formal timing execution

## Protocol completion

- Formal timing runs: `10/10`
- Timing cells: `100`
- Functional references: `100`
- Warm-up observations: `1,000`
- Measured observations: `10,000`
- Fresh CKG builds: `11,100`
- Functional mismatches: `0`
- Exactly balanced runs: `10/10`
- Scientific freeze: `false`
- Final latency claim authorized: `false`

## Aggregate files

- `reports/article_experiments/sensitivity/e3_controlled_execution/planning/aggregates/constraint_count_nv24_stage10/formal_timing/formal_timing_observations.csv`
- `reports/article_experiments/sensitivity/e3_controlled_execution/planning/aggregates/constraint_count_nv24_stage10/formal_timing/seed_level_step_summary.csv`
- `reports/article_experiments/sensitivity/e3_controlled_execution/planning/aggregates/constraint_count_nv24_stage10/formal_timing/level_step_descriptive_summary.csv`

## Next stage

`SA3_stage_10_precision_analysis`

The descriptive summaries are not cluster-adjusted and must not yet be reported as final latency estimates.
