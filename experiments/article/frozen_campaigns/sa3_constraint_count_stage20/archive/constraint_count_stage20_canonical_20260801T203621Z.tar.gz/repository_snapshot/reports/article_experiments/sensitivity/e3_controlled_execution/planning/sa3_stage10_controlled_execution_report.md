# SA3 stage-10 controlled execution

- Formal runs: `10/10`
- Instance results: `50`
- Executed steps: `100`
- Timelines: `50`
- Failed instances: `0`
- Failed steps: `0`
- Formal timing started: `false`
- Scientific freeze: `false`

## Runs

| Replication | Seed | State | Instances | Steps |
|---:|---:|---|---:|---:|
| 0 | 101 | executed | 5 | 10 |
| 1 | 202 | executed | 5 | 10 |
| 2 | 1198202409 | executed | 5 | 10 |
| 3 | 796786883 | executed | 5 | 10 |
| 4 | 1126922093 | executed | 5 | 10 |
| 5 | 809989256 | executed | 5 | 10 |
| 6 | 618554674 | executed | 5 | 10 |
| 7 | 1363159082 | executed | 5 | 10 |
| 8 | 874332939 | executed | 5 | 10 |
| 9 | 1767972531 | executed | 5 | 10 |

## Next stage

`SA3_stage_10_formal_timing_execution`
