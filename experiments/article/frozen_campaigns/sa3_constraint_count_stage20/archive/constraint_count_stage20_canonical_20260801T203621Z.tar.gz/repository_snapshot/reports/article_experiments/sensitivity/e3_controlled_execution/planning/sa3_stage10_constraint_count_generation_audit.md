# SA3 stage-10 constraint-count audit

## Corrected validation rule

A strict-common query must cover all five selected instances. Multiple occurrences inside the same instance are permitted.

## Formal campaign

- Instances: `50`
- Structural seeds: `10`
- Levels: `2, 4, 8, 12, 16`
- Fixed virtual-node count: `24`
- Deterministic generation: `true`
- Scientific freeze: `false`

| Replication | Seed | Common queries | Raw occurrence counts | Usable |
|---:|---:|---:|---|---|
| 0 | 101 | 2 | [5, 5] | True |
| 1 | 202 | 2 | [5, 5] | True |
| 2 | 1198202409 | 2 | [5, 5] | True |
| 3 | 796786883 | 2 | [5, 5] | True |
| 4 | 1126922093 | 2 | [5, 6] | True |
| 5 | 809989256 | 2 | [5, 5] | True |
| 6 | 618554674 | 2 | [5, 5] | True |
| 7 | 1363159082 | 2 | [5, 5] | True |
| 8 | 874332939 | 2 | [5, 5] | True |
| 9 | 1767972531 | 2 | [5, 5] | True |

## Gate result

- Usable replications: `10/10`
- All replications usable: `True`
- Total strict-common queries: `20`
- Next stage: `SA3_stage_10_execution_preparation`

No formal E3 or timing execution was performed during this audit.
