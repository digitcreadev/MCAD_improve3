# SA3 stage-20 constraint-count generation

## Extension decision

- Stage 10 sufficient: `false`
- Failing p95 precision cells: `6`
- Extension to stage 20: `required`

## Generated design

- Structural seeds: `20`
- Factor levels: `2, 4, 8, 12, 16`
- Instances: `100`
- Fixed virtual-node count: `24`
- Preserved stage-10 instances: `50`
- New instances: `50`
- Prefix bitwise identity: `true`
- Deterministic generation: `true`
- Scientific freeze: `false`

## Next stage

`SA3_stage_20_common_workload_audit`

Only replications 10 through 19 require new execution evidence.
