# SA3 stage-10 execution preparation

## Formal design

- Structural replications: `10`
- Levels per replication: `5`
- Instances selected: `50`
- Workload steps per replication: `2`
- Workloads generated: `10`
- Execution specs generated: `10`
- Discover-only validations: `10/10`
- Controlled execution started: `false`
- Formal timing started: `false`
- Scientific freeze: `false`

## Prepared replications

| Replication | Seed | Instances | Steps | Discovery |
|---:|---:|---:|---:|---|
| 0 | 101 | 5 | 2 | success |
| 1 | 202 | 5 | 2 | success |
| 2 | 1198202409 | 5 | 2 | success |
| 3 | 796786883 | 5 | 2 | success |
| 4 | 1126922093 | 5 | 2 | success |
| 5 | 809989256 | 5 | 2 | success |
| 6 | 618554674 | 5 | 2 | success |
| 7 | 1363159082 | 5 | 2 | success |
| 8 | 874332939 | 5 | 2 | success |
| 9 | 1767972531 | 5 | 2 | success |

## Next stage

`SA3_stage_10_controlled_execution`
