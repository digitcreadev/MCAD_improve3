# SA4 membership-density controlled-execution audit

- Status: `success`
- Partitions: `10`
- Instances: `40`
- Total controlled steps: `952`
- Output files: `200`
- Published instance directories: `40`
- Transient runtime roots absent: `10`
- Archived execution logs: `10`
- Controlled execution audited: `true`
- Timing execution authorized: `false`
- Scientific freeze: `false`

## Next stage

`SA4_membership_density_controlled_execution_freeze`
