# SA4 exact historical recovery validation

- Validation status: **PASS**
- Source commit: `36fe29d42c8ca53e79e5fa2a8dc35df6e1860c48`
- Partitions: 10
- Instances: 40
- Controlled steps: 952
- Canonical outputs: 200
- Archived logs: 10
- Frozen manifest entries: 212
- Manifest entries passing: 212
- Manifest entries failing: 0
- Runtime transient roots absent: 10/10
- Timing execution authorized: false
- Latency claim authorized: false
