MCAD SA4 membership-density Stage-10 canonical payload

Source commit: 39da63c63a3062a79460377280758771d934c9b4
Factor: membership_density
Stage: 10
Successful bootstrap executions: 1
All precision targets met: true
Stage-10 sufficient: true
Stage-20 extension required: false

Validate with:
  sha256sum -c PAYLOAD_SHA256SUMS
