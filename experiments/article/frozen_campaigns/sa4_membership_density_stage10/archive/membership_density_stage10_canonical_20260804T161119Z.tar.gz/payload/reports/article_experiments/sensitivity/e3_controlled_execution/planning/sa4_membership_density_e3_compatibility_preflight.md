# SA4 membership-density E3 compatibility preflight

## Generator versions

- Structural: `mcad-sensitivity-e2.1-membership-density-v1`
- Campaign: `mcad-sensitivity-e2.2-membership-density-v1`

## Compatibility

- Structural version directly accepted: `False`
- Campaign version directly accepted: `False`
- Membership-density factor explicitly covered: `False`
- Status: `e3_compatibility_extension_required`

## Gaps

- `density_structural_version_not_accepted`
- `density_campaign_version_not_accepted`
- `membership_density_factor_not_explicitly_covered`

No canonical campaign or execution was started.
