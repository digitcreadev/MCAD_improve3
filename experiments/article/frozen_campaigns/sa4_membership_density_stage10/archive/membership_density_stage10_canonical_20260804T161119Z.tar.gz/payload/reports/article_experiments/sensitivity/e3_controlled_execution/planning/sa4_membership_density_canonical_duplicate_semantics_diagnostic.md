# SA4 duplicate-semantic diagnostic

- Classification: `stable_duplicate_semantics_within_replications`
- Affected instances: `8`
- Affected replications: `4, 9`
- Semantic sets invariant: `True`
- Semantic multisets invariant: `True`
- Exact full-node duplicate groups: `0`
- Semantic-only duplicate groups: `8`
- Cross-constraint duplicate groups: `0`

- Canonical campaign generated: `false`
- Controlled execution started: `false`
- Timing execution started: `false`

## Next stage

`SA4_membership_density_duplicate_semantics_contract_review`
