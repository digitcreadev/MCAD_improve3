# SA4 membership-density capability audit

## Constraint-count gate

- Stage 20 sufficient: `true`
- Stage 30 required: `false`
- Failing precision cells: `0`

## Generator capability

- Native membership-density support proven: `False`
- Capability status: `generator_extension_required`
- Explicit density specification fields: `[]`
- Integer-only level contract detected: `True`
- Targeted membership-density tests found: `2`
- Independent oracle signals found: `0`

## Identified gaps

- `missing_membership_density_factor_branch`
- `missing_explicit_density_specification_field`
- `density_level_encoding_requires_design_decision`
- `missing_independent_density_oracle`

## Next stage

`SA4_membership_density_design_contract`

No controlled instances or timing measurements were generated.
