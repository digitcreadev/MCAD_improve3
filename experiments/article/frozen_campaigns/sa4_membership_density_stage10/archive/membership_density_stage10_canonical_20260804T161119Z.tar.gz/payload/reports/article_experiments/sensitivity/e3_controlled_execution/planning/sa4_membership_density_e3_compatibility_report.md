# SA4 membership-density E3 compatibility

- E3 executor version: `mcad-sensitivity-e3-v2`
- Factor-specific profiles: `true`
- Legacy profiles preserved: `true`
- Density profile accepted: `true`
- Cross-factor pairs rejected: `true`
- Actual campaign version recorded: `true`
- Timing harness modified: `false`
- Canonical campaign generated: `false`
- Source commit: `7bbe1f084e5096c354b4ce52afb253e1a6c28f94`

## Next stage

`SA4_membership_density_common_workload_audit_design`
