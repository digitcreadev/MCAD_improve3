# SA4 membership-density canonical campaign preregistration

- Status: `frozen`
- Campaign: `membership_density_stage10_c4_nv24`
- Density levels: `25, 50, 75, 100`
- Structural seeds: `10`
- Expected instances: `40`
- Additional seeds are a continuation: `true`
- Alternative seed schedule: `false`
- Generation authorized: `true`
- Canonical campaign generated: `false`
- Source commit: `1880d15005b484bd22b327c168eb4dcc487a6933`

## Frozen seeds

`101, 202, 1198202409, 796786883, 1126922093, 809989256, 618554674, 1363159082, 874332939, 1767972531`

## Next stage

`SA4_membership_density_canonical_campaign_generation`
