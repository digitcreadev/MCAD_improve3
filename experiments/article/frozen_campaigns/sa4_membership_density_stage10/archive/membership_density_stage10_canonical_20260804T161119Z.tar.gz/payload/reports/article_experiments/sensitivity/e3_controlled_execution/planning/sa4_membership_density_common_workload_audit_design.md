# SA4 membership-density common-workload audit design

## Temporary design family

- Levels: `25, 50, 75, 100`
- Structural seeds: `101, 202`
- Instances: `8`
- Canonical campaign: `false`

## Semantic workload

- Strict common semantic nodes: `0`
- Semantic union: `48`
- Same workload across levels: `True`
- Same workload across seeds: `False`
- Unique candidate query specs: `0`

## Design decision

A dedicated, campaign-parameterized density auditor is required.
It must verify that membership links are the only varying structural element.
It must emit the strict common query specifications without relying on technical node identifiers.

No canonical campaign or execution was started.
