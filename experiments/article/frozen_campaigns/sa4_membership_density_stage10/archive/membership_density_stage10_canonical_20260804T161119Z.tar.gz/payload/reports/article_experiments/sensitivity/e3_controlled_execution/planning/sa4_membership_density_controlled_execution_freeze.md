# SA4 membership-density controlled-execution freeze

- Status: `success`
- Partitions: `10`
- Instances: `40`
- Total controlled steps: `952`
- Frozen evidence files: `212`
- Controlled execution frozen: `true`
- Timing preregistration authorized: `true`
- Timing execution authorized: `false`
- Latency claim authorized: `false`
- Scientific freeze: `false`

## Next stage

`SA4_membership_density_timing_preregistration_preflight`
