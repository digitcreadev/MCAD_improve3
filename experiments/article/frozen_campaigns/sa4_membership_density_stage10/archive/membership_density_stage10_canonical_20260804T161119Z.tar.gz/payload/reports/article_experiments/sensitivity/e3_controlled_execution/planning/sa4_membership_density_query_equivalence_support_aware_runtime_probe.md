# SA4 support-aware query-equivalence runtime probe

- Probe instances: `8`
- Equivalent pairs realized together: `true`
- First gains match active supports: `true`
- Support progress consistent: `true`
- Repeated query adds no resource: `true`
- Second evaluation contributive: `false`
- Expected partition sizes: `2 × 23, 8 × 24`
- Workload decision: `deduplicate by canonical query specification while preserving equivalence-class metadata`

- Canonical campaign generated: `false`
- Controlled execution started: `false`
- Timing execution started: `false`

## Next stage

`SA4_membership_density_query_equivalence_contract_amendment`
