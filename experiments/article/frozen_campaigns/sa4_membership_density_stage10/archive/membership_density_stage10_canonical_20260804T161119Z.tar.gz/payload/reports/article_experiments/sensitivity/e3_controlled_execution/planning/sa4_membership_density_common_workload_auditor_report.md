# SA4 membership-density common-workload auditor

- Auditor implementation: `success`
- Strategy: `one workload per structural seed`
- Levels per partition: `25, 50, 75, 100`
- Steps per workload: `24`
- Membership links: `6, 12, 18, 24`
- Nested memberships: `true`
- Global workload authorized: `false`
- Canonical campaign generated: `false`
- Source commit: `f5f2f09a49e83f7836d88b28b82dd6a7520806f9`

## Next stage

`SA4_membership_density_canonical_campaign_preregistration`
