# SA4 canonical partition-spec preregistration preflight

- Status: `success`
- Canonical campaign: `present`
- Canonical audit: `valid`
- Instances: `40`
- Partitions: `10`
- Partition key: `replication_index`
- Step histogram: `2 x 23, 8 x 24`
- Query-equivalence replications: `4, 9`
- Abandoned staging paths: `0`
- Partition specs generated: `false`
- Controlled execution started: `false`

## Next stage

`SA4_membership_density_canonical_partition_spec_preregistration_implementation`
