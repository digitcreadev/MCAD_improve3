# SA4 canonical partition-spec audit and freeze

- Status: `success`
- Audited partitions: `10`
- Selected instances: `40`
- Total canonical workload steps: `238`
- Total structural virtual nodes: `240`
- Step histogram: `2 x 23, 8 x 24`
- Query-equivalence replications: `4, 9`
- Frozen inputs: `true`
- Controlled execution authorized: `true`
- Controlled execution started: `false`
- Timing execution authorized: `false`
- Scientific freeze: `false`

## Next stage

`SA4_membership_density_controlled_execution_preflight`
