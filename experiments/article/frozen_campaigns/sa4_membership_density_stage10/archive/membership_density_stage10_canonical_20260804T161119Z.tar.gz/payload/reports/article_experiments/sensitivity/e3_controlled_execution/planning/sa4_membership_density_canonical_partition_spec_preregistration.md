# SA4 canonical partition-spec preregistration

- Status: `frozen`
- Partitions: `10`
- Instances per partition: `4`
- Step histogram: `2 x 23, 8 x 24`
- Binding normalization: strip `instances/` for comparison only
- Execution selection paths preserved: `true`
- Equivalence metadata preserved outside workload schema: `true`
- Execution output directories created: `false`
- Controlled execution authorized: `false`
- Controlled execution started: `false`

## Next stage

`SA4_membership_density_canonical_partition_spec_audit_and_freeze`
