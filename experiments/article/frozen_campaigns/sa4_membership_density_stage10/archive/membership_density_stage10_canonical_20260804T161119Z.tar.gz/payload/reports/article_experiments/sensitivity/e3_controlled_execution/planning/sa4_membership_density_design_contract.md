# SA4 membership-density design contract

## Exact density model

- Baseline constraints: `4`
- Baseline virtual nodes: `24` total
- Requirement sets: `4`
- Maximum memberships: `24`
- Rejected global-product denominator: `96`

| Density | Membership links |
|---:|---:|
| 25% | 6 |
| 50% | 12 |
| 75% | 18 |
| 100% | 24 |

## Experimental invariants

- Membership sets are deterministic.
- Membership sets are nested across levels.
- Allocation is balanced across constraints.
- Every requirement set remains nonempty.
- Non-membership semantics remain fixed.
- Unknown and duplicate references are forbidden.

## State

- Independent oracle implemented: `true`
- Instances generated: `false`
- Controlled execution started: `false`
- Timing execution started: `false`
- Scientific freeze: `false`

## Next stage

`SA4_membership_density_generator_extension`
