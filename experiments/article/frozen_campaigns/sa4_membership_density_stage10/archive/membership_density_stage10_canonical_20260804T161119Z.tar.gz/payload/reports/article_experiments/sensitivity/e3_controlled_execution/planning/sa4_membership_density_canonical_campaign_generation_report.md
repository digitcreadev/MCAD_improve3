# SA4 amended canonical campaign generation

- Status: `success`
- Campaign: `membership_density_stage10_c4_nv24`
- Instances: `40`
- Structural replications: `10`
- Structural virtual nodes per partition: `24`
- Workload step histogram: `2 x 23, 8 x 24`
- Query-equivalence replications: `4, 9`
- Equivalence-class metadata preserved: `true`
- Global workload authorized: `false`
- Controlled execution started: `false`
- Timing execution started: `false`
- Campaign digest: `2504dfa883a74daae99a6ac9922cb779e294eb18bed0ab6f3df43da79d9c45a9`
- Audit digest: `cc687d3660c96661c548ec195eba16161e17d2b72f79ee9ee48c1490f3ad91b1`
- Blueprint bundle digest: `7728bba3b6df3c102bff5c457b3fae0ae8de6d07711c0d99808493a5ca0ae87c`

## Next stage

`SA4_membership_density_canonical_partition_spec_preregistration`
