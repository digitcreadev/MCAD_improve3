# SA4 query-equivalence contract amendment

- Status: `success`
- Workload equivalence key: `canonical_query_spec_digest`
- Structural virtual nodes per partition: `24`
- Allowed workload steps: `23 or 24`
- Expected histogram: `2 x 23, 8 x 24`
- Equivalence-class metadata preserved: `true`
- Generator changed: `false`
- Evaluator changed: `false`
- Canonical campaign generated: `false`
- Controlled execution started: `false`
- Amendment commit: `36fe29d42c8ca53e79e5fa2a8dc35df6e1860c48`

## Next stage

`SA4_membership_density_canonical_campaign_generation`
