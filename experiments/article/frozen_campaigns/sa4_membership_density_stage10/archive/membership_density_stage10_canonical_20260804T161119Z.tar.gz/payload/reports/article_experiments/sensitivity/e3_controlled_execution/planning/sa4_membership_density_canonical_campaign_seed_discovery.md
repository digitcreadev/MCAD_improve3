# SA4 membership-density canonical seed discovery

## Classification

- Status: `seed_schedule_disambiguation_required`
- Authoritative candidate count: `13`
- Distinct authoritative first-ten sequences: `2`

## Safety state

- Preregistration frozen: `false`
- Canonical campaign generated: `false`
- Controlled execution started: `false`
- Timing execution started: `false`

## Next stage

`SA4_membership_density_seed_source_disambiguation`
