from __future__ import annotations

import csv
import json
import os
import sys
from collections import Counter
from pathlib import Path
from typing import Any

RESULTS = Path(os.environ["RESULTS_DIR"])
OUT_JSON = Path(os.environ["VALIDATION_JSON"])
OUT_MD = Path(os.environ["VALIDATION_MD"])
EXPECTED_HEAD = os.environ["EXPECTED_HEAD"]
SOURCE_TREE_UNCHANGED = os.environ.get("SOURCE_TREE_UNCHANGED") == "true"

checks: list[dict[str, Any]] = []


def add_check(name: str, actual: Any, expected: Any) -> None:
    checks.append(
        {
            "name": name,
            "actual": actual,
            "expected": expected,
            "ok": actual == expected,
        }
    )


def read_csv(name: str) -> list[dict[str, str]]:
    path = RESULTS / name
    if not path.is_file():
        add_check(f"file_present::{name}", False, True)
        return []
    add_check(f"file_present::{name}", True, True)
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter=";"))


def as_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


expected_nonempty_files = [
    "robustness_report.md",
    "figures/robustness_false_allow_by_policy.png",
    "figures/robustness_false_block_by_policy.png",
    "figures/robustness_auc_phi_by_policy.png",
    "figures/robustness_false_allow_by_type.png",
    "figures/robustness_block_reason_distribution_mcad.png",
    "figures/robustness_explainable_block_rate_by_type.png",
]

for relative in expected_nonempty_files:
    path = RESULTS / relative
    add_check(f"nonempty_file::{relative}", path.is_file() and path.stat().st_size > 0, True)

sessions = read_csv("robustness_policy_session_metrics.csv")
steps = read_csv("robustness_policy_step_metrics.csv")
policy_summary = read_csv("robustness_policy_summary.csv")
by_type = read_csv("robustness_summary_by_scenario_type_and_policy.csv")
explain = read_csv("mcad_block_explainability_steps.csv")
explain_summary = read_csv("mcad_block_explainability_summary.csv")
reason_rows = read_csv("mcad_block_reason_distribution.csv")

expected_policies = {
    "mcad",
    "baseline_naive",
    "baseline_measure_overlap",
    "ablation_no_sat",
    "ablation_no_real",
    "ablation_ceval_any_intersection",
    "baseline_random_matched",
}
expected_scenarios = {
    "rb_fm_clause_diagnostics",
    "rb_fm_semantic_traps",
    "rb_fm_long_noisy_session",
    "rb_fm_borderline_recovery",
    "rb_aw_clause_diagnostics",
    "rb_aw_semantic_traps",
    "rb_aw_long_noisy_session",
    "rb_aw_borderline_recovery",
}
expected_types = {
    "adversarial_sat",
    "adversarial_semantic",
    "stress_long",
    "noisy_borderline",
}
expected_reason_distribution = {
    "agg_ok": 2,
    "grain_ok": 10,
    "measures_present": 2,
    "missing_requirement_set": 4,
    "slc_ok": 12,
    "time_ok": 2,
    "unit_ok": 2,
}

policies = {row.get("policy", "") for row in sessions}
scenarios = {row.get("scenario_id", "") for row in sessions}
scenario_types = {row.get("scenario_type", "") for row in sessions}
config_paths = {row.get("config_path", "") for row in sessions}
repeat_ids = {row.get("repeat_id", "") for row in sessions}

mcad_sessions = [row for row in sessions if row.get("policy") == "mcad"]
mcad_steps = [row for row in steps if row.get("policy") == "mcad"]
mcad_allows = [row for row in explain if as_bool(row.get("mcad_allow"))]
mcad_blocks = [row for row in explain if not as_bool(row.get("mcad_allow"))]
oracle_mismatches = [
    row
    for row in explain
    if as_bool(row.get("mcad_allow")) != as_bool(row.get("oracle_allow"))
]
unexplained_blocks = [
    row
    for row in mcad_blocks
    if not as_bool(row.get("explainable_block"))
]
unclassified_blocks = [
    row
    for row in mcad_blocks
    if row.get("primary_reason") == "unclassified_block"
]

reason_distribution = {
    row.get("primary_reason", ""): int(row.get("count") or 0)
    for row in reason_rows
}

add_check("session_rows", len(sessions), 1680)
add_check("step_rows", len(steps), 9660)
add_check("policy_summary_rows", len(policy_summary), 7)
add_check("summary_by_type_policy_rows", len(by_type), 28)
add_check("policy_count", len(policies), 7)
add_check("policy_set", sorted(policies), sorted(expected_policies))
add_check("scenario_count", len(scenarios), 8)
add_check("scenario_set", sorted(scenarios), sorted(expected_scenarios))
add_check("scenario_type_count", len(scenario_types), 4)
add_check("scenario_type_set", sorted(scenario_types), sorted(expected_types))
add_check("config_path_count", len(config_paths), 2)
add_check("repeat_id_count", len(repeat_ids), 30)
add_check("mcad_session_rows", len(mcad_sessions), 240)
add_check("mcad_step_rows", len(mcad_steps), 1380)
add_check("explainability_rows", len(explain), 46)
add_check("explainability_summary_rows", len(explain_summary), 4)
add_check("mcad_allow_count", len(mcad_allows), 12)
add_check("mcad_block_count", len(mcad_blocks), 34)
add_check("oracle_mismatch_count", len(oracle_mismatches), 0)
add_check("unexplained_block_count", len(unexplained_blocks), 0)
add_check("unclassified_block_count", len(unclassified_blocks), 0)
add_check("reason_total", sum(reason_distribution.values()), 34)
add_check("reason_distribution", reason_distribution, expected_reason_distribution)
add_check("source_commit", EXPECTED_HEAD, "185290880a75d6df17c03aad6abbb44ca3818bf0")
add_check("source_tree_unchanged", SOURCE_TREE_UNCHANGED, True)

meta_path = RESULTS / "robustness_meta.json"
if meta_path.is_file():
    add_check("file_present::robustness_meta.json", True, True)
    metadata = json.loads(meta_path.read_text(encoding="utf-8"))
else:
    add_check("file_present::robustness_meta.json", False, True)
    metadata = []

add_check("metadata_entry_count", len(metadata), 2)
add_check("metadata_seed_values", sorted({entry.get("seed") for entry in metadata}, key=repr), [42])
add_check("metadata_repeat_values", sorted({entry.get("repeats") for entry in metadata}, key=repr), [30])
add_check("metadata_scenario_counts", sorted((entry.get("n_scenarios") for entry in metadata), key=repr), [4, 4])
add_check(
    "metadata_config_paths",
    sorted((entry.get("config_path") for entry in metadata), key=repr),
    sorted(
        [
            "backend/harness/scenarios_robustness_foodmart.yaml",
            "backend/harness/scenarios_robustness_adventureworks.yaml",
        ]
    ),
)

all_ok = all(item["ok"] for item in checks)
report = {
    "schema": "mcad.robustness.canonical.validation.v1",
    "results_dir": str(RESULTS),
    "source_commit": EXPECTED_HEAD,
    "scientific_validation_pass": all_ok,
    "checks": checks,
}
OUT_JSON.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

lines = [
    "# MCAD canonical robustness validation",
    "",
    f"- Results: `{RESULTS}`",
    f"- Source commit: `{EXPECTED_HEAD}`",
    f"- Scientific validation: **{'PASS' if all_ok else 'FAIL'}**",
    "",
    "| Check | Actual | Expected | Status |",
    "|---|---:|---:|---|",
]
for item in checks:
    lines.append(
        f"| {item['name']} | `{item['actual']}` | `{item['expected']}` | "
        f"{'PASS' if item['ok'] else 'FAIL'} |"
    )
OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")

if not all_ok:
    failed = [item["name"] for item in checks if not item["ok"]]
    print("validation_failed_checks=" + ",".join(failed))
    raise SystemExit(1)

print("robustness_scientific_validation=PASS")
