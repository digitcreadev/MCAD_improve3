# MCAD canonical robustness validation

- Results: `/workspaces/mcad_robustness_canonical_20260731T223533Z/results`
- Source commit: `185290880a75d6df17c03aad6abbb44ca3818bf0`
- Scientific validation: **PASS**

| Check | Actual | Expected | Status |
|---|---:|---:|---|
| nonempty_file::robustness_report.md | `True` | `True` | PASS |
| nonempty_file::figures/robustness_false_allow_by_policy.png | `True` | `True` | PASS |
| nonempty_file::figures/robustness_false_block_by_policy.png | `True` | `True` | PASS |
| nonempty_file::figures/robustness_auc_phi_by_policy.png | `True` | `True` | PASS |
| nonempty_file::figures/robustness_false_allow_by_type.png | `True` | `True` | PASS |
| nonempty_file::figures/robustness_block_reason_distribution_mcad.png | `True` | `True` | PASS |
| nonempty_file::figures/robustness_explainable_block_rate_by_type.png | `True` | `True` | PASS |
| file_present::robustness_policy_session_metrics.csv | `True` | `True` | PASS |
| file_present::robustness_policy_step_metrics.csv | `True` | `True` | PASS |
| file_present::robustness_policy_summary.csv | `True` | `True` | PASS |
| file_present::robustness_summary_by_scenario_type_and_policy.csv | `True` | `True` | PASS |
| file_present::mcad_block_explainability_steps.csv | `True` | `True` | PASS |
| file_present::mcad_block_explainability_summary.csv | `True` | `True` | PASS |
| file_present::mcad_block_reason_distribution.csv | `True` | `True` | PASS |
| session_rows | `1680` | `1680` | PASS |
| step_rows | `9660` | `9660` | PASS |
| policy_summary_rows | `7` | `7` | PASS |
| summary_by_type_policy_rows | `28` | `28` | PASS |
| policy_count | `7` | `7` | PASS |
| policy_set | `['ablation_ceval_any_intersection', 'ablation_no_real', 'ablation_no_sat', 'baseline_measure_overlap', 'baseline_naive', 'baseline_random_matched', 'mcad']` | `['ablation_ceval_any_intersection', 'ablation_no_real', 'ablation_no_sat', 'baseline_measure_overlap', 'baseline_naive', 'baseline_random_matched', 'mcad']` | PASS |
| scenario_count | `8` | `8` | PASS |
| scenario_set | `['rb_aw_borderline_recovery', 'rb_aw_clause_diagnostics', 'rb_aw_long_noisy_session', 'rb_aw_semantic_traps', 'rb_fm_borderline_recovery', 'rb_fm_clause_diagnostics', 'rb_fm_long_noisy_session', 'rb_fm_semantic_traps']` | `['rb_aw_borderline_recovery', 'rb_aw_clause_diagnostics', 'rb_aw_long_noisy_session', 'rb_aw_semantic_traps', 'rb_fm_borderline_recovery', 'rb_fm_clause_diagnostics', 'rb_fm_long_noisy_session', 'rb_fm_semantic_traps']` | PASS |
| scenario_type_count | `4` | `4` | PASS |
| scenario_type_set | `['adversarial_sat', 'adversarial_semantic', 'noisy_borderline', 'stress_long']` | `['adversarial_sat', 'adversarial_semantic', 'noisy_borderline', 'stress_long']` | PASS |
| config_path_count | `2` | `2` | PASS |
| repeat_id_count | `30` | `30` | PASS |
| mcad_session_rows | `240` | `240` | PASS |
| mcad_step_rows | `1380` | `1380` | PASS |
| explainability_rows | `46` | `46` | PASS |
| explainability_summary_rows | `4` | `4` | PASS |
| mcad_allow_count | `12` | `12` | PASS |
| mcad_block_count | `34` | `34` | PASS |
| oracle_mismatch_count | `0` | `0` | PASS |
| unexplained_block_count | `0` | `0` | PASS |
| unclassified_block_count | `0` | `0` | PASS |
| reason_total | `34` | `34` | PASS |
| reason_distribution | `{'slc_ok': 12, 'grain_ok': 10, 'missing_requirement_set': 4, 'measures_present': 2, 'time_ok': 2, 'unit_ok': 2, 'agg_ok': 2}` | `{'agg_ok': 2, 'grain_ok': 10, 'measures_present': 2, 'missing_requirement_set': 4, 'slc_ok': 12, 'time_ok': 2, 'unit_ok': 2}` | PASS |
| source_commit | `185290880a75d6df17c03aad6abbb44ca3818bf0` | `185290880a75d6df17c03aad6abbb44ca3818bf0` | PASS |
| source_tree_unchanged | `True` | `True` | PASS |
| file_present::robustness_meta.json | `True` | `True` | PASS |
| metadata_entry_count | `2` | `2` | PASS |
| metadata_seed_values | `[42]` | `[42]` | PASS |
| metadata_repeat_values | `[30]` | `[30]` | PASS |
| metadata_scenario_counts | `[4, 4]` | `[4, 4]` | PASS |
| metadata_config_paths | `['backend/harness/scenarios_robustness_adventureworks.yaml', 'backend/harness/scenarios_robustness_foodmart.yaml']` | `['backend/harness/scenarios_robustness_adventureworks.yaml', 'backend/harness/scenarios_robustness_foodmart.yaml']` | PASS |
