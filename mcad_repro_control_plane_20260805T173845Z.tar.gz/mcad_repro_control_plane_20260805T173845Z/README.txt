MCAD emergency reproducibility control-plane snapshot
=====================================================

Captured at UTC: 20260805T173845Z
Repository: /workspaces/MCAD_improve3
Repository HEAD: 20dfec11a502cc0fccbcc07f6e2df0734debe29c
Repository branch: paper/phase3-controlled-execution
Timing process PID: absent

Contents
--------
- orchestration scripts stored directly under /workspaces;
- detached SA5/robustness audit and recovery metadata;
- repository state, refs, history and reproducibility indexes;
- a small copy of tracked control-plane sources and planning manifests.

Deliberate exclusions
---------------------
- current timing output files;
- large campaign payloads already committed in Git;
- Git object database and full git bundle;
- virtual environments;
- execution of tests or analyses.

This archive protects against Codespace loss only after it is downloaded
outside the Codespace. After the timing campaign, create a full Git bundle
and commit canonical orchestration scripts into the repository.
