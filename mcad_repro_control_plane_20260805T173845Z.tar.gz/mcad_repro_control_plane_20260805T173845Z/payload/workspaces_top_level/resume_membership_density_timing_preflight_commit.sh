#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-membership-density-timing-preflight-20260802T190407Z"
EXPECTED_HEAD="bbe66c639c729322aeacb5f269e8e78ef3a3e42c"

OUTPUT_JSON="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_timing_preregistration_preflight.json"
OUTPUT_MD="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_timing_preregistration_preflight.md"

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

git diff --quiet
git diff --cached --quiet

test -f "$OUTPUT_JSON"
test -f "$OUTPUT_MD"

git check-ignore -q "$OUTPUT_JSON"
git check-ignore -q "$OUTPUT_MD"

jq -e '
  .status
    == "membership_density_timing_preregistration_preflight_complete"
  and .factor == "membership_density"
  and .structural_contract.stage_size == 10
  and .structural_contract.levels == [25, 50, 75, 100]
  and .frozen_functional_evidence.functional_step_count == 952
  and .frozen_functional_evidence.functional_mismatch_count == 0
  and .workload_balance_audit.available_step_count_histogram
      == {"23": 2, "24": 8}
  and .workload_balance_audit.balanced_local_step_indexes
      == [range(1; 24)]
  and .workload_balance_audit.balanced_step_count == 23
  and .workload_balance_audit.global_query_digest_intersection_count == 0
  and .workload_balance_audit.within_replication_cross_level_equivalence_required
      == true
  and .workload_balance_audit.cross_replication_query_digest_identity_required
      == false
  and .proposed_timing_protocol.timing_cluster_cell_count == 920
  and .proposed_timing_protocol.precision_cell_count == 92
  and .proposed_timing_protocol.warmup_observation_count == 9200
  and .proposed_timing_protocol.measurement_observation_count == 92000
  and .timing_input_materialization.required == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .preflight_decision.formal_timing_preregistration_ready == true
  and .preflight_decision.timing_input_materialization_ready == false
  and .preflight_decision.timing_execution_ready == false
  and .next_stage
      == "formalize_membership_density_timing_preregistration"
' "$OUTPUT_JSON" >/dev/null

echo "recovery_gate=PASS"
echo "preflight_reexecution_performed=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Force-add ignored preflight artifacts ==="

git add -f \
  "$OUTPUT_JSON" \
  "$OUTPUT_MD"

git diff --cached --check
git diff --cached --stat

test "$(
  git diff --cached --name-only | wc -l
)" -eq 2

echo "ignored_artifact_force_add=PASS"

echo
echo "=== 3. Commit preflight ==="

git commit \
  -m "chore(experiments): preflight membership-density timing preregistration"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 4. Push branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 5. Create pull request ==="

EXISTING_PR="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state all \
    --json number,url,state
)"

test "$(jq 'length' <<<"$EXISTING_PR")" -eq 0

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preflight membership-density timing preregistration" \
    --body "$(cat <<'EOF'
## Scope

- audits the frozen ten-replication membership-density workload;
- performs no functional or timing execution;
- resolves the 23-step versus 24-step workload imbalance;
- identifies the balanced local-position intersection `1..23`;
- proposes timing-only derived workloads and execution specs;
- records the absence of a global cross-replication query-digest intersection.

## Proposed temporal dimensions

- structural replications: `10`;
- density levels: `4`;
- selected local positions: `23`;
- cluster-level timing cells: `920`;
- precision cells: `92`;
- warmup observations: `9200`;
- formal measurements: `92000`.

## Estimand limitation

The same local step position is not necessarily the same query across
structural replications. Cross-level equivalence is required within each
replication; cross-replication query identity is not assumed.

## Controls

- functional rerun: `false`;
- timing execution authorized: `false`;
- timing execution performed: `false`;
- precision analysis performed: `false`;
- latency claims authorized: `false`.

## Next stage

`formalize_membership_density_timing_preregistration`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 6. Final state ==="

echo "membership_density_timing_preregistration_preflight=PASS"
echo "commit=$COMMIT"
echo "balanced_timing_step_count=23"
echo "global_query_digest_intersection_count=0"
echo "cross_replication_query_identity_assumed=false"
echo "timing_cluster_cell_count=920"
echo "precision_cell_count=92"
echo "measurement_observation_count=92000"
echo "timing_execution_authorized=false"
echo "timing_execution_performed=false"
echo "functional_execution_rerun_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_timing_preflight"

git status --short --branch
git log --oneline --decorate -4
