#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="791dade992f0de8ed80f5f675ebda0cef7654b1d"

PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_stage10"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

ARCHIVE="$PACKAGE/archive/membership_density_stage10_canonical_20260804T161119Z.tar.gz"
STATUS_JSON="$PACKAGE/STATUS.json"
PROVENANCE_JSON="$PACKAGE/PROVENANCE.json"
FREEZE_JSON="$PACKAGE/freeze/FREEZE.json"

DECISION="reports/article_experiments/sensitivity/e3_controlled_execution/audits/membership_density/timing_stage10/precision_analysis/stage10_portfolio_precision_decision_report.json"

EXPECTED_ARCHIVE_SHA="1729d7913e68407f754804c9d23468559e0eeefbf616e8f7ecc6be5fab940ffc"
EXPECTED_DECISION_SHA="92a9307a89e92c5e849b0e058f5e0a3c89633f6f8cd39f98ec9a2b9392cc88a4"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
INSPECTION_ROOT="/workspaces/membership_density_manuscript_integration_inspection_${STAMP}"

trap 'echo "[ERROR] Manuscript integration inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$REGISTRY" \
  "$ARCHIVE" \
  "$STATUS_JSON" \
  "$PROVENANCE_JSON" \
  "$FREEZE_JSON" \
  "$DECISION"
do
  test -f "$FILE"
done

test "$(sha256sum "$ARCHIVE" | awk '{print $1}')" \
  = "$EXPECTED_ARCHIVE_SHA"

test "$(sha256sum "$DECISION" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

jq -e '
  .status == "completed_precision_targets_met"
  and .factor == "membership_density"
  and .stage == 10
  and .successful_bootstrap_execution_count == 1
  and .all_precision_targets_met == true
  and .failing_cell_count == 0
  and .stage10_sufficient == true
  and .stage20_extension_required == false
  and .scientific_freeze == true
  and .latency_claim_authorized == true
  and .manuscript_resume_authorized == true
  and .global_scientific_freeze == false
' "$STATUS_JSON" >/dev/null

jq -e '
  .freeze_status == "frozen"
  and .factor == "membership_density"
  and .immutability.canonical_timing_rerun_allowed == false
  and .immutability.canonical_adapter_rematerialization_allowed == false
  and .immutability.canonical_bootstrap_rerun_allowed == false
  and .immutability.canonical_evidence_modification_allowed == false
  and .publication_controls.scientific_freeze == true
  and .publication_controls.latency_claim_authorized == true
  and .publication_controls.manuscript_resume_authorized == true
  and .publication_controls.global_scientific_freeze == false
' "$FREEZE_JSON" >/dev/null

echo "repository_gate=PASS"
echo "scientific_freeze=true"
echo "latency_claim_authorized=true"
echo "manuscript_resume_authorized=true"
echo "global_scientific_freeze=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Initialize detached inspection output ==="

rm -rf "$INSPECTION_ROOT"

mkdir -p \
  "$INSPECTION_ROOT/context" \
  "$INSPECTION_ROOT/history"

echo "inspection_root=$INSPECTION_ROOT"

echo
echo "=== 3. Discover tracked manuscript candidates ==="

git ls-files \
  '*.tex' \
  '*.md' \
  '*.qmd' \
  '*.rst' \
  '*.adoc' \
  '*.bib' \
  '*.yaml' \
  '*.yml' \
  > "$INSPECTION_ROOT/tracked_text_files.txt"

python3 - \
  "$ROOT" \
  "$INSPECTION_ROOT" <<'PY'
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
output_root = Path(sys.argv[2]).resolve()

tracked_file_list = (
    output_root / "tracked_text_files.txt"
).read_text(encoding="utf-8").splitlines()

excluded_prefixes = (
    ".git/",
    "node_modules/",
    "vendor/",
    "dist/",
    "build/",
    "reports/",
    "experiments/article/frozen_campaigns/",
)

publication_path_tokens = (
    "paper",
    "article",
    "manuscript",
    "publication",
    "thesis",
    "document",
    "docs",
)

content_markers = (
    r"\\documentclass",
    r"\\begin\{document\}",
    r"\\section\{",
    r"\\subsection\{",
    r"^#\s+",
    r"^##\s+",
    r"\babstract\b",
    r"\bresults?\b",
    r"\bdiscussion\b",
    r"\bmethodology\b",
    r"\bexperimental\b",
    r"\bsensitivity\b",
    r"analyse de sensibilité",
)

keyword_groups: dict[str, tuple[str, ...]] = {
    "membership_density": (
        "membership_density",
        "membership density",
        "membership-density",
        "densité d’appartenance",
        "densite d'appartenance",
    ),
    "virtual_node_count": (
        "virtual_node_count",
        "virtual node count",
        "virtual-node-count",
    ),
    "constraint_count": (
        "constraint_count",
        "constraint count",
        "constraint-count",
    ),
    "sensitivity": (
        "sensitivity analysis",
        "sensitivity study",
        "analyse de sensibilité",
        "sensitivity",
        "sa3",
        "sa4",
    ),
    "publication_controls": (
        "scientific freeze",
        "latency claim",
        "manuscript",
        "publication",
    ),
}

suffix_scores = {
    ".tex": 8,
    ".qmd": 7,
    ".rst": 5,
    ".adoc": 5,
    ".md": 3,
    ".bib": 2,
    ".yaml": 1,
    ".yml": 1,
}

candidates: list[dict[str, Any]] = []
hits: list[dict[str, Any]] = []

for relative_path in tracked_file_list:
    normalized = relative_path.replace("\\", "/")

    if normalized.startswith(excluded_prefixes):
        continue

    path = root / relative_path

    if not path.is_file():
        continue

    try:
        size = path.stat().st_size
    except OSError:
        continue

    if size > 8_000_000:
        continue

    try:
        text = path.read_text(
            encoding="utf-8",
            errors="replace",
        )
    except OSError:
        continue

    lowered = text.lower()
    lowered_path = normalized.lower()

    score = suffix_scores.get(path.suffix.lower(), 0)

    path_tokens = [
        token
        for token in publication_path_tokens
        if token in lowered_path
    ]

    score += 5 * len(path_tokens)

    matched_markers: list[str] = []

    for marker in content_markers:
        if re.search(
            marker,
            text,
            flags=re.IGNORECASE | re.MULTILINE,
        ):
            matched_markers.append(marker)
            score += 2

    group_counts: dict[str, int] = {}

    for group, terms in keyword_groups.items():
        count = sum(
            lowered.count(term.lower())
            for term in terms
        )

        group_counts[group] = count

        if count:
            score += min(count, 20)

    line_records: list[dict[str, Any]] = []

    for line_number, line in enumerate(
        text.splitlines(),
        start=1,
    ):
        lowered_line = line.lower()

        matched_groups = [
            group
            for group, terms in keyword_groups.items()
            if any(
                term.lower() in lowered_line
                for term in terms
            )
        ]

        if matched_groups:
            line_record = {
                "path": normalized,
                "line": line_number,
                "groups": matched_groups,
                "text": line[:500],
            }

            hits.append(line_record)
            line_records.append(line_record)

    if (
        score > 0
        or path.suffix.lower() in {
            ".tex",
            ".qmd",
            ".rst",
            ".adoc",
        }
    ):
        candidates.append({
            "path": normalized,
            "suffix": path.suffix.lower(),
            "size_bytes": size,
            "score": score,
            "publication_path_tokens": path_tokens,
            "matched_content_marker_count": len(
                matched_markers
            ),
            "keyword_counts": group_counts,
            "keyword_hit_line_count": len(line_records),
        })

candidates.sort(
    key=lambda record: (
        -record["score"],
        record["path"],
    )
)

hits.sort(
    key=lambda record: (
        record["path"],
        record["line"],
    )
)

primary_candidates = candidates[:40]

report = {
    "schema_version": (
        "mcad-membership-density-"
        "manuscript-integration-inspection-v1"
    ),
    "tracked_text_file_count": len(tracked_file_list),
    "candidate_file_count": len(candidates),
    "keyword_hit_count": len(hits),
    "primary_candidates": primary_candidates,
    "all_candidates": candidates,
    "keyword_hits": hits,
}

(output_root / "integration_target_report.json").write_text(
    json.dumps(report, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

with (
    output_root / "primary_candidates.tsv"
).open(
    "w",
    encoding="utf-8",
    newline="\n",
) as handle:
    handle.write(
        "score\tpath\tmembership_density\t"
        "virtual_node_count\tconstraint_count\t"
        "sensitivity\n"
    )

    for record in primary_candidates:
        counts = record["keyword_counts"]

        handle.write(
            f"{record['score']}\t"
            f"{record['path']}\t"
            f"{counts['membership_density']}\t"
            f"{counts['virtual_node_count']}\t"
            f"{counts['constraint_count']}\t"
            f"{counts['sensitivity']}\n"
        )

with (
    output_root / "keyword_hits.tsv"
).open(
    "w",
    encoding="utf-8",
    newline="\n",
) as handle:
    handle.write("path\tline\tgroups\ttext\n")

    for record in hits:
        rendered_text = (
            record["text"]
            .replace("\t", " ")
            .replace("\r", " ")
            .replace("\n", " ")
        )

        handle.write(
            f"{record['path']}\t"
            f"{record['line']}\t"
            f"{','.join(record['groups'])}\t"
            f"{rendered_text}\n"
        )

print("manuscript_candidate_discovery=PASS")
print(
    f"tracked_text_file_count={len(tracked_file_list)}"
)
print(f"candidate_file_count={len(candidates)}")
print(f"keyword_hit_count={len(hits)}")
PY

echo
echo "--- Highest-scoring manuscript candidates ---"

column -t -s $'\t' \
  "$INSPECTION_ROOT/primary_candidates.tsv" |
  sed -n '1,31p'

echo
echo "=== 4. Inspect existing sensitivity-result precedents ==="

git grep \
  -n \
  -I \
  -i \
  -E \
  'constraint_count|constraint count|virtual_node_count|virtual node count|membership_density|membership density|membership-density|sensitivity analysis|analyse de sensibilité|SA3|SA4' \
  -- \
  '*.tex' \
  '*.md' \
  '*.qmd' \
  '*.rst' \
  '*.adoc' \
  '*.bib' \
  > "$INSPECTION_ROOT/all_sensitivity_hits.txt" \
  || true

grep -Ev \
  '^(reports/|experiments/article/frozen_campaigns/)' \
  "$INSPECTION_ROOT/all_sensitivity_hits.txt" \
  > "$INSPECTION_ROOT/manuscript_scope_sensitivity_hits.txt" \
  || true

echo
echo "--- Manuscript-scope sensitivity hits ---"

sed -n '1,220p' \
  "$INSPECTION_ROOT/manuscript_scope_sensitivity_hits.txt"

echo
echo "=== 5. Extract contextual sections from top candidates ==="

python3 - \
  "$ROOT" \
  "$INSPECTION_ROOT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
inspection_root = Path(sys.argv[2]).resolve()

report = json.loads(
    (
        inspection_root / "integration_target_report.json"
    ).read_text(encoding="utf-8")
)

terms = (
    "membership_density",
    "membership density",
    "membership-density",
    "constraint_count",
    "constraint count",
    "virtual_node_count",
    "virtual node count",
    "sensitivity",
    "analyse de sensibilité",
    "results",
    "résultats",
)

output_lines: list[str] = []

for candidate in report["primary_candidates"][:15]:
    relative_path = candidate["path"]
    path = root / relative_path

    try:
        lines = path.read_text(
            encoding="utf-8",
            errors="replace",
        ).splitlines()
    except OSError:
        continue

    matching_indexes = [
        index
        for index, line in enumerate(lines)
        if any(
            term in line.lower()
            for term in terms
        )
    ]

    if not matching_indexes:
        continue

    selected_indexes: set[int] = set()

    for index in matching_indexes[:20]:
        lower = max(0, index - 3)
        upper = min(len(lines), index + 4)

        selected_indexes.update(range(lower, upper))

    output_lines.extend([
        "=" * 80,
        f"FILE={relative_path}",
        f"SCORE={candidate['score']}",
        "=" * 80,
    ])

    previous_index = None

    for index in sorted(selected_indexes):
        if (
            previous_index is not None
            and index > previous_index + 1
        ):
            output_lines.append("...")

        output_lines.append(
            f"{index + 1}:{lines[index]}"
        )

        previous_index = index

    output_lines.append("")

context_path = (
    inspection_root
    / "context"
    / "top_candidate_context.txt"
)

context_path.write_text(
    "\n".join(output_lines) + "\n",
    encoding="utf-8",
)

print("candidate_context_extraction=PASS")
print(f"context_line_count={len(output_lines)}")
PY

sed -n '1,360p' \
  "$INSPECTION_ROOT/context/top_candidate_context.txt"

echo
echo "=== 6. Inspect relevant Git history ==="

git log \
  --all \
  --date=iso-strict \
  --pretty=format:'%H%x09%ad%x09%s' \
  --regexp-ignore-case \
  --extended-regexp \
  --grep='manuscript|paper|article|results|sensitivity|constraint.count|virtual.node|membership.density' \
  > "$INSPECTION_ROOT/history/relevant_commits.tsv" \
  || true

echo "--- Relevant historical commits ---"

sed -n '1,100p' \
  "$INSPECTION_ROOT/history/relevant_commits.tsv"

echo
echo "=== 7. Canonical values available for manuscript integration ==="

jq '{
  factor,
  stage,
  status,
  analysis_contract: {
    factor_levels:
      .analysis_contract.factor_levels,
    measurement_observation_count:
      .analysis_contract.measurement_observation_count,
    structural_seed_count:
      .analysis_contract.structural_seed_count,
    bootstrap_repetitions:
      .analysis_contract.bootstrap_repetitions,
    bootstrap_seed:
      .analysis_contract.bootstrap_seed,
    confidence_level:
      .analysis_contract.confidence_level,
    median_relative_half_width_target:
      .analysis_contract.median_relative_half_width_target,
    p95_relative_half_width_target:
      .analysis_contract.p95_relative_half_width_target
  },
  cell_results: [
    .cell_results[] | {
      factor_level,
      median_ms,
      p95_ms,
      median_relative_half_width,
      p95_relative_half_width,
      median_target_met,
      p95_target_met
    }
  ],
  precision_decision,
  next_stage
}' "$DECISION" \
  | tee "$INSPECTION_ROOT/canonical_manuscript_values.json"

echo
echo "=== 8. Frozen-registry integration status ==="

awk '
  /^[[:space:]]{2}sa4_membership_density_stage10:[[:space:]]*$/ {
    capture=1
  }

  capture {
    print
  }

  capture &&
  /^[[:space:]]{2}[A-Za-z0-9_.-]+:[[:space:]]*$/ &&
  $0 !~ /sa4_membership_density_stage10/ {
    exit
  }
' "$REGISTRY" \
  | tee "$INSPECTION_ROOT/registry_entry.txt"

echo
echo "=== 9. Final immutability check ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(sha256sum "$ARCHIVE" | awk '{print $1}')" \
  = "$EXPECTED_ARCHIVE_SHA"

test "$(sha256sum "$DECISION" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

echo "manuscript_integration_inspection=PASS"
echo "repository_modified=false"
echo "scientific_execution_performed=false"
echo "timing_reexecution_performed=false"
echo "bootstrap_rerun_performed=false"
echo "canonical_archive_modified=false"
echo "inspection_root=$INSPECTION_ROOT"
echo "next_stage=author_exact_membership_density_manuscript_patch"

git status --short --branch
