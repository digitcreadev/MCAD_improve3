#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=9

BASE="paper/phase3-controlled-execution"
FEATURE="paper/audit-virtual-node-count-stage10-functional-20260802T145136Z"
EXPECTED_HEAD="3d1c6ad370f6b8612a46b362e54d2683e59187f4"

REPORT_REL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"

cd "$ROOT"

echo "=== 1. PR merge gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,baseRefName,mergeable,mergeStateStatus,isDraft
)"

PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"
IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"

CHECK_JSON="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket \
    2>/dev/null || true
)"

if [ -n "$CHECK_JSON" ]; then
  CHECK_COUNT="$(jq 'length' <<<"$CHECK_JSON")"
  NON_PASSING="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$CHECK_JSON"
  )"
else
  CHECK_COUNT=0
  NON_PASSING=0
fi

echo "pr_state=$PR_STATE"
echo "pr_head=$PR_HEAD"
echo "pr_base=$PR_BASE"
echo "is_draft=$IS_DRAFT"
echo "mergeable=$MERGEABLE"
echo "merge_state=$MERGE_STATE"
echo "check_count=$CHECK_COUNT"
echo "non_passing_check_count=$NON_PASSING"

test "$PR_STATE" = "OPEN"
test "$PR_HEAD" = "$EXPECTED_HEAD"
test "$PR_BASE" = "$BASE"
test "$IS_DRAFT" = "false"
test "$MERGEABLE" = "MERGEABLE"
test "$MERGE_STATE" = "CLEAN"
test "$NON_PASSING" -eq 0

echo "merge_gate=PASS"

echo
echo "=== 2. Merge PR #9 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 3. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

echo "base_head=$BASE_HEAD"

echo
echo "=== 4. Verify merged functional-completion audit ==="

git merge-base --is-ancestor "$EXPECTED_HEAD" HEAD

test -f "$REPORT_REL"

python - "$REPORT_REL" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
report = json.loads(path.read_text(encoding="utf-8"))

expected = {
    "status": "pass",
    "replication_count": 10,
    "instance_count": 30,
    "functional_step_count": 60,
    "all_replications_passed": True,
    "timing_execution_performed": False,
    "timing_artifact_count": 0,
    "latency_claim_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, got {actual!r}"
        )

prefix = report.get("historical_prefix", {})

if prefix.get("reused") is not True:
    raise SystemExit("Historical prefix is not marked reused.")

if prefix.get("rerun_performed") is not False:
    raise SystemExit("Historical prefix is marked as rerun.")

if len(report.get("runs", [])) != 10:
    raise SystemExit("Expected exactly 10 audited runs.")

print("merged_functional_completion_report=PASS")
print("replication_count=10")
print("instance_count=30")
print("functional_step_count=60")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 5. Clean local feature branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$FEATURE"
then
  git branch -d "$FEATURE"
fi

echo
echo "=== 6. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "virtual_node_count_stage10_functional_completion_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "instance_count=30"
echo "functional_step_count=60"
echo "historical_prefix_rerun_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=prepare_stage10_formal_timing_authorization"

git status --short --branch
git log --oneline --decorate -4
