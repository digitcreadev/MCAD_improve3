#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=11

BASE="paper/phase3-controlled-execution"
BRANCH="paper/prepare-virtual-node-count-stage10-timing-20260802T155232Z"
EXPECTED_HEAD="09ff31e7fa33ca99daba051b30bec88d9657980a"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

PLAN="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_execution_plan.json"

VALIDATION="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_preparation/timing_runner_validation.json"

trap 'echo "[ERROR] Merge preparation script stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PLAN"
test -f "$VALIDATION"

echo "branch=$BRANCH"
echo "head=$EXPECTED_HEAD"
echo "local_gate=PASS"
echo "tests_rerun=false"
echo "functional_execution_rerun=false"
echo "timing_execution=false"

echo
echo "=== 2. Wait for PR head propagation ==="

PR_HEAD=""

for ATTEMPT in $(seq 1 60); do
  PR_HEAD="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json headRefOid \
      --jq '.headRefOid'
  )"

  echo "head_poll_attempt=$ATTEMPT pr_head=$PR_HEAD"

  if [ "$PR_HEAD" = "$EXPECTED_HEAD" ]; then
    break
  fi

  sleep 5
done

test "$PR_HEAD" = "$EXPECTED_HEAD"

echo "pr_head_propagation=PASS"

echo
echo "=== 3. Wait for CI checks to appear ==="

CHECK_COUNT=0

for ATTEMPT in $(seq 1 60); do
  CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if [ -n "$CHECKS" ]; then
    CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"
  else
    CHECK_COUNT=0
  fi

  echo "check_discovery_attempt=$ATTEMPT check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 5
done

test "$CHECK_COUNT" -gt 0

echo "ci_checks_discovered=PASS"

echo
echo "=== 4. Wait for CI completion ==="

gh pr checks "$PR" \
  --repo "$REPO" \
  --watch \
  --interval 10

FINAL_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link
)"

NON_PASSING="$(
  jq '[.[] | select(.bucket != "pass")] | length' \
    <<<"$FINAL_CHECKS"
)"

echo "$FINAL_CHECKS" | jq .
echo "non_passing_check_count=$NON_PASSING"

test "$NON_PASSING" -eq 0

echo "preparation_ci=PASS"

echo
echo "=== 5. Final merge gate ==="

MERGE_READY=0

for ATTEMPT in $(seq 1 30); do
  PR_DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
  PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
  PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"

  echo \
    "merge_poll_attempt=$ATTEMPT " \
    "state=$PR_STATE " \
    "head=$PR_HEAD " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$PR_STATE" = "OPEN" ] \
     && [ "$PR_HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$PR_BASE" = "$BASE" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    MERGE_READY=1
    break
  fi

  sleep 5
done

test "$MERGE_READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 6. Merge PR #11 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 7. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "base_head=$BASE_HEAD"
echo "preparation_commit_is_ancestor=PASS"

echo
echo "=== 8. Verify merged timing plan ==="

"$PYTHON" - "$PLAN" "$VALIDATION" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

plan_path = Path(sys.argv[1])
validation_path = Path(sys.argv[2])

if not plan_path.is_file():
    raise SystemExit(f"Missing plan: {plan_path}")

if not validation_path.is_file():
    raise SystemExit(
        f"Missing validation: {validation_path}"
    )

plan = json.loads(
    plan_path.read_text(encoding="utf-8")
)
validation = json.loads(
    validation_path.read_text(encoding="utf-8")
)

assert plan["status"] == "prepared"
assert validation["status"] == "pass"

assert (
    plan["runner"]["sha256_matches_preregistration"]
    is True
)
assert (
    plan["precision_analyzer"][
        "sha256_matches_preregistration"
    ]
    is True
)

scope = plan["scope"]

assert scope["replication_count"] == 10
assert scope["factor_levels"] == [6, 12, 24]
assert scope["steps_per_instance"] == 2
assert scope["timing_cell_count"] == 60
assert scope["warmups_per_cell"] == 10
assert scope["measurements_per_cell"] == 100
assert scope["expected_warmup_count"] == 600
assert scope["expected_measurement_count"] == 6000

replications = plan["replications"]

assert len(replications) == 10

assert [
    item["replication_index"]
    for item in replications
] == list(range(10))

assert [
    item["execution_order_seed"]
    for item in replications
] == [
    20260728 + index
    for index in range(10)
]

for item in replications:
    assert item["logical_status"] == "ready"
    assert item["runner_invocation_performed"] is False
    assert item["functional_digest_check_required"] is True
    assert item["fresh_ckg_state_required"] is True
    assert item["reuse_successful"] is True
    assert item["timing_cell_count"] == 6
    assert item["expected_warmup_count"] == 60
    assert item["expected_measurement_count"] == 600

assert plan["execution_state"] == {
    "runner_invocation_performed": False,
    "timing_execution_performed": False,
    "warmup_count_observed": 0,
    "measurement_count_observed": 0,
    "timing_output_directories_created": False,
}

assert (
    validation[
        "runner_sha256_matches_preregistration"
    ]
    is True
)
assert (
    validation[
        "precision_analyzer_sha256_matches_preregistration"
    ]
    is True
)
assert validation["replication_count"] == 10
assert validation["timing_cell_count"] == 60
assert validation["expected_warmup_count"] == 600
assert validation["expected_measurement_count"] == 6000
assert validation["timing_execution_performed"] is False

print("merged_timing_runner_preparation=PASS")
print("runner_sha256_matches_preregistration=true")
print("analyzer_sha256_matches_preregistration=true")
print("replication_count=10")
print("timing_cell_count=60")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("timing_execution_performed=false")
PY

echo
echo "=== 9. Cleanup local preparation branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 10. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "stage10_timing_runner_preparation_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=execute_stage10_formal_timing_campaign"

git status --short --branch
git log --oneline --decorate -5
