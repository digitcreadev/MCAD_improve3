#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

CLOSURE_ROOT="/workspaces/sa5_objective_count_v2_binding_closure_20260804T214659Z"

CLOSURE_REPORT="$CLOSURE_ROOT/sa5_objective_count_v2_binding_closure.json"
EXPECTED_CLOSURE_REPORT_SHA="c2f156da3f07edc587c2e2afac78c96d0335ec06cc240bc2a4ec8bd22efc268c"

CLOSURE_SURFACE="$CLOSURE_ROOT/sa5_objective_count_v2_binding_closure.txt"
EXPECTED_CLOSURE_SURFACE_SHA="118473bd654530731969a0a980757903565f9bb18d5717ab047805a8f417a6cb"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

E3_CONTRACT="backend/harness/sensitivity_execution/e3_contract.yaml"
E3_VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"
E3_CONTRACT_TEST="backend/harness/sensitivity_execution/tests/test_e3_contract.py"
MEMBERSHIP_COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py"
OBJECTIVE_PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
CONTROLLED_FAMILIES_TEST="backend/harness/sensitivity_generator/tests/test_controlled_families.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

V1_E21="mcad-sensitivity-e2.1-objective-count-v1"
V1_E22="mcad-sensitivity-e2.2-objective-count-v1"
V2_E21="mcad-sensitivity-e2.1-objective-count-v2"
V2_E22="mcad-sensitivity-e2.2-objective-count-v2"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_binding_candidate_classification_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_binding_candidate_classification.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_binding_candidate_classification.txt"

trap 'echo "[ERROR] SA5 v2 candidate classification stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Exact read-only classification gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$CLOSURE_REPORT" \
  "$CLOSURE_SURFACE" \
  "$PREREG" \
  "$AMENDMENT" \
  "$E3_CONTRACT" \
  "$E3_VALIDATOR" \
  "$E3_CONTRACT_TEST" \
  "$MEMBERSHIP_COMPATIBILITY_TEST" \
  "$OBJECTIVE_PREREG_TEST" \
  "$CONTROLLED_FAMILIES_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$CLOSURE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_CLOSURE_REPORT_SHA"

test "$(
  sha256sum "$CLOSURE_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_CLOSURE_SURFACE_SHA"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "sa5_objective_count_v2_projected_patch_scope_incomplete"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .projected_scope.new_file_count == 9
  and .projected_scope.modified_file_count == 4
  and .additional_modified_candidate_count == 6
  and .revised_scope.total_patch_file_count == 19
  and .scope_complete == false
  and .next_stage
    == "revise_sa5_objective_count_v2_patch_scope_before_authoring"
' "$CLOSURE_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "classification_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "closure_report_sha256=$EXPECTED_CLOSURE_REPORT_SHA"
echo "candidate_count=6"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Baseline candidate-test gate ==="

"$PYTHON" -m pytest \
  "$E3_CONTRACT_TEST" \
  "$MEMBERSHIP_COMPATIBILITY_TEST" \
  "$OBJECTIVE_PREREG_TEST" \
  "$CONTROLLED_FAMILIES_TEST" \
  -q \
  -p no:cacheprovider

echo "candidate_baseline_tests=PASS"

echo
echo "=== 3. Classify exact binding semantics ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export CLOSURE_REPORT
export REPORT
export SURFACE
export EXPECTED_HEAD
export V1_E21
export V1_E22
export V2_E21
export V2_E22

python3 - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"]).resolve()

closure_path = Path(
    os.environ["CLOSURE_REPORT"]
).resolve()

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])

source_commit = os.environ["EXPECTED_HEAD"]

v1_e21 = os.environ["V1_E21"]
v1_e22 = os.environ["V1_E22"]
v2_e21 = os.environ["V2_E21"]
v2_e22 = os.environ["V2_E22"]

closure = json.loads(
    closure_path.read_text(encoding="utf-8")
)

planned_new_files = set(
    closure["projected_scope"]["new_files"]
)

planned_modified_files = set(
    closure["projected_scope"]["modified_files"]
)

candidate_files = set(
    closure["additional_modified_candidates"]
)

expected_candidates = {
    (
        "backend/harness/sensitivity_execution/"
        "e3_contract.yaml"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_e3_contract.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_membership_density_compatibility.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_stage10_preregistration.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "validate_e3_contract.py"
    ),
    (
        "backend/harness/sensitivity_generator/"
        "tests/test_controlled_families.py"
    ),
}

if candidate_files != expected_candidates:
    raise AssertionError(
        "Unexpected closure candidate set: "
        f"{sorted(candidate_files)}"
    )


def sha256(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def contexts(
    text: str,
    tokens: tuple[str, ...],
    radius: int = 4,
) -> list[dict[str, Any]]:
    lines = text.splitlines()
    result: list[dict[str, Any]] = []
    seen: set[tuple[int, int]] = set()

    for index, line in enumerate(
        lines,
        start=1,
    ):
        if not any(
            token in line
            for token in tokens
        ):
            continue

        start = max(1, index - radius)
        end = min(
            len(lines),
            index + radius,
        )

        key = (start, end)

        if key in seen:
            continue

        seen.add(key)

        result.append(
            {
                "start_line": start,
                "end_line": end,
                "text": "\n".join(
                    lines[start - 1 : end]
                ),
            }
        )

    return result


def relevant_test_functions(
    path: Path,
    text: str,
) -> list[dict[str, Any]]:
    if path.suffix != ".py":
        return []

    tree = ast.parse(
        text,
        filename=str(path),
    )

    lines = text.splitlines()
    result: list[dict[str, Any]] = []

    relevant_tokens = (
        "objective_count",
        "SUPPORTED_GENERATOR_VERSION_PAIRS",
        "SUPPORTED_FACTOR_GENERATOR_PROFILES",
        "factor_generator_profiles",
        v1_e21,
        v1_e22,
        v2_e21,
        v2_e22,
    )

    for node in tree.body:
        if not isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            continue

        start = int(node.lineno)
        end = int(
            getattr(node, "end_lineno", start)
        )

        source = "\n".join(
            lines[start - 1 : end]
        )

        if not any(
            token in source
            for token in relevant_tokens
        ):
            continue

        result.append(
            {
                "name": node.name,
                "start_line": start,
                "end_line": end,
                "source": source,
            }
        )

    return result


file_reports: dict[str, dict[str, Any]] = {}

for relative in sorted(candidate_files):
    path = root / relative
    text = path.read_text(encoding="utf-8")

    file_reports[relative] = {
        "sha256": sha256(path),
        "v1_e21_literal_count": text.count(
            v1_e21
        ),
        "v1_e22_literal_count": text.count(
            v1_e22
        ),
        "v2_e21_literal_count": text.count(
            v2_e21
        ),
        "v2_e22_literal_count": text.count(
            v2_e22
        ),
        "objective_count_token_count": (
            text.count("objective_count")
        ),
        "executor_mapping_reference_count": (
            text.count(
                "SUPPORTED_GENERATOR_VERSION_PAIRS"
            )
        ),
        "contract_mapping_reference_count": (
            text.count(
                "SUPPORTED_FACTOR_GENERATOR_PROFILES"
            )
        ),
        "contract_yaml_reference_count": (
            text.count(
                "factor_generator_profiles"
            )
        ),
        "contexts": contexts(
            text,
            (
                v1_e21,
                v1_e22,
                v2_e21,
                v2_e22,
                "objective_count",
                "SUPPORTED_GENERATOR_VERSION_PAIRS",
                "SUPPORTED_FACTOR_GENERATOR_PROFILES",
                "factor_generator_profiles",
            ),
        ),
        "relevant_test_functions": (
            relevant_test_functions(
                path,
                text,
            )
        ),
    }


e3_contract_path = (
    "backend/harness/sensitivity_execution/"
    "e3_contract.yaml"
)

validator_path = (
    "backend/harness/sensitivity_execution/"
    "validate_e3_contract.py"
)

objective_prereg_test_path = (
    "backend/harness/sensitivity_execution/"
    "tests/test_objective_count_stage10_preregistration.py"
)

controlled_families_test_path = (
    "backend/harness/sensitivity_generator/"
    "tests/test_controlled_families.py"
)

e3_contract_test_path = (
    "backend/harness/sensitivity_execution/"
    "tests/test_e3_contract.py"
)

membership_test_path = (
    "backend/harness/sensitivity_execution/"
    "tests/test_membership_density_compatibility.py"
)

required_modified_candidates = {
    e3_contract_path,
    validator_path,
    objective_prereg_test_path,
    controlled_families_test_path,
}

review_only_candidates = {
    e3_contract_test_path,
    membership_test_path,
}


# Authoritative profile data must move to v2.
contract_yaml = yaml.safe_load(
    (root / e3_contract_path).read_text(
        encoding="utf-8"
    )
)

profiles = contract_yaml[
    "factor_generator_profiles"
]

objective_profile = profiles[
    "objective_count"
]

assert objective_profile[
    "campaign_generator_version"
] == v1_e22

assert objective_profile[
    "structural_generator_version"
] == v1_e21

# The validator contains the corresponding active profile.
assert (
    file_reports[validator_path][
        "v1_e21_literal_count"
    ]
    >= 1
)

assert (
    file_reports[validator_path][
        "v1_e22_literal_count"
    ]
    >= 1
)

# The objective-count tests directly bind the active versions.
objective_test_report = file_reports[
    objective_prereg_test_path
]

assert (
    objective_test_report[
        "executor_mapping_reference_count"
    ]
    >= 1
)

controlled_test_report = file_reports[
    controlled_families_test_path
]

assert (
    controlled_test_report[
        "v1_e21_literal_count"
    ]
    >= 1
)

assert (
    controlled_test_report[
        "v1_e22_literal_count"
    ]
    >= 1
)

# Generic E3 contract tests must not carry direct objective-count
# version literals. They should continue to validate generic shape.
generic_contract_test = file_reports[
    e3_contract_test_path
]

assert (
    generic_contract_test[
        "v1_e21_literal_count"
    ]
    == 0
)

assert (
    generic_contract_test[
        "v1_e22_literal_count"
    ]
    == 0
)

assert (
    generic_contract_test[
        "contract_yaml_reference_count"
    ]
    >= 1
)

# Membership-density compatibility must remain factor-local and must
# not contain objective-count version literals.
membership_test = file_reports[
    membership_test_path
]

assert (
    membership_test[
        "v1_e21_literal_count"
    ]
    == 0
)

assert (
    membership_test[
        "v1_e22_literal_count"
    ]
    == 0
)

assert (
    membership_test[
        "executor_mapping_reference_count"
    ]
    >= 1
)


final_modified_files = (
    planned_modified_files
    | required_modified_candidates
)

final_total_patch_file_count = (
    len(planned_new_files)
    + len(final_modified_files)
)

assert len(planned_new_files) == 9
assert len(planned_modified_files) == 4
assert len(required_modified_candidates) == 4
assert len(review_only_candidates) == 2
assert len(final_modified_files) == 8
assert final_total_patch_file_count == 17

status = (
    "sa5_objective_count_v2_"
    "binding_candidate_classification_resolved"
)

next_stage = (
    "author_sa5_objective_count_"
    "materialization_contract_v2_patch_"
    "with_17_file_scope"
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "binding-candidate-classification-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "closure_audit_sha256": sha256(
        closure_path
    ),
    "projected_scope": {
        "new_files": sorted(
            planned_new_files
        ),
        "modified_files": sorted(
            planned_modified_files
        ),
        "new_file_count": len(
            planned_new_files
        ),
        "modified_file_count": len(
            planned_modified_files
        ),
        "total_patch_file_count": (
            len(planned_new_files)
            + len(planned_modified_files)
        ),
    },
    "candidate_classification": {
        "required_modified_candidates": sorted(
            required_modified_candidates
        ),
        "required_modified_candidate_count": (
            len(required_modified_candidates)
        ),
        "review_only_unchanged_candidates": sorted(
            review_only_candidates
        ),
        "review_only_unchanged_candidate_count": (
            len(review_only_candidates)
        ),
        "classification_rule": (
            "Modify active objective-count version "
            "bindings and tests containing direct "
            "objective-count profile expectations. "
            "Preserve generic profile-shape tests and "
            "membership-density factor-local tests."
        ),
    },
    "final_scope": {
        "new_files": sorted(
            planned_new_files
        ),
        "modified_files": sorted(
            final_modified_files
        ),
        "review_only_files": sorted(
            review_only_candidates
        ),
        "new_file_count": len(
            planned_new_files
        ),
        "modified_file_count": len(
            final_modified_files
        ),
        "review_only_file_count": len(
            review_only_candidates
        ),
        "total_patch_file_count": (
            final_total_patch_file_count
        ),
    },
    "file_evidence": file_reports,
    "scope_complete": True,
    "preserve_v1_module_bytes": True,
    "preserve_membership_density_profile": True,
    "preserve_generic_e3_contract_tests": True,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface: list[str] = [
    "SA5 OBJECTIVE-COUNT V2 BINDING CANDIDATE CLASSIFICATION",
    "=" * 88,
    f"source_commit={source_commit}",
    f"status={status}",
    "projected_total_patch_file_count=13",
    "closure_candidate_total_patch_file_count=19",
    "required_additional_modified_file_count=4",
    "review_only_unchanged_file_count=2",
    "final_modified_file_count=8",
    "final_total_patch_file_count=17",
    "scope_complete=true",
    "",
    "=== REQUIRED ADDITIONAL MODIFICATIONS ===",
    *sorted(required_modified_candidates),
    "",
    "=== REVIEW ONLY — EXPECTED UNCHANGED ===",
    *sorted(review_only_candidates),
    "",
    "=== FINAL NEW FILES ===",
    *sorted(planned_new_files),
    "",
    "=== FINAL MODIFIED FILES ===",
    *sorted(final_modified_files),
    "",
    "=== EXACT CANDIDATE EVIDENCE ===",
]

for relative in sorted(file_reports):
    evidence = file_reports[relative]

    surface.extend(
        [
            "",
            "=" * 88,
            f"FILE={relative}",
            f"SHA256={evidence['sha256']}",
            (
                "v1_e21_literal_count="
                f"{evidence['v1_e21_literal_count']}"
            ),
            (
                "v1_e22_literal_count="
                f"{evidence['v1_e22_literal_count']}"
            ),
            (
                "objective_count_token_count="
                f"{evidence['objective_count_token_count']}"
            ),
            (
                "executor_mapping_reference_count="
                f"{evidence['executor_mapping_reference_count']}"
            ),
            (
                "contract_mapping_reference_count="
                f"{evidence['contract_mapping_reference_count']}"
            ),
            (
                "contract_yaml_reference_count="
                f"{evidence['contract_yaml_reference_count']}"
            ),
        ]
    )

    for context in evidence["contexts"]:
        surface.extend(
            [
                "",
                (
                    f"LINES={context['start_line']}-"
                    f"{context['end_line']}"
                ),
                context["text"],
            ]
        )

    for function in evidence[
        "relevant_test_functions"
    ]:
        surface.extend(
            [
                "",
                (
                    f"FUNCTION={function['name']} "
                    f"LINES={function['start_line']}-"
                    f"{function['end_line']}"
                ),
                function["source"],
            ]
        )

surface.extend(
    [
        "",
        "=== SCIENTIFIC CONTROLS ===",
        "preserve_v1_module_bytes=true",
        "preserve_membership_density_profile=true",
        "canonical_campaign_generated=false",
        "campaign_materialization_performed=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface),
    encoding="utf-8",
)

print("binding_candidate_classification=PASS")
print(f"status={status}")
print(
    "required_additional_modified_file_count="
    f"{len(required_modified_candidates)}"
)
print(
    "review_only_unchanged_file_count="
    f"{len(review_only_candidates)}"
)
print(
    "final_new_file_count="
    f"{len(planned_new_files)}"
)
print(
    "final_modified_file_count="
    f"{len(final_modified_files)}"
)
print(
    "final_total_patch_file_count="
    f"{final_total_patch_file_count}"
)
print("scope_complete=true")
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{hashlib.sha256(report_path.read_bytes()).hexdigest()}"
)
print(
    "surface_sha256="
    f"{hashlib.sha256(surface_path.read_bytes()).hexdigest()}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate final classified scope ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-binding-candidate-classification-v1"
  and .status
    == "sa5_objective_count_v2_binding_candidate_classification_resolved"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .read_only == true
  and .projected_scope.new_file_count == 9
  and .projected_scope.modified_file_count == 4
  and .projected_scope.total_patch_file_count == 13
  and .candidate_classification.required_modified_candidate_count
    == 4
  and .candidate_classification.review_only_unchanged_candidate_count
    == 2
  and .candidate_classification.required_modified_candidates
    == [
      "backend/harness/sensitivity_execution/e3_contract.yaml",
      "backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py",
      "backend/harness/sensitivity_execution/validate_e3_contract.py",
      "backend/harness/sensitivity_generator/tests/test_controlled_families.py"
    ]
  and .candidate_classification.review_only_unchanged_candidates
    == [
      "backend/harness/sensitivity_execution/tests/test_e3_contract.py",
      "backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py"
    ]
  and .final_scope.new_file_count == 9
  and .final_scope.modified_file_count == 8
  and .final_scope.review_only_file_count == 2
  and .final_scope.total_patch_file_count == 17
  and .scope_complete == true
  and .preserve_v1_module_bytes == true
  and .preserve_membership_density_profile == true
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_17_file_scope"
' "$REPORT" >/dev/null

echo "classified_scope_validation=PASS"

echo
echo "=== 5. Compact final scope ==="

jq '{
  status,
  source_commit,
  candidate_classification,
  final_scope,
  scope_complete,
  preserve_v1_module_bytes,
  preserve_membership_density_profile,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value semantic surface ==="

grep -nE \
  '^(status=|required_additional|review_only|final_modified|final_total|scope_complete=|FILE=|FUNCTION=|next_stage=)' \
  "$SURFACE" |
  head -n 500 || true

echo
echo "=== 7. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

echo "sa5_objective_count_v2_binding_candidate_classification=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "required_additional_modified_file_count=4"
echo "review_only_unchanged_file_count=2"
echo "final_new_file_count=9"
echo "final_modified_file_count=8"
echo "final_total_patch_file_count=17"
echo "scope_complete=true"
echo "report=$REPORT"
echo "surface=$SURFACE"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=author_sa5_objective_count_materialization_contract_v2_patch_with_17_file_scope"

git status --short --branch
