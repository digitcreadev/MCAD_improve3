#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
PLANNING="$E3/planning"
SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_SPECS="$SETUP_ROOT/specs"

SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
EXPECTED_SETUP_MANIFEST_SHA="5e5baad8a32d5c9c8e647d8d2365d68a9e3a286e620fc783373ec577a26cf155"

SETUP_SHA_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"
EXPECTED_SETUP_SHA_MANIFEST_SHA="c785ab0fafc1c424e7a737d0dfd4282cb01b7ef071cf54c2adeb4304fb9ad9af"

PREFLIGHT_JSON="$PLANNING/sa5_objective_count_stage10_timing_preregistration_preflight.json"
PREFLIGHT_MD="$PLANNING/sa5_objective_count_stage10_timing_preregistration_preflight.md"
PREREG_JSON="$PLANNING/sa5_objective_count_stage10_portfolio_timing_preregistration.json"
PREREG_MD="$PLANNING/sa5_objective_count_stage10_portfolio_timing_preregistration.md"
MATERIALIZATION_JSON="$PLANNING/sa5_objective_count_stage10_timing_input_materialization.json"
MATERIALIZATION_MD="$PLANNING/sa5_objective_count_stage10_timing_input_materialization.md"
AUTHORIZATION_JSON="$PLANNING/sa5_objective_count_stage10_timing_execution_authorization.json"
AUTHORIZATION_MD="$PLANNING/sa5_objective_count_stage10_timing_execution_authorization.md"

READINESS_REPORT="/workspaces/sa5_objective_count_stage10_post_merge_analysis_readiness_20260805T150733Z/sa5_objective_count_stage10_post_merge_analysis_readiness.json"
EXPECTED_READINESS_REPORT_SHA="95bc871859b3488f90ad04b16f206b108b4ac676c2c0aba64666db8157cf0898"

TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/prepare-sa5-objective-count-stage10-timing-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_timing_setup_resume.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 Timing Setup resume stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Resume gate: reuse the 20 generated files ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

# Tracked state must be clean. The generated files are ignored evidence files,
# so ordinary git status intentionally does not enumerate them.
git diff --quiet
git diff --cached --quiet
test -z "$(git status --porcelain)"

verify_sha "$READINESS_REPORT" "$EXPECTED_READINESS_REPORT_SHA"
verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_SHA_MANIFEST" "$EXPECTED_SETUP_SHA_MANIFEST_SHA"

test "$(wc -l < "$SETUP_SHA_MANIFEST")" -eq 19
sha256sum -c "$SETUP_SHA_MANIFEST" >/dev/null

test "$(find "$SETUP_SPECS" -maxdepth 1 -type f -name '*.json' | wc -l)" -eq 10
test ! -e "$TIMING_RUN_ROOT"

echo "resume_gate=PASS"
echo "generated_files_reused=true"
echo "generation_reexecuted=false"
echo "failure_cause=generated_files_are_gitignored"
echo "setup_manifest_sha256=$EXPECTED_SETUP_MANIFEST_SHA"
echo "setup_file_manifest_sha256=$EXPECTED_SETUP_SHA_MANIFEST_SHA"

echo
echo "=== 2. Reconstruct and validate the exact 20-file scope ==="

{
  find "$SETUP_ROOT" -type f
  printf '%s\n' \
    "$PREFLIGHT_JSON" \
    "$PREFLIGHT_MD" \
    "$PREREG_JSON" \
    "$PREREG_MD" \
    "$MATERIALIZATION_JSON" \
    "$MATERIALIZATION_MD" \
    "$AUTHORIZATION_JSON" \
    "$AUTHORIZATION_MD"
} |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 20
test "$(sort -u "$TMP_ROOT/expected_files.txt" | wc -l)" -eq 20

while IFS= read -r FILE; do
  test -f "$FILE"
done < "$TMP_ROOT/expected_files.txt"

jq -e '
  .status == "sa5_objective_count_stage10_timing_setup_complete"
  and .source_commit
    == "0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .objective_count_timing_plan.factor_levels
    == [1,2,5,10,20,50]
  and .objective_count_timing_plan.replication_count == 10
  and .objective_count_timing_plan.instance_count == 60
  and .objective_count_timing_plan.timing_spec_count == 10
  and .objective_count_timing_plan.measured_repetitions_per_factor_level
    == 2530
  and .objective_count_timing_plan.expected_observation_rows_per_replication
    == 15180
  and .objective_count_timing_plan.expected_total_observation_rows
    == 151800
  and .authorization.timing_preregistration_preflight_complete == true
  and .authorization.timing_preregistration_complete == true
  and .authorization.timing_inputs_materialized == true
  and .authorization.timing_execution_authorized == true
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .setup_complete == true
' "$SETUP_MANIFEST" >/dev/null

jq -e '
  .status == "timing_execution_authorized"
  and .timing_spec_count == 10
  and .measured_repetitions_per_factor_level == 2530
  and .expected_observation_rows_per_replication == 15180
  and .expected_total_observation_rows == 151800
  and .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .precision_analysis_authorized == false
  and .bootstrap_analysis_authorized == false
  and .scientific_result_interpretation_authorized == false
  and .manuscript_integration_authorized == false
  and .blocker_count == 0
  and .authorization_complete == true
  and .next_stage
    == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION_JSON" >/dev/null

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  SPEC="$SETUP_SPECS/objective_count_rep_${TOKEN}_portfolio_timing_stage10.json"

  jq -e \
    --argjson index "$INDEX" \
    '
      .replication_index == $index
      and .factor == "objective_count"
      and .factor_levels == [1,2,5,10,20,50]
      and .selected_instance_count == 6
      and .workload_step_count_per_instance == 32
      and .measured_repetitions_per_factor_level == 2530
      and .expected_observation_rows == 15180
      and .continue_on_instance_failure == false
      and .functional_result_reexecution_forbidden == true
      and .timing_execution_authorized == true
      and .timing_execution_performed == false
      and .precision_analysis_authorized == false
    ' "$SPEC" >/dev/null

  OUTPUT_DIR="$(jq -r '.timing_output_dir' "$SPEC")"
  test ! -e "$OUTPUT_DIR"
done

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "exact_generated_scope_gate=PASS"
echo "generated_file_count=20"
echo "timing_spec_count=10"
echo "measured_repetitions_per_factor_level=2530"
echo "expected_observation_rows_per_replication=15180"
echo "expected_total_observation_rows=151800"
echo "timing_execution_performed=false"

echo
echo "=== 3. Create branch and force-stage ignored timing setup ==="

git switch -c "$BRANCH"

mapfile -t GENERATED_FILES < "$TMP_ROOT/expected_files.txt"
git add -f -- "${GENERATED_FILES[@]}"

git diff --cached --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 20
test -z "$(git diff --name-only)"

echo "timing_setup_stage=PASS"
echo "staged_file_count=20"

echo
echo "=== 4. Commit the single accelerated Timing Setup lot ==="

git commit \
  -m "chore(experiments): prepare SA5 objective-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git diff-tree --no-commit-id --name-only -r "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/committed_files.txt"

echo "timing_setup_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=20"

echo
echo "=== 5. Push and create the single Timing Setup PR ==="

git push -u origin "$BRANCH"

SETUP_MANIFEST_SHA="$(sha256sum "$SETUP_MANIFEST" | awk '{print $1}')"
SETUP_FILES_SHA="$(sha256sum "$SETUP_SHA_MANIFEST" | awk '{print $1}')"
AUTH_SHA="$(sha256sum "$AUTHORIZATION_JSON" | awk '{print $1}')"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Prepare SA5 objective-count Stage-10 timing" \
    --body-file - <<EOF
## Accelerated Timing Setup

This single setup PR combines:

1. timing preregistration preflight;
2. portfolio timing preregistration;
3. timing-input materialization;
4. timing-execution authorization.

## Frozen scope

- factor levels: 1, 2, 5, 10, 20, 50
- replications: 10
- canonical instances: 60
- measured repetitions per factor level: 2,530
- expected rows per replication: 15,180
- expected total observation rows: 151,800
- timing specifications: 10
- timing execution performed: false
- precision and bootstrap analyses performed: false
- manuscript modified: false

## Provenance

- source commit: \`$EXPECTED_HEAD\`
- timing setup manifest SHA-256: \`$SETUP_MANIFEST_SHA\`
- timing setup file manifest SHA-256: \`$SETUP_FILES_SHA\`
- timing authorization SHA-256: \`$AUTH_SHA\`

No SA5 objective-count timing value has been observed or analyzed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

gh pr view "$PR_NUMBER" \
  --repo "$REPO" \
  --json state,isDraft,headRefOid,headRefName,baseRefName,title |
jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .title == "Prepare SA5 objective-count Stage-10 timing"
  ' >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 20

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "timing_setup_push=PASS"
echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"
echo "pr_file_count=20"

echo
echo "=== 6. Final state ==="

echo "sa5_objective_count_stage10_timing_setup_resume=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"
echo "generated_file_count=20"
echo "timing_spec_count=10"
echo "measured_repetitions_per_factor_level=2530"
echo "expected_observation_rows_per_replication=15180"
echo "expected_total_observation_rows=151800"
echo "setup_manifest_sha256=$SETUP_MANIFEST_SHA"
echo "setup_file_manifest_sha256=$SETUP_FILES_SHA"
echo "authorization_sha256=$AUTH_SHA"

echo "timing_preregistration_preflight_complete=true"
echo "timing_preregistration_complete=true"
echo "timing_inputs_materialized=true"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_timing_setup"

git status --short --branch
git log --oneline --decorate -5
