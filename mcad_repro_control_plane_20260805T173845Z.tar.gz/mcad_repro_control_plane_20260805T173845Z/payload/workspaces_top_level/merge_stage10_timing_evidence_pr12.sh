#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=12

BASE="paper/phase3-controlled-execution"
BRANCH="paper/execute-virtual-node-count-stage10-timing-20260802T162601Z"
EXPECTED_HEAD="9afdeff619860260d5918b54fb1fcde2cfda980d"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

OUTPUT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/virtual_node_count_stage10_c4"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution"

REPORT="$AUDIT_ROOT/formal_timing_execution_report.json"

trap 'echo "[ERROR] PR #12 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$REPORT"

echo "branch=$BRANCH"
echo "head=$EXPECTED_HEAD"
echo "local_gate=PASS"
echo "tests_rerun=false"
echo "functional_execution_rerun=false"
echo "timing_execution_rerun=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
)"

PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"

echo "pr_state=$PR_STATE"
echo "pr_head=$PR_HEAD"
echo "pr_base=$PR_BASE"
echo "is_draft=$IS_DRAFT"

test "$PR_STATE" = "OPEN"
test "$PR_HEAD" = "$EXPECTED_HEAD"
test "$PR_BASE" = "$BASE"
test "$IS_DRAFT" = "false"

echo "pr_identity_gate=PASS"

echo
echo "=== 3. Discover CI checks ==="

CHECK_COUNT=0
CHECKS=""

for ATTEMPT in $(seq 1 12); do
  CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if [ -n "$CHECKS" ]; then
    CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"
  else
    CHECK_COUNT=0
  fi

  echo \
    "check_discovery_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 5
done

if [ "$CHECK_COUNT" -gt 0 ]; then
  echo "ci_status=CHECKS_DISCOVERED"

  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASSING="$(
    jq \
      '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  echo "$FINAL_CHECKS" | jq .
  echo "non_passing_check_count=$NON_PASSING"

  test "$NON_PASSING" -eq 0

  echo "timing_evidence_ci=PASS"
else
  echo "ci_status=NOT_TRIGGERED_FOR_THIS_CHANGESET"
  echo "timing_evidence_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Final merge gate ==="

MERGE_READY=0

for ATTEMPT in $(seq 1 30); do
  PR_DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
  PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
  PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"

  echo \
    "merge_poll_attempt=$ATTEMPT " \
    "state=$PR_STATE " \
    "head=$PR_HEAD " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$PR_STATE" = "OPEN" ] \
     && [ "$PR_HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$PR_BASE" = "$BASE" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    MERGE_READY=1
    break
  fi

  sleep 5
done

test "$MERGE_READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #12 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "base_head=$BASE_HEAD"
echo "timing_commit_is_ancestor=PASS"

echo
echo "=== 7. Verify merged timing evidence ==="

"$PYTHON" - \
  "$ROOT" \
  "$REPORT" \
  "$OUTPUT_ROOT" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
report_path = root / sys.argv[2]
output_root = root / sys.argv[3]


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SystemExit(f"Missing JSON: {path}")

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


report = load_json(report_path)

expected = {
    "status": "pass",
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

replications = report.get("replications")

if not isinstance(replications, list):
    raise SystemExit("Missing replications list.")

if len(replications) != 10:
    raise SystemExit("Expected ten replications.")

total_rows = 0
total_warmups = 0
total_measurements = 0

for expected_index, item in enumerate(replications):
    index = int(item["replication_index"])

    if index != expected_index:
        raise SystemExit(
            f"Unexpected replication index {index}."
        )

    csv_path = (
        output_root
        / f"rep_{index:03d}"
        / "timing_observations.csv"
    )

    if not csv_path.is_file():
        raise SystemExit(
            f"Missing timing CSV: {csv_path}"
        )

    if (
        sha256_file(csv_path)
        != item["timing_observations_sha256"]
    ):
        raise SystemExit(
            f"Replication {index}: CSV hash mismatch."
        )

    with csv_path.open(
        newline="",
        encoding="utf-8",
    ) as stream:
        rows = list(csv.DictReader(stream))

    phases = Counter(
        str(row.get("phase", "")).lower()
        for row in rows
    )

    if len(rows) != 660:
        raise SystemExit(
            f"Replication {index}: "
            f"expected 660 rows, got {len(rows)}."
        )

    if phases["warmup"] != 60:
        raise SystemExit(
            f"Replication {index}: invalid warmup count."
        )

    if phases["measurement"] != 600:
        raise SystemExit(
            f"Replication {index}: invalid measurement count."
        )

    total_rows += len(rows)
    total_warmups += phases["warmup"]
    total_measurements += phases["measurement"]

if total_rows != 6600:
    raise SystemExit(
        f"Expected 6600 rows, got {total_rows}."
    )

if total_warmups != 600:
    raise SystemExit(
        f"Expected 600 warmups, got {total_warmups}."
    )

if total_measurements != 6000:
    raise SystemExit(
        f"Expected 6000 measurements, "
        f"got {total_measurements}."
    )

print("merged_timing_evidence=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("csv_observation_row_count=6600")
print("warmup_observation_count=600")
print("measurement_observation_count=6000")
print("all_csv_hashes_match=true")
print("functional_execution_rerun_performed=false")
print("timing_execution_rerun_performed=false")
print("timing_execution_performed=true")
print("precision_analysis_performed=false")
PY

echo
echo "=== 8. Cleanup local execution branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "stage10_timing_evidence_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "warmup_observation_count=600"
echo "measurement_observation_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "timing_execution_performed=true"
echo "precision_analysis_performed=false"
echo "next_stage=analyze_stage10_clustered_timing_precision_v2"

git status --short --branch
git log --oneline --decorate -5
