
#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=35

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
EXPECTED_PARENT="6c4dac8312f4798fd0f1ede499cba58f57ab8368"
EXPECTED_SPEC_COMMIT="4aeb2749f480593038e3118ab61414824da85d91"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN="$E3/campaigns/objective_count_stage10_c8_nv32"
WORKLOADS="$CAMPAIGN/common_workloads"
SPECS="$E3/execution_specs"
RUNS="$E3/runs"

SPEC_MANIFEST="$SPECS/objective_count_stage10_execution_spec_manifest.json"
SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

SPEC_REPORT="$E3/planning/sa5_objective_count_stage10_execution_spec_materialization_report.json"
SPEC_REPORT_SHA="5aba779eee953daaba56eeb39e6f3ee189eca379de3a38b4b720db66be46f23e"

SPEC_SUMMARY="$E3/planning/sa5_objective_count_stage10_execution_spec_materialization_report.md"
SPEC_SUMMARY_SHA="d38d216f6e4a75225a49d1e433c437beda4a410ae6af4c0466273102275e9671"

CAMPAIGN_HASHES="$E3/audits/objective_count_stage10_c8_nv32/canonical_campaign_file_manifest.sha256"
CAMPAIGN_HASHES_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

CI_AUDIT="/workspaces/sa5_objective_count_pr35_ci_eligibility_audit_20260805T130550Z/sa5_objective_count_pr35_ci_eligibility_audit.json"
CI_AUDIT_SHA="d8866ca85e684fb8d7f9838ab4e7ad9d512a926fa9fd67146c82fadda8147ea7"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT="/workspaces/sa5_objective_count_stage10_functional_execution_authorization_${STAMP}"
REPORT="$AUDIT/sa5_objective_count_stage10_functional_execution_authorization.json"
SURFACE="$AUDIT/sa5_objective_count_stage10_functional_execution_authorization.txt"
PREFLIGHT="$AUDIT/detached_preflight_runtime"

trap 'echo "[ERROR] Functional authorization audit stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact merged-state gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

read -r C P1 P2 EXTRA <<<"$(git rev-list --parents -n 1 "$EXPECTED_HEAD")"
test "$C" = "$EXPECTED_HEAD"
test "$P1" = "$EXPECTED_PARENT"
test "$P2" = "$EXPECTED_SPEC_COMMIT"
test -z "${EXTRA:-}"

gh pr view "$PR" --repo "$REPO" \
  --json state,mergedAt,mergeCommit,headRefOid,baseRefName |
jq -e \
  --arg merge "$EXPECTED_HEAD" \
  --arg feature "$EXPECTED_SPEC_COMMIT" \
  --arg base "$BASE" \
  '.state=="MERGED"
   and .mergedAt!=null
   and .mergeCommit.oid==$merge
   and .headRefOid==$feature
   and .baseRefName==$base' >/dev/null

verify_sha "$CI_AUDIT" "$CI_AUDIT_SHA"
jq -e '
  .pull_request==35
  and .eligible_pull_request_workflow_count==0
  and .registered_ci.failure_count==0
  and .decision.ci_absence_is_expected==true
  and .blocker_count==0
' "$CI_AUDIT" >/dev/null

echo "merged_state_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "execution_spec_commit=$EXPECTED_SPEC_COMMIT"

echo
echo "=== 2. Frozen-input integrity gate ==="

verify_sha "$SPEC_MANIFEST" "$SPEC_MANIFEST_SHA"
verify_sha "$SPEC_REPORT" "$SPEC_REPORT_SHA"
verify_sha "$SPEC_SUMMARY" "$SPEC_SUMMARY_SHA"
verify_sha "$CAMPAIGN_HASHES" "$CAMPAIGN_HASHES_SHA"
sha256sum -c "$CAMPAIGN_HASHES" >/dev/null

test "$(find "$SPECS" -maxdepth 1 -type f \
  -name 'objective_count_stage10_rep_*_canonical.json' | wc -l)" -eq 10

test "$({ find "$RUNS" -maxdepth 1 -type d \
  -name 'objective_count_stage10_rep_*_canonical' 2>/dev/null || true; } |
  wc -l)" -eq 0

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "frozen_input_integrity_gate=PASS"
echo "canonical_execution_spec_count=10"
echo "canonical_run_count=0"

echo
echo "=== 3. E3 contract gate ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" backend/harness/sensitivity_execution/validate_e3_contract.py
echo "e3_contract_gate=PASS"

echo
echo "=== 4. Complete detached preflight and authorization ==="

rm -rf "$AUDIT"
mkdir -p "$AUDIT"

export REPORT SURFACE PREFLIGHT
export SPEC_MANIFEST_ABS="$ROOT/$SPEC_MANIFEST"
export SPECS_ABS="$ROOT/$SPECS"
export CAMPAIGN_ABS="$ROOT/$CAMPAIGN"
export WORKLOADS_ABS="$ROOT/$WORKLOADS"
export RUNS_ABS="$ROOT/$RUNS"
export EXPECTED_HEAD EXPECTED_SPEC_COMMIT
export SPEC_MANIFEST_SHA SPEC_REPORT_SHA CAMPAIGN_HASHES_SHA

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import inspect
import json
import os
import shutil
from collections import Counter
from pathlib import Path
from typing import Any

from backend.ckg.ckg_updater import CKGGraph
from backend.harness.sensitivity_execution.execute_controlled_family import (
    E3_EXECUTOR_VERSION,
    _build_instance_ckg,
    _execute_instance,
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    SCHEMA_VERSION as EXECUTION_SCHEMA_VERSION,
    validate_execution_spec,
)
from backend.harness.sensitivity_execution.validate_workload_spec import (
    validate_workload_spec,
)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        ) + "\n",
        encoding="utf-8",
    )


report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])
preflight_root = Path(os.environ["PREFLIGHT"])

spec_manifest_path = Path(os.environ["SPEC_MANIFEST_ABS"])
spec_dir = Path(os.environ["SPECS_ABS"])
campaign = Path(os.environ["CAMPAIGN_ABS"]).resolve()
workloads = Path(os.environ["WORKLOADS_ABS"]).resolve()
runs = Path(os.environ["RUNS_ABS"]).resolve()

spec_manifest = read_json(spec_manifest_path)
campaign_manifest = read_json(campaign / "campaign_manifest.json")
workload_manifest = read_json(
    workloads / "common_workloads_manifest.json"
)

assert spec_manifest["execution_spec_count"] == 10
assert spec_manifest["selected_instances_per_spec"] == 6
assert spec_manifest["total_selected_instance_count"] == 60
assert spec_manifest["unique_selected_instance_count"] == 60
assert campaign_manifest["levels"] == [1, 2, 5, 10, 20, 50]
assert campaign_manifest["realised_instance_count"] == 60
assert workload_manifest["workload_count"] == 10
assert workload_manifest["workload_length"] == 32
assert workload_manifest["contributive_query_count_per_workload"] == 24
assert workload_manifest["non_contributive_query_count_per_workload"] == 8

spec_paths = sorted(
    spec_dir.glob("objective_count_stage10_rep_*_canonical.json")
)
assert len(spec_paths) == 10

execution_ids: list[str] = []
output_dirs: list[str] = []
workload_paths: list[str] = []
instance_ids: list[str] = []
all_instances = []
spec_rows: list[dict[str, Any]] = []

for entry, spec_path in zip(spec_manifest["entries"], spec_paths):
    assert spec_path.name == entry["filename"]
    assert sha(spec_path) == entry["file_sha256"]

    payload = read_json(spec_path)
    validate_execution_spec(payload)
    assert payload["continue_on_instance_failure"] is False

    inputs = load_execution_inputs(spec_path)
    assert inputs.campaign_dir.resolve() == campaign
    assert inputs.workload_path.parent.resolve() == workloads
    assert inputs.output_dir.parent == runs
    assert not inputs.output_dir.exists()

    workload = read_json(inputs.workload_path)
    validate_workload_spec(workload)
    assert len(workload["steps"]) == 32

    assert len(inputs.instances) == 6
    assert [x.factor_level for x in inputs.instances] == [1, 2, 5, 10, 20, 50]

    rep = int(entry["replication_index"])
    seed = int(entry["seed"])
    assert {x.replication_index for x in inputs.instances} == {rep}
    assert {x.seed for x in inputs.instances} == {seed}

    ids = [x.canonical_instance_id for x in inputs.instances]
    assert ids == entry["selected_instance_ids"]

    execution_ids.append(payload["execution_id"])
    output_dirs.append(str(inputs.output_dir))
    workload_paths.append(str(inputs.workload_path))
    instance_ids.extend(ids)
    all_instances.extend(inputs.instances)

    spec_rows.append({
        "replication_index": rep,
        "seed": seed,
        "filename": spec_path.name,
        "execution_id": payload["execution_id"],
        "output_dir": str(inputs.output_dir),
        "workload_path": str(inputs.workload_path),
        "selected_instance_count": 6,
        "selected_instance_ids": ids,
        "continue_on_instance_failure": False,
    })

assert len(set(execution_ids)) == 10
assert len(set(output_dirs)) == 10
assert len(set(workload_paths)) == 10
assert len(instance_ids) == 60
assert len(set(instance_ids)) == 60
assert len(all_instances) == 60

assert Counter(x.factor_level for x in all_instances) == {
    1: 10, 2: 10, 5: 10, 10: 10, 20: 10, 50: 10
}
assert Counter(x.replication_index for x in all_instances) == {
    index: 6 for index in range(10)
}

source = inspect.getsource(_execute_instance)
assert '"objective_id": instance.objective_id' in source
assert "ckg.evaluate_step" in source
assert "ckg.update_from_step" in source

original = CKGGraph.evaluate_step

def forbidden(*args: Any, **kwargs: Any) -> Any:
    raise AssertionError(
        "evaluate_step is forbidden during authorization preflight"
    )

CKGGraph.evaluate_step = forbidden
preflight_rows: list[dict[str, Any]] = []

try:
    for instance in sorted(
        all_instances,
        key=lambda x: (x.replication_index, x.factor_level),
    ):
        runtime = preflight_root / instance.canonical_instance_id
        ckg = _build_instance_ckg(
            instance=instance,
            runtime_output_dir=runtime,
        )
        assert instance.objective_id in ckg.objectives
        assert len(ckg.objectives) == instance.factor_level
        assert len(ckg.G) > 0
        assert ckg.G.number_of_edges() > 0
        assert not ckg.history
        assert not ckg.session_coverage
        assert not ckg.session_weighted_coverage
        assert not ckg.session_resource_coverage

        preflight_rows.append({
            "canonical_instance_id": instance.canonical_instance_id,
            "factor_level": instance.factor_level,
            "replication_index": instance.replication_index,
            "seed": instance.seed,
            "objective_count": len(ckg.objectives),
            "graph_node_count": len(ckg.G),
            "graph_edge_count": ckg.G.number_of_edges(),
            "selected_objective_present": True,
            "fresh_history": True,
            "fresh_session_state": True,
        })
finally:
    CKGGraph.evaluate_step = original

assert len(preflight_rows) == 60
shutil.rmtree(preflight_root)
assert not preflight_root.exists()
assert not list(runs.glob("objective_count_stage10_rep_*_canonical"))

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "functional-execution-authorization-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "functional_execution_authorized"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "execution_spec_commit": os.environ["EXPECTED_SPEC_COMMIT"],
    "canonical_evidence": {
        "execution_spec_manifest_sha256": os.environ["SPEC_MANIFEST_SHA"],
        "execution_spec_materialization_report_sha256": os.environ[
            "SPEC_REPORT_SHA"
        ],
        "campaign_file_manifest_sha256": os.environ["CAMPAIGN_HASHES_SHA"],
        "execution_schema_version": EXECUTION_SCHEMA_VERSION,
        "executor_version": E3_EXECUTOR_VERSION,
    },
    "execution_plan": {
        "execution_spec_count": 10,
        "instances_per_spec": 6,
        "total_instance_count": 60,
        "unique_instance_count": 60,
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "replication_indices": list(range(10)),
        "workload_count": 10,
        "steps_per_workload": 32,
        "expected_total_step_evaluations": 1920,
        "unique_execution_ids": True,
        "unique_output_directories": True,
        "unique_workload_paths": True,
        "continue_on_instance_failure": False,
        "specs": spec_rows,
    },
    "complete_detached_preflight": {
        "performed": True,
        "formal_campaign_execution": False,
        "workload_step_execution_performed": False,
        "evaluator_call_count": 0,
        "instance_count": 60,
        "all_selected_objectives_present": True,
        "all_graphs_nonempty": True,
        "all_histories_fresh": True,
        "all_session_states_fresh": True,
        "runtime_cleaned": True,
        "instances": preflight_rows,
    },
    "runtime_contract": {
        "objective_rebinding_confirmed": True,
        "production_evaluator_call_confirmed": True,
        "production_updater_call_confirmed": True,
        "evaluator_reimplementation_used": False,
        "output_directories_absent_before_execution": True,
    },
    "authorization": {
        "canonical_functional_execution_authorized": True,
        "execution_scope_frozen": True,
        "execution_specs_frozen": True,
        "campaign_inputs_frozen": True,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "canonical_execution_specs_committed": True,
        "canonical_stage10_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "authorization_complete": True,
    "next_stage": (
        "execute_sa5_objective_count_stage10_functional_campaign"
    ),
}

write_json(report_path, report)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT STAGE-10 FUNCTIONAL EXECUTION AUTHORIZATION",
        "=" * 88,
        f"source_commit={report['source_commit']}",
        "execution_spec_count=10",
        "total_instance_count=60",
        "expected_total_step_evaluations=1920",
        "complete_detached_preflight=PASS",
        "preflight_instance_count=60",
        "workload_step_execution_performed=false",
        "evaluator_call_count=0",
        "preflight_runtime_cleaned=true",
        "canonical_functional_execution_authorized=true",
        "timing_execution_authorized=false",
        "precision_analysis_authorized=false",
        "bootstrap_analysis_authorized=false",
        "scientific_result_interpretation_authorized=false",
        "manuscript_integration_authorized=false",
        "canonical_stage10_functional_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        "blocker_count=0",
        "authorization_complete=true",
        f"next_stage={report['next_stage']}",
        "",
    ]),
    encoding="utf-8",
)

print("complete_detached_preflight=PASS")
print("preflight_instance_count=60")
print("preflight_factor_level_coverage=PASS")
print("preflight_replication_coverage=PASS")
print("workload_step_execution_performed=false")
print("evaluator_call_count=0")
print("preflight_runtime_cleaned=true")
print("runtime_objective_rebinding_confirmed=true")
print("expected_total_step_evaluations=1920")
print("canonical_functional_execution_authorized=true")
print(f"report={report_path}")
print(f"report_sha256={sha(report_path)}")
print(f"surface={surface_path}")
print(f"surface_sha256={sha(surface_path)}")
print(f"next_stage={report['next_stage']}")
PY

echo
echo "=== 5. Authorization report gate ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_authorized"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .execution_spec_commit
    == "4aeb2749f480593038e3118ab61414824da85d91"
  and .execution_plan.execution_spec_count == 10
  and .execution_plan.total_instance_count == 60
  and .execution_plan.unique_instance_count == 60
  and .execution_plan.expected_total_step_evaluations == 1920
  and .complete_detached_preflight.instance_count == 60
  and .complete_detached_preflight.workload_step_execution_performed == false
  and .complete_detached_preflight.evaluator_call_count == 0
  and .complete_detached_preflight.runtime_cleaned == true
  and .runtime_contract.objective_rebinding_confirmed == true
  and .runtime_contract.production_evaluator_call_confirmed == true
  and .runtime_contract.production_updater_call_confirmed == true
  and .authorization.canonical_functional_execution_authorized == true
  and .authorization.execution_scope_frozen == true
  and .authorization.execution_specs_frozen == true
  and .authorization.campaign_inputs_frozen == true
  and .authorization.timing_execution_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .authorization_complete == true
  and .next_stage
    == "execute_sa5_objective_count_stage10_functional_campaign"
' "$REPORT" >/dev/null

echo "functional_execution_authorization_report_validation=PASS"

echo
echo "=== 6. Immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
verify_sha "$SPEC_MANIFEST" "$SPEC_MANIFEST_SHA"
verify_sha "$SPEC_REPORT" "$SPEC_REPORT_SHA"
verify_sha "$SPEC_SUMMARY" "$SPEC_SUMMARY_SHA"
verify_sha "$CAMPAIGN_HASHES" "$CAMPAIGN_HASHES_SHA"
sha256sum -c "$CAMPAIGN_HASHES" >/dev/null

test "$({ find "$RUNS" -maxdepth 1 -type d \
  -name 'objective_count_stage10_rep_*_canonical' 2>/dev/null || true; } |
  wc -l)" -eq 0

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "repository_immutability_gate=PASS"
echo "canonical_run_count=0"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Final state ==="

echo "sa5_objective_count_stage10_functional_execution_authorization=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$(sha256sum "$REPORT" | awk '{print $1}')"
echo "surface=$SURFACE"
echo "surface_sha256=$(sha256sum "$SURFACE" | awk '{print $1}')"
echo "execution_spec_count=10"
echo "total_instance_count=60"
echo "expected_total_step_evaluations=1920"
echo "complete_detached_preflight=PASS"
echo "preflight_instance_count=60"
echo "evaluator_call_count=0"
echo "canonical_run_count=0"
echo "blocker_count=0"
echo "authorization_complete=true"
echo "canonical_functional_execution_authorized=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_authorized=false"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "manuscript_integration_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=execute_sa5_objective_count_stage10_functional_campaign"

git status --short --branch
