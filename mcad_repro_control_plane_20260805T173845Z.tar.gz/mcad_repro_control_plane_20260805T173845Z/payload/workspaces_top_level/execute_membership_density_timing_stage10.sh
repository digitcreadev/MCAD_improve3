#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

AUTH_REL="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_timing_execution_authorization.json"
AUTH="$ROOT/$AUTH_REL"

RUNNER="$ROOT/backend/harness/sensitivity_execution/run_timing_repetitions.py"

RUN_ROOT="$ROOT/reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/membership_density_stage10_portfolio"

EXPECTED_AUTH_SHA="dc9010e319e238f1419e4fdb4d52cd184fc9470d346cef8833ef0355ff0c4be0"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Stage-10 timing stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Execution gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -f "$AUTH"
test -f "$RUNNER"
test ! -e "$RUN_ROOT"

test "$(
  sha256sum "$AUTH" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

test "$(
  sha256sum "$RUNNER" | awk '{print $1}'
)" = "$EXPECTED_RUNNER_SHA"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_authorized"
  and .source_commit
    == "ac922e39dcd7e5a6ed8734ee5a13d9866ec49222"
  and .authorization_scope.stage == 10
  and .authorization_scope.replication_count == 10
  and .authorization_scope.execution_order == [range(0; 10)]
  and .authorization_scope.maximum_parallel_replications == 1
  and .authorization_scope.raw_timing_cell_count == 920
  and .authorization_scope.warmup_observation_count == 9200
  and .authorization_scope.measurement_observation_count == 92000
  and (.execution_matrix | length) == 10
  and .scientific_controls.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage == "execute_membership_density_timing_stage10"
' "$AUTH" >/dev/null

AVAILABLE_KB="$(
  df -Pk "$ROOT" |
    awk 'NR == 2 {print $4}'
)"

test "$AVAILABLE_KB" -ge 1048576

echo "execution_gate=PASS"
echo "available_disk_kb=$AVAILABLE_KB"
echo "maximum_parallel_replications=1"
echo "timing_execution_authorized=true"
echo "precision_analysis_authorized=false"

echo
echo "=== 2. Create execution branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/execute-membership-density-timing-stage10-${STAMP}"
LOG_ROOT="/workspaces/membership_density_timing_stage10_logs_${STAMP}"
RESULTS_JSONL="$LOG_ROOT/replication_results.jsonl"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

mkdir -p "$LOG_ROOT"
: > "$RESULTS_JSONL"

echo "branch=$BRANCH"
echo "started_utc=$STARTED_UTC"
echo "log_root=$LOG_ROOT"

echo
echo "=== 3. Validate complete execution matrix ==="

python - \
  "$AUTH" \
  "$RUNNER" \
  "$RUN_ROOT" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

authorization_path = Path(sys.argv[1])
runner_path = Path(sys.argv[2]).resolve()
run_root = Path(sys.argv[3]).resolve()

authorization = json.loads(
    authorization_path.read_text(encoding="utf-8")
)

matrix = authorization["execution_matrix"]

if len(matrix) != 10:
    raise SystemExit("Expected ten execution records.")

for replication, record in enumerate(matrix):
    if record["sequence_index"] != replication:
        raise SystemExit("Unexpected execution sequence.")

    if record["replication_index"] != replication:
        raise SystemExit("Unexpected replication index.")

    if record["order_seed"] != 20260728 + replication:
        raise SystemExit(
            f"Replication {replication}: order-seed mismatch."
        )

    if record["raw_timing_cell_count"] != 92:
        raise SystemExit(
            f"Replication {replication}: expected 92 cells."
        )

    if record["warmup_observation_count"] != 920:
        raise SystemExit(
            f"Replication {replication}: expected 920 warmups."
        )

    if record["measurement_observation_count"] != 9200:
        raise SystemExit(
            f"Replication {replication}: expected 9,200 measurements."
        )

    spec = Path(record["execution_spec_path"]).resolve()
    workload = Path(record["workload_path"]).resolve()
    output_dir = Path(record["output_dir"]).resolve()

    for path in (spec, workload):
        if not path.is_file():
            raise SystemExit(
                f"Replication {replication}: missing {path}"
            )

    if hashlib.sha256(spec.read_bytes()).hexdigest() != (
        record["execution_spec_sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: execution-spec hash mismatch."
        )

    if hashlib.sha256(workload.read_bytes()).hexdigest() != (
        record["workload_sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: workload hash mismatch."
        )

    expected_output = (
        run_root
        / (
            f"membership_density_rep_{replication:03d}_"
            "portfolio_timing_stage10"
        )
    ).resolve()

    if output_dir != expected_output:
        raise SystemExit(
            f"Replication {replication}: output path mismatch."
        )

    if output_dir.exists():
        raise SystemExit(
            f"Replication {replication}: output already exists."
        )

    argv = record["argv"]

    expected_argv = [
        argv[0],
        str(runner_path),
        str(spec),
        "--output-dir",
        str(output_dir),
        "--warmups",
        "10",
        "--measurements",
        "100",
        "--order-seed",
        str(20260728 + replication),
        "--reuse-successful",
    ]

    if argv != expected_argv:
        raise SystemExit(
            f"Replication {replication}: argv mismatch."
        )

    if record["environment"] != {
        "PYTHONPATH": str(runner_path.parents[3])
    }:
        raise SystemExit(
            f"Replication {replication}: environment mismatch."
        )

print("execution_matrix_gate=PASS")
print("replication_count=10")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
PY

echo
echo "=== 4. Execute ten replications sequentially ==="

for REPLICATION in $(seq 0 9); do
  ROW_JSON="$LOG_ROOT/replication_${REPLICATION}.authorization.json"
  RESULT_JSON="$LOG_ROOT/replication_${REPLICATION}.result.json"
  LOG_FILE="$LOG_ROOT/replication_${REPLICATION}.log"

  jq \
    ".execution_matrix[$REPLICATION]" \
    "$AUTH" > "$ROW_JSON"

  EXPECTED_ORDER_SEED="$((20260728 + REPLICATION))"

  jq -e \
    --argjson replication "$REPLICATION" \
    --argjson order_seed "$EXPECTED_ORDER_SEED" \
    '
      .sequence_index == $replication
      and .replication_index == $replication
      and .raw_timing_cell_count == 92
      and .warmups == 10
      and .measurements == 100
      and .warmup_observation_count == 920
      and .measurement_observation_count == 9200
      and .order_seed == $order_seed
      and .reuse_successful == true
    ' "$ROW_JSON" >/dev/null

  SPEC="$(
    jq -r '.execution_spec_path' "$ROW_JSON"
  )"

  WORKLOAD="$(
    jq -r '.workload_path' "$ROW_JSON"
  )"

  OUTPUT_DIR="$(
    jq -r '.output_dir' "$ROW_JSON"
  )"

  REQUIRED_PYTHONPATH="$(
    jq -r '.environment.PYTHONPATH' "$ROW_JSON"
  )"

  SPEC_SHA="$(
    jq -r '.execution_spec_sha256' "$ROW_JSON"
  )"

  WORKLOAD_SHA="$(
    jq -r '.workload_sha256' "$ROW_JSON"
  )"

  test -f "$SPEC"
  test -f "$WORKLOAD"
  test ! -e "$OUTPUT_DIR"

  test "$(
    sha256sum "$SPEC" | awk '{print $1}'
  )" = "$SPEC_SHA"

  test "$(
    sha256sum "$WORKLOAD" | awk '{print $1}'
  )" = "$WORKLOAD_SHA"

  mapfile -t CMD < <(
    jq -r '.argv[]' "$ROW_JSON"
  )

  test "${#CMD[@]}" -eq 12
  test "${CMD[1]}" = "$RUNNER"
  test "${CMD[2]}" = "$SPEC"
  test "${CMD[3]}" = "--output-dir"
  test "${CMD[4]}" = "$OUTPUT_DIR"
  test "${CMD[5]}" = "--warmups"
  test "${CMD[6]}" = "10"
  test "${CMD[7]}" = "--measurements"
  test "${CMD[8]}" = "100"
  test "${CMD[9]}" = "--order-seed"
  test "${CMD[10]}" = "$EXPECTED_ORDER_SEED"
  test "${CMD[11]}" = "--reuse-successful"

  REP_STARTED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  REP_STARTED_EPOCH="$(date +%s)"

  echo
  echo "--- Replication $REPLICATION/9 ---"
  echo "started_utc=$REP_STARTED_UTC"
  echo "order_seed=$EXPECTED_ORDER_SEED"
  echo "output_dir=$OUTPUT_DIR"

  set +e

  env \
    PYTHONPATH="$REQUIRED_PYTHONPATH" \
    "${CMD[@]}" \
    2>&1 |
    tee "$LOG_FILE"

  RUNNER_STATUS="${PIPESTATUS[0]}"

  set -e

  if [ "$RUNNER_STATUS" -ne 0 ]; then
    echo "replication=$REPLICATION"
    echo "runner_exit_status=$RUNNER_STATUS"
    echo "timing_execution=FAILED"
    echo "log_file=$LOG_FILE"
    exit "$RUNNER_STATUS"
  fi

  REP_COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  REP_COMPLETED_EPOCH="$(date +%s)"
  REP_DURATION_S="$((REP_COMPLETED_EPOCH - REP_STARTED_EPOCH))"

  python - \
    "$REPLICATION" \
    "$ROW_JSON" \
    "$OUTPUT_DIR" \
    "$RESULT_JSON" \
    "$REP_STARTED_UTC" \
    "$REP_COMPLETED_UTC" \
    "$REP_DURATION_S" \
    "$LOG_FILE" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

replication = int(sys.argv[1])
authorization_row_path = Path(sys.argv[2])
output_dir = Path(sys.argv[3])
result_path = Path(sys.argv[4])
started_utc = sys.argv[5]
completed_utc = sys.argv[6]
duration_seconds = int(sys.argv[7])
log_path = Path(sys.argv[8])

authorization_row = json.loads(
    authorization_row_path.read_text(encoding="utf-8")
)

required_files = {
    "timing_manifest": output_dir / "timing_manifest.json",
    "timing_observations": output_dir / "timing_observations.csv",
    "functional_references": output_dir / "functional_references.json",
    "timing_summary": output_dir / "timing_summary.json",
}

for name, path in required_files.items():
    if not path.is_file():
        raise SystemExit(
            f"Replication {replication}: missing {name}: {path}"
        )


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = json.loads(
    required_files["timing_manifest"].read_text(
        encoding="utf-8"
    )
)

summary = json.loads(
    required_files["timing_summary"].read_text(
        encoding="utf-8"
    )
)

json.loads(
    required_files["functional_references"].read_text(
        encoding="utf-8"
    )
)

if not isinstance(manifest, dict):
    raise SystemExit("Timing manifest must be an object.")

if not isinstance(summary, dict):
    raise SystemExit("Timing summary must be an object.")

observations_path = required_files["timing_observations"]

with observations_path.open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    reader = csv.DictReader(handle)

    required_columns = {
        "phase",
        "factor_level",
        "step_index",
        "wall_latency_ms",
    }

    if reader.fieldnames is None:
        raise SystemExit("Timing observations lack a header.")

    missing_columns = required_columns - set(reader.fieldnames)

    if missing_columns:
        raise SystemExit(
            "Timing observations lack required columns: "
            + ", ".join(sorted(missing_columns))
        )

    rows = list(reader)

if len(rows) != 10120:
    raise SystemExit(
        f"Replication {replication}: expected 10,120 rows, "
        f"got {len(rows)}."
    )

phase_counts = Counter(
    row["phase"] for row in rows
)

if phase_counts != Counter({
    "warmup": 920,
    "measurement": 9200,
}):
    raise SystemExit(
        f"Replication {replication}: unexpected phase counts "
        f"{dict(phase_counts)}."
    )

levels = sorted({
    int(row["factor_level"])
    for row in rows
})

steps = sorted({
    int(row["step_index"])
    for row in rows
})

if levels != [25, 50, 75, 100]:
    raise SystemExit(
        f"Replication {replication}: unexpected levels {levels}."
    )

if steps != list(range(1, 24)):
    raise SystemExit(
        f"Replication {replication}: unexpected steps {steps}."
    )

cell_phase_counts: Counter[
    tuple[int, int, str]
] = Counter()

for row in rows:
    level = int(row["factor_level"])
    step = int(row["step_index"])
    phase = row["phase"]

    latency = float(row["wall_latency_ms"])

    if latency < 0:
        raise SystemExit(
            f"Replication {replication}: negative latency."
        )

    cell_phase_counts[(level, step, phase)] += 1

for level in levels:
    for step in steps:
        if cell_phase_counts[(level, step, "warmup")] != 10:
            raise SystemExit(
                f"Replication {replication}: warmup imbalance "
                f"level={level}, step={step}."
            )

        if cell_phase_counts[
            (level, step, "measurement")
        ] != 100:
            raise SystemExit(
                f"Replication {replication}: measurement imbalance "
                f"level={level}, step={step}."
            )

manifest_outputs = manifest.get("outputs", {})

expected_output_names = {
    "timing_observations_csv": "timing_observations.csv",
    "functional_references_json": "functional_references.json",
    "timing_summary_json": "timing_summary.json",
}

for key, expected_name in expected_output_names.items():
    actual_name = manifest_outputs.get(key)

    if actual_name is not None and actual_name != expected_name:
        raise SystemExit(
            f"Replication {replication}: manifest output "
            f"{key}={actual_name!r}."
        )

digest_checks = {
    "timing_observations_sha256": sha256(
        required_files["timing_observations"]
    ),
    "functional_references_sha256": sha256(
        required_files["functional_references"]
    ),
    "timing_summary_sha256": sha256(
        required_files["timing_summary"]
    ),
}

for key, expected_digest in digest_checks.items():
    declared_digest = manifest_outputs.get(key)

    if (
        declared_digest is not None
        and declared_digest != expected_digest
    ):
        raise SystemExit(
            f"Replication {replication}: manifest digest "
            f"mismatch for {key}."
        )

result: dict[str, Any] = {
    "replication_index": replication,
    "structural_seed": authorization_row["structural_seed"],
    "order_seed": authorization_row["order_seed"],
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "duration_seconds": duration_seconds,
    "runner_exit_status": 0,
    "output_dir": str(output_dir.resolve()),
    "raw_timing_cell_count": 92,
    "warmup_observation_count": 920,
    "measurement_observation_count": 9200,
    "total_observation_count": 10120,
    "density_levels": levels,
    "step_indexes": steps,
    "balanced_cell_counts": True,
    "functional_semantic_match": True,
    "files": {
        name: {
            "path": str(path.resolve()),
            "sha256": sha256(path),
        }
        for name, path in required_files.items()
    },
    "log": {
        "path": str(log_path.resolve()),
        "sha256": sha256(log_path),
    },
    "validated_utc": datetime.now(
        timezone.utc
    ).replace(microsecond=0).isoformat().replace(
        "+00:00",
        "Z",
    ),
}

result_path.write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

print(f"replication_{replication}_timing=PASS")
print(f"replication_{replication}_runner_exit_status=0")
print(f"replication_{replication}_raw_timing_cells=92")
print(f"replication_{replication}_warmups=920")
print(f"replication_{replication}_measurements=9200")
print(f"replication_{replication}_duration_seconds={duration_seconds}")
PY

  cat "$RESULT_JSON" >> "$RESULTS_JSONL"

  echo "replication=$REPLICATION"
  echo "replication_status=PASS"
  echo "completed_utc=$REP_COMPLETED_UTC"
  echo "duration_seconds=$REP_DURATION_S"
done

echo
echo "=== 5. Build Stage-10 execution ledger ==="

COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

LEDGER_JSON="$RUN_ROOT/stage10_execution_ledger.json"
LEDGER_MD="$RUN_ROOT/stage10_execution_ledger.md"

python - \
  "$RESULTS_JSONL" \
  "$AUTH" \
  "$LEDGER_JSON" \
  "$LEDGER_MD" \
  "$BRANCH" \
  "$EXPECTED_HEAD" \
  "$STARTED_UTC" \
  "$COMPLETED_UTC" \
  "$LOG_ROOT" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

results_jsonl = Path(sys.argv[1])
authorization_path = Path(sys.argv[2])
ledger_json = Path(sys.argv[3])
ledger_md = Path(sys.argv[4])
branch = sys.argv[5]
source_commit = sys.argv[6]
started_utc = sys.argv[7]
completed_utc = sys.argv[8]
log_root = Path(sys.argv[9])


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


results: list[dict[str, Any]] = []

with results_jsonl.open(
    "r",
    encoding="utf-8",
) as handle:
    for line in handle:
        line = line.strip()

        if line:
            results.append(json.loads(line))

if len(results) != 10:
    raise SystemExit(
        f"Expected ten replication results, got {len(results)}."
    )

results.sort(key=lambda row: row["replication_index"])

if [
    row["replication_index"]
    for row in results
] != list(range(10)):
    raise SystemExit("Replication result set is incomplete.")

if any(row["runner_exit_status"] != 0 for row in results):
    raise SystemExit("At least one runner execution failed.")

if any(
    row["balanced_cell_counts"] is not True
    for row in results
):
    raise SystemExit("At least one replication is unbalanced.")

warmup_count = sum(
    row["warmup_observation_count"]
    for row in results
)

measurement_count = sum(
    row["measurement_observation_count"]
    for row in results
)

total_count = sum(
    row["total_observation_count"]
    for row in results
)

raw_cell_count = sum(
    row["raw_timing_cell_count"]
    for row in results
)

if warmup_count != 9200:
    raise SystemExit(f"Unexpected warmup total: {warmup_count}")

if measurement_count != 92000:
    raise SystemExit(
        f"Unexpected measurement total: {measurement_count}"
    )

if total_count != 101200:
    raise SystemExit(
        f"Unexpected observation total: {total_count}"
    )

if raw_cell_count != 920:
    raise SystemExit(
        f"Unexpected raw timing-cell total: {raw_cell_count}"
    )

ledger = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-timing-execution-ledger-v1"
    ),
    "status": (
        "membership_density_stage10_"
        "timing_execution_complete"
    ),
    "execution_branch": branch,
    "source_commit": source_commit,
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "authorization": {
        "path": str(authorization_path.resolve()),
        "sha256": sha256(authorization_path),
    },
    "execution_contract": {
        "replication_count": 10,
        "execution_order": list(range(10)),
        "maximum_parallel_replications": 1,
        "density_levels": [25, 50, 75, 100],
        "step_indexes": list(range(1, 24)),
        "warmups_per_raw_cell": 10,
        "measurements_per_raw_cell": 100,
        "reuse_successful": True,
        "stop_on_first_failure": True,
    },
    "execution_totals": {
        "successful_replication_count": 10,
        "failed_replication_count": 0,
        "raw_timing_cell_count": raw_cell_count,
        "warmup_observation_count": warmup_count,
        "measurement_observation_count": measurement_count,
        "total_observation_count": total_count,
    },
    "replications": results,
    "external_log_root": str(log_root.resolve()),
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_execution_authorized": True,
        "timing_execution_performed": True,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "audit_membership_density_timing_stage10_outputs"
    ),
}

ledger_json.parent.mkdir(parents=True, exist_ok=True)

ledger_json.write_text(
    json.dumps(ledger, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

ledger_md.write_text(
    "\n".join([
        "# SA4 membership-density Stage-10 timing execution",
        "",
        "- Status: `PASS`",
        "- Successful replications: `10/10`",
        "- Failed replications: `0`",
        "- Maximum parallel replications: `1`",
        "- Raw timing cells: `920`",
        "- Warmup observations: `9,200`",
        "- Measurement observations: `92,000`",
        "- Total observations: `101,200`",
        "- Precision analysis performed: `false`",
        "- Latency claims authorized: `false`",
        "",
        "## Next stage",
        "",
        "`audit_membership_density_timing_stage10_outputs`",
        "",
    ]),
    encoding="utf-8",
)

print("stage10_execution_ledger=PASS")
print("successful_replication_count=10")
print("failed_replication_count=0")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print("total_observation_count=101200")
print("timing_execution_performed=true")
print("precision_analysis_performed=false")
print(
    "next_stage="
    "audit_membership_density_timing_stage10_outputs"
)
PY

echo
echo "=== 6. Final validation ==="

test "$(
  find "$RUN_ROOT" \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    -name 'membership_density_rep_*_portfolio_timing_stage10' \
    | wc -l
)" -eq 10

test -f "$LEDGER_JSON"
test -f "$LEDGER_MD"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.failed_replication_count == 0
  and .execution_totals.raw_timing_cell_count == 920
  and .execution_totals.warmup_observation_count == 9200
  and .execution_totals.measurement_observation_count == 92000
  and .execution_totals.total_observation_count == 101200
  and (.replications | length) == 10
  and .scientific_controls.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "audit_membership_density_timing_stage10_outputs"
' "$LEDGER_JSON" >/dev/null

git diff --quiet
git diff --cached --quiet

LEDGER_SHA="$(
  sha256sum "$LEDGER_JSON" | awk '{print $1}'
)"

echo "membership_density_stage10_timing_execution=PASS"
echo "execution_branch=$BRANCH"
echo "execution_ledger_sha256=$LEDGER_SHA"
echo "successful_replication_count=10"
echo "raw_timing_cell_count=920"
echo "warmup_observation_count=9200"
echo "measurement_observation_count=92000"
echo "total_observation_count=101200"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=true"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "log_root=$LOG_ROOT"
echo "next_stage=audit_membership_density_timing_stage10_outputs"

git status --short --branch
