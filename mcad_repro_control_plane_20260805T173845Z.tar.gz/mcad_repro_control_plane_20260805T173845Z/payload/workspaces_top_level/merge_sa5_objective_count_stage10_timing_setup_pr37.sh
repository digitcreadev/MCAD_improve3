#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=37

BASE="paper/phase3-controlled-execution"
BRANCH="paper/prepare-sa5-objective-count-stage10-timing-20260805T153354Z"

EXPECTED_BASE_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"
EXPECTED_FEATURE_HEAD="e76f68808811f8c84616386e55e6873deebd2bed"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
EXPECTED_SETUP_MANIFEST_SHA="5e5baad8a32d5c9c8e647d8d2365d68a9e3a286e620fc783373ec577a26cf155"

SETUP_FILES="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"
EXPECTED_SETUP_FILES_SHA="c785ab0fafc1c424e7a737d0dfd4282cb01b7ef071cf54c2adeb4304fb9ad9af"

AUTHORIZATION="$E3/planning/sa5_objective_count_stage10_timing_execution_authorization.json"
EXPECTED_AUTHORIZATION_SHA="bb8805eaaedb3277e25197a1eab2d5b4e484aa66006fc4a4dcf0bff424b47c20"

TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CI_AUDIT_ROOT="/workspaces/sa5_objective_count_pr37_ci_eligibility_audit_${STAMP}"
CI_AUDIT_REPORT="$CI_AUDIT_ROOT/sa5_objective_count_pr37_ci_eligibility_audit.json"
CI_AUDIT_SURFACE="$CI_AUDIT_ROOT/sa5_objective_count_pr37_ci_eligibility_audit.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_pr37_merge.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #37 merge stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact Timing Setup gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_FILES" "$EXPECTED_SETUP_FILES_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"

test "$(wc -l < "$SETUP_FILES")" -eq 19
sha256sum -c "$SETUP_FILES" >/dev/null

jq -e '
  .status == "sa5_objective_count_stage10_timing_setup_complete"
  and .source_commit
    == "0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .objective_count_timing_plan.factor_levels
    == [1,2,5,10,20,50]
  and .objective_count_timing_plan.replication_count == 10
  and .objective_count_timing_plan.instance_count == 60
  and .objective_count_timing_plan.timing_spec_count == 10
  and .objective_count_timing_plan.measured_repetitions_per_factor_level == 2530
  and .objective_count_timing_plan.expected_observation_rows_per_replication == 15180
  and .objective_count_timing_plan.expected_total_observation_rows == 151800
  and .authorization.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .setup_complete == true
' "$SETUP_MANIFEST" >/dev/null

jq -e '
  .status == "timing_execution_authorized"
  and .timing_spec_count == 10
  and .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .precision_analysis_authorized == false
  and .bootstrap_analysis_authorized == false
  and .scientific_result_interpretation_authorized == false
  and .manuscript_integration_authorized == false
  and .blocker_count == 0
  and .authorization_complete == true
  and .next_stage
    == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION" >/dev/null

test ! -e "$TIMING_RUN_ROOT"

echo "timing_setup_gate=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "feature_head=$EXPECTED_FEATURE_HEAD"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo
echo "=== 2. Reconstruct exact 20-file PR scope ==="

awk '{print $2}' "$SETUP_FILES" |
  sort > "$TMP_ROOT/expected_files.txt"

printf '%s\n' "$SETUP_FILES" >> "$TMP_ROOT/expected_files.txt"
sort -o "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 20
test "$(sort -u "$TMP_ROOT/expected_files.txt" | wc -l)" -eq 20

git diff --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/feature_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/feature_files.txt"

echo "exact_scope_gate=PASS"
echo "pr_file_count=20"

echo
echo "=== 3. PR identity and scope gate ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,isDraft,headRefOid,headRefName,baseRefName,title |
jq -e \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .isDraft == false
    and .headRefOid == $feature
    and .headRefName == $branch
    and .baseRefName == $base
    and .title == "Prepare SA5 objective-count Stage-10 timing"
  ' >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 4. Registered CI or workflow-ineligibility gate ==="

PR_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

if ! jq -e 'type == "array"' >/dev/null <<<"$PR_CHECKS"; then
  PR_CHECKS='[]'
fi

PR_CHECK_COUNT="$(jq 'length' <<<"$PR_CHECKS")"

ACTIONS_RUNS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
)"
ACTIONS_RUN_COUNT="$(jq '.total_count' <<<"$ACTIONS_RUNS")"

CHECK_RUNS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
)"
CHECK_RUN_COUNT="$(jq '.total_count' <<<"$CHECK_RUNS")"

COMBINED_STATUS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
)"
LEGACY_STATUS_COUNT="$(jq '.statuses | length' <<<"$COMBINED_STATUS")"

CI_OBJECT_COUNT="$(
  printf '%s\n' \
    "$PR_CHECK_COUNT" \
    "$ACTIONS_RUN_COUNT" \
    "$CHECK_RUN_COUNT" \
    "$LEGACY_STATUS_COUNT" |
  awk '{sum += $1} END {print sum + 0}'
)"

CI_MODE=""

if [ "$CI_OBJECT_COUNT" -gt 0 ]; then
  CI_MODE="registered"

  ACTION_FAILURE="$(
    jq '
      [
        .workflow_runs[]
        | select(
            .status == "completed"
            and (
              .conclusion
              | IN("success", "neutral", "skipped")
              | not
            )
          )
      ] | length
    ' <<<"$ACTIONS_RUNS"
  )"
  ACTION_PENDING="$(
    jq '[.workflow_runs[] | select(.status != "completed")] | length' \
      <<<"$ACTIONS_RUNS"
  )"
  CHECK_FAILURE="$(
    jq '
      [
        .check_runs[]
        | select(
            .status == "completed"
            and (
              .conclusion
              | IN("success", "neutral", "skipped")
              | not
            )
          )
      ] | length
    ' <<<"$CHECK_RUNS"
  )"
  CHECK_PENDING="$(
    jq '[.check_runs[] | select(.status != "completed")] | length' \
      <<<"$CHECK_RUNS"
  )"
  LEGACY_FAILURE="$(
    jq '[.statuses[] | select(.state != "success")] | length' \
      <<<"$COMBINED_STATUS"
  )"

  test "$ACTION_PENDING" -eq 0
  test "$ACTION_FAILURE" -eq 0
  test "$CHECK_PENDING" -eq 0
  test "$CHECK_FAILURE" -eq 0
  test "$LEGACY_FAILURE" -eq 0

  echo "registered_ci_gate=PASS"
else
  CI_MODE="workflow_ineligible"
  mkdir -p "$CI_AUDIT_ROOT"

  export ROOT BASE PR REPO
  export EXPECTED_BASE_HEAD EXPECTED_FEATURE_HEAD
  export CI_AUDIT_REPORT CI_AUDIT_SURFACE
  export EXPECTED_FILES_PATH="$TMP_ROOT/expected_files.txt"

  "$PYTHON" - <<'PY'
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
base_branch = os.environ["BASE"]
changed_files = Path(
    os.environ["EXPECTED_FILES_PATH"]
).read_text(encoding="utf-8").splitlines()

workflow_root = root / ".github" / "workflows"
workflow_files = sorted([
    *workflow_root.glob("*.yml"),
    *workflow_root.glob("*.yaml"),
])
assert workflow_files


def as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def ordered(value: str, patterns: list[str]) -> bool:
    included = False
    for raw in patterns:
        negated = raw.startswith("!")
        pattern = raw[1:] if negated else raw
        if fnmatch.fnmatchcase(value, pattern):
            included = not negated
    return included


def event_config(on_value: Any, event: str) -> tuple[bool, Any]:
    if isinstance(on_value, str):
        return on_value == event, None
    if isinstance(on_value, list):
        return event in [str(item) for item in on_value], None
    if isinstance(on_value, dict):
        return event in on_value, on_value.get(event)
    return False, None


results = []

for workflow_path in workflow_files:
    document = yaml.load(
        workflow_path.read_text(encoding="utf-8"),
        Loader=yaml.BaseLoader,
    )
    assert isinstance(document, dict)

    event_rows = []

    for event in ("pull_request", "pull_request_target"):
        present, config = event_config(document.get("on"), event)
        if not present:
            continue
        if not isinstance(config, dict):
            config = {}

        branches = as_list(config.get("branches"))
        branches_ignore = as_list(config.get("branches-ignore"))
        paths = as_list(config.get("paths"))
        paths_ignore = as_list(config.get("paths-ignore"))

        branch_ok = True
        if branches:
            branch_ok = ordered(base_branch, branches)
        elif branches_ignore:
            branch_ok = not any(
                fnmatch.fnmatchcase(base_branch, pattern)
                for pattern in branches_ignore
            )

        path_ok = True
        if paths:
            path_ok = any(
                ordered(path, paths)
                for path in changed_files
            )
        elif paths_ignore:
            path_ok = any(
                not any(
                    fnmatch.fnmatchcase(path, pattern)
                    for pattern in paths_ignore
                )
                for path in changed_files
            )

        event_rows.append({
            "event": event,
            "eligible": branch_ok and path_ok,
        })

    results.append({
        "workflow": workflow_path.relative_to(root).as_posix(),
        "has_pull_request_event": bool(event_rows),
        "eligible": any(row["eligible"] for row in event_rows),
        "events": event_rows,
    })

eligible = [row for row in results if row["eligible"]]
assert not eligible

report = {
    "schema_version": (
        "mcad-sa5-objective-count-pr37-ci-eligibility-audit-v1"
    ),
    "status": (
        "no_ci_registration_expected_from_workflow_trigger_filters"
    ),
    "repository": os.environ["REPO"],
    "pull_request": int(os.environ["PR"]),
    "base_branch": base_branch,
    "base_head": os.environ["EXPECTED_BASE_HEAD"],
    "feature_head": os.environ["EXPECTED_FEATURE_HEAD"],
    "changed_file_count": len(changed_files),
    "workflow_file_count": len(results),
    "eligible_pull_request_workflow_count": 0,
    "registered_ci_object_count": 0,
    "ci_absence_is_expected": True,
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
}

report_path = Path(os.environ["CI_AUDIT_REPORT"])
surface_path = Path(os.environ["CI_AUDIT_SURFACE"])

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT PR #37 CI ELIGIBILITY AUDIT",
        "=" * 72,
        "pull_request=37",
        "changed_file_count=20",
        "eligible_pull_request_workflow_count=0",
        "registered_ci_object_count=0",
        "ci_absence_is_expected=true",
        "blocker_count=0",
        "audit_complete=true",
        "",
    ]),
    encoding="utf-8",
)

print("workflow_ineligibility_gate=PASS")
print(f"workflow_file_count={len(results)}")
print("eligible_pull_request_workflow_count=0")
print("registered_ci_object_count=0")
print(f"ci_audit_report={report_path}")
print(
    "ci_audit_report_sha256="
    + hashlib.sha256(report_path.read_bytes()).hexdigest()
)
print(f"ci_audit_surface={surface_path}")
print(
    "ci_audit_surface_sha256="
    + hashlib.sha256(surface_path.read_bytes()).hexdigest()
)
PY
fi

echo "ci_mode=$CI_MODE"

echo
echo "=== 5. Fast regression and mergeability gate ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"

DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,isDraft,mergeable,mergeStateStatus
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .isDraft == false
    and .mergeable == "MERGEABLE"
    and .mergeStateStatus == "CLEAN"
  ' <<<"$DATA" >/dev/null

echo "regression_gate=PASS"
echo "mergeability_gate=PASS"

echo
echo "=== 6. Merge exact PR #37 head ==="

MERGE_RESULT="$(
  gh api \
    --method PUT \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/pulls/$PR/merge" \
    -f merge_method=merge \
    -f sha="$EXPECTED_FEATURE_HEAD"
)"

jq -e '.merged == true' <<<"$MERGE_RESULT" >/dev/null

MERGE_COMMIT="$(jq -r '.sha' <<<"$MERGE_RESULT")"
test -n "$MERGE_COMMIT"
test "$MERGE_COMMIT" != "null"

echo "merge_command=PASS"
echo "merge_commit=$MERGE_COMMIT"

echo
echo "=== 7. Synchronize base and validate lineage ==="

git fetch origin --prune

if [ -n "$(git ls-remote --heads origin "$BRANCH")" ]; then
  git push origin --delete "$BRANCH"
fi

git switch "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

test "$(git rev-parse HEAD)" = "$MERGE_COMMIT"

read -r COMMIT P1 P2 EXTRA \
  <<<"$(git rev-list --parents -n 1 "$MERGE_COMMIT")"

test "$COMMIT" = "$MERGE_COMMIT"
test "$P1" = "$EXPECTED_BASE_HEAD"
test "$P2" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA:-}"

echo "merge_lineage_gate=PASS"
echo "first_parent=$P1"
echo "second_parent=$P2"

echo
echo "=== 8. Post-merge exact setup integrity ==="

while IFS= read -r FILE; do
  test -f "$FILE"
  git ls-files --error-unmatch "$FILE" >/dev/null
done < "$TMP_ROOT/expected_files.txt"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_FILES" "$EXPECTED_SETUP_FILES_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
sha256sum -c "$SETUP_FILES" >/dev/null

test ! -e "$TIMING_RUN_ROOT"
test -z "$(git status --porcelain)"

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge "$MERGE_COMMIT" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge
  ' <<<"$FINAL_PR" >/dev/null

if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git branch -d "$BRANCH"
fi

echo "post_merge_setup_integrity_gate=PASS"
echo "pr_final_state=PASS"
echo "branch_cleanup=PASS"

echo
echo "=== 9. Final state ==="

echo "sa5_objective_count_stage10_timing_setup_merge=PASS"
echo "base_head=$MERGE_COMMIT"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "pull_request=37"
echo "ci_mode=$CI_MODE"
echo "merged_file_count=20"
echo "timing_spec_count=10"
echo "measured_repetitions_per_factor_level=2530"
echo "expected_observation_rows_per_replication=15180"
echo "expected_total_observation_rows=151800"

echo "timing_preregistration_preflight_complete=true"
echo "timing_preregistration_complete=true"
echo "timing_inputs_materialized=true"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"

echo "next_stage=execute_sa5_objective_count_stage10_timing_campaign"

git status --short --branch
git log --oneline --decorate -5
