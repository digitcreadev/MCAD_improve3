#!/usr/bin/env bash
set -Eeuo pipefail

HIST="/workspaces/MCAD_improve3"
RECON="/workspaces/MCAD_bridge_reconciliation_20260801T175259Z"

BRANCH="recovery/bridge-reconciliation-20260801T175259Z"
EXPECTED_HEAD="7efc3e74a0f416adc7e0d07cc732e796cf5cc2f0"

SA4_ARCHIVE="/workspaces/SA4_EXACT_RECOVERY_20260801T105252Z.tar.gz"
SA4_SIDECAR="${SA4_ARCHIVE}.sha256"
SA4_INFO="/workspaces/SA4_EXACT_RECOVERY_20260801T105252Z_INFO.txt"

ROBUSTNESS_ROOT="/workspaces/bridge_handoff_import_20260801T172739Z/extracted/MCAD_robustness_handoff_20260731T232253Z/artifacts"
ROBUSTNESS_ARCHIVE="$ROBUSTNESS_ROOT/mcad_robustness_canonical_20260731T223533Z.tar.gz"
ROBUSTNESS_SIDECAR="${ROBUSTNESS_ARCHIVE}.sha256"
ROBUSTNESS_FREEZE_JSON="$ROBUSTNESS_ROOT/mcad_robustness_canonical_20260731T223533Z_FREEZE.json"
ROBUSTNESS_FREEZE_MD="$ROBUSTNESS_ROOT/mcad_robustness_canonical_20260731T223533Z_FREEZE.md"
ROBUSTNESS_FREEZE_SHA="$ROBUSTNESS_ROOT/mcad_robustness_canonical_20260731T223533Z_FREEZE.sha256"
ROBUSTNESS_RUNNER="$ROBUSTNESS_ROOT/run_robustness_canonical_v3.sh"

DEST_REL="experiments/article/frozen_campaigns"
DEST="$RECON/$DEST_REL"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BUILD="/workspaces/frozen_campaigns_materialization_${STAMP}"
BUILD_ROOT="$BUILD/frozen_campaigns"

fail() {
  echo "[ERROR] $*" >&2
  exit 1
}

echo "=== 1. Minimal state gate ==="

test "$(git -C "$HIST" branch --show-current)" = \
  "paper/phase3-controlled-execution" ||
  fail "Historical branch differs."

test -z "$(git -C "$HIST" status --porcelain)" ||
  fail "Historical worktree is not clean."

test "$(git -C "$RECON" branch --show-current)" = "$BRANCH" ||
  fail "Reconciliation branch differs."

test "$(git -C "$RECON" rev-parse HEAD)" = "$EXPECTED_HEAD" ||
  fail "Reconciliation HEAD differs."

test -z "$(git -C "$RECON" status --porcelain)" ||
  fail "Reconciliation worktree is not clean."

test ! -e "$DEST" ||
  fail "Destination already exists: $DEST"

for path in \
  "$SA4_ARCHIVE" \
  "$SA4_SIDECAR" \
  "$SA4_INFO" \
  "$ROBUSTNESS_ARCHIVE" \
  "$ROBUSTNESS_SIDECAR" \
  "$ROBUSTNESS_FREEZE_JSON" \
  "$ROBUSTNESS_FREEZE_MD" \
  "$ROBUSTNESS_FREEZE_SHA" \
  "$ROBUSTNESS_RUNNER"
do
  test -f "$path" || fail "Missing source: $path"
done

mkdir -p "$BUILD_ROOT"

echo "=== 2. Build and validate campaign packages ==="

python - \
  "$BUILD_ROOT" \
  "$SA4_ARCHIVE" \
  "$SA4_SIDECAR" \
  "$SA4_INFO" \
  "$ROBUSTNESS_ARCHIVE" \
  "$ROBUSTNESS_SIDECAR" \
  "$ROBUSTNESS_FREEZE_JSON" \
  "$ROBUSTNESS_FREEZE_MD" \
  "$ROBUSTNESS_FREEZE_SHA" \
  "$ROBUSTNESS_RUNNER" <<'PY'
from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import tarfile
from pathlib import Path

(
    build_root_arg,
    sa4_archive_arg,
    sa4_sidecar_arg,
    sa4_info_arg,
    robustness_archive_arg,
    robustness_sidecar_arg,
    robustness_freeze_json_arg,
    robustness_freeze_md_arg,
    robustness_freeze_sha_arg,
    robustness_runner_arg,
) = sys.argv[1:]

root = Path(build_root_arg)

sa4_archive = Path(sa4_archive_arg)
sa4_sidecar = Path(sa4_sidecar_arg)
sa4_info = Path(sa4_info_arg)

robustness_archive = Path(robustness_archive_arg)
robustness_sidecar = Path(robustness_sidecar_arg)
robustness_freeze_json = Path(robustness_freeze_json_arg)
robustness_freeze_md = Path(robustness_freeze_md_arg)
robustness_freeze_sha = Path(robustness_freeze_sha_arg)
robustness_runner = Path(robustness_runner_arg)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)

    return digest.hexdigest()


def expected_sidecar_digest(path: Path) -> str:
    match = re.search(
        r"\b([0-9a-fA-F]{64})\b",
        path.read_text(encoding="utf-8", errors="replace"),
    )

    if match is None:
        raise RuntimeError(f"No SHA-256 found in {path}")

    return match.group(1).lower()


def validate_archive(archive: Path, sidecar: Path) -> tuple[str, list[str]]:
    actual = sha256(archive)
    expected = expected_sidecar_digest(sidecar)

    if actual != expected:
        raise RuntimeError(
            f"Checksum mismatch for {archive}: "
            f"expected={expected}, actual={actual}"
        )

    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getnames()

    if not members:
        raise RuntimeError(f"Empty archive: {archive}")

    return actual, members


sa4_digest, sa4_members = validate_archive(
    sa4_archive,
    sa4_sidecar,
)

robustness_digest, robustness_members = validate_archive(
    robustness_archive,
    robustness_sidecar,
)

expected_robustness_digest = (
    "181ad92da7e7153869e453e1c76ecfc7"
    "b021713684c5842e33f4e3273b3119d2"
)

if robustness_digest != expected_robustness_digest:
    raise RuntimeError(
        "Unexpected canonical robustness archive digest."
    )

freeze = json.loads(
    robustness_freeze_json.read_text(encoding="utf-8")
)

freeze_expectations = {
    "scientific_freeze": True,
    "freeze_scope": "robustness_non_temporal",
    "global_scientific_freeze": False,
    "latency_claim_authorized": False,
}

for key, expected in freeze_expectations.items():
    observed = freeze.get(key)

    if observed != expected:
        raise RuntimeError(
            f"Freeze contract mismatch for {key}: "
            f"expected={expected!r}, observed={observed!r}"
        )

sa4 = root / "sa4_membership_density_controlled_execution"
robustness = root / "robustness_non_temporal"

for directory in (
    sa4 / "archive",
    sa4 / "source",
    robustness / "archive",
    robustness / "freeze",
    robustness / "scripts",
):
    directory.mkdir(parents=True, exist_ok=True)

shutil.copy2(
    sa4_archive,
    sa4 / "archive" / sa4_archive.name,
)

shutil.copy2(
    sa4_info,
    sa4 / "source" / sa4_info.name,
)

(
    sa4 / "archive" / f"{sa4_archive.name}.sha256"
).write_text(
    f"{sa4_digest}  {sa4_archive.name}\n",
    encoding="utf-8",
)

(sa4 / "CONTENTS.txt").write_text(
    "\n".join(sa4_members) + "\n",
    encoding="utf-8",
)

shutil.copy2(
    robustness_archive,
    robustness / "archive" / robustness_archive.name,
)

(
    robustness
    / "archive"
    / f"{robustness_archive.name}.sha256"
).write_text(
    f"{robustness_digest}  {robustness_archive.name}\n",
    encoding="utf-8",
)

for source in (
    robustness_freeze_json,
    robustness_freeze_md,
    robustness_freeze_sha,
):
    shutil.copy2(
        source,
        robustness / "freeze" / source.name,
    )

shutil.copy2(
    robustness_runner,
    robustness / "scripts" / robustness_runner.name,
)

(robustness / "CONTENTS.txt").write_text(
    "\n".join(robustness_members) + "\n",
    encoding="utf-8",
)

(root / "README.md").write_text(
    """# MCAD frozen campaigns

This directory stores repository-resident canonical evidence packages.

A campaign is marked as repository-persistent only when its archive,
checksum, provenance, reproducibility procedure and freeze status are
present here. Runtime directories and intermediate outputs are not
canonical evidence.
""",
    encoding="utf-8",
)

(sa4 / "README.md").write_text(
    """# SA4 membership-density controlled execution

Exact recovered evidence package for the completed controlled execution
of the `membership_density` sensitivity factor.

The campaign was recovered from its validated historical manifest. It was
not regenerated during repository reconciliation.
""",
    encoding="utf-8",
)

(sa4 / "REPRODUCE.md").write_text(
    """# Reproducibility status

This package preserves the exact historical execution rather than replacing
it with a new run.

Validated properties:

- 212 manifest entries;
- 200 canonical outputs;
- 10 archived logs;
- historical source commit:
  `36fe29d42c8ca53e79e5fa2a8dc35df6e1860c48`;
- complete E3 regression: 196 passed;
- targeted SA4 regression: 37 passed.

No timing or latency claim is authorized.
""",
    encoding="utf-8",
)

(sa4 / "STATUS.json").write_text(
    json.dumps(
        {
            "campaign_id": (
                "sa4_membership_density_controlled_execution"
            ),
            "scientific_status": "completed_recovered",
            "repository_persistence_status": "complete",
            "scientific_freeze": True,
            "freeze_scope": (
                "membership_density_controlled_execution"
            ),
            "global_scientific_freeze": False,
            "timing_execution_authorized": False,
            "latency_claim_authorized": False,
            "manifest_file_count": 212,
            "canonical_output_count": 200,
            "archived_log_count": 10,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

(sa4 / "PROVENANCE.json").write_text(
    json.dumps(
        {
            "historical_source_commit": (
                "36fe29d42c8ca53e79e5fa2a8dc35df6e1860c48"
            ),
            "repository_reconciliation_base": (
                "463d0d4e76904edc80cb7a90637f0eae2ac87d72"
            ),
            "repository_reconciliation_head_before_persistence": (
                "7efc3e74a0f416adc7e0d07cc732e796cf5cc2f0"
            ),
            "canonical_archive_sha256": sa4_digest,
            "recovery_mode": "exact_manifest_validated_recovery",
            "campaign_regenerated": False,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

(robustness / "README.md").write_text(
    """# Non-temporal robustness campaign

Canonical frozen package for the completed non-temporal robustness
campaign. The archive, freeze certificate, exact runner and checksums are
stored together.
""",
    encoding="utf-8",
)

(robustness / "REPRODUCE.md").write_text(
    """# Reproducibility procedure

Use the versioned runner in `scripts/`. The canonical archive must remain
byte-identical to its recorded SHA-256 digest.

The scientific freeze applies only to non-temporal robustness. No timing or
latency claim is authorized.
""",
    encoding="utf-8",
)

(robustness / "STATUS.json").write_text(
    json.dumps(
        {
            "campaign_id": "robustness_non_temporal",
            "scientific_status": "completed_frozen",
            "repository_persistence_status": "complete",
            **freeze_expectations,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

(robustness / "PROVENANCE.json").write_text(
    json.dumps(
        {
            "bridge_source_commit": (
                "185290880a75d6df17c03aad6abbb44ca3818bf0"
            ),
            "reconciled_commit": (
                "7efc3e74a0f416adc7e0d07cc732e796cf5cc2f0"
            ),
            "canonical_archive_sha256": robustness_digest,
            "campaign_regenerated_during_reconciliation": False,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

registry = f"""schema_version: mcad-frozen-campaign-registry-v1
authoritative: true

campaigns:
  robustness_non_temporal:
    scientific_status: completed_frozen
    repository_persistence_status: complete
    path: robustness_non_temporal
    canonical_archive_sha256: {robustness_digest}
    freeze_scope: robustness_non_temporal
    latency_claim_authorized: false

  sa4_membership_density_controlled_execution:
    scientific_status: completed_recovered
    repository_persistence_status: complete
    path: sa4_membership_density_controlled_execution
    canonical_archive_sha256: {sa4_digest}
    manifest_file_count: 212
    canonical_output_count: 200
    archived_log_count: 10
    latency_claim_authorized: false

  ui_q1_q6:
    scientific_status: completed_frozen
    repository_persistence_status: recovery_audit_required

  campaign_a_foodmart:
    scientific_status: completed_frozen
    repository_persistence_status: recovery_audit_required

  campaign_b_multidataset:
    scientific_status: completed_frozen
    repository_persistence_status: recovery_audit_required

  campaign_c_backend_portability:
    scientific_status: completed_frozen
    repository_persistence_status: recovery_audit_required

  ablations:
    scientific_status: completed_functional_causal_freeze
    repository_persistence_status: recovery_audit_required
    statistical_scope_warning: smoke_archive_is_not_final_statistical_campaign

  remaining_sensitivity:
    scientific_status: partial
    repository_persistence_status: not_frozen
    next_action: inventory_and_continue_remaining_factors

  baselines:
    scientific_status: incomplete
    repository_persistence_status: not_frozen

  structural_scalability:
    scientific_status: incomplete
    repository_persistence_status: not_frozen

  evidence_usefulness:
    scientific_status: incomplete
    repository_persistence_status: not_frozen

  human_validation:
    scientific_status: incomplete
    repository_persistence_status: not_frozen

  final_statistics:
    scientific_status: incomplete
    repository_persistence_status: not_frozen

global_state:
  global_scientific_freeze: false
  latency_claim_authorized: false
  manuscript_resume_authorized: false
"""

(root / "REGISTRY.yaml").write_text(
    registry,
    encoding="utf-8",
)


def generate_manifest(campaign: Path) -> None:
    entries = []

    for path in sorted(campaign.rglob("*")):
        if not path.is_file():
            continue

        if path.name in {"MANIFEST.json", "SHA256SUMS"}:
            continue

        entries.append(
            {
                "path": path.relative_to(campaign).as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )

    (campaign / "MANIFEST.json").write_text(
        json.dumps(
            {
                "schema_version": (
                    "mcad-frozen-campaign-manifest-v1"
                ),
                "campaign_id": campaign.name,
                "file_count": len(entries),
                "files": entries,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )

    checksum_lines = []

    for path in sorted(campaign.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS":
            continue

        checksum_lines.append(
            f"{sha256(path)}  "
            f"{path.relative_to(campaign).as_posix()}"
        )

    (campaign / "SHA256SUMS").write_text(
        "\n".join(checksum_lines) + "\n",
        encoding="utf-8",
    )


generate_manifest(sa4)
generate_manifest(robustness)

print(f"sa4_archive_sha256={sa4_digest}")
print(f"robustness_archive_sha256={robustness_digest}")
print("frozen_campaign_build=PASS")
PY

echo "=== 3. Materialize into reconciliation worktree ==="

mkdir -p "$(dirname "$DEST")"
mv "$BUILD_ROOT" "$DEST"

SA4_SIZE="$(stat -c '%s' "$DEST/sa4_membership_density_controlled_execution/archive/$(
  basename "$SA4_ARCHIVE"
)")"

ROBUSTNESS_SIZE="$(stat -c '%s' "$DEST/robustness_non_temporal/archive/$(
  basename "$ROBUSTNESS_ARCHIVE"
)")"

LFS_THRESHOLD=$((50 * 1024 * 1024))
STORAGE_MODE="normal_git"

if [ "$SA4_SIZE" -ge "$LFS_THRESHOLD" ] || \
   [ "$ROBUSTNESS_SIZE" -ge "$LFS_THRESHOLD" ]; then

  git -C "$RECON" lfs install --local

  (
    cd "$RECON"
    git lfs track \
      "$DEST_REL/*/archive/*.tar.gz"
  )

  STORAGE_MODE="git_lfs"
fi

echo "sa4_archive_size_bytes=$SA4_SIZE"
echo "robustness_archive_size_bytes=$ROBUSTNESS_SIZE"
echo "archive_storage_mode=$STORAGE_MODE"

echo "=== 4. Verify internal package checksums ==="

for campaign in \
  "$DEST/sa4_membership_density_controlled_execution" \
  "$DEST/robustness_non_temporal"
do
  (
    cd "$campaign"
    sha256sum -c SHA256SUMS
  )
done

echo "=== 5. Commit persistence package ==="

git -C "$RECON" add "$DEST_REL"

if [ -f "$RECON/.gitattributes" ]; then
  git -C "$RECON" add .gitattributes
fi

git -C "$RECON" diff --cached --check

git -C "$RECON" commit \
  -m "chore(experiments): persist recovered frozen campaigns"

PERSISTENCE_COMMIT="$(git -C "$RECON" rev-parse HEAD)"

echo "persistence_commit=$PERSISTENCE_COMMIT"

echo "=== 6. Push reconciliation branch ==="

git -C "$RECON" push -u origin "$BRANCH"

REMOTE_COMMIT="$(
  git -C "$RECON" ls-remote \
    --heads origin "$BRANCH" |
  awk '{print $1}'
)"

test "$REMOTE_COMMIT" = "$PERSISTENCE_COMMIT" ||
  fail "Remote branch does not match local persistence commit."

echo
echo "frozen_campaign_persistence=PASS"
echo "archive_storage_mode=$STORAGE_MODE"
echo "persistence_commit=$PERSISTENCE_COMMIT"
echo "remote_commit=$REMOTE_COMMIT"
echo "repository_campaigns_available=true"
echo "membership_density_rerun_required=false"
echo "next_stage=inventory_remaining_sensitivity_factors"
