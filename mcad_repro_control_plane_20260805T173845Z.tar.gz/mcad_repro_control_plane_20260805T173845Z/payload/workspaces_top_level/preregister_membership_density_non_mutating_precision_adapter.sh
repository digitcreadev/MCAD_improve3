#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6d244ec318cf3986900b3220924050974b141cd1"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/preregister-membership-density-precision-adapter-$STAMP"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PORTFOLIO_PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"

LEDGER="$REPORTS/timing_runs/membership_density_stage10_portfolio/stage10_execution_ledger.json"

OUTPUT_AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

REPLICATION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

PREREG_JSON="$REPORTS/planning/sa4_membership_density_non_mutating_precision_adapter_preregistration.json"

PREREG_MD="$REPORTS/planning/sa4_membership_density_non_mutating_precision_adapter_preregistration.md"

EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"

EXPECTED_OUTPUT_AUDIT_SHA="fd3bf7ef8ee06e09ffe88548b361516ee9ad0760964932fed1ed3b7e83477888"

trap 'echo "[ERROR] Adapter preregistration stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Preregistration gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"

for FILE in \
  "$PORTFOLIO_PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$REPLICATION_PLAN" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test ! -e "$PREREG_JSON"
test ! -e "$PREREG_MD"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$OUTPUT_AUDIT" | awk '{print $1}'
)" = "$EXPECTED_OUTPUT_AUDIT_SHA"

jq -e '
  .factor == "membership_density"
  and .derived_analysis_adapter.required == true
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .derived_analysis_adapter.analyzer_measurements_per_cluster_argument
      == 2300
  and .derived_analysis_adapter.derived_observation_count == 92000
  and .derived_analysis_adapter.raw_timing_csv_modification_allowed
      == false
  and .precision_protocol.bootstrap_repetitions == 10000
  and .precision_protocol.bootstrap_seed == 20260728
  and .precision_protocol.confidence_level == 0.95
  and .precision_protocol.median_relative_half_width_target == 0.10
  and .precision_protocol.p95_relative_half_width_target == 0.15
' "$PORTFOLIO_PREREG" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.measurement_observation_count == 92000
  and .scientific_controls.precision_analysis_performed == false
' "$LEDGER" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$OUTPUT_AUDIT" >/dev/null

echo "preregistration_gate=PASS"
echo "adapter_materialization_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create preregistration branch ==="

git switch -c "$BRANCH"

echo "branch=$BRANCH"

echo
echo "=== 3. Audit immutable timing sources and write contract ==="

CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$BASE" \
  "$EXPECTED_HEAD" \
  "$PORTFOLIO_PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$REPLICATION_PLAN" \
  "$ANALYZER" \
  "$PREREG_JSON" \
  "$PREREG_MD" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
source_branch = sys.argv[2]
source_commit = sys.argv[3]

portfolio_prereg_path = (root / sys.argv[4]).resolve()
ledger_path = (root / sys.argv[5]).resolve()
output_audit_path = (root / sys.argv[6]).resolve()
replication_plan_path = (root / sys.argv[7]).resolve()
analyzer_path = (root / sys.argv[8]).resolve()

prereg_json_path = (root / sys.argv[9]).resolve()
prereg_md_path = (root / sys.argv[10]).resolve()
created_utc = sys.argv[11]


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return str(path.resolve().relative_to(root))


portfolio_prereg = load_object(portfolio_prereg_path)
ledger = load_object(ledger_path)
output_audit = load_object(output_audit_path)
replication_plan = load_object(replication_plan_path)

replications = ledger.get("replications")

if not isinstance(replications, list) or len(replications) != 10:
    raise SystemExit("Expected ten execution-ledger replications.")

expected_levels = [25, 50, 75, 100]
expected_steps = list(range(1, 24))
expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

source_csv_records: list[dict[str, Any]] = []

total_rows = 0
total_warmups = 0
total_measurements = 0

for expected_replication, record in enumerate(replications):
    if record.get("replication_index") != expected_replication:
        raise SystemExit("Replication sequence mismatch.")

    declaration = record["files"]["timing_observations"]

    csv_path = Path(declaration["path"])

    if not csv_path.is_absolute():
        csv_path = root / csv_path

    csv_path = csv_path.resolve()

    if not csv_path.is_file():
        raise SystemExit(f"Missing timing CSV: {csv_path}")

    actual_sha = sha256(csv_path)

    if actual_sha != declaration["sha256"]:
        raise SystemExit(
            f"Replication {expected_replication}: CSV SHA mismatch."
        )

    phase_counts: Counter[str] = Counter()
    levels: set[int] = set()
    steps: set[int] = set()
    seeds: set[int] = set()

    row_count = 0

    with csv_path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)

        required_columns = {
            "phase",
            "factor_level",
            "replication_index",
            "seed",
            "step_position",
            "step_index",
            "step_id",
            "fresh_state",
            "wall_latency_ms",
            "semantic_digest",
            "semantic_match",
        }

        if reader.fieldnames is None:
            raise SystemExit(
                f"Replication {expected_replication}: header absent."
            )

        missing = required_columns - set(reader.fieldnames)

        if missing:
            raise SystemExit(
                f"Replication {expected_replication}: "
                f"missing columns {sorted(missing)}."
            )

        for row in reader:
            row_count += 1

            replication = int(row["replication_index"])

            if replication != expected_replication:
                raise SystemExit(
                    f"Replication {expected_replication}: "
                    "row replication mismatch."
                )

            phase_counts[row["phase"]] += 1
            levels.add(int(row["factor_level"]))
            steps.add(int(row["step_index"]))
            seeds.add(int(row["seed"]))

    if row_count != 10120:
        raise SystemExit(
            f"Replication {expected_replication}: "
            f"expected 10,120 rows, got {row_count}."
        )

    if phase_counts != Counter({
        "warmup": 920,
        "measurement": 9200,
    }):
        raise SystemExit(
            f"Replication {expected_replication}: "
            f"phase totals differ: {dict(phase_counts)}."
        )

    if sorted(levels) != expected_levels:
        raise SystemExit(
            f"Replication {expected_replication}: levels differ."
        )

    if sorted(steps) != expected_steps:
        raise SystemExit(
            f"Replication {expected_replication}: steps differ."
        )

    if seeds != {expected_seeds[expected_replication]}:
        raise SystemExit(
            f"Replication {expected_replication}: seed differs."
        )

    expected_order_seed = 20260728 + expected_replication

    if record.get("order_seed") != expected_order_seed:
        raise SystemExit(
            f"Replication {expected_replication}: "
            "order seed differs."
        )

    raw_bytes = csv_path.read_bytes()

    if b"\r\n" in raw_bytes:
        line_ending = "CRLF"
    else:
        line_ending = "LF"

    source_csv_records.append({
        "replication_index": expected_replication,
        "structural_seed": expected_seeds[expected_replication],
        "formal_order_seed": expected_order_seed,
        "path": relative(csv_path),
        "sha256": actual_sha,
        "line_ending": line_ending,
        "source_row_count": row_count,
        "warmup_row_count": 920,
        "measurement_row_count": 9200,
        "factor_levels": expected_levels,
        "source_step_indexes": expected_steps,
    })

    total_rows += row_count
    total_warmups += phase_counts["warmup"]
    total_measurements += phase_counts["measurement"]

if total_rows != 101200:
    raise SystemExit("Expected 101,200 source observations.")

if total_warmups != 9200:
    raise SystemExit("Expected 9,200 warmups.")

if total_measurements != 92000:
    raise SystemExit("Expected 92,000 measurements.")

planned_root = (
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution/audits/membership_density/"
    "timing_stage10/precision_analysis"
)

planned_paths = {
    "observations_csv": (
        f"{planned_root}/"
        "stage10_portfolio_measurement_observations.csv"
    ),
    "timing_report_adapter_json": (
        f"{planned_root}/"
        "analyzer_timing_report_adapter.json"
    ),
    "precision_input_manifest_json": (
        f"{planned_root}/precision_input_manifest.json"
    ),
    "analyzer_log": (
        f"{planned_root}/analyzer.log"
    ),
    "raw_intervals_csv": (
        f"{planned_root}/raw_analyzer_intervals.csv"
    ),
    "raw_report_json": (
        f"{planned_root}/raw_analyzer_report.json"
    ),
    "raw_report_md": (
        f"{planned_root}/raw_analyzer_report.md"
    ),
    "canonical_decision_json": (
        f"{planned_root}/"
        "stage10_portfolio_precision_decision_report.json"
    ),
    "canonical_decision_md": (
        f"{planned_root}/"
        "stage10_portfolio_precision_decision_report.md"
    ),
}

preregistration = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "non-mutating-precision-adapter-preregistration-v1"
    ),
    "status": (
        "membership_density_non_mutating_"
        "precision_adapter_preregistered"
    ),
    "created_utc": created_utc,
    "campaign_id": (
        "sa4-membership-density-stage10-"
        "portfolio-precision"
    ),
    "factor": "membership_density",
    "stage": 10,
    "source_branch": source_branch,
    "source_commit": source_commit,
    "source_artifacts": {
        "portfolio_timing_preregistration": {
            "path": relative(portfolio_prereg_path),
            "sha256": sha256(portfolio_prereg_path),
            "status": portfolio_prereg.get("status"),
        },
        "execution_ledger": {
            "path": relative(ledger_path),
            "sha256": sha256(ledger_path),
            "status": ledger.get("status"),
        },
        "stage10_output_audit": {
            "path": relative(output_audit_path),
            "sha256": sha256(output_audit_path),
            "status": output_audit.get("status"),
        },
        "replication_execution_plan": {
            "path": relative(replication_plan_path),
            "sha256": sha256(replication_plan_path),
            "top_level_keys": sorted(replication_plan.keys()),
        },
        "precision_analyzer": {
            "path": relative(analyzer_path),
            "sha256": sha256(analyzer_path),
            "version": (
                "mcad-sensitivity-sa3-clustered-precision-v2"
            ),
        },
        "timing_csv_files": source_csv_records,
    },
    "primary_estimand": {
        "name": (
            "density_level_latency_distribution_over_"
            "seed_specific_23_query_portfolios"
        ),
        "factor_levels": expected_levels,
        "synthetic_analyzer_step_index": 0,
        "inferential_cell_count": 4,
        "resampling_unit": "structural_seed",
        "structural_seed_count_per_level": 10,
        "queries_per_structural_seed_and_level": 23,
        "measurements_per_query": 100,
        "measurements_per_cluster": 2300,
        "measurements_per_inferential_cell": 23000,
        "total_measurement_observation_count": 92000,
        "cross_seed_query_identity_required": False,
        "within_replication_cross_level_equivalence_required": True,
    },
    "observation_adapter_contract": {
        "required": True,
        "planned_output_path": planned_paths[
            "observations_csv"
        ],
        "source_selection": {
            "phase": "measurement",
            "warmups_excluded": True,
            "expected_source_csv_count": 10,
            "expected_source_measurement_row_count": 92000,
            "every_source_measurement_used_exactly_once": True,
        },
        "output_contract": {
            "row_count": 92000,
            "line_ending": "LF",
            "factor_levels": expected_levels,
            "step_indexes": [0],
            "replication_indexes": list(range(10)),
            "structural_seeds": expected_seeds,
            "clusters_per_level_step_cell": 10,
            "measurements_per_cluster": 2300,
            "analyzer_timing_cell_count": 40,
            "inferential_cell_count": 4,
        },
        "analyzer_columns": {
            "formal_replication_index": (
                "Copy source replication_index."
            ),
            "formal_structural_seed": (
                "Copy source seed."
            ),
            "formal_order_seed": (
                "Copy the execution-ledger order_seed."
            ),
            "phase": (
                "Copy source phase; only measurement rows allowed."
            ),
            "factor_level": (
                "Copy source membership-density factor_level."
            ),
            "step_index": (
                "Set to synthetic analyzer value 0."
            ),
            "wall_latency_ms": (
                "Copy source wall_latency_ms without transformation."
            ),
            "fresh_state": (
                "Copy source fresh_state; must evaluate true."
            ),
            "semantic_match": (
                "Copy source semantic_match; must evaluate true."
            ),
        },
        "required_provenance_columns": [
            "source_replication_index",
            "source_structural_seed",
            "source_order_seed",
            "source_step_position",
            "source_step_index",
            "source_step_id",
            "source_query_spec_digest",
            "source_semantic_digest",
            "source_timing_csv",
            "source_timing_csv_sha256",
            "source_row_number",
            "source_observation_index",
            "source_cell_id",
            "source_canonical_instance_id",
        ],
        "query_spec_digest_join_contract": {
            "source_path": relative(
                replication_plan_path
            ),
            "minimum_join_identity": [
                "replication_index",
                "factor_level",
                "source_step_index",
            ],
            "cross_check_identity": [
                "source_step_id",
                "source_canonical_instance_id",
            ],
            "unmatched_row_count_required": 0,
            "ambiguous_row_count_required": 0,
            "duplicate_source_row_count_required": 0,
            "semantic_digest_substitution_allowed": False,
            "actual_json_paths_must_be_recorded": True,
        },
        "immutability": {
            "raw_timing_csv_modification_allowed": False,
            "raw_timing_csv_normalization_allowed": False,
            "raw_timing_csv_line_ending_change_allowed": False,
            "raw_source_sha256_must_be_preserved": True,
            "analyzer_source_modification_allowed": False,
        },
    },
    "timing_report_adapter_contract": {
        "required": True,
        "planned_output_path": planned_paths[
            "timing_report_adapter_json"
        ],
        "status": "stage10_formal_timing_execution_success",
        "factor": "membership_density",
        "totals_key": "totals",
        "totals": {
            "run_count": 10,
            "successful_run_count": 10,
            "cell_count": 40,
            "measurement_observation_count": 92000,
            "functional_mismatch_count": 0,
            "exactly_balanced_run_count": 10,
            "structural_seed_count": 10,
        },
        "balance_semantics": {
            "exactly_balanced_run_count_means": (
                "Every replication contributes exactly 2,300 "
                "measurements to each density-level synthetic-step "
                "cluster."
            ),
            "does_not_claim_exact_order_position_balance": True,
            "source_output_audit_required": True,
        },
    },
    "precision_analyzer_contract": {
        "source_modification_allowed": False,
        "path": relative(analyzer_path),
        "sha256": sha256(analyzer_path),
        "arguments": {
            "stage_size": 10,
            "observations": planned_paths[
                "observations_csv"
            ],
            "timing_report": planned_paths[
                "timing_report_adapter_json"
            ],
            "intervals_csv": planned_paths[
                "raw_intervals_csv"
            ],
            "report_json": planned_paths[
                "raw_report_json"
            ],
            "report_md": planned_paths[
                "raw_report_md"
            ],
            "levels": "25,50,75,100",
            "steps": "0",
            "measurements_per_cluster": 2300,
            "bootstrap_repetitions": 10000,
            "bootstrap_seed": 20260728,
            "confidence_level": 0.95,
            "median_target": 0.10,
            "p95_target": 0.15,
        },
        "expected_input_timing_cell_count": 40,
        "expected_inferential_cell_count": 4,
        "expected_observation_count": 92000,
        "expected_observation_count_per_inferential_cell": 23000,
        "expected_structural_seed_count": 10,
        "expected_raw_factor_label": "constraint_count",
        "raw_factor_label_authoritative": False,
        "raw_next_stage_authoritative": False,
    },
    "canonical_decision_wrapper_contract": {
        "required": True,
        "planned_output_paths": {
            "json": planned_paths[
                "canonical_decision_json"
            ],
            "markdown": planned_paths[
                "canonical_decision_md"
            ],
        },
        "canonical_factor": "membership_density",
        "required_raw_report_factor_label": "constraint_count",
        "required_factor_levels": expected_levels,
        "required_step_indexes": [0],
        "required_inferential_cell_count": 4,
        "required_structural_seed_count": 10,
        "required_measurement_observation_count": 92000,
        "raw_report_hash_must_be_preserved": True,
        "raw_interval_hash_must_be_preserved": True,
        "raw_log_hash_must_be_preserved": True,
        "success_decision": {
            "status": "pass",
            "all_precision_targets_met": True,
            "failing_cell_count": 0,
            "stage10_sufficient": True,
            "stage20_extension_required": False,
            "next_stage": (
                "prepare_membership_density_stage10_freeze"
            ),
        },
        "failure_decision": {
            "status": "precision_targets_not_met",
            "stage10_sufficient": False,
            "stage20_extension_required": True,
            "stage20_execution_authorized": False,
            "next_stage": (
                "preregister_membership_density_stage20_extension"
            ),
        },
    },
    "planned_artifacts": planned_paths,
    "materialization_authorization": {
        "authorized": True,
        "scope": [
            "Materialize the measurement-only observation adapter.",
            "Materialize the analyzer timing-report adapter.",
            "Materialize a pre-analysis input manifest.",
        ],
        "precision_analyzer_execution_authorized": False,
        "canonical_decision_materialization_authorized": False,
        "raw_timing_execution_authorized": False,
        "stage20_execution_authorized": False,
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_execution_performed": True,
        "timing_reexecution_performed": False,
        "adapter_materialization_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "materialize_membership_density_"
        "non_mutating_precision_adapter_inputs"
    ),
}

prereg_json_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

prereg_json_path.write_text(
    json.dumps(
        preregistration,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

prereg_md_path.write_text(
    "\n".join([
        (
            "# SA4 membership-density non-mutating "
            "precision adapter preregistration"
        ),
        "",
        "- Status: `preregistered`",
        "- Factor: `membership_density`",
        "- Structural replications: `10`",
        "- Density levels: `25, 50, 75, 100`",
        "- Synthetic analyzer step: `0`",
        "- Timing-report cells: `40`",
        "- Inferential cells: `4`",
        "- Measurements per structural cluster: `2,300`",
        "- Measurements per inferential cell: `23,000`",
        "- Total measurements: `92,000`",
        "",
        "## Non-mutating strategy",
        "",
        (
            "The raw timing CSV files and the preregistered "
            "precision analyzer remain byte-for-byte unchanged."
        ),
        "",
        (
            "A measurement-only observation adapter maps the "
            "23 seed-specific queries to synthetic analyzer "
            "`step_index=0` while preserving row-level source "
            "provenance."
        ),
        "",
        (
            "The raw analyzer label `constraint_count` and its "
            "raw next-stage value are explicitly non-authoritative."
        ),
        "",
        (
            "A canonical decision wrapper will publish the "
            "scientific factor as `membership_density`."
        ),
        "",
        "## Authorization",
        "",
        "- Adapter-input materialization: `authorized`",
        "- Precision-analyzer execution: `not authorized`",
        "- Stage-20 execution: `not authorized`",
        "- Latency claims: `not authorized`",
        "",
        "## Next stage",
        "",
        (
            "`materialize_membership_density_"
            "non_mutating_precision_adapter_inputs`"
        ),
        "",
    ]),
    encoding="utf-8",
)

print("source_timing_evidence_audit=PASS")
print("source_timing_csv_count=10")
print("source_total_observation_count=101200")
print("source_warmup_observation_count=9200")
print("source_measurement_observation_count=92000")
print("planned_analyzer_timing_cell_count=40")
print("planned_inferential_cell_count=4")
print("planned_measurements_per_cluster=2300")
print("planned_measurements_per_inferential_cell=23000")
print("observation_adapter_materialization_authorized=true")
print("precision_analysis_authorized=false")
print("precision_analysis_performed=false")
PY

echo
echo "=== 4. Validate preregistration ==="

test -f "$PREREG_JSON"
test -f "$PREREG_MD"

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_preregistered"
  and .factor == "membership_density"
  and .stage == 10
  and .primary_estimand.inferential_cell_count == 4
  and .primary_estimand.structural_seed_count_per_level == 10
  and .primary_estimand.measurements_per_cluster == 2300
  and .primary_estimand.measurements_per_inferential_cell == 23000
  and .primary_estimand.total_measurement_observation_count == 92000
  and .observation_adapter_contract.required == true
  and .observation_adapter_contract.output_contract.row_count == 92000
  and .observation_adapter_contract.output_contract.step_indexes == [0]
  and .observation_adapter_contract.output_contract.analyzer_timing_cell_count
      == 40
  and .observation_adapter_contract.output_contract.inferential_cell_count
      == 4
  and .observation_adapter_contract.immutability.raw_timing_csv_modification_allowed
      == false
  and .observation_adapter_contract.immutability.analyzer_source_modification_allowed
      == false
  and .timing_report_adapter_contract.totals.cell_count == 40
  and .timing_report_adapter_contract.totals.measurement_observation_count
      == 92000
  and .precision_analyzer_contract.arguments.levels == "25,50,75,100"
  and .precision_analyzer_contract.arguments.steps == "0"
  and .precision_analyzer_contract.arguments.measurements_per_cluster == 2300
  and .precision_analyzer_contract.arguments.bootstrap_repetitions == 10000
  and .precision_analyzer_contract.arguments.bootstrap_seed == 20260728
  and .precision_analyzer_contract.expected_inferential_cell_count == 4
  and .precision_analyzer_contract.expected_raw_factor_label
      == "constraint_count"
  and .precision_analyzer_contract.raw_factor_label_authoritative == false
  and .canonical_decision_wrapper_contract.canonical_factor
      == "membership_density"
  and .materialization_authorization.authorized == true
  and .materialization_authorization.precision_analyzer_execution_authorized
      == false
  and .scientific_controls.adapter_materialization_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "materialize_membership_density_non_mutating_precision_adapter_inputs"
' "$PREREG_JSON" >/dev/null

PREREG_SHA="$(
  sha256sum "$PREREG_JSON" | awk '{print $1}'
)"

echo "adapter_preregistration_validation=PASS"
echo "adapter_preregistration_sha256=$PREREG_SHA"

echo
echo "=== 5. Commit preregistration ==="

git add \
  "$PREREG_JSON" \
  "$PREREG_MD"

git diff --cached --check

test "$(
  git diff --cached --name-only | wc -l
)" -eq 2

git commit \
  -m "chore(experiments): preregister membership-density precision adapter"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 6. Push preregistration branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister membership-density precision adapter" \
    --body "$(cat <<EOF
## Scope

Preregisters a non-mutating precision-analysis integration for
\`membership_density\`.

## Fixed analysis contract

- structural replications: \`10\`;
- density levels: \`25, 50, 75, 100\`;
- synthetic analyzer step: \`0\`;
- timing-report cells: \`40\`;
- inferential cells: \`4\`;
- measurements per structural cluster: \`2,300\`;
- measurements per inferential cell: \`23,000\`;
- total measurements: \`92,000\`.

## Non-mutating controls

- raw timing CSV modification: \`false\`;
- analyzer source modification: \`false\`;
- raw analyzer factor label authoritative: \`false\`;
- raw analyzer next stage authoritative: \`false\`;
- canonical wrapper factor: \`membership_density\`.

## Authorization

- adapter-input materialization: \`true\`;
- precision analysis: \`false\`;
- Stage-20 execution: \`false\`;
- latency claims: \`false\`.

## Integrity

- execution ledger SHA-256:
  \`$EXPECTED_LEDGER_SHA\`;
- Stage-10 output audit SHA-256:
  \`$EXPECTED_OUTPUT_AUDIT_SHA\`;
- adapter preregistration SHA-256:
  \`$PREREG_SHA\`.

## Next stage

\`materialize_membership_density_non_mutating_precision_adapter_inputs\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_non_mutating_precision_adapter_preregistration=PASS"
echo "commit=$COMMIT"
echo "adapter_preregistration_sha256=$PREREG_SHA"
echo "source_timing_csv_count=10"
echo "measurement_observation_count=92000"
echo "adapter_materialization_performed=false"
echo "adapter_materialization_authorized=true"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_precision_adapter_preregistration"

git status --short --branch
git log --oneline --decorate -4
