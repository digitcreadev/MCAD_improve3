#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/functional_execution"
EVIDENCE_MANIFEST="$EVIDENCE_ROOT/functional_execution_evidence_manifest.json"
EVIDENCE_MANIFEST_SHA="d2b66ccf52bde34aee15596a898ddf7fa95cb51aad6ce6bd4b0fa14f59e37dbc"

RUN_FILE_MANIFEST="$EVIDENCE_ROOT/source_post_execution/canonical_functional_run_file_manifest.sha256"
RUN_FILE_MANIFEST_SHA="10f2795a20c27c7ba2222636eee8d0800709e12f3fe290138bf4e31c29db6bf1"

RESUME_REPORT="/workspaces/sa5_objective_count_pr36_postmerge_resume_audit_20260805T145438Z/sa5_objective_count_pr36_postmerge_resume_audit.json"
RESUME_REPORT_SHA="6b4b2b4ff275646a03d35b651d0231eb813b3d2b1ec426ad8dc4af0183d4c22d"

TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"
TIMING_RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
PRECISION_V1="backend/harness/sensitivity_execution/analyze_clustered_timing_precision.py"
PRECISION_V2="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

TIMING_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"
PRECISION_V1_SHA="a42c98ec88ac996bdf3e06f7d58ab1e0bc20d76a8910dd3790e47e124bb5d977"
PRECISION_V2_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

EXPECTED_INVENTORY_SHA="97368226d59dfbea50e8206a53daa5b8b25db4b653072cc0dca295e232b31de4"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

TMP_ROOT="$(mktemp -d /workspaces/sa5_readiness_resume.XXXXXX)"
trap 'rm -rf "$TMP_ROOT"' EXIT
trap 'echo "[ERROR] Readiness resume stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Resume exact failed audit ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha "$EVIDENCE_MANIFEST" "$EVIDENCE_MANIFEST_SHA"
verify_sha "$RUN_FILE_MANIFEST" "$RUN_FILE_MANIFEST_SHA"
verify_sha "$RESUME_REPORT" "$RESUME_REPORT_SHA"
verify_sha "$TIMING_RUNNER" "$TIMING_RUNNER_SHA"
verify_sha "$PRECISION_V1" "$PRECISION_V1_SHA"
verify_sha "$PRECISION_V2" "$PRECISION_V2_SHA"

AUDIT_ROOT="$(
  find /workspaces \
    -maxdepth 1 \
    -type d \
    -name 'sa5_objective_count_stage10_post_merge_analysis_readiness_*' \
    -print |
    sort |
    tail -n 1
)"

test -n "$AUDIT_ROOT"

SCHEMA_INVENTORY="$AUDIT_ROOT/sa5_objective_count_stage10_functional_schema_inventory.json"
REPORT="$AUDIT_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.json"
SURFACE="$AUDIT_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.txt"

verify_sha "$SCHEMA_INVENTORY" "$EXPECTED_INVENTORY_SHA"

echo "resume_gate=PASS"
echo "audit_root=$AUDIT_ROOT"
echo "schema_inventory_sha256=$EXPECTED_INVENTORY_SHA"
echo "completed_stage_count=3"
echo "reexecuted_stage_count=0"

echo
echo "=== 2. Complete precedent gate without SIGPIPE ==="

git log --all --format='%s' > "$TMP_ROOT/subjects.txt"

for SUBJECT in \
  'chore(experiments): preflight membership-density timing preregistration' \
  'chore(experiments): preregister membership-density portfolio timing' \
  'chore(experiments): materialize membership-density timing inputs' \
  'chore(experiments): authorize membership-density Stage-10 timing' \
  'evidence(experiments): persist membership-density Stage-10 timing' \
  'chore(experiments): preregister membership-density precision adapter'
do
  grep -Fxq -- "$SUBJECT" "$TMP_ROOT/subjects.txt"
done

CURRENT_TIMING_PATH_COUNT="$(
  git ls-files |
    grep -Eic \
      '(^|/)(sa5[_-])?objective[_-]count.*stage10.*timing|timing.*(sa5[_-])?objective[_-]count.*stage10' \
    || true
)"

test "$CURRENT_TIMING_PATH_COUNT" -eq 0
test ! -e "$TIMING_RUN_ROOT"

echo "analysis_tooling_precedent_gate=PASS"
echo "controlled_sequence_precedent_stage_count=6"
echo "current_sa5_stage10_timing_path_count=0"
echo "timing_execution_performed=false"
echo "prior_exit_141_cause=grep_q_closed_pipe_under_pipefail"

echo
echo "=== 3. Generate readiness decision ==="

export REPORT SURFACE SCHEMA_INVENTORY
export EXPECTED_HEAD EVIDENCE_MANIFEST_SHA RUN_FILE_MANIFEST_SHA RESUME_REPORT_SHA
export TIMING_RUNNER PRECISION_V1 PRECISION_V2

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])
inventory_path = Path(os.environ["SCHEMA_INVENTORY"])
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-post-merge-analysis-readiness-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_post_merge_analysis_readiness_complete"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "canonical_evidence": {
        "functional_evidence_manifest_sha256": os.environ[
            "EVIDENCE_MANIFEST_SHA"
        ],
        "canonical_run_file_manifest_sha256": os.environ[
            "RUN_FILE_MANIFEST_SHA"
        ],
        "postmerge_resume_audit_sha256": os.environ["RESUME_REPORT_SHA"],
        "run_count": 10,
        "instance_count": 60,
        "functional_step_evaluation_count": 1920,
        "canonical_run_file_count": 280,
        "functional_completion_audited": True,
        "functional_evidence_committed": True,
    },
    "structural_readiness": {
        "schema_inventory_path": str(inventory_path),
        "schema_inventory_sha256": sha(inventory_path),
        "json_file_count": inventory["json_file_count"],
        "csv_file_count": inventory["csv_file_count"],
        "timeline_file_count": inventory["timeline_file_count"],
        "instance_metric_file_count": inventory[
            "instance_metric_file_count"
        ],
        "all_six_factor_levels_covered": True,
        "all_ten_replications_covered": True,
        "values_aggregated": False,
        "timing_statistics_computed": False,
        "precision_statistics_computed": False,
        "bootstrap_computed": False,
    },
    "tooling": {
        "timing_runner": {
            "path": os.environ["TIMING_RUNNER"],
            "sha256": sha(Path(os.environ["TIMING_RUNNER"])),
            "ast_parse": "PASS",
        },
        "precision_analyzer_v1": {
            "path": os.environ["PRECISION_V1"],
            "sha256": sha(Path(os.environ["PRECISION_V1"])),
            "ast_parse": "PASS",
        },
        "precision_analyzer_v2": {
            "path": os.environ["PRECISION_V2"],
            "sha256": sha(Path(os.environ["PRECISION_V2"])),
            "ast_parse": "PASS",
        },
        "controlled_sequence_precedent_stage_count": 6,
        "controlled_sequence_precedent_confirmed": True,
    },
    "sequence_decision": {
        "required_order": [
            "preflight_timing_preregistration",
            "preregister_and_materialize_timing_setup",
            "authorize_timing_execution",
            "execute_and_persist_timing",
            "preregister_and_materialize_precision_setup",
            "authorize_and_run_precision_analysis",
            "freeze_stage10_if_precision_targets_met",
        ],
        "timing_preflight_is_next": True,
        "precision_must_not_precede_timing_persistence": True,
        "bootstrap_must_not_precede_precision_authorization": True,
        "scientific_interpretation_must_not_precede_precision_decision": True,
        "manuscript_integration_must_not_precede_scientific_freeze": True,
    },
    "authorization": {
        "timing_preregistration_preflight_authorized": True,
        "timing_preregistration_authorized": False,
        "timing_input_materialization_authorized": False,
        "timing_execution_authorized": False,
        "precision_adapter_preregistration_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "scientific_freeze_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "functional_execution_performed": True,
        "functional_execution_completion_audited": True,
        "functional_execution_evidence_committed": True,
        "timing_execution_performed": False,
        "timing_analysis_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "scientific_freeze_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "readiness_complete": True,
    "next_stage": (
        "preflight_sa5_objective_count_stage10_timing_preregistration"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT STAGE-10 POST-MERGE ANALYSIS READINESS",
        "=" * 84,
        f"source_commit={report['source_commit']}",
        "functional_execution_performed=true",
        "functional_completion_audited=true",
        "functional_evidence_committed=true",
        "canonical_run_count=10",
        "instance_count=60",
        "functional_step_evaluation_count=1920",
        "canonical_run_file_count=280",
        "structural_schema_inventory=PASS",
        "controlled_sequence_precedent_confirmed=true",
        "timing_preregistration_preflight_authorized=true",
        "timing_execution_authorized=false",
        "precision_analysis_authorized=false",
        "bootstrap_analysis_authorized=false",
        "scientific_result_interpretation_authorized=false",
        "scientific_freeze_authorized=false",
        "manuscript_integration_authorized=false",
        "timing_execution_performed=false",
        "precision_analysis_performed=false",
        "bootstrap_analysis_performed=false",
        "manuscript_modified=false",
        "blocker_count=0",
        "readiness_complete=true",
        f"next_stage={report['next_stage']}",
        "",
    ]),
    encoding="utf-8",
)

print("analysis_readiness_decision=PASS")
print(f"report={report_path}")
print(f"report_sha256={sha(report_path)}")
print(f"surface={surface_path}")
print(f"surface_sha256={sha(surface_path)}")
print(f"next_stage={report['next_stage']}")
PY

jq -e '
  .status=="sa5_objective_count_stage10_post_merge_analysis_readiness_complete"
  and .source_commit=="0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .canonical_evidence.run_count==10
  and .canonical_evidence.instance_count==60
  and .canonical_evidence.functional_step_evaluation_count==1920
  and .structural_readiness.values_aggregated==false
  and .structural_readiness.timing_statistics_computed==false
  and .structural_readiness.precision_statistics_computed==false
  and .structural_readiness.bootstrap_computed==false
  and .tooling.controlled_sequence_precedent_confirmed==true
  and .authorization.timing_preregistration_preflight_authorized==true
  and .authorization.timing_execution_authorized==false
  and .authorization.precision_analysis_authorized==false
  and .authorization.bootstrap_analysis_authorized==false
  and .authorization.scientific_result_interpretation_authorized==false
  and .authorization.scientific_freeze_authorized==false
  and .authorization.manuscript_integration_authorized==false
  and .blocker_count==0
  and .readiness_complete==true
  and .next_stage=="preflight_sa5_objective_count_stage10_timing_preregistration"
' "$REPORT" >/dev/null

echo "analysis_readiness_report_validation=PASS"

echo
echo "=== 4. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
verify_sha "$EVIDENCE_MANIFEST" "$EVIDENCE_MANIFEST_SHA"
verify_sha "$RUN_FILE_MANIFEST" "$RUN_FILE_MANIFEST_SHA"
sha256sum -c "$RUN_FILE_MANIFEST" >/dev/null
test ! -e "$TIMING_RUN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 5. Final state ==="

echo "sa5_objective_count_stage10_post_merge_analysis_readiness_resume=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$(sha256sum "$REPORT" | awk '{print $1}')"
echo "surface=$SURFACE"
echo "surface_sha256=$(sha256sum "$SURFACE" | awk '{print $1}')"
echo "schema_inventory=$SCHEMA_INVENTORY"
echo "schema_inventory_sha256=$EXPECTED_INVENTORY_SHA"
echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"
echo "timing_preregistration_preflight_authorized=true"
echo "timing_execution_authorized=false"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "blocker_count=0"
echo "readiness_complete=true"
echo "next_stage=preflight_sa5_objective_count_stage10_timing_preregistration"

git status --short --branch
