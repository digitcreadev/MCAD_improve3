#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="bbe66c639c729322aeacb5f269e8e78ef3a3e42c"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

CAMPAIGN="$REPORTS/planning/formal_campaigns/membership_density_stage10_c4_nv24"
COMMON_AUDIT="$CAMPAIGN/audit/membership_density_common_workload_audit.json"

EXECUTION_AUDIT="$REPORTS/planning/sa4_membership_density_controlled_execution_audit.json"
EXECUTION_FREEZE="$REPORTS/planning/sa4_membership_density_controlled_execution_freeze.json"
FROZEN_MANIFEST="$REPORTS/planning/sa4_membership_density_controlled_execution_frozen_manifest.json"
EXECUTION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_controlled_execution"
ARCHIVE="$PACKAGE/archive/SA4_EXACT_RECOVERY_20260801T105252Z.tar.gz"

TIMING_RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

cd "$ROOT"

echo "=== 1. Repository and evidence gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$COMMON_AUDIT" \
  "$EXECUTION_AUDIT" \
  "$EXECUTION_FREEZE" \
  "$FROZEN_MANIFEST" \
  "$EXECUTION_PLAN" \
  "$ARCHIVE" \
  "$TIMING_RUNNER" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test -x "$PYTHON"

echo "repository_gate=PASS"
echo "membership_density_functional_rerun_performed=false"
echo "membership_density_timing_execution_performed=false"
echo "membership_density_precision_analysis_performed=false"

echo
echo "=== 2. Resolve frozen functional and common-workload contract ==="

"$PYTHON" - \
  "$ROOT" \
  "$CAMPAIGN" \
  "$COMMON_AUDIT" \
  "$EXECUTION_AUDIT" \
  "$EXECUTION_FREEZE" \
  "$FROZEN_MANIFEST" \
  "$EXECUTION_PLAN" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
campaign = root / sys.argv[2]
paths = [root / value for value in sys.argv[3:]]


def load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


payloads = {
    path.name: load(path)
    for path in paths
}

manifest = load(campaign / "campaign_manifest.json")
spec = load(campaign / "campaign_spec.json")

print(f"campaign_id={manifest.get('campaign_id')}")
print(f"factor={manifest.get('factor')}")
print(f"levels={manifest.get('levels')}")
print(f"seeds={manifest.get('seeds')}")
print(
    "replication_count="
    f"{manifest.get('replication_count')}"
)
print(
    "realised_instance_count="
    f"{manifest.get('realised_instance_count')}"
)

if manifest.get("factor") != "membership_density":
    raise SystemExit("Unexpected campaign factor.")

if manifest.get("levels") != [25, 50, 75, 100]:
    raise SystemExit(
        f"Unexpected density levels: "
        f"{manifest.get('levels')}"
    )

if manifest.get("replication_count") != 10:
    raise SystemExit("Expected ten replications.")

print()
print("artifact_sha256_values:")

for path in paths:
    print(
        f"{path.relative_to(root).as_posix()}="
        f"{sha256(path)}"
    )

terms = (
    "status",
    "authorized",
    "authorization",
    "freeze",
    "frozen",
    "partition",
    "replication",
    "instance",
    "step",
    "query",
    "workload",
    "common",
    "intersection",
    "digest",
    "output_file",
    "runtime_root",
    "timing",
    "latency",
    "precision",
    "next_stage",
)


def walk(
    value: Any,
    prefix: str,
) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            current = f"{prefix}.{key}"

            if any(
                term in key.lower()
                for term in terms
            ):
                compact = json.dumps(
                    child,
                    sort_keys=True,
                    separators=(",", ":"),
                )

                if len(compact) <= 450:
                    print(f"{current}={compact}")

            walk(child, current)

    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk(child, f"{prefix}[{index}]")


for name, payload in payloads.items():
    print()
    print(f"--- {name} ---")
    walk(payload, "$")

print()
print("functional_contract_resolution=PASS")
PY

echo
echo "=== 3. Determine exact common timing cells ==="

"$PYTHON" - \
  "$ROOT" \
  "$COMMON_AUDIT" \
  "$REPORTS/workloads" \
  "$REPORTS/execution_specs" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
audit_path = root / sys.argv[2]
workloads_root = root / sys.argv[3]
specs_root = root / sys.argv[4]


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


audit = load(audit_path)

workloads = sorted(
    workloads_root.glob(
        "membership_density_rep_*_canonical.json"
    )
)

specs = sorted(
    specs_root.glob(
        "membership_density_rep_*_canonical.json"
    )
)

if len(workloads) != 10:
    raise SystemExit(
        f"Expected ten workloads, got {len(workloads)}."
    )

if len(specs) != 10:
    raise SystemExit(
        f"Expected ten execution specs, got {len(specs)}."
    )

print("workload_count=10")
print("execution_spec_count=10")

for rep, (workload_path, spec_path) in enumerate(
    zip(workloads, specs, strict=True)
):
    workload = load(workload_path)
    spec = load(spec_path)

    workload_keys = (
        sorted(workload)
        if isinstance(workload, dict)
        else []
    )

    spec_keys = (
        sorted(spec)
        if isinstance(spec, dict)
        else []
    )

    print()
    print(f"replication_index={rep}")
    print(f"workload_path={workload_path}")
    print(f"execution_spec_path={spec_path}")
    print(
        "workload_top_level_keys="
        + ",".join(workload_keys)
    )
    print(
        "execution_spec_top_level_keys="
        + ",".join(spec_keys)
    )

    for label, payload in (
        ("workload", workload),
        ("execution_spec", spec),
    ):
        encoded = json.dumps(
            payload,
            sort_keys=True,
            separators=(",", ":"),
        )

        for term in (
            "common",
            "step_id",
            "step_index",
            "factor_level",
            "query",
            "workload",
            "expected_step_count",
        ):
            if term in encoded:
                print(
                    f"{label}_contains_{term}=true"
                )

print()
print(
    "common_timing_cell_source_resolution=PASS"
)
PY

echo
echo "=== 4. Check recovered archive for temporal artifacts ==="

"$PYTHON" - "$ARCHIVE" <<'PY'
from __future__ import annotations

import re
import sys
import tarfile
from pathlib import Path

archive = Path(sys.argv[1])

pattern = re.compile(
    r"membership_density.*"
    r"(timing|temporal|precision|preregistration|"
    r"authorization)",
    re.IGNORECASE,
)

with tarfile.open(archive, "r:gz") as stream:
    matches = sorted(
        member.name
        for member in stream.getmembers()
        if pattern.search(member.name)
    )

print(
    f"recovered_temporal_artifact_count="
    f"{len(matches)}"
)

for name in matches:
    print(f"recovered_temporal_artifact={name}")

if matches:
    print(
        "recovered_temporal_contract_present=true"
    )
    print(
        "temporal_contract_action="
        "audit_and_materialize_recovered_contract"
    )
else:
    print(
        "recovered_temporal_contract_present=false"
    )
    print(
        "temporal_contract_action="
        "create_preregistration_preflight"
    )
PY

echo
echo "=== 5. Timing implementation identities ==="

sha256sum \
  "$TIMING_RUNNER" \
  "$ANALYZER"

PYTHONPATH="$ROOT" \
  "$PYTHON" "$TIMING_RUNNER" --help

echo
echo "=== 6. Final state ==="

echo "membership_density_temporal_contract_resolution=PASS"
echo "membership_density_functional_rerun_performed=false"
echo "membership_density_timing_execution_performed=false"
echo "membership_density_precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=create_membership_density_timing_preregistration_preflight"

git status --short --branch
