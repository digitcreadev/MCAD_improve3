#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="496addef55cc60a3303fa1e62a12392be2296ece"

BRANCH="paper/preregister-sa5-objective-count-stage10-20260804T185827Z"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/resume_sa5_preregistration.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 preregistration resume stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Resume gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

test -f "$PREREG"
test -f "$PREREG_TEST"

test -z "$(git diff --name-only)"
test -z "$(git diff --cached --name-only)"

test "$(
  git status --porcelain -- "$PREREG_TEST"
)" = "?? $PREREG_TEST"

PREREG_IGNORE_RULE="$(
  git check-ignore -v "$PREREG" || true
)"

test -n "$PREREG_IGNORE_RULE"

echo "resume_gate=PASS"
echo "current_head=$EXPECTED_HEAD"
echo "preregistration_file_exists=true"
echo "preregistration_test_exists=true"
echo "tracked_file_modification_count=0"
echo "preregistration_ignore_state=IGNORED"
echo "preregistration_ignore_rule=$PREREG_IGNORE_RULE"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"

echo
echo "=== 2. Revalidate preserved preregistration ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-campaign-preregistration-v1"
  and .preregistration_id
    == "sa5_objective_count_stage10_c8_nv32"
  and .status == "preregistered_not_materialized"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "496addef55cc60a3303fa1e62a12392be2296ece"
  and .implementation_commit
    == "a4f7767b2100c997456b55efce2714da6e29254f"
  and .factor_contract.factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .factor_contract.selected_objective_index == 0
  and .factor_contract.constraints_per_objective == 8
  and .factor_contract.virtual_nodes_per_objective == 32
  and .factor_contract.workload_length == 40
  and .factor_contract.noise_ratio == 0.25
  and .replication_contract.replication_count == 10
  and .replication_contract.expected_instance_count == 60
  and (
    .replication_contract.structural_seeds
    | length
  ) == 10
  and (
    .replication_contract.structural_seeds
    | unique
    | length
  ) == 10
  and .authorization.campaign_materialization_authorized_now
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.stage20_execution_authorized
    == false
  and .authorization.latency_claim_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$PREREG" >/dev/null

PREREG_SHA="$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)"

echo "preserved_preregistration_validation=PASS"
echo "preregistration_sha256=$PREREG_SHA"

echo
echo "=== 3. Minimal test revalidation ==="

"$PYTHON" -m py_compile \
  "$PREREG_TEST"

"$PYTHON" -m pytest \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

echo "minimal_preregistration_revalidation=PASS"

echo
echo "=== 4. Force-stage ignored preregistration ==="

git add -f "$PREREG"
git add "$PREREG_TEST"

printf '%s\n' \
  "$PREREG_TEST" \
  "$PREREG" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

git diff --cached --name-only |
  sort \
  > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

STAGED_FILE_COUNT="$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)"

test "$STAGED_FILE_COUNT" -eq 2

git diff --cached --check

echo "preregistration_force_stage=PASS"
echo "staged_file_count=2"
echo "ignored_preregistration_force_added=true"

echo
echo "=== 5. Validate staged scope ==="

test -z "$(
  git diff --cached --name-only |
    grep -Ev \
      '^(reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration\.json|backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration\.py)$' \
    || true
)"

test -z "$(
  git diff --cached --name-only |
    grep -E \
      '^(MCAD_audited_real_main_fr\.tex|experiments/article/frozen_campaigns/|reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/)' \
    || true
)"

echo "staged_scope_validation=PASS"
echo "canonical_campaign_generated=false"
echo "manuscript_modified=false"

echo
echo "=== 6. Commit preregistration ==="

git commit \
  -m "chore(experiments): preregister SA5 objective-count Stage-10"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"

echo "commit=PASS"
echo "commit=$COMMIT"
echo "preregistration_sha256=$PREREG_SHA"

echo
echo "=== 7. Push preregistration branch ==="

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

EXISTING_PR_COUNT="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state all \
    --json number \
    --jq 'length'
)"

test "$EXISTING_PR_COUNT" -eq 0

SEEDS="$(
  jq -r '
    .replication_contract.structural_seeds
    | map(tostring)
    | join(", ")
  ' "$PREREG"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister SA5 objective-count Stage-10 campaign" \
    --body "$(cat <<EOF
## SA5 preregistration

Preregisters the canonical Stage-10 objective-count campaign before
materialization.

### Factor contract

- levels: \`1, 2, 5, 10, 20, 50\`;
- replications: \`10\`;
- expected instances: \`60\`;
- selected objective index: \`0\`;
- constraints per objective: \`8\`;
- virtual nodes per objective: \`32\`;
- workload length: \`40\`;
- noise ratio: \`0.25\`.

### Structural seeds

\`$SEEDS\`

### Common-workload contract

For each seed, one deterministic canonical workload is shared across
all six objective-count levels after deterministic selected-objective
identifier substitution.

### Scientific controls

- canonical campaign generated: \`false\`;
- campaign materialization authorized now: \`false\`;
- functional execution authorized: \`false\`;
- timing execution authorized: \`false\`;
- precision analysis authorized: \`false\`;
- bootstrap execution authorized: \`false\`;
- Stage-20 execution authorized: \`false\`;
- latency claims authorized: \`false\`;
- manuscript integration authorized: \`false\`;
- global scientific freeze: \`false\`.

Materialization becomes eligible only after merge of this
preregistration.

### Integrity

- preregistration SHA-256: \`$PREREG_SHA\`.

## Next stage

\`materialize_sa5_objective_count_stage10_structure_and_common_workloads\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Verify pull-request scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 10. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_stage10_preregistration_resume=PASS"
echo "commit=$COMMIT"
echo "preregistration=$PREREG"
echo "preregistration_sha256=$PREREG_SHA"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "selected_objective_index=0"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_authorized_now=false"
echo "functional_execution_authorized=false"
echo "timing_execution_authorized=false"
echo "bootstrap_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_preregistration"

git status --short --branch
git log --oneline --decorate -4
