#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"

AMENDMENT_003_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"

SCOPE_REPORT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

CLASSIFICATION_ROOT="/workspaces/sa5_existing_noise_production_hit_classification_20260804T233007Z"

CLASSIFICATION_REPORT="$CLASSIFICATION_ROOT/sa5_existing_noise_production_hit_classification.json"
EXPECTED_CLASSIFICATION_REPORT_SHA="b89b96e727e5fc460dab1c32ba957a8b8e8f287e1eff4f5ce2580706ee3020fb"

CLASSIFICATION_SURFACE="$CLASSIFICATION_ROOT/sa5_existing_noise_production_hit_classification.txt"
EXPECTED_CLASSIFICATION_SURFACE_SHA="8d20be9e3f07f3633de7d05e541efe402b07edfc278b5c552b63ff0449c7ac3e"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

TARGET_E21_VERSION="mcad-sensitivity-e2.1-objective-count-v2"
TARGET_E22_VERSION="mcad-sensitivity-e2.2-objective-count-v2"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-sa5-objective-count-noise-operators-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_noise_operator_amendment.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 noise-operator amendment stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Noise-operator amendment preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$SCOPE_REPORT" \
  "$CLASSIFICATION_REPORT" \
  "$CLASSIFICATION_SURFACE" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test "$(
  sha256sum "$CLASSIFICATION_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_CLASSIFICATION_REPORT_SHA"

test "$(
  sha256sum "$CLASSIFICATION_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_CLASSIFICATION_SURFACE_SHA"

test ! -e "$AMENDMENT_003"
test ! -e "$AMENDMENT_003_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "sa5_objective_count_v2_existing_noise_hits_classified_partial_operator_suite"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .source_scope.resolved_file_count == 21
  and .operator_suite.exact_operator_classes
    == ["missing_cube"]
  and .operator_suite.template_label_only_classes
    == ["wrong_measure"]
  and .operator_suite.missing_exact_operator_class_count
    == 7
  and .operator_suite.authoritative_operator_suite_present
    == false
  and .redundancy_ordering.failure_count == 1
  and .redundancy_ordering.failures[0].replication_index
    == 2
  and .redundancy_ordering.failures[0].seed
    == 1198202409
  and .redundancy_ordering.failures[0].redundant_contribution_position
    == 1
  and .classification_complete == true
  and .noise_operator_contract_amendment_required
    == true
  and .v2_patch_authoring_authorized
    == false
  and .next_stage
    == "preregister_sa5_objective_count_noise_operator_and_redundancy_ordering_amendment"
' "$CLASSIFICATION_REPORT" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_v2_post_capacity_scope_resolved"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .final_scope.new_file_count == 10
  and .final_scope.modified_file_count == 11
  and .final_scope.total_patch_file_count == 21
  and .scope_complete == true
' "$SCOPE_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "noise_operator_amendment_preflight_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "classification_report_sha256=$EXPECTED_CLASSIFICATION_REPORT_SHA"
echo "exact_existing_operator_class_count=1"
echo "missing_exact_operator_class_count=7"
echo "redundancy_ordering_failure_count=1"
echo "prior_21_file_scope_authoritative=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Create noise-operator amendment branch ==="

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Author authoritative amendment and tests ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_003" \
  "$AMENDMENT_003_TEST" \
  "$CREATED_UTC" \
  "$EXPECTED_HEAD" \
  "$EXPECTED_PREREG_SHA" \
  "$EXPECTED_AMENDMENT_001_SHA" \
  "$EXPECTED_AMENDMENT_002_SHA" \
  "$EXPECTED_SCOPE_REPORT_SHA" \
  "$EXPECTED_CLASSIFICATION_REPORT_SHA" \
  "$EXPECTED_CLASSIFICATION_SURFACE_SHA" \
  "$TARGET_E21_VERSION" \
  "$TARGET_E22_VERSION" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any


root = Path(sys.argv[1]).resolve()

prereg_path = root / sys.argv[2]
amendment_001_path = root / sys.argv[3]
amendment_002_path = root / sys.argv[4]
amendment_003_path = root / sys.argv[5]
test_path = root / sys.argv[6]

created_utc = sys.argv[7]
source_commit = sys.argv[8]

prereg_sha = sys.argv[9]
amendment_001_sha = sys.argv[10]
amendment_002_sha = sys.argv[11]
scope_report_sha = sys.argv[12]
classification_report_sha = sys.argv[13]
classification_surface_sha = sys.argv[14]

target_e21 = sys.argv[15]
target_e22 = sys.argv[16]


def digest(value: str) -> str:
    return hashlib.sha256(
        value.encode("utf-8")
    ).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    assert isinstance(value, dict)

    return value


prereg = load_json(prereg_path)
amendment_001 = load_json(
    amendment_001_path
)
amendment_002 = load_json(
    amendment_002_path
)

seeds = list(
    prereg[
        "replication_contract"
    ]["structural_seeds"]
)

noise_classes = list(
    amendment_002[
        "revised_workload_contract"
    ]["noise_class_order"]
)

support_coordinates = list(
    amendment_002[
        "revised_workload_contract"
    ]["support_coordinates"]
)

assert seeds == [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

assert noise_classes == [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

assert len(support_coordinates) == 24
assert [
    row["support_ordinal"]
    for row in support_coordinates
] == list(range(24))

non_redundant_classes = [
    noise_class
    for noise_class in noise_classes
    if noise_class != "redundant_contribution"
]

assert len(non_redundant_classes) == 7


def selected_noise_positions(
    seed: int,
) -> list[int]:
    ranked = sorted(
        range(1, 33),
        key=lambda position: (
            digest(
                "mcad-sa5-noise-position-v2"
                f"|{seed}|{position}"
            ),
            position,
        ),
    )

    return sorted(ranked[:8])


def ranked_non_redundant_classes(
    seed: int,
) -> list[str]:
    return sorted(
        non_redundant_classes,
        key=lambda noise_class: (
            digest(
                "mcad-sa5-noise-class-v3"
                f"|{seed}|{noise_class}"
            ),
            noise_class,
        ),
    )


def target_support_ordinals(
    seed: int,
) -> dict[str, int]:
    unused = set(range(24))
    result: dict[str, int] = {}

    for noise_class in non_redundant_classes:
        selected = min(
            unused,
            key=lambda support_ordinal: (
                digest(
                    "mcad-sa5-noise-target-v3"
                    f"|{seed}|{noise_class}|"
                    f"{support_ordinal}"
                ),
                support_ordinal,
            ),
        )

        result[noise_class] = selected
        unused.remove(selected)

    assert len(set(result.values())) == 7

    return result


schedule_rows: list[dict[str, Any]] = []

for replication_index, seed in enumerate(
    seeds
):
    noise_positions = (
        selected_noise_positions(seed)
    )

    contributive_positions = [
        position
        for position in range(1, 33)
        if position not in noise_positions
    ]

    assert len(noise_positions) == 8
    assert len(contributive_positions) == 24

    first_contributive_position = (
        contributive_positions[0]
    )

    eligible_redundant_positions = [
        position
        for position in noise_positions
        if position > first_contributive_position
    ]

    assert eligible_redundant_positions

    redundant_position = min(
        eligible_redundant_positions
    )

    source_step_index = max(
        position
        for position in contributive_positions
        if position < redundant_position
    )

    source_support_ordinal = (
        contributive_positions.index(
            source_step_index
        )
    )

    remaining_noise_positions = [
        position
        for position in noise_positions
        if position != redundant_position
    ]

    remaining_class_order = (
        ranked_non_redundant_classes(
            seed
        )
    )

    class_by_position = {
        str(redundant_position): (
            "redundant_contribution"
        )
    }

    for position, noise_class in zip(
        remaining_noise_positions,
        remaining_class_order,
        strict=True,
    ):
        class_by_position[
            str(position)
        ] = noise_class

    assert set(
        class_by_position.values()
    ) == set(noise_classes)

    target_ordinals = (
        target_support_ordinals(seed)
    )

    schedule_rows.append(
        {
            "replication_index": (
                replication_index
            ),
            "seed": seed,
            "noise_positions": (
                noise_positions
            ),
            "contributive_positions": (
                contributive_positions
            ),
            "first_contributive_position": (
                first_contributive_position
            ),
            "eligible_redundant_positions": (
                eligible_redundant_positions
            ),
            "redundant_contribution_position": (
                redundant_position
            ),
            "redundant_source_step_index": (
                source_step_index
            ),
            "redundant_source_support_ordinal": (
                source_support_ordinal
            ),
            "class_by_position": dict(
                sorted(
                    class_by_position.items(),
                    key=lambda item: int(
                        item[0]
                    ),
                )
            ),
            "target_support_ordinal_by_class": (
                target_ordinals
            ),
        }
    )

assert schedule_rows[2][
    "replication_index"
] == 2

assert schedule_rows[2]["seed"] == (
    1198202409
)

assert schedule_rows[2][
    "redundant_contribution_position"
] == 8

assert schedule_rows[2][
    "redundant_source_step_index"
] == 7

assert all(
    row[
        "redundant_contribution_position"
    ]
    > row["first_contributive_position"]
    for row in schedule_rows
)


semantic_fields = [
    "cube",
    "measures",
    "group_by",
    "slicers",
    "aggregators",
    "units",
    "window_start",
    "window_end",
    "time_members",
]

operator_definitions = {
    "wrong_measure": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["measures"],
        "mutation": {
            "operation": "replace",
            "field": "measures",
            "value": [
                "__MCAD_SA5_WRONG_MEASURE__"
            ],
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "measures"
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "wrong_context": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["slicers"],
        "mutation": {
            "operation": (
                "replace_mapping_value"
            ),
            "field": "slicers",
            "key": "Geography.Region",
            "value": (
                "__MCAD_SA5_WRONG_CONTEXT__"
            ),
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "slicers"
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "insufficient_grain": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["group_by"],
        "mutation": {
            "operation": "replace",
            "field": "group_by",
            "value": [
                "Geography.Region"
            ],
            "removed_required_token": (
                "Time.Month"
            ),
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "group_by"
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "invalid_aggregation": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["aggregators"],
        "mutation": {
            "operation": "replace",
            "field": "aggregators",
            "value": [
                "__MCAD_SA5_INVALID_AGGREGATION__"
            ],
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "aggregators"
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "invalid_unit": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["units"],
        "mutation": {
            "operation": "replace",
            "field": "units",
            "value": [
                "__MCAD_SA5_INVALID_UNIT__"
            ],
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "units"
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "invalid_time_window": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": [
            "window_start",
            "window_end",
        ],
        "mutation": {
            "operation": (
                "swap_window_boundaries"
            ),
            "field_pair": [
                "window_start",
                "window_end",
            ],
            "postcondition": (
                "window_start > window_end"
            ),
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field
            not in {
                "window_start",
                "window_end",
            }
        ],
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "missing_cube": {
        "source": (
            "canonical contributive base query "
            "for the assigned support coordinate"
        ),
        "changed_fields": ["cube"],
        "mutation": {
            "operation": "replace",
            "field": "cube",
            "value": "",
        },
        "preserved_fields": [
            field
            for field in semantic_fields
            if field != "cube"
        ],
        "existing_precedent": {
            "path": (
                "backend/harness/tools/"
                "find_sat_ablation_witness.py"
            ),
            "function": (
                "generate_mutations"
            ),
            "classification": (
                "partial_query_mutation_precedent"
            ),
            "authoritative_for_sa5": False,
        },
        "expected_sat": False,
        "expected_real_node_count": 0,
        "expected_oracle_contributive": False,
    },
    "redundant_contribution": {
        "source": (
            "immediately preceding contributive "
            "workload step"
        ),
        "changed_fields": [],
        "mutation": {
            "operation": (
                "exact_semantic_projection_replay"
            ),
            "semantic_projection_fields": (
                semantic_fields
            ),
            "source_step_rule": (
                "greatest contributive step index "
                "strictly less than the redundant "
                "noise position"
            ),
        },
        "preserved_fields": semantic_fields,
        "expected_sat": True,
        "expected_real_node_count": 1,
        "expected_oracle_contributive": False,
        "expected_gained_resource_count": 0,
        "prior_contribution_required": True,
    },
}

assert set(operator_definitions) == set(
    noise_classes
)

amendment: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-noise-"
        "operator-and-redundancy-ordering-"
        "amendment-v1"
    ),
    "amendment_id": (
        "sa5_objective_count_noise_operator_"
        "and_redundancy_ordering_amendment_003"
    ),
    "status": (
        "preregistered_implementation_required"
    ),
    "phase": "SA5",
    "factor": "objective_count",
    "stage": 10,
    "created_utc": created_utc,
    "source_repository": (
        "digitcreadev/MCAD_improve3"
    ),
    "source_branch": (
        "paper/phase3-controlled-execution"
    ),
    "source_commit": source_commit,
    "amends": {
        "original_preregistration": {
            "artifact_path": str(
                prereg_path.relative_to(root)
            ),
            "artifact_sha256": prereg_sha,
        },
        "materialization_contract_amendment_001": {
            "artifact_path": str(
                amendment_001_path.relative_to(
                    root
                )
            ),
            "artifact_sha256": (
                amendment_001_sha
            ),
        },
        "workload_capacity_amendment_002": {
            "artifact_path": str(
                amendment_002_path.relative_to(
                    root
                )
            ),
            "artifact_sha256": (
                amendment_002_sha
            ),
        },
        "amendment_precedence": (
            "This amendment is authoritative "
            "for canonical support-query construction, "
            "noise mutation operators, non-redundant "
            "noise target selection, redundant-step "
            "placement, replay-source selection, "
            "operator oracle outcomes, and the "
            "post-amendment implementation-scope "
            "projection."
        ),
        "superseded_fields": [
            (
                "capacity amendment 002: "
                "revised_workload_contract."
                "class_to_position_assignment"
            ),
            (
                "post-capacity scope reprojection: "
                "final 21-file implementation scope"
            ),
        ],
        "preserved_fields": [
            "objective-count levels: 1,2,5,10,20,50",
            "ten structural seeds",
            "ten replications",
            "workload length: 32",
            "contributive steps per workload: 24",
            "non-contributive steps per workload: 8",
            "requested and realised noise ratio: 0.25",
            "eight noise classes",
            "one occurrence of each class per replication",
            "noise-position SHA-256 selection",
            "24 support coordinates",
            "factor-scoped union-requirement-set policy",
            "common workload across all six levels",
            "all execution prohibitions",
        ],
    },
    "audit_provenance": {
        "scope_report_sha256": (
            scope_report_sha
        ),
        "classification_report_sha256": (
            classification_report_sha
        ),
        "classification_surface_sha256": (
            classification_surface_sha
        ),
        "existing_exact_operator_classes": [
            "missing_cube"
        ],
        "template_label_only_classes": [
            "wrong_measure"
        ],
        "missing_exact_operator_class_count": 7,
        "old_redundancy_ordering_failure": {
            "replication_index": 2,
            "seed": 1198202409,
            "old_position": 1,
            "prior_contributive_step_count": 0,
        },
    },
    "canonical_support_query_contract": {
        "semantic_projection_fields": (
            semantic_fields
        ),
        "base_query_fields": {
            "cube": (
                "selected support virtual node.fact"
            ),
            "measures": [
                (
                    "selected support virtual "
                    "node.measure"
                )
            ],
            "group_by": (
                "selected support virtual node.grain"
            ),
            "slicers": (
                "selected support virtual node.slicers"
            ),
            "aggregators": [
                (
                    "selected support virtual "
                    "node.aggregator"
                )
            ],
            "units": [
                (
                    "selected support virtual "
                    "node.unit"
                )
            ],
            "window_start": (
                "selected support virtual "
                "node.window_start"
            ),
            "window_end": (
                "selected support virtual "
                "node.window_end"
            ),
            "time_members": [],
        },
        "expected_base_query_outcome": {
            "sat": True,
            "real_node_count": 1,
            "oracle_contributive_on_first_use": True,
            "gained_resource_count_on_first_use": 1,
        },
        "unique_context_assignment": {
            "scope": (
                "Each constraint independently."
            ),
            "candidate_year_domain": {
                "minimum": 2000,
                "maximum": 2020,
                "count": 21,
            },
            "candidate_region_domain": {
                "format": "Region_%02d",
                "minimum_index": 1,
                "maximum_index": 10,
                "count": 10,
            },
            "candidate_pair_count": 210,
            "algorithm": (
                "For each seed and 1-based constraint "
                "index, rank every (year, region) pair "
                "by ascending SHA-256 of UTF-8 string "
                "'mcad-sa5-objective-count-context-v2|"
                "<seed>|<constraint-index>|<year>|"
                "<region>'; assign the first four "
                "distinct pairs in ranked order to "
                "local virtual-node indices 0,1,2,3."
            ),
            "required_distinct_context_count_per_constraint": 4,
            "support_query_real_node_count_required": 1,
            "support_query_signature_duplicate_count_required": 0,
        },
    },
    "noise_operator_contract": {
        "noise_class_order": (
            noise_classes
        ),
        "non_redundant_noise_classes": (
            non_redundant_classes
        ),
        "operator_definitions": (
            operator_definitions
        ),
        "single_operator_rule": (
            "A non-redundant noise query applies "
            "exactly one registered mutation operator "
            "to one canonical contributive base query. "
            "All semantic fields not listed in "
            "changed_fields must remain byte-equivalent."
        ),
        "operator_provenance_rule": (
            "The workload materializer and independent "
            "auditor must record the noise class, "
            "target support ordinal, mutation operator "
            "version, semantic projection before and "
            "after mutation, and both SHA-256 digests."
        ),
        "operator_registry_version": (
            "mcad-sa5-objective-count-"
            "noise-operators-v1"
        ),
    },
    "revised_noise_schedule_contract": {
        "workload_length": 32,
        "noise_step_count": 8,
        "contributive_step_count": 24,
        "noise_position_selection": {
            "preserved_from_amendment_002": True,
            "algorithm": (
                "Rank positions 1..32 by ascending "
                "SHA-256 of UTF-8 string "
                "'mcad-sa5-noise-position-v2|"
                "<seed>|<position>'; select the eight "
                "lowest digests and sort numerically."
            ),
        },
        "redundant_position_selection": {
            "algorithm": (
                "Compute the complement contributive "
                "positions. From selected noise "
                "positions strictly greater than the "
                "first contributive position, choose "
                "the numerically smallest position."
            ),
            "eligible_position_required": True,
            "prior_contributive_step_required": True,
        },
        "redundant_source_selection": {
            "algorithm": (
                "Choose the greatest contributive "
                "position strictly smaller than the "
                "redundant-contribution position."
            ),
            "semantic_projection_replay_required": True,
        },
        "remaining_class_assignment": {
            "algorithm": (
                "Exclude redundant_contribution. Rank "
                "the remaining seven classes by "
                "ascending SHA-256 of UTF-8 string "
                "'mcad-sa5-noise-class-v3|<seed>|"
                "<class>'; assign this order to the "
                "remaining seven selected noise "
                "positions in ascending numeric order."
            ),
        },
        "non_redundant_target_selection": {
            "algorithm": (
                "Process the seven non-redundant "
                "classes in canonical noise-class "
                "order. For each class, choose the "
                "unused support ordinal with the "
                "lowest SHA-256 of UTF-8 string "
                "'mcad-sa5-noise-target-v3|<seed>|"
                "<class>|<support-ordinal>'; ties are "
                "resolved by ascending support ordinal."
            ),
            "distinct_target_required_within_replication": True,
            "target_count_per_replication": 7,
        },
        "schedule_rows": schedule_rows,
        "old_failure_resolved": {
            "replication_index": 2,
            "seed": 1198202409,
            "old_redundant_position": 1,
            "new_redundant_position": 8,
            "new_source_step_index": 7,
            "prior_contributive_step_exists": True,
        },
    },
    "materialization_acceptance_contract": {
        "required_workload_count": 10,
        "required_workload_length": 32,
        "required_contributive_query_count_per_workload": 24,
        "required_non_contributive_query_count_per_workload": 8,
        "required_noise_class_count_per_workload": 8,
        "required_count_per_noise_class_per_workload": 1,
        "required_stage10_noise_query_count": 80,
        "required_operator_registry_version": (
            "mcad-sa5-objective-count-"
            "noise-operators-v1"
        ),
        "required_unique_support_query_count": 24,
        "required_support_query_signature_duplicate_count": 0,
        "required_non_redundant_mutation_count": 7,
        "required_non_redundant_sat_true_count": 0,
        "required_non_redundant_real_node_count": 0,
        "required_redundant_replay_count": 1,
        "required_redundant_sat_true_count": 1,
        "required_redundant_real_node_count": 1,
        "required_redundant_gained_resource_count": 0,
        "required_redundant_oracle_contributive": False,
        "required_redundancy_ordering_failure_count": 0,
        "required_operator_oracle_mismatch_count": 0,
        "required_cross_level_workload_mismatch_count": 0,
    },
    "implementation_contract": {
        "implementation_required_before_materialization": True,
        "target_structural_generator_version": target_e21,
        "target_campaign_generator_version": target_e22,
        "required_dedicated_production_module": (
            "backend/harness/sensitivity_execution/"
            "tools/objective_count_noise_operators_v2.py"
        ),
        "required_dedicated_test_module": (
            "backend/harness/sensitivity_execution/"
            "tests/test_objective_count_noise_operators_v2.py"
        ),
        "required_independent_audits": [
            (
                "support-query signature uniqueness"
            ),
            (
                "exact one-field mutation for each "
                "non-redundant class"
            ),
            (
                "operator-specific evaluator outcome"
            ),
            (
                "redundant replay source and ordering"
            ),
            (
                "24-contribution and 8-noise count"
            ),
        ],
        "prior_21_file_scope_authoritative": False,
        "implementation_scope_must_be_reprojected_after_merge": True,
        "preserve_v1_generator_module_bytes": True,
        "preserve_historical_factor_behavior": True,
        "preserve_membership_density_profile": True,
    },
    "authorization": {
        "amendment_persistence_authorized": True,
        "v2_implementation_authorized_after_amendment_merge": True,
        "v2_patch_authoring_authorized_before_amendment_merge": False,
        "canonical_campaign_materialization_authorized": False,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "manuscript_integration_authorized": False,
        "global_scientific_freeze": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "campaign_materialization_performed": False,
        "functional_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": (
        "reproject_sa5_objective_count_v2_"
        "implementation_scope_after_noise_"
        "operator_amendment_merge"
    ),
}

amendment_003_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

amendment_003_path.write_text(
    json.dumps(
        amendment,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

test_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

test_path.write_text(
    r'''from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[4]

PLANNING_ROOT = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
)

PREREG_PATH = (
    PLANNING_ROOT
    / (
        "sa5_objective_count_stage10_"
        "campaign_preregistration.json"
    )
)

AMENDMENT_001_PATH = (
    PLANNING_ROOT
    / (
        "sa5_objective_count_"
        "materialization_contract_amendment.json"
    )
)

AMENDMENT_002_PATH = (
    PLANNING_ROOT
    / (
        "sa5_objective_count_workload_"
        "contribution_capacity_amendment.json"
    )
)

AMENDMENT_003_PATH = (
    PLANNING_ROOT
    / (
        "sa5_objective_count_noise_operator_"
        "and_redundancy_ordering_amendment.json"
    )
)

EXPECTED_PREREG_SHA = (
    "a92bb672c2c0ac61d3700ce49c9f3340"
    "ffe6b2f01f08b0f94dd354f96c8c8d5e"
)

EXPECTED_AMENDMENT_001_SHA = (
    "2e0ff32570d9e427e753fdda5bc81699"
    "6d2608778879c1c4c5568fc47bf088e1"
)

EXPECTED_AMENDMENT_002_SHA = (
    "32b3f28d0815fa3e0713f00bc0a4188"
    "63e28089f00fe4079e20c7f257ac960dc"
)


def load_json(
    path: Path,
) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    assert isinstance(value, dict)

    return value


def digest(value: str) -> str:
    return hashlib.sha256(
        value.encode("utf-8")
    ).hexdigest()


def load_amendment() -> dict[str, Any]:
    return load_json(
        AMENDMENT_003_PATH
    )


def test_prior_artifacts_remain_unchanged() -> None:
    assert hashlib.sha256(
        PREREG_PATH.read_bytes()
    ).hexdigest() == EXPECTED_PREREG_SHA

    assert hashlib.sha256(
        AMENDMENT_001_PATH.read_bytes()
    ).hexdigest() == EXPECTED_AMENDMENT_001_SHA

    assert hashlib.sha256(
        AMENDMENT_002_PATH.read_bytes()
    ).hexdigest() == EXPECTED_AMENDMENT_002_SHA


def test_amendment_identity_and_precedence() -> None:
    amendment = load_amendment()

    assert amendment["schema_version"] == (
        "mcad-sa5-objective-count-noise-"
        "operator-and-redundancy-ordering-"
        "amendment-v1"
    )

    assert amendment["amendment_id"] == (
        "sa5_objective_count_noise_operator_"
        "and_redundancy_ordering_amendment_003"
    )

    assert amendment["status"] == (
        "preregistered_implementation_required"
    )

    assert amendment["factor"] == "objective_count"
    assert amendment["stage"] == 10

    superseded = amendment[
        "amends"
    ]["superseded_fields"]

    assert any(
        "class_to_position_assignment"
        in value
        for value in superseded
    )

    assert any(
        "21-file" in value
        for value in superseded
    )


def test_all_eight_noise_operators_are_exact() -> None:
    amendment = load_amendment()

    contract = amendment[
        "noise_operator_contract"
    ]

    classes = contract[
        "noise_class_order"
    ]

    definitions = contract[
        "operator_definitions"
    ]

    assert classes == [
        "wrong_measure",
        "wrong_context",
        "insufficient_grain",
        "invalid_aggregation",
        "invalid_unit",
        "invalid_time_window",
        "missing_cube",
        "redundant_contribution",
    ]

    assert set(definitions) == set(classes)

    for noise_class in classes[:-1]:
        definition = definitions[
            noise_class
        ]

        assert definition[
            "expected_sat"
        ] is False

        assert definition[
            "expected_real_node_count"
        ] == 0

        assert definition[
            "expected_oracle_contributive"
        ] is False

        assert definition[
            "changed_fields"
        ]

    redundant = definitions[
        "redundant_contribution"
    ]

    assert redundant[
        "changed_fields"
    ] == []

    assert redundant[
        "expected_sat"
    ] is True

    assert redundant[
        "expected_real_node_count"
    ] == 1

    assert redundant[
        "expected_gained_resource_count"
    ] == 0

    assert redundant[
        "expected_oracle_contributive"
    ] is False

    assert redundant[
        "prior_contribution_required"
    ] is True


def test_support_query_uniqueness_contract() -> None:
    contract = load_amendment()[
        "canonical_support_query_contract"
    ]

    assert contract[
        "semantic_projection_fields"
    ] == [
        "cube",
        "measures",
        "group_by",
        "slicers",
        "aggregators",
        "units",
        "window_start",
        "window_end",
        "time_members",
    ]

    expected = contract[
        "expected_base_query_outcome"
    ]

    assert expected["sat"] is True
    assert expected["real_node_count"] == 1
    assert expected[
        "oracle_contributive_on_first_use"
    ] is True
    assert expected[
        "gained_resource_count_on_first_use"
    ] == 1

    uniqueness = contract[
        "unique_context_assignment"
    ]

    assert uniqueness[
        "candidate_pair_count"
    ] == 210

    assert uniqueness[
        "required_distinct_context_count_per_constraint"
    ] == 4

    assert uniqueness[
        "support_query_real_node_count_required"
    ] == 1

    assert uniqueness[
        "support_query_signature_duplicate_count_required"
    ] == 0


def test_schedule_is_deterministic_and_redundancy_is_ordered() -> None:
    amendment = load_amendment()

    schedule = amendment[
        "revised_noise_schedule_contract"
    ]

    rows = schedule["schedule_rows"]

    classes = amendment[
        "noise_operator_contract"
    ]["noise_class_order"]

    non_redundant = [
        value
        for value in classes
        if value != "redundant_contribution"
    ]

    assert len(rows) == 10

    for row in rows:
        seed = int(row["seed"])

        expected_noise_positions = sorted(
            sorted(
                range(1, 33),
                key=lambda position: (
                    digest(
                        "mcad-sa5-noise-position-v2"
                        f"|{seed}|{position}"
                    ),
                    position,
                ),
            )[:8]
        )

        assert row[
            "noise_positions"
        ] == expected_noise_positions

        contributive_positions = [
            position
            for position in range(1, 33)
            if position
            not in expected_noise_positions
        ]

        assert row[
            "contributive_positions"
        ] == contributive_positions

        first_contributive = (
            contributive_positions[0]
        )

        eligible = [
            position
            for position
            in expected_noise_positions
            if position > first_contributive
        ]

        redundant_position = min(
            eligible
        )

        assert row[
            "redundant_contribution_position"
        ] == redundant_position

        source_step = max(
            position
            for position in contributive_positions
            if position < redundant_position
        )

        assert row[
            "redundant_source_step_index"
        ] == source_step

        assert row[
            "redundant_source_support_ordinal"
        ] == contributive_positions.index(
            source_step
        )

        assert redundant_position > (
            first_contributive
        )

        class_by_position = row[
            "class_by_position"
        ]

        assert set(
            class_by_position.values()
        ) == set(classes)

        targets = row[
            "target_support_ordinal_by_class"
        ]

        assert set(targets) == set(
            non_redundant
        )

        assert len(
            set(targets.values())
        ) == 7

    replication_two = rows[2]

    assert replication_two[
        "replication_index"
    ] == 2

    assert replication_two[
        "seed"
    ] == 1198202409

    assert replication_two[
        "redundant_contribution_position"
    ] == 8

    assert replication_two[
        "redundant_source_step_index"
    ] == 7


def test_acceptance_contract_closes_noise_semantics() -> None:
    acceptance = load_amendment()[
        "materialization_acceptance_contract"
    ]

    assert acceptance[
        "required_workload_count"
    ] == 10

    assert acceptance[
        "required_workload_length"
    ] == 32

    assert acceptance[
        "required_contributive_query_count_per_workload"
    ] == 24

    assert acceptance[
        "required_non_contributive_query_count_per_workload"
    ] == 8

    assert acceptance[
        "required_count_per_noise_class_per_workload"
    ] == 1

    assert acceptance[
        "required_unique_support_query_count"
    ] == 24

    assert acceptance[
        "required_support_query_signature_duplicate_count"
    ] == 0

    assert acceptance[
        "required_non_redundant_sat_true_count"
    ] == 0

    assert acceptance[
        "required_redundant_sat_true_count"
    ] == 1

    assert acceptance[
        "required_redundant_gained_resource_count"
    ] == 0

    assert acceptance[
        "required_redundancy_ordering_failure_count"
    ] == 0

    assert acceptance[
        "required_operator_oracle_mismatch_count"
    ] == 0


def test_scope_requires_reprojection_and_execution_remains_forbidden() -> None:
    amendment = load_amendment()

    implementation = amendment[
        "implementation_contract"
    ]

    authorization = amendment[
        "authorization"
    ]

    assert implementation[
        "prior_21_file_scope_authoritative"
    ] is False

    assert implementation[
        "implementation_scope_must_be_reprojected_after_merge"
    ] is True

    assert implementation[
        "preserve_v1_generator_module_bytes"
    ] is True

    assert implementation[
        "preserve_historical_factor_behavior"
    ] is True

    assert authorization[
        "v2_patch_authoring_authorized_before_amendment_merge"
    ] is False

    assert authorization[
        "canonical_campaign_materialization_authorized"
    ] is False

    assert authorization[
        "functional_execution_authorized"
    ] is False

    assert authorization[
        "timing_execution_authorized"
    ] is False

    assert authorization[
        "manuscript_integration_authorized"
    ] is False

    assert amendment["next_stage"] == (
        "reproject_sa5_objective_count_v2_"
        "implementation_scope_after_noise_"
        "operator_amendment_merge"
    )
'''.rstrip()
    + "\n",
    encoding="utf-8",
)

print("noise_operator_amendment_authoring=PASS")
print(
    "amendment="
    f"{amendment_003_path.relative_to(root)}"
)
print(
    "test="
    f"{test_path.relative_to(root)}"
)
print("registered_noise_operator_count=8")
print("non_redundant_operator_count=7")
print("redundant_operator_count=1")
print("support_query_real_node_count_required=1")
print("old_failure_seed=1198202409")
print("old_redundant_position=1")
print("new_redundant_position=8")
print("new_redundant_source_step=7")
print("prior_21_file_scope_authoritative=false")
PY

echo
echo "=== 4. Validate amendment JSON ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-noise-operator-and-redundancy-ordering-amendment-v1"
  and .amendment_id
    == "sa5_objective_count_noise_operator_and_redundancy_ordering_amendment_003"
  and .status
    == "preregistered_implementation_required"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"

  and .audit_provenance.existing_exact_operator_classes
    == ["missing_cube"]
  and .audit_provenance.template_label_only_classes
    == ["wrong_measure"]
  and .audit_provenance.missing_exact_operator_class_count
    == 7

  and (
    .noise_operator_contract.noise_class_order
    | length
  ) == 8
  and (
    .noise_operator_contract.operator_definitions
    | keys
    | length
  ) == 8
  and .noise_operator_contract.operator_registry_version
    == "mcad-sa5-objective-count-noise-operators-v1"

  and .canonical_support_query_contract.expected_base_query_outcome.sat
    == true
  and .canonical_support_query_contract.expected_base_query_outcome.real_node_count
    == 1
  and .canonical_support_query_contract.unique_context_assignment.candidate_pair_count
    == 210
  and .canonical_support_query_contract.unique_context_assignment.required_distinct_context_count_per_constraint
    == 4
  and .canonical_support_query_contract.unique_context_assignment.support_query_signature_duplicate_count_required
    == 0

  and .noise_operator_contract.operator_definitions.wrong_measure.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.wrong_context.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.insufficient_grain.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_aggregation.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_unit.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_time_window.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.missing_cube.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_sat
    == true
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_gained_resource_count
    == 0
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_oracle_contributive
    == false

  and (
    .revised_noise_schedule_contract.schedule_rows
    | length
  ) == 10
  and .revised_noise_schedule_contract.old_failure_resolved.replication_index
    == 2
  and .revised_noise_schedule_contract.old_failure_resolved.seed
    == 1198202409
  and .revised_noise_schedule_contract.old_failure_resolved.old_redundant_position
    == 1
  and .revised_noise_schedule_contract.old_failure_resolved.new_redundant_position
    == 8
  and .revised_noise_schedule_contract.old_failure_resolved.new_source_step_index
    == 7
  and .revised_noise_schedule_contract.old_failure_resolved.prior_contributive_step_exists
    == true

  and .materialization_acceptance_contract.required_workload_count
    == 10
  and .materialization_acceptance_contract.required_workload_length
    == 32
  and .materialization_acceptance_contract.required_unique_support_query_count
    == 24
  and .materialization_acceptance_contract.required_non_redundant_mutation_count
    == 7
  and .materialization_acceptance_contract.required_redundant_replay_count
    == 1
  and .materialization_acceptance_contract.required_redundancy_ordering_failure_count
    == 0
  and .materialization_acceptance_contract.required_operator_oracle_mismatch_count
    == 0

  and .implementation_contract.prior_21_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true
  and .implementation_contract.preserve_v1_generator_module_bytes
    == true
  and .implementation_contract.preserve_historical_factor_behavior
    == true

  and .authorization.v2_patch_authoring_authorized_before_amendment_merge
    == false
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false

  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.campaign_materialization_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_noise_operator_amendment_merge"
' "$AMENDMENT_003" >/dev/null

echo "noise_operator_amendment_json_validation=PASS"

echo
echo "=== 5. Compile and test amendment chain ==="

"$PYTHON" -m py_compile \
  "$AMENDMENT_003_TEST"

"$PYTHON" -m pytest \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

echo "noise_operator_amendment_tests=PASS"

echo
echo "=== 6. Repository-scope gate ==="

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

test -f "$AMENDMENT_003"
test -f "$AMENDMENT_003_TEST"

test -n "$(
  git check-ignore -v "$AMENDMENT_003" || true
)"

test "$(
  git status --porcelain -- "$AMENDMENT_003_TEST"
)" = "?? $AMENDMENT_003_TEST"

test -z "$(git diff --name-only)"
test -z "$(git diff --cached --name-only)"

echo "repository_scope_gate=PASS"
echo "prior_artifacts_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Force-stage amendment ==="

git add -f "$AMENDMENT_003"
git add "$AMENDMENT_003_TEST"

printf '%s\n' \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_003" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

git diff --cached --name-only |
  sort \
  > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)" -eq 2

git diff --cached --check

echo "noise_operator_amendment_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 8. Commit amendment ==="

git commit \
  -m "chore(experiments): preregister SA5 noise operators"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"

AMENDMENT_003_SHA="$(
  sha256sum "$AMENDMENT_003" |
    awk '{print $1}'
)"

echo "commit=PASS"
echo "commit=$COMMIT"
echo "noise_operator_amendment_sha256=$AMENDMENT_003_SHA"

echo
echo "=== 9. Push amendment branch ==="

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 10. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister SA5 objective-count noise operators" \
    --body "$(cat <<EOF
## SA5 noise-operator and redundancy-ordering amendment

The read-only classification found:

- one partial mutation precedent: \`missing_cube\`;
- one label-only precedent: \`wrong_measure\`;
- seven missing exact operator definitions;
- one invalid redundant-contribution schedule at replication 2,
  seed \`1198202409\`, position \`1\`.

### Registered operators

The amendment now defines exact operators for all eight classes:

- \`wrong_measure\`;
- \`wrong_context\`;
- \`insufficient_grain\`;
- \`invalid_aggregation\`;
- \`invalid_unit\`;
- \`invalid_time_window\`;
- \`missing_cube\`;
- \`redundant_contribution\`.

### Redundancy correction

For replication 2:

- previous redundant position: \`1\`;
- revised redundant position: \`8\`;
- replay source step: \`7\`.

Every redundant replay must therefore have a prior contributive source.

### Query-target uniqueness

Canonical support queries must realise exactly one support NV. The
objective-count v2 generator must allocate four distinct context pairs
per constraint and the independent auditor must report zero duplicate
support-query signatures.

### Scope consequence

The prior 21-file implementation scope is not authoritative. It must be
reprojected after this amendment merges, including a dedicated operator
registry and dedicated operator tests.

### Scientific controls

- canonical campaign generated: \`false\`;
- campaign materialization performed: \`false\`;
- functional execution authorized: \`false\`;
- timing execution authorized: \`false\`;
- manuscript modified: \`false\`.

### Integrity

- amendment SHA-256: \`$AMENDMENT_003_SHA\`;
- classification report SHA-256: \`$EXPECTED_CLASSIFICATION_REPORT_SHA\`;
- classification surface SHA-256: \`$EXPECTED_CLASSIFICATION_SURFACE_SHA\`;
- capacity amendment SHA-256: \`$EXPECTED_AMENDMENT_002_SHA\`.

## Next stage

\`reproject_sa5_objective_count_v2_implementation_scope_after_noise_operator_amendment_merge\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 11. Verify pull-request identity and scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count noise operators"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 12. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_noise_operator_amendment=PASS"
echo "commit=$COMMIT"
echo "noise_operator_amendment=$AMENDMENT_003"
echo "noise_operator_amendment_sha256=$AMENDMENT_003_SHA"

echo "registered_noise_operator_count=8"
echo "non_redundant_operator_count=7"
echo "redundant_operator_count=1"

echo "support_query_real_node_count_required=1"
echo "support_query_signature_duplicate_count_required=0"

echo "old_failure_seed=1198202409"
echo "old_redundant_position=1"
echo "new_redundant_position=8"
echo "new_redundant_source_step=7"

echo "prior_21_file_scope_authoritative=false"
echo "v2_patch_authoring_authorized=false"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_noise_operator_amendment"

git status --short --branch
git log --oneline --decorate -4
