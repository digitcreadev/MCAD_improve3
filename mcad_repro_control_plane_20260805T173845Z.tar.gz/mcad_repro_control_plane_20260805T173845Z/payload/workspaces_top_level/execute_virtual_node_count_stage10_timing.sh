#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="aea4d6f284b2aadcfd470b80fd3a951a0ad46f00"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

PLAN="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_execution_plan.json"

AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"

OUTPUT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/virtual_node_count_stage10_c4"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution"

LOG_DIR="$AUDIT_ROOT/logs"

REPORT="$AUDIT_ROOT/formal_timing_execution_report.json"
SUMMARY="$AUDIT_ROOT/formal_timing_execution_report.md"

trap 'echo "[ERROR] Timing execution stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Formal timing execution gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$RUNNER"
test -f "$PLAN"
test -f "$AUTH"

test ! -e "$OUTPUT_ROOT"
test ! -e "$AUDIT_ROOT"

echo "branch=$BASE"
echo "head=$EXPECTED_HEAD"
echo "execution_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"

echo
echo "=== 2. Create formal timing execution branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/execute-virtual-node-count-stage10-timing-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "started_utc=$STARTED_UTC"

echo
echo "=== 3. Preflight plan, authorization and digests ==="

MATRIX_FILE="$(mktemp)"

"$PYTHON" - \
  "$ROOT" \
  "$PLAN" \
  "$AUTH" \
  "$RUNNER" \
  "$MATRIX_FILE" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
plan_path = root / sys.argv[2]
authorization_path = root / sys.argv[3]
runner_path = root / sys.argv[4]
matrix_path = Path(sys.argv[5])


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SystemExit(f"Missing JSON artifact: {path}")

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


plan = load_json(plan_path)
authorization = load_json(authorization_path)

if plan.get("status") != "prepared":
    raise SystemExit("Timing execution plan is not prepared.")

if authorization.get("status") != "authorized":
    raise SystemExit("Formal timing is not authorized.")

if plan.get("campaign_id") != "virtual_node_count_stage10_c4":
    raise SystemExit("Unexpected timing campaign.")

if authorization.get("campaign_id") != plan.get("campaign_id"):
    raise SystemExit("Authorization/plan campaign mismatch.")

scope = plan.get("scope", {})

expected_scope = {
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmups_per_cell": 10,
    "measurements_per_cell": 100,
    "expected_warmup_count": 600,
    "expected_measurement_count": 6000,
}

for key, expected in expected_scope.items():
    actual = scope.get(key)

    if actual != expected:
        raise SystemExit(
            f"Plan {key}: expected {expected!r}, "
            f"got {actual!r}"
        )

state = plan.get("execution_state", {})

if state.get("runner_invocation_performed") is not False:
    raise SystemExit("Plan already records a runner invocation.")

if state.get("timing_execution_performed") is not False:
    raise SystemExit("Plan already records timing execution.")

prohibitions = plan.get("prohibitions", {})

for key in (
    "functional_execution_rerun_authorized",
    "historical_prefix_rerun_authorized",
    "stage20_execution_authorized",
    "latency_claim_authorized",
    "scientific_freeze_authorized",
):
    if prohibitions.get(key) is not False:
        raise SystemExit(f"{key} must remain false.")

runner_sha256 = sha256_file(runner_path)
expected_runner_sha256 = plan["runner"]["sha256"]

if runner_sha256 != expected_runner_sha256:
    raise SystemExit(
        "Timing runner SHA-256 differs from the prepared plan."
    )

replications = plan.get("replications", [])

if not isinstance(replications, list) or len(replications) != 10:
    raise SystemExit("Expected 10 timing replications.")

matrix_lines: list[str] = []

for expected_index, replication in enumerate(replications):
    index = int(replication["replication_index"])

    if index != expected_index:
        raise SystemExit(
            f"Unexpected replication ordering: {index}"
        )

    if replication.get("logical_status") != "ready":
        raise SystemExit(
            f"Replication {index} is not ready."
        )

    if replication.get("runner_invocation_performed") is not False:
        raise SystemExit(
            f"Replication {index} already records execution."
        )

    if replication.get("functional_digest_check_required") is not True:
        raise SystemExit(
            f"Replication {index} lacks digest enforcement."
        )

    if replication.get("fresh_ckg_state_required") is not True:
        raise SystemExit(
            f"Replication {index} lacks fresh-CKG enforcement."
        )

    if replication.get("reuse_successful") is not True:
        raise SystemExit(
            f"Replication {index} lacks successful reuse."
        )

    source_run = root / replication["source_functional_run_path"]
    execution_spec = source_run / "execution_spec.json"
    execution_manifest = source_run / "execution_manifest.json"

    if not source_run.is_dir():
        raise SystemExit(
            f"Missing source functional run: {source_run}"
        )

    if not execution_spec.is_file():
        raise SystemExit(
            f"Missing execution spec: {execution_spec}"
        )

    if not execution_manifest.is_file():
        raise SystemExit(
            f"Missing execution manifest: {execution_manifest}"
        )

    manifest = load_json(execution_manifest)

    expected_digest = replication["source_functional_digest"]
    actual_digest = manifest.get(
        "deterministic_execution_digest"
    )

    if actual_digest != expected_digest:
        raise SystemExit(
            f"Functional digest mismatch for replication {index}."
        )

    expected_order_seed = 20260728 + index
    order_seed = int(replication["execution_order_seed"])

    if order_seed != expected_order_seed:
        raise SystemExit(
            f"Order-seed mismatch for replication {index}."
        )

    if int(replication["timing_cell_count"]) != 6:
        raise SystemExit(
            f"Expected 6 cells for replication {index}."
        )

    if int(replication["expected_warmup_count"]) != 60:
        raise SystemExit(
            f"Expected 60 warmups for replication {index}."
        )

    if int(replication["expected_measurement_count"]) != 600:
        raise SystemExit(
            f"Expected 600 measurements for replication {index}."
        )

    matrix_lines.append(
        "\t".join(
            (
                f"{index:03d}",
                execution_spec.relative_to(root).as_posix(),
                str(order_seed),
                expected_digest,
            )
        )
    )

matrix_path.write_text(
    "\n".join(matrix_lines) + "\n",
    encoding="utf-8",
)

print("timing_preflight=PASS")
print(f"runner_sha256={runner_sha256}")
print("replication_count=10")
print("timing_cell_count=60")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("functional_digest_matrix=PASS")
print("timing_execution_performed=false")
PY

mkdir -p "$OUTPUT_ROOT"
mkdir -p "$LOG_DIR"

echo
echo "=== 4. Execute ten formal timing replications ==="

COMPLETED_REPLICATIONS=0

while IFS=$'\t' read -r \
  REP \
  SPEC_REL \
  ORDER_SEED \
  FUNCTIONAL_DIGEST
do
  OUT_REL="$OUTPUT_ROOT/rep_${REP}"
  LOG_REL="$LOG_DIR/rep_${REP}.log"

  test ! -e "$OUT_REL"
  test ! -e "$LOG_REL"
  test -f "$SPEC_REL"

  echo
  echo "--- replication=$REP ---"
  echo "execution_spec=$SPEC_REL"
  echo "output_dir=$OUT_REL"
  echo "order_seed=$ORDER_SEED"
  echo "expected_warmups=60"
  echo "expected_measurements=600"

  set +e

  PYTHONPATH="$ROOT" \
    "$PYTHON" "$RUNNER" \
      "$SPEC_REL" \
      --output-dir "$OUT_REL" \
      --warmups 10 \
      --measurements 100 \
      --order-seed "$ORDER_SEED" \
      --reuse-successful \
      2>&1 | tee "$LOG_REL"

  RUNNER_STATUS="${PIPESTATUS[0]}"

  set -e

  echo "runner_exit_status=$RUNNER_STATUS"

  if [ "$RUNNER_STATUS" -ne 0 ]; then
    echo "failed_replication=$REP"
    echo "partial_outputs_preserved=true"
    exit 1
  fi

  test -d "$OUT_REL"
  test -f "$OUT_REL/timing_observations.csv"

  COMPLETED_REPLICATIONS=$((COMPLETED_REPLICATIONS + 1))

  echo "replication_${REP}=PASS"
done < "$MATRIX_FILE"

rm -f "$MATRIX_FILE"

test "$COMPLETED_REPLICATIONS" -eq 10

echo
echo "completed_replication_count=$COMPLETED_REPLICATIONS"
echo "timing_runner_execution=PASS"

echo
echo "=== 5. Validate outputs and produce formal report ==="

COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$PLAN" \
  "$AUTH" \
  "$RUNNER" \
  "$OUTPUT_ROOT" \
  "$LOG_DIR" \
  "$REPORT" \
  "$SUMMARY" \
  "$BRANCH" \
  "$STARTED_UTC" \
  "$COMPLETED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable

root = Path(sys.argv[1])
plan_path = root / sys.argv[2]
authorization_path = root / sys.argv[3]
runner_path = root / sys.argv[4]
output_root = root / sys.argv[5]
log_dir = root / sys.argv[6]
report_path = root / sys.argv[7]
summary_path = root / sys.argv[8]
execution_branch = sys.argv[9]
started_utc = sys.argv[10]
completed_utc = sys.argv[11]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def collect_scalars(
    value: Any,
    path: tuple[str, ...] = (),
) -> Iterable[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from collect_scalars(
                child,
                path + (str(key),),
            )
        return

    if isinstance(value, list):
        for index, child in enumerate(value):
            yield from collect_scalars(
                child,
                path + (f"[{index}]",),
            )
        return

    yield ".".join(path), value


def output_tree_digest(directory: Path) -> tuple[str, int]:
    entries: list[str] = []

    for path in sorted(
        item
        for item in directory.rglob("*")
        if item.is_file()
    ):
        relative = path.relative_to(directory).as_posix()
        entries.append(
            f"{relative}\t{sha256_file(path)}"
        )

    digest = hashlib.sha256(
        ("\n".join(entries) + "\n").encode("utf-8")
    ).hexdigest()

    return digest, len(entries)


plan = load_json(plan_path)
authorization = load_json(authorization_path)

runner_sha256 = sha256_file(runner_path)

if runner_sha256 != plan["runner"]["sha256"]:
    raise SystemExit("Runner hash changed during execution.")

replication_reports: list[dict[str, Any]] = []

total_warmups = 0
total_measurements = 0
total_cells = 0

for replication in plan["replications"]:
    index = int(replication["replication_index"])
    rep_name = f"rep_{index:03d}"

    directory = output_root / rep_name
    log_path = log_dir / f"{rep_name}.log"
    observations_path = directory / "timing_observations.csv"

    if not directory.is_dir():
        raise SystemExit(
            f"Missing timing output directory: {directory}"
        )

    if not log_path.is_file():
        raise SystemExit(
            f"Missing timing execution log: {log_path}"
        )

    if not observations_path.is_file():
        raise SystemExit(
            f"Missing timing observations: {observations_path}"
        )

    json_paths = sorted(directory.rglob("*.json"))

    if not json_paths:
        raise SystemExit(
            f"No JSON timing manifests found: {directory}"
        )

    scalar_records: list[tuple[str, Any, str]] = []

    for json_path in json_paths:
        payload = load_json(json_path)

        for scalar_path, value in collect_scalars(payload):
            scalar_records.append(
                (
                    scalar_path.lower(),
                    value,
                    json_path.relative_to(directory).as_posix(),
                )
            )

    warmup_candidates = [
        (path, value, source)
        for path, value, source in scalar_records
        if (
            "warmup" in path
            and "count" in path
            and isinstance(value, int)
            and not isinstance(value, bool)
        )
    ]

    measurement_candidates = [
        (path, value, source)
        for path, value, source in scalar_records
        if (
            (
                "measurement" in path
                or "measurements" in path
            )
            and "count" in path
            and isinstance(value, int)
            and not isinstance(value, bool)
        )
    ]

    expected_warmups = int(
        replication["expected_warmup_count"]
    )
    expected_measurements = int(
        replication["expected_measurement_count"]
    )

    matching_warmups = [
        item
        for item in warmup_candidates
        if item[1] == expected_warmups
    ]

    matching_measurements = [
        item
        for item in measurement_candidates
        if item[1] == expected_measurements
    ]

    if not matching_warmups:
        raise SystemExit(
            f"Replication {index}: no manifest records "
            f"{expected_warmups} warmups. "
            f"Candidates={warmup_candidates}"
        )

    if not matching_measurements:
        raise SystemExit(
            f"Replication {index}: no manifest records "
            f"{expected_measurements} measurements. "
            f"Candidates={measurement_candidates}"
        )

    with observations_path.open(
        newline="",
        encoding="utf-8",
    ) as stream:
        observation_row_count = sum(
            1 for _ in csv.DictReader(stream)
        )

    if observation_row_count <= 0:
        raise SystemExit(
            f"Replication {index}: empty timing CSV."
        )

    log_text = log_path.read_text(
        encoding="utf-8",
        errors="replace",
    )

    if (
        f"measurement_observation_count="
        f"{expected_measurements}"
        not in log_text
    ):
        raise SystemExit(
            f"Replication {index}: measurement count "
            "not confirmed by runner log."
        )

    tree_sha256, output_file_count = output_tree_digest(
        directory
    )

    replication_reports.append(
        {
            "replication_index": index,
            "structural_seed": int(
                replication["structural_seed"]
            ),
            "execution_order_seed": int(
                replication["execution_order_seed"]
            ),
            "source_functional_run_path": (
                replication[
                    "source_functional_run_path"
                ]
            ),
            "source_functional_digest": (
                replication[
                    "source_functional_digest"
                ]
            ),
            "timing_output_path": (
                directory.relative_to(root).as_posix()
            ),
            "timing_log_path": (
                log_path.relative_to(root).as_posix()
            ),
            "timing_cell_count": 6,
            "warmup_observation_count": (
                expected_warmups
            ),
            "measurement_observation_count": (
                expected_measurements
            ),
            "timing_csv_row_count": (
                observation_row_count
            ),
            "timing_observations_sha256": (
                sha256_file(observations_path)
            ),
            "timing_log_sha256": sha256_file(
                log_path
            ),
            "output_tree_sha256": tree_sha256,
            "output_file_count": output_file_count,
            "runner_exit_status": 0,
            "status": "pass",
        }
    )

    total_cells += 6
    total_warmups += expected_warmups
    total_measurements += expected_measurements

if len(replication_reports) != 10:
    raise SystemExit("Expected 10 timing replications.")

if total_cells != 60:
    raise SystemExit(
        f"Expected 60 cells, got {total_cells}."
    )

if total_warmups != 600:
    raise SystemExit(
        f"Expected 600 warmups, got {total_warmups}."
    )

if total_measurements != 6000:
    raise SystemExit(
        f"Expected 6000 measurements, "
        f"got {total_measurements}."
    )

source_commit = subprocess.check_output(
    ["git", "rev-parse", "HEAD"],
    cwd=root,
    text=True,
).strip()

report = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "formal-timing-execution-report-v1"
    ),
    "status": "pass",
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "execution_branch": execution_branch,
    "execution_source_commit": source_commit,
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "runner": {
        "path": runner_path.relative_to(root).as_posix(),
        "sha256": runner_sha256,
        "matches_prepared_plan": True,
    },
    "authorization": {
        "path": authorization_path.relative_to(root).as_posix(),
        "sha256": sha256_file(authorization_path),
        "status": authorization["status"],
    },
    "execution_plan": {
        "path": plan_path.relative_to(root).as_posix(),
        "sha256": sha256_file(plan_path),
        "status": plan["status"],
    },
    "replication_count": 10,
    "timing_cell_count": total_cells,
    "warmup_observation_count": total_warmups,
    "measurement_observation_count": (
        total_measurements
    ),
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
    "scientific_freeze_authorized": False,
    "replications": replication_reports,
    "next_stage": (
        "analyze_stage10_clustered_timing_precision_v2"
    ),
}

report_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

summary = f"""# Virtual-node-count Stage-10 formal timing

- Status: `PASS`
- Replications: `10`
- Timing cells: `{total_cells}`
- Warmup observations: `{total_warmups}`
- Measurement observations: `{total_measurements}`
- Functional execution rerun: `false`
- Historical-prefix rerun: `false`
- Timing execution performed: `true`
- Precision analysis performed: `false`
- Latency claim authorized: `false`
- Stage-20 authorized: `false`

## Next stage

`analyze_stage10_clustered_timing_precision_v2`
"""

summary_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

summary_path.write_text(
    summary,
    encoding="utf-8",
)

print("stage10_formal_timing_execution=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("warmup_observation_count=600")
print("measurement_observation_count=6000")
print("all_replications_passed=true")
print("functional_execution_rerun_performed=false")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=true")
print("precision_analysis_performed=false")
print("latency_claim_authorized=false")
print("stage20_execution_authorized=false")
print(
    "next_stage="
    "analyze_stage10_clustered_timing_precision_v2"
)
PY

echo
echo "=== 6. Final report gate ==="

"$PYTHON" - "$REPORT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
report = json.loads(
    path.read_text(encoding="utf-8")
)

expected = {
    "status": "pass",
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

if len(report.get("replications", [])) != 10:
    raise SystemExit("Expected 10 replication reports.")

for replication in report["replications"]:
    if replication.get("status") != "pass":
        raise SystemExit(
            "Non-passing timing replication."
        )

    if replication.get("runner_exit_status") != 0:
        raise SystemExit(
            "Non-zero timing runner exit status."
        )

    if replication.get(
        "warmup_observation_count"
    ) != 60:
        raise SystemExit(
            "Unexpected per-replication warmup count."
        )

    if replication.get(
        "measurement_observation_count"
    ) != 600:
        raise SystemExit(
            "Unexpected per-replication measurement count."
        )

print("formal_timing_report_validation=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("warmup_observation_count=600")
print("measurement_observation_count=6000")
print("timing_execution_performed=true")
PY

echo
echo "=== 7. Commit and push timing evidence ==="

git add -f \
  "$OUTPUT_ROOT" \
  "$AUDIT_ROOT"

git diff --cached --check

git commit \
  -m "evidence(experiments): execute virtual-node-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Execute virtual-node-count Stage-10 formal timing" \
    --body "$(cat <<'EOF'
## Scope

- executes the formally authorized Stage-10 timing campaign;
- reuses the preregistered timing runner;
- checks the functional digest before every replication;
- executes ten structural replications;
- executes 60 timing cells;
- records 600 warmup observations;
- records 6000 measurement observations;
- performs no functional rerun.

## Result

- replications: 10/10 PASS;
- timing cells: 60;
- warmups: 600;
- measurements: 6000;
- timing execution performed: true;
- precision analysis performed: false;
- latency claims: unauthorized;
- Stage-20: unauthorized.

## Next stage

Run the preregistered clustered precision analyzer v2.
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

echo "virtual_node_count_stage10_timing_execution=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "warmup_observation_count=600"
echo "measurement_observation_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=true"
echo "precision_analysis_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_execution_evidence"

git status --short --branch
git log --oneline --decorate -4
