#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0674825017698f25562d43400ff4e72cb6484e2f"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

PRIOR_SCOPE_ROOT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z"
PRIOR_SCOPE_REPORT="$PRIOR_SCOPE_ROOT/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_PRIOR_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

VALIDATOR="backend/harness/sensitivity_execution/validate_workload_spec.py"
VALIDATOR_TEST="backend/harness/sensitivity_execution/tests/test_workload_spec.py"
WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"

CKG_SOURCE="backend/ckg/ckg_updater.py"

AMENDMENT_003_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py"
AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"

PROPOSED_OPERATOR_MODULE="backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py"
PROPOSED_OPERATOR_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_post_noise_scope_reprojection_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_post_noise_scope_reprojection.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_post_noise_scope_reprojection.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_post_noise_scope.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 post-noise scope reprojection stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Post-amendment repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_003" \
  "$PRIOR_SCOPE_REPORT" \
  "$VALIDATOR" \
  "$VALIDATOR_TEST" \
  "$WORKLOAD_SCHEMA" \
  "$CKG_SOURCE" \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$AMENDMENT_003" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_003_SHA"

test "$(
  sha256sum "$PRIOR_SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_PRIOR_SCOPE_REPORT_SHA"

test ! -e "$PROPOSED_OPERATOR_MODULE"
test ! -e "$PROPOSED_OPERATOR_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "preregistered_implementation_required"
  and .factor == "objective_count"
  and .stage == 10

  and .implementation_contract.required_dedicated_production_module
    == "backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py"
  and .implementation_contract.required_dedicated_test_module
    == "backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py"

  and .implementation_contract.prior_21_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true

  and .authorization.v2_implementation_authorized_after_amendment_merge
    == true
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false

  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_noise_operator_amendment_merge"
' "$AMENDMENT_003" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_v2_post_capacity_scope_resolved"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .final_scope.new_file_count == 10
  and .final_scope.modified_file_count == 11
  and .final_scope.total_patch_file_count == 21
  and .scope_complete == true
' "$PRIOR_SCOPE_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "noise_operator_amendment_sha256=$EXPECTED_AMENDMENT_003_SHA"
echo "prior_21_file_scope_authoritative=false"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Baseline regression gate ==="

"$PYTHON" -m py_compile \
  "$VALIDATOR" \
  "$VALIDATOR_TEST" \
  "$CKG_SOURCE"

"$PYTHON" -m pytest \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  "$VALIDATOR_TEST" \
  -q \
  -p no:cacheprovider

echo "baseline_regression_gate=PASS"

echo
echo "=== 3. Run detached validator and evaluator feasibility probe ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export AMENDMENT_003
export PRIOR_SCOPE_REPORT
export VALIDATOR
export VALIDATOR_TEST
export WORKLOAD_SCHEMA
export CKG_SOURCE
export PROPOSED_OPERATOR_MODULE
export PROPOSED_OPERATOR_TEST
export TMP_ROOT
export REPORT
export SURFACE

"$PYTHON" - <<'PY'
from __future__ import annotations

import ast
import copy
import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any

import yaml

from backend.ckg.ckg_updater import CKGGraph
from backend.harness.sensitivity_execution.validate_workload_spec import (
    SCHEMA_VERSION,
    validate_workload_spec,
)


root = Path(os.environ["ROOT"]).resolve()
source_commit = os.environ["EXPECTED_HEAD"]

amendment_path = root / os.environ["AMENDMENT_003"]

prior_scope_path = Path(
    os.environ["PRIOR_SCOPE_REPORT"]
).resolve()

validator_path = root / os.environ["VALIDATOR"]
validator_test_path = root / os.environ["VALIDATOR_TEST"]
schema_path = root / os.environ["WORKLOAD_SCHEMA"]
ckg_path = root / os.environ["CKG_SOURCE"]

proposed_operator_module = os.environ[
    "PROPOSED_OPERATOR_MODULE"
]

proposed_operator_test = os.environ[
    "PROPOSED_OPERATOR_TEST"
]

tmp_root = Path(os.environ["TMP_ROOT"])
report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(value, dict):
        raise AssertionError(
            f"JSON root is not an object: {path}"
        )

    return value


amendment = load_json(amendment_path)
prior_scope = load_json(prior_scope_path)
schema = load_json(schema_path)

operator_contract = amendment[
    "noise_operator_contract"
]

operator_definitions = operator_contract[
    "operator_definitions"
]

noise_classes = operator_contract[
    "noise_class_order"
]

registry_version = operator_contract[
    "operator_registry_version"
]

assert noise_classes == [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

assert set(operator_definitions) == set(
    noise_classes
)

assert registry_version == (
    "mcad-sa5-objective-count-"
    "noise-operators-v1"
)


# --------------------------------------------------------------
# JSON-schema structural compatibility
# --------------------------------------------------------------

query_schema = (
    schema["properties"]["steps"]["items"]
    ["properties"]["query_spec"]
)

cube_schema = query_schema[
    "properties"
]["cube"]

window_start_schema = query_schema[
    "properties"
]["window_start"]

window_end_schema = query_schema[
    "properties"
]["window_end"]

schema_allows_extension_fields = (
    query_schema.get(
        "additionalProperties"
    )
    is True
)

schema_cube_allows_empty_string = (
    cube_schema.get("type") == "string"
    and "minLength" not in cube_schema
    and "pattern" not in cube_schema
)

schema_has_no_window_order_constraint = (
    window_start_schema.get("type")
    == "string"
    and window_end_schema.get("type")
    == "string"
)

assert schema_allows_extension_fields
assert schema_cube_allows_empty_string
assert schema_has_no_window_order_constraint


# --------------------------------------------------------------
# Canonical base query and exact operators
# --------------------------------------------------------------

semantic_fields = amendment[
    "canonical_support_query_contract"
]["semantic_projection_fields"]

assert semantic_fields == [
    "cube",
    "measures",
    "group_by",
    "slicers",
    "aggregators",
    "units",
    "window_start",
    "window_end",
    "time_members",
]

base_query: dict[str, Any] = {
    "cube": "SyntheticFact",
    "measures": ["Sales"],
    "group_by": [
        "Time.Month",
        "Geography.Region",
    ],
    "slicers": {
        "Geography.Region": "Region_01",
        "Time.Year": "2001",
    },
    "aggregators": ["SUM"],
    "units": ["USD"],
    "window_start": "2001-01-01",
    "window_end": "2001-12-31",
    "time_members": [],
}


def apply_operator(
    noise_class: str,
    source_query: dict[str, Any],
) -> dict[str, Any]:
    query = copy.deepcopy(source_query)

    definition = operator_definitions[
        noise_class
    ]

    mutation = definition[
        "mutation"
    ]

    operation = mutation[
        "operation"
    ]

    if operation == "replace":
        query[
            mutation["field"]
        ] = copy.deepcopy(
            mutation["value"]
        )

    elif operation == "replace_mapping_value":
        field = mutation["field"]

        mapping = dict(
            query.get(field) or {}
        )

        mapping[
            mutation["key"]
        ] = mutation["value"]

        query[field] = mapping

    elif operation == "swap_window_boundaries":
        first, second = mutation[
            "field_pair"
        ]

        query[first], query[second] = (
            query[second],
            query[first],
        )

    elif operation == "exact_semantic_projection_replay":
        query = {
            field: copy.deepcopy(
                source_query.get(field)
            )
            for field in mutation[
                "semantic_projection_fields"
            ]
        }

    else:
        raise AssertionError(
            f"Unsupported operator: {operation}"
        )

    query["mcad_controlled_noise"] = {
        "noise_class": noise_class,
        "operator_registry_version": (
            registry_version
        ),
    }

    return query


operator_queries = {
    noise_class: apply_operator(
        noise_class,
        base_query,
    )
    for noise_class in noise_classes
}


# --------------------------------------------------------------
# Current generic workload-validator behavior
# --------------------------------------------------------------

def workload_for_query(
    noise_class: str,
    query_spec: dict[str, Any],
) -> dict[str, Any]:
    return {
        "contract_version": SCHEMA_VERSION,
        "workload_id": (
            "sa5-noise-validator-probe-"
            f"{noise_class}"
        ),
        "objective_id": (
            "O_SA5_NOISE_VALIDATOR_PROBE"
        ),
        "session_id": (
            "S_SA5_NOISE_VALIDATOR_PROBE_"
            f"{noise_class}"
        ),
        "steps": [
            {
                "step_index": 1,
                "step_id": (
                    "step-0001-"
                    f"{noise_class}"
                ),
                "query_spec": (
                    copy.deepcopy(
                        query_spec
                    )
                ),
            }
        ],
    }


validator_results: dict[
    str,
    dict[str, Any],
] = {}

for noise_class, query_spec in (
    operator_queries.items()
):
    try:
        validate_workload_spec(
            workload_for_query(
                noise_class,
                query_spec,
            )
        )

    except AssertionError as exc:
        validator_results[
            noise_class
        ] = {
            "accepted": False,
            "error": str(exc),
        }

    else:
        validator_results[
            noise_class
        ] = {
            "accepted": True,
            "error": None,
        }


validator_rejected_classes = sorted(
    noise_class
    for noise_class, result
    in validator_results.items()
    if not result["accepted"]
)

validator_accepted_classes = sorted(
    noise_class
    for noise_class, result
    in validator_results.items()
    if result["accepted"]
)

assert validator_rejected_classes == [
    "invalid_time_window",
    "missing_cube",
]

assert (
    "window_start must not be after window_end"
    in validator_results[
        "invalid_time_window"
    ]["error"]
)

assert (
    "cube must be a non-empty string"
    in validator_results[
        "missing_cube"
    ]["error"]
)

assert validator_accepted_classes == [
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "redundant_contribution",
    "wrong_context",
    "wrong_measure",
]


# --------------------------------------------------------------
# Detached evaluator-feasibility proof
# --------------------------------------------------------------

objective_id = (
    "O_SA5_NOISE_OPERATOR_"
    "FEASIBILITY_PROBE"
)

constraint_id = (
    f"{objective_id}_C0001"
)

virtual_nodes: list[dict[str, Any]] = []

for index in range(4):
    year = 2001 + index

    virtual_nodes.append(
        {
            "id": (
                f"{constraint_id}_NV"
                f"{index + 1:04d}"
            ),
            "fact": "SyntheticFact",
            "grain": [
                "Time.Month",
                "Geography.Region",
            ],
            "measure": "Sales",
            "aggregator": "SUM",
            "unit": "USD",
            "slicers": {
                "Geography.Region": (
                    f"Region_{index + 1:02d}"
                ),
                "Time.Year": str(year),
            },
            "window_start": (
                f"{year}-01-01"
            ),
            "window_end": (
                f"{year}-12-31"
            ),
        }
    )

target_resource_id = virtual_nodes[0]["id"]

objective_document = {
    "objectives": [
        {
            "id": objective_id,
            "name": objective_id,
            "description": (
                "Detached SA5 noise-operator "
                "feasibility probe"
            ),
            "session_support_policy": (
                "union_requirement_sets"
            ),
            "kpis": [
                f"{objective_id}_KPI0001"
            ],
            "constraints": [
                {
                    "id": constraint_id,
                    "kpi_id": (
                        f"{objective_id}_KPI0001"
                    ),
                    "description": (
                        "Detached probe constraint"
                    ),
                    "weight": 1.0,
                    "requirement_sets": [
                        [target_resource_id]
                    ],
                    "virtual_nodes": (
                        virtual_nodes
                    ),
                }
            ],
        }
    ]
}

objective_path = (
    tmp_root / "objectives.yaml"
)

objective_path.write_text(
    yaml.safe_dump(
        objective_document,
        sort_keys=False,
        allow_unicode=True,
    ),
    encoding="utf-8",
)

ckg = CKGGraph(
    output_dir=str(
        tmp_root / "runtime"
    )
)

for attribute_name in (
    "G",
    "objectives",
    "history",
    "session_coverage",
    "session_weighted_coverage",
    "session_resource_coverage",
):
    getattr(
        ckg,
        attribute_name,
    ).clear()

ckg.bootstrap_objectives(
    str(objective_path)
)


def evaluate(
    session_id: str,
    step_index: int,
    query_spec: dict[str, Any],
) -> dict[str, Any]:
    return ckg.evaluate_step(
        session_id,
        objective_id,
        step_index,
        {
            "objective_id": objective_id,
            "query_spec": copy.deepcopy(
                query_spec
            ),
        },
    )


base_result = evaluate(
    "S_SA5_BASE_PROBE",
    1,
    base_query,
)

assert base_result["sat"] is True
assert base_result[
    "real_node_ids"
] == [target_resource_id]
assert base_result[
    "gained_resource_ids"
] == [target_resource_id]
assert base_result[
    "is_session_contributive"
] is True


non_redundant_results: dict[
    str,
    dict[str, Any],
] = {}

for noise_class in noise_classes:
    if noise_class == (
        "redundant_contribution"
    ):
        continue

    result = evaluate(
        (
            "S_SA5_NOISE_PROBE_"
            f"{noise_class}"
        ),
        1,
        operator_queries[
            noise_class
        ],
    )

    assert result["sat"] is False
    assert result["real_node_ids"] == []

    non_redundant_results[
        noise_class
    ] = {
        "sat": result["sat"],
        "real_node_ids": (
            result["real_node_ids"]
        ),
        "failed_clause_names": [
            clause["name"]
            for clause in result[
                "clauses"
            ]
            if not clause["ok"]
        ],
    }


redundant_session = (
    "S_SA5_REDUNDANT_PROBE"
)

redundant_source_result = evaluate(
    redundant_session,
    1,
    base_query,
)

redundant_result = evaluate(
    redundant_session,
    2,
    operator_queries[
        "redundant_contribution"
    ],
)

assert redundant_source_result[
    "is_session_contributive"
] is True

assert redundant_result["sat"] is True

assert redundant_result[
    "real_node_ids"
] == [target_resource_id]

assert redundant_result[
    "gained_resource_ids"
] == []

assert redundant_result[
    "is_session_contributive"
] is False


operator_oracle_mismatch_count = 0

for noise_class, result in (
    non_redundant_results.items()
):
    definition = operator_definitions[
        noise_class
    ]

    if (
        result["sat"]
        != definition["expected_sat"]
    ):
        operator_oracle_mismatch_count += 1

    if (
        len(result["real_node_ids"])
        != definition[
            "expected_real_node_count"
        ]
    ):
        operator_oracle_mismatch_count += 1

redundant_definition = operator_definitions[
    "redundant_contribution"
]

if (
    redundant_result["sat"]
    != redundant_definition[
        "expected_sat"
    ]
):
    operator_oracle_mismatch_count += 1

if (
    len(
        redundant_result[
            "real_node_ids"
        ]
    )
    != redundant_definition[
        "expected_real_node_count"
    ]
):
    operator_oracle_mismatch_count += 1

if (
    len(
        redundant_result[
            "gained_resource_ids"
        ]
    )
    != redundant_definition[
        "expected_gained_resource_count"
    ]
):
    operator_oracle_mismatch_count += 1

if (
    redundant_result[
        "is_session_contributive"
    ]
    != redundant_definition[
        "expected_oracle_contributive"
    ]
):
    operator_oracle_mismatch_count += 1

assert operator_oracle_mismatch_count == 0


# --------------------------------------------------------------
# Source-owner and scope closure
# --------------------------------------------------------------

validator_text = validator_path.read_text(
    encoding="utf-8"
)

validator_test_text = (
    validator_test_path.read_text(
        encoding="utf-8"
    )
)

assert (
    "require_non_empty_string("
    in validator_text
)

assert (
    "query_spec.get(\"cube\")"
    in validator_text
)

assert (
    "window_start must not be after window_end"
    in validator_text
)

assert (
    "def test_rejects_reversed_window"
    in validator_test_text
)


tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]

validator_definition_owners: list[
    dict[str, Any]
] = []

for relative in tracked_files:
    path = root / relative

    if path.suffix != ".py":
        continue

    try:
        text = path.read_text(
            encoding="utf-8"
        )

        tree = ast.parse(
            text,
            filename=str(path),
        )

    except (
        OSError,
        UnicodeDecodeError,
        SyntaxError,
    ):
        continue

    for node in ast.walk(tree):
        if not isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            continue

        if node.name not in {
            "validate_query_spec",
            "validate_workload_spec",
        }:
            continue

        validator_definition_owners.append(
            {
                "path": relative.as_posix(),
                "function": node.name,
                "line": int(node.lineno),
            }
        )

assert {
    owner["path"]
    for owner in validator_definition_owners
} == {
    "backend/harness/sensitivity_execution/"
    "validate_workload_spec.py"
}


prior_new_files = set(
    prior_scope[
        "final_scope"
    ]["new_files"]
)

prior_modified_files = set(
    prior_scope[
        "final_scope"
    ]["modified_files"]
)

assert len(prior_new_files) == 10
assert len(prior_modified_files) == 11

required_new_files = {
    proposed_operator_module,
    proposed_operator_test,
}

required_modified_files = {
    (
        "backend/harness/sensitivity_execution/"
        "validate_workload_spec.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_workload_spec.py"
    ),
}

review_only_unchanged_files = {
    (
        "backend/harness/sensitivity_execution/"
        "workload_spec.schema.json"
    ),
}

final_new_files = (
    prior_new_files
    | required_new_files
)

final_modified_files = (
    prior_modified_files
    | required_modified_files
)

assert len(final_new_files) == 12
assert len(final_modified_files) == 13

final_total_patch_file_count = (
    len(final_new_files)
    + len(final_modified_files)
)

assert final_total_patch_file_count == 25

for relative in final_new_files:
    if (root / relative).exists():
        raise AssertionError(
            "Proposed new file already exists: "
            f"{relative}"
        )


blockers: list[str] = []

if operator_oracle_mismatch_count:
    blockers.append(
        "noise_operator_evaluator_outcome_mismatch"
    )

if set(validator_rejected_classes) != {
    "invalid_time_window",
    "missing_cube",
}:
    blockers.append(
        "unexpected_workload_validator_blocker_set"
    )

if not schema_allows_extension_fields:
    blockers.append(
        "workload_schema_blocks_controlled_metadata"
    )

if not schema_cube_allows_empty_string:
    blockers.append(
        "workload_schema_blocks_missing_cube_operator"
    )

scope_complete = not blockers

if scope_complete:
    status = (
        "sa5_objective_count_v2_post_noise_"
        "operator_scope_resolved"
    )

    next_stage = (
        "author_sa5_objective_count_"
        "materialization_contract_v2_patch_"
        "with_25_file_scope"
    )

else:
    status = (
        "sa5_objective_count_v2_post_noise_"
        "operator_scope_blocked"
    )

    next_stage = (
        "resolve_sa5_objective_count_v2_"
        "post_noise_scope_blockers"
    )


report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "post-noise-operator-scope-"
        "reprojection-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "amendment_sha256": (
        sha256_file(amendment_path)
    ),
    "prior_scope": {
        "authoritative": False,
        "new_file_count": 10,
        "modified_file_count": 11,
        "total_patch_file_count": 21,
        "new_files": sorted(
            prior_new_files
        ),
        "modified_files": sorted(
            prior_modified_files
        ),
    },
    "schema_probe": {
        "path": str(
            schema_path.relative_to(root)
        ),
        "additional_query_properties_allowed": (
            schema_allows_extension_fields
        ),
        "cube_schema_allows_empty_string": (
            schema_cube_allows_empty_string
        ),
        "schema_has_no_window_order_constraint": (
            schema_has_no_window_order_constraint
        ),
        "modification_required": False,
    },
    "current_validator_probe": {
        "proposed_controlled_metadata_path": (
            "query_spec.mcad_controlled_noise"
        ),
        "accepted_classes": (
            validator_accepted_classes
        ),
        "rejected_classes": (
            validator_rejected_classes
        ),
        "results": validator_results,
        "controlled_exception_count_required": 2,
        "default_strict_behavior_must_be_preserved": True,
        "required_exception_classes": [
            "invalid_time_window",
            "missing_cube",
        ],
    },
    "evaluator_feasibility_probe": {
        "base_query_sat": (
            base_result["sat"]
        ),
        "base_query_real_node_ids": (
            base_result[
                "real_node_ids"
            ]
        ),
        "base_query_gained_resource_ids": (
            base_result[
                "gained_resource_ids"
            ]
        ),
        "base_query_is_session_contributive": (
            base_result[
                "is_session_contributive"
            ]
        ),
        "non_redundant_operator_results": (
            non_redundant_results
        ),
        "redundant_source_is_contributive": (
            redundant_source_result[
                "is_session_contributive"
            ]
        ),
        "redundant_sat": (
            redundant_result["sat"]
        ),
        "redundant_real_node_ids": (
            redundant_result[
                "real_node_ids"
            ]
        ),
        "redundant_gained_resource_ids": (
            redundant_result[
                "gained_resource_ids"
            ]
        ),
        "redundant_is_session_contributive": (
            redundant_result[
                "is_session_contributive"
            ]
        ),
        "operator_oracle_mismatch_count": (
            operator_oracle_mismatch_count
        ),
        "semantic_materializability_proven": (
            operator_oracle_mismatch_count
            == 0
        ),
    },
    "required_scope_additions": {
        "new_files": sorted(
            required_new_files
        ),
        "modified_files": sorted(
            required_modified_files
        ),
        "review_only_unchanged_files": sorted(
            review_only_unchanged_files
        ),
        "new_file_count": len(
            required_new_files
        ),
        "modified_file_count": len(
            required_modified_files
        ),
        "review_only_file_count": len(
            review_only_unchanged_files
        ),
        "rationale": {
            proposed_operator_module: [
                (
                    "implement all eight registered "
                    "noise operators"
                ),
                (
                    "construct semantic projections "
                    "and provenance digests"
                ),
                (
                    "implement deterministic target "
                    "and redundancy selection"
                ),
            ],
            proposed_operator_test: [
                (
                    "test exact one-field mutations "
                    "and redundant replay"
                ),
                (
                    "test deterministic schedules "
                    "and oracle outcomes"
                ),
            ],
            (
                "backend/harness/sensitivity_execution/"
                "validate_workload_spec.py"
            ): [
                (
                    "allow missing_cube only under "
                    "explicit controlled-noise metadata"
                ),
                (
                    "allow invalid_time_window only "
                    "under explicit controlled-noise "
                    "metadata"
                ),
                (
                    "retain strict rejection for all "
                    "ordinary workloads"
                ),
            ],
            (
                "backend/harness/sensitivity_execution/"
                "tests/test_workload_spec.py"
            ): [
                (
                    "preserve generic invalid-input "
                    "regressions"
                ),
                (
                    "test the two factor-scoped "
                    "controlled-noise exceptions"
                ),
                (
                    "reject mismatched or unknown "
                    "controlled-noise declarations"
                ),
            ],
        },
    },
    "final_scope": {
        "new_files": sorted(
            final_new_files
        ),
        "modified_files": sorted(
            final_modified_files
        ),
        "review_only_unchanged_files": sorted(
            review_only_unchanged_files
        ),
        "new_file_count": len(
            final_new_files
        ),
        "modified_file_count": len(
            final_modified_files
        ),
        "total_patch_file_count": (
            final_total_patch_file_count
        ),
    },
    "validator_definition_owners": (
        validator_definition_owners
    ),
    "blockers": blockers,
    "blocker_count": len(blockers),
    "scope_complete": scope_complete,
    "semantic_materializability_proven": (
        operator_oracle_mismatch_count == 0
    ),
    "preserve_v1_generator_module_bytes": True,
    "preserve_historical_workload_validation": True,
    "preserve_historical_support_behavior": True,
    "preserve_membership_density_profile": True,
    "v2_patch_authoring_authorized": (
        scope_complete
        and operator_oracle_mismatch_count == 0
    ),
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 POST-NOISE-OPERATOR SCOPE REPROJECTION",
    "=" * 96,
    f"source_commit={source_commit}",
    f"status={status}",
    "prior_21_file_scope_authoritative=false",
    "",
    "=== CURRENT VALIDATOR BLOCKERS ===",
    (
        "validator_rejected_classes="
        + json.dumps(
            validator_rejected_classes
        )
    ),
    "controlled_exception_count_required=2",
    "default_strict_behavior_must_be_preserved=true",
    "",
    "=== SCHEMA PROBE ===",
    (
        "additional_query_properties_allowed="
        f"{str(schema_allows_extension_fields).lower()}"
    ),
    (
        "cube_schema_allows_empty_string="
        f"{str(schema_cube_allows_empty_string).lower()}"
    ),
    (
        "schema_has_no_window_order_constraint="
        f"{str(schema_has_no_window_order_constraint).lower()}"
    ),
    "workload_schema_modification_required=false",
    "",
    "=== EVALUATOR FEASIBILITY ===",
    (
        "base_query_real_node_count="
        f"{len(base_result['real_node_ids'])}"
    ),
    (
        "base_query_gained_resource_count="
        f"{len(base_result['gained_resource_ids'])}"
    ),
    "non_redundant_sat_false_count=7",
    (
        "redundant_sat="
        f"{str(redundant_result['sat']).lower()}"
    ),
    (
        "redundant_real_node_count="
        f"{len(redundant_result['real_node_ids'])}"
    ),
    (
        "redundant_gained_resource_count="
        f"{len(redundant_result['gained_resource_ids'])}"
    ),
    (
        "redundant_is_session_contributive="
        f"{str(redundant_result['is_session_contributive']).lower()}"
    ),
    (
        "operator_oracle_mismatch_count="
        f"{operator_oracle_mismatch_count}"
    ),
    (
        "semantic_materializability_proven="
        f"{str(operator_oracle_mismatch_count == 0).lower()}"
    ),
    "",
    "=== REQUIRED ADDITIONAL NEW FILES ===",
    *sorted(required_new_files),
    "",
    "=== REQUIRED ADDITIONAL MODIFIED FILES ===",
    *sorted(required_modified_files),
    "",
    "=== REVIEW ONLY — UNCHANGED ===",
    *sorted(review_only_unchanged_files),
    "",
    "=== FINAL NEW FILES ===",
    *sorted(final_new_files),
    "",
    "=== FINAL MODIFIED FILES ===",
    *sorted(final_modified_files),
    "",
    "=== FINAL COUNTS ===",
    f"final_new_file_count={len(final_new_files)}",
    (
        "final_modified_file_count="
        f"{len(final_modified_files)}"
    ),
    (
        "final_total_patch_file_count="
        f"{final_total_patch_file_count}"
    ),
    f"blocker_count={len(blockers)}",
    (
        "scope_complete="
        f"{str(scope_complete).lower()}"
    ),
    (
        "v2_patch_authoring_authorized="
        f"{str(report['v2_patch_authoring_authorized']).lower()}"
    ),
    "",
    "canonical_campaign_materialization_authorized=false",
    "canonical_campaign_generated=false",
    "campaign_materialization_performed=false",
    "functional_execution_performed=false",
    "timing_execution_performed=false",
    "bootstrap_execution_performed=false",
    "scientific_execution_performed=false",
    "manuscript_modified=false",
    f"next_stage={next_stage}",
    "",
]

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("post_noise_scope_reprojection=PASS")
print(f"status={status}")
print("prior_21_file_scope_authoritative=false")
print(
    "validator_rejected_classes="
    + ",".join(
        validator_rejected_classes
    )
)
print(
    "controlled_exception_count_required=2"
)
print(
    "workload_schema_modification_required=false"
)
print(
    "operator_oracle_mismatch_count="
    f"{operator_oracle_mismatch_count}"
)
print(
    "semantic_materializability_proven="
    f"{str(operator_oracle_mismatch_count == 0).lower()}"
)
print(
    "required_additional_new_file_count="
    f"{len(required_new_files)}"
)
print(
    "required_additional_modified_file_count="
    f"{len(required_modified_files)}"
)
print(
    "final_new_file_count="
    f"{len(final_new_files)}"
)
print(
    "final_modified_file_count="
    f"{len(final_modified_files)}"
)
print(
    "final_total_patch_file_count="
    f"{final_total_patch_file_count}"
)
print(
    "blocker_count="
    f"{len(blockers)}"
)
print(
    "scope_complete="
    f"{str(scope_complete).lower()}"
)
print(
    "v2_patch_authoring_authorized="
    f"{str(report['v2_patch_authoring_authorized']).lower()}"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate final scope report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-post-noise-operator-scope-reprojection-v1"
  and .status
    == "sa5_objective_count_v2_post_noise_operator_scope_resolved"
  and .source_commit
    == "0674825017698f25562d43400ff4e72cb6484e2f"
  and .read_only == true

  and .prior_scope.authoritative == false
  and .prior_scope.new_file_count == 10
  and .prior_scope.modified_file_count == 11
  and .prior_scope.total_patch_file_count == 21

  and .schema_probe.additional_query_properties_allowed
    == true
  and .schema_probe.cube_schema_allows_empty_string
    == true
  and .schema_probe.schema_has_no_window_order_constraint
    == true
  and .schema_probe.modification_required
    == false

  and .current_validator_probe.rejected_classes
    == [
      "invalid_time_window",
      "missing_cube"
    ]
  and .current_validator_probe.controlled_exception_count_required
    == 2
  and .current_validator_probe.default_strict_behavior_must_be_preserved
    == true

  and .evaluator_feasibility_probe.base_query_sat
    == true
  and (
    .evaluator_feasibility_probe.base_query_real_node_ids
    | length
  ) == 1
  and (
    .evaluator_feasibility_probe.base_query_gained_resource_ids
    | length
  ) == 1
  and .evaluator_feasibility_probe.base_query_is_session_contributive
    == true
  and .evaluator_feasibility_probe.redundant_sat
    == true
  and (
    .evaluator_feasibility_probe.redundant_real_node_ids
    | length
  ) == 1
  and .evaluator_feasibility_probe.redundant_gained_resource_ids
    == []
  and .evaluator_feasibility_probe.redundant_is_session_contributive
    == false
  and .evaluator_feasibility_probe.operator_oracle_mismatch_count
    == 0
  and .evaluator_feasibility_probe.semantic_materializability_proven
    == true

  and .required_scope_additions.new_files
    == [
      "backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py",
      "backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py"
    ]
  and .required_scope_additions.modified_files
    == [
      "backend/harness/sensitivity_execution/tests/test_workload_spec.py",
      "backend/harness/sensitivity_execution/validate_workload_spec.py"
    ]
  and .required_scope_additions.review_only_unchanged_files
    == [
      "backend/harness/sensitivity_execution/workload_spec.schema.json"
    ]

  and .final_scope.new_file_count == 12
  and .final_scope.modified_file_count == 13
  and .final_scope.total_patch_file_count == 25

  and .blocker_count == 0
  and .scope_complete == true
  and .semantic_materializability_proven
    == true

  and .preserve_v1_generator_module_bytes
    == true
  and .preserve_historical_workload_validation
    == true
  and .preserve_historical_support_behavior
    == true
  and .preserve_membership_density_profile
    == true

  and .v2_patch_authoring_authorized
    == true
  and .canonical_campaign_materialization_authorized
    == false
  and .canonical_campaign_generated
    == false
  and .campaign_materialization_performed
    == false
  and .functional_execution_performed
    == false
  and .scientific_execution_performed
    == false
  and .manuscript_modified
    == false

  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_25_file_scope"
' "$REPORT" >/dev/null

echo "post_noise_scope_report_validation=PASS"

echo
echo "=== 5. Compact final scope ==="

jq '{
  status,
  source_commit,
  prior_scope,
  schema_probe,
  current_validator_probe,
  evaluator_feasibility_probe,
  required_scope_additions,
  final_scope,
  blocker_count,
  scope_complete,
  semantic_materializability_proven,
  v2_patch_authoring_authorized,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value reprojection surface ==="

grep -nE \
  '^(status=|prior_21|validator_rejected|controlled_exception|workload_schema|base_query|non_redundant|redundant_|operator_oracle|semantic_materializability|backend/|final_new|final_modified|final_total|blocker_count=|scope_complete=|v2_patch|next_stage=)' \
  "$SURFACE" |
  head -n 500 || true

echo
echo "=== 7. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$AMENDMENT_003" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_003_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$PROPOSED_OPERATOR_MODULE"
test ! -e "$PROPOSED_OPERATOR_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_objective_count_v2_post_noise_scope_reprojection=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo "prior_21_file_scope_authoritative=false"
echo "required_additional_new_file_count=2"
echo "required_additional_modified_file_count=2"
echo "workload_schema_modification_required=false"

echo "final_new_file_count=12"
echo "final_modified_file_count=13"
echo "final_total_patch_file_count=25"

echo "operator_oracle_mismatch_count=0"
echo "semantic_materializability_proven=true"
echo "blocker_count=0"
echo "scope_complete=true"
echo "v2_patch_authoring_authorized=true"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo "next_stage=author_sa5_objective_count_materialization_contract_v2_patch_with_25_file_scope"

git status --short --branch
