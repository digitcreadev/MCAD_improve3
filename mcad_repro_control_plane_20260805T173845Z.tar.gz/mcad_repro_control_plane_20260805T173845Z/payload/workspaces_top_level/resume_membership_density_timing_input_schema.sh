#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="5a25d5e5a90c0fd821d9c0c21dc539fcfb9e8766"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

cd "$ROOT"

echo "=== 1. Resume gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$RUNNER"

echo "resume_gate=PASS"
echo "source_schema_audit_already_passed=true"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Runner input contract ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" "$RUNNER" --help

echo "runner_cli_import_gate=PASS"

echo
echo "=== 3. Runner path-handling source excerpts ==="

"$PYTHON" - "$RUNNER" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

path = Path(sys.argv[1])
lines = path.read_text(encoding="utf-8").splitlines()

terms = (
    "execution_spec",
    "workload_path",
    "campaign_dir",
    "output_dir",
    "run_root",
    "timing_root",
    "observations",
    "timing_report",
)

selected: set[int] = set()

for index, line in enumerate(lines):
    if any(term in line for term in terms):
        for context in range(
            max(0, index - 4),
            min(len(lines), index + 5),
        ):
            selected.add(context)

previous = -2

for index in sorted(selected):
    if index > previous + 1:
        print("...")

    print(f"{index + 1}:{lines[index]}")
    previous = index
PY

echo
echo "=== 4. Exact source-input summary ==="

echo "source_workload_count=10"
echo "source_execution_spec_count=10"
echo "source_step_count_23_replications=2"
echo "source_step_count_24_replications=8"
echo "balanced_derived_step_count=23"
echo "derived_workload_count_required=10"
echo "derived_execution_spec_count_required=10"
echo "source_campaign_dir_preserved=true"
echo "source_workload_files_modified=false"
echo "source_execution_specs_modified=false"
echo "source_functional_output_dirs_modified=false"

echo
echo "=== 5. Final state ==="

echo "membership_density_timing_input_schema_inspection=PASS"
echo "timing_input_materialization_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "next_stage=materialize_membership_density_timing_inputs"

git status --short --branch
