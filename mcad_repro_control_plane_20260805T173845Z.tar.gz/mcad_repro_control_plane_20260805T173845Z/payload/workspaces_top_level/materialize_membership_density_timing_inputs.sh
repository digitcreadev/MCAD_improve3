#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="5a25d5e5a90c0fd821d9c0c21dc539fcfb9e8766"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"
PREFLIGHT="$REPORTS/planning/sa4_membership_density_timing_preregistration_preflight.json"
EXECUTION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

SOURCE_WORKLOADS="$REPORTS/workloads"
SOURCE_SPECS="$REPORTS/execution_specs"

INPUT_ROOT="$REPORTS/timing_inputs/membership_density_stage10_portfolio"
DERIVED_WORKLOADS="$INPUT_ROOT/workloads"
DERIVED_SPECS="$INPUT_ROOT/execution_specs"
INPUT_MANIFEST="$INPUT_ROOT/materialization_manifest.json"

OUTPUT_JSON="$REPORTS/planning/sa4_membership_density_timing_input_materialization.json"
OUTPUT_MD="$REPORTS/planning/sa4_membership_density_timing_input_materialization.md"

TIMING_RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Timing-input materialization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Materialization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"

for FILE in \
  "$PREREG" \
  "$PREFLIGHT" \
  "$EXECUTION_PLAN" \
  "$RUNNER"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$RUNNER" | awk '{print $1}'
)" = "$EXPECTED_RUNNER_SHA"

test ! -e "$INPUT_ROOT"
test ! -e "$OUTPUT_JSON"
test ! -e "$OUTPUT_MD"
test ! -e "$TIMING_RUN_ROOT"

jq -e '
  .status
    == "membership_density_portfolio_timing_preregistration_complete"
  and .structural_contract.stage_size == 10
  and .structural_contract.levels == [25, 50, 75, 100]
  and .semantic_support_audit.selected_local_step_indexes
      == [range(1; 24)]
  and .raw_timing_protocol.raw_timing_cell_count == 920
  and .raw_timing_protocol.measurement_observation_count == 92000
  and .scientific_controls.timing_input_materialization_authorized
      == true
  and .scientific_controls.timing_input_materialization_performed
      == false
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.precision_analysis_authorized == false
  and .next_stage == "prepare_membership_density_timing_inputs"
' "$PREREG" >/dev/null

echo "materialization_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create materialization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/materialize-membership-density-timing-inputs-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Materialize balanced timing inputs ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$PREFLIGHT" \
  "$EXECUTION_PLAN" \
  "$SOURCE_WORKLOADS" \
  "$SOURCE_SPECS" \
  "$DERIVED_WORKLOADS" \
  "$DERIVED_SPECS" \
  "$INPUT_MANIFEST" \
  "$OUTPUT_JSON" \
  "$OUTPUT_MD" \
  "$TIMING_RUN_ROOT" \
  "$RUNNER" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$EXPECTED_RUNNER_SHA" <<'PY'
from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
prereg_path = root / sys.argv[2]
preflight_path = root / sys.argv[3]
execution_plan_path = root / sys.argv[4]
source_workloads_root = root / sys.argv[5]
source_specs_root = root / sys.argv[6]
derived_workloads_root = root / sys.argv[7]
derived_specs_root = root / sys.argv[8]
input_manifest_path = root / sys.argv[9]
output_json = root / sys.argv[10]
output_md = root / sys.argv[11]
timing_run_root = root / sys.argv[12]
runner_path = root / sys.argv[13]
source_commit = sys.argv[14]
created_utc = sys.argv[15]
expected_runner_sha = sys.argv[16]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_payload(value: Any) -> str:
    encoded = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    return hashlib.sha256(encoded).hexdigest()


prereg = load_json(prereg_path)
preflight = load_json(preflight_path)
execution_plan = load_json(execution_plan_path)

if prereg.get("status") != (
    "membership_density_portfolio_"
    "timing_preregistration_complete"
):
    raise SystemExit("Formal timing preregistration is incomplete.")

controls = prereg.get("scientific_controls", {})

if controls.get(
    "timing_input_materialization_authorized"
) is not True:
    raise SystemExit("Timing-input materialization is not authorized.")

if controls.get("timing_execution_authorized") is not False:
    raise SystemExit("Timing execution is unexpectedly authorized.")

if controls.get("precision_analysis_authorized") is not False:
    raise SystemExit("Precision analysis is unexpectedly authorized.")

if sha256_file(runner_path) != expected_runner_sha:
    raise SystemExit("Timing-runner SHA-256 mismatch.")

expected_levels = [25, 50, 75, 100]
expected_steps = list(range(1, 24))
expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

if (
    prereg.get("structural_contract", {}).get("levels")
    != expected_levels
):
    raise SystemExit("Unexpected density-level contract.")

if (
    prereg.get("structural_contract", {}).get("seeds")
    != expected_seeds
):
    raise SystemExit("Unexpected structural-seed contract.")

if (
    prereg.get("semantic_support_audit", {})
    .get("selected_local_step_indexes")
    != expected_steps
):
    raise SystemExit("Expected selected local positions 1..23.")

preflight_replications = preflight.get("replications")

if not isinstance(preflight_replications, list):
    raise SystemExit("Preflight replication records are absent.")

preflight_by_replication = {
    int(item["replication_index"]): item
    for item in preflight_replications
}

if sorted(preflight_by_replication) != list(range(10)):
    raise SystemExit("Preflight replication matrix is incomplete.")

partitions = execution_plan.get("partitions")

if not isinstance(partitions, list):
    raise SystemExit("Replication execution plan lacks partitions.")

partition_by_replication = {
    int(item["replication_index"]): item
    for item in partitions
}

if sorted(partition_by_replication) != list(range(10)):
    raise SystemExit("Execution-plan replication matrix is incomplete.")

source_hashes_before: dict[str, str] = {}
records: list[dict[str, Any]] = []

total_source_steps = 0
total_derived_steps = 0
total_excluded_steps = 0
total_instance_count = 0

for replication in range(10):
    source_workload_path = (
        source_workloads_root
        / f"membership_density_rep_{replication:03d}_canonical.json"
    )

    source_spec_path = (
        source_specs_root
        / f"membership_density_rep_{replication:03d}_canonical.json"
    )

    if not source_workload_path.is_file():
        raise SystemExit(
            f"Missing source workload: {source_workload_path}"
        )

    if not source_spec_path.is_file():
        raise SystemExit(
            f"Missing source execution spec: {source_spec_path}"
        )

    source_workload_sha = sha256_file(source_workload_path)
    source_spec_sha = sha256_file(source_spec_path)

    source_hashes_before[str(source_workload_path)] = (
        source_workload_sha
    )

    source_hashes_before[str(source_spec_path)] = (
        source_spec_sha
    )

    preflight_record = preflight_by_replication[replication]

    if (
        preflight_record.get("functional_workload_sha256")
        != source_workload_sha
    ):
        raise SystemExit(
            f"Replication {replication}: source workload "
            "differs from preflight."
        )

    if (
        preflight_record.get(
            "functional_execution_spec_sha256"
        )
        != source_spec_sha
    ):
        raise SystemExit(
            f"Replication {replication}: source spec "
            "differs from preflight."
        )

    source_workload = load_json(source_workload_path)
    source_spec = load_json(source_spec_path)

    source_steps = source_workload.get("steps")

    if not isinstance(source_steps, list):
        raise SystemExit(
            f"Replication {replication}: workload lacks steps."
        )

    source_step_count = len(source_steps)

    if source_step_count not in (23, 24):
        raise SystemExit(
            f"Replication {replication}: unexpected source "
            f"step count {source_step_count}."
        )

    source_indexes = [
        int(step["step_index"])
        for step in source_steps
    ]

    if source_indexes != list(
        range(1, source_step_count + 1)
    ):
        raise SystemExit(
            f"Replication {replication}: non-contiguous "
            "source step indexes."
        )

    selected_steps = copy.deepcopy(source_steps[:23])

    selected_indexes = [
        int(step["step_index"])
        for step in selected_steps
    ]

    if selected_indexes != expected_steps:
        raise SystemExit(
            f"Replication {replication}: selected step "
            "indexes differ from 1..23."
        )

    selected_step_ids = [
        str(step.get("step_id"))
        for step in selected_steps
    ]

    expected_step_ids = [
        f"Q{index:03d}"
        for index in expected_steps
    ]

    if selected_step_ids != expected_step_ids:
        raise SystemExit(
            f"Replication {replication}: selected step IDs "
            "differ from Q001..Q023."
        )

    partition = partition_by_replication[replication]
    equivalence = partition.get("equivalence_metadata")

    if not isinstance(equivalence, list):
        raise SystemExit(
            f"Replication {replication}: equivalence "
            "metadata is absent."
        )

    equivalence_by_step = {
        int(item["step_index"]): item
        for item in equivalence
    }

    if not all(
        step_index in equivalence_by_step
        for step_index in expected_steps
    ):
        raise SystemExit(
            f"Replication {replication}: incomplete query "
            "digest mapping."
        )

    selected_query_digests = [
        {
            "step_index": step_index,
            "step_id": str(
                equivalence_by_step[step_index]["step_id"]
            ),
            "query_spec_digest": str(
                equivalence_by_step[
                    step_index
                ]["query_spec_digest"]
            ),
        }
        for step_index in expected_steps
    ]

    canonical_instance_ids = partition.get(
        "canonical_instance_ids"
    )

    if (
        not isinstance(canonical_instance_ids, list)
        or len(canonical_instance_ids) != 4
    ):
        raise SystemExit(
            f"Replication {replication}: expected four "
            "canonical instances."
        )

    derived_workload = copy.deepcopy(source_workload)

    derived_workload["workload_id"] = (
        "e3-membership-density-"
        f"rep_{replication:03d}-"
        "portfolio-timing-stage10-v1"
    )

    derived_workload["steps"] = selected_steps

    derived_workload_path = (
        derived_workloads_root
        / f"membership_density_rep_{replication:03d}_"
          "portfolio_timing_stage10.json"
    )

    derived_spec_path = (
        derived_specs_root
        / f"membership_density_rep_{replication:03d}_"
          "portfolio_timing_stage10.json"
    )

    timing_output_dir = (
        timing_run_root
        / f"membership_density_rep_{replication:03d}_"
          "portfolio_timing_stage10"
    )

    derived_spec = copy.deepcopy(source_spec)

    derived_spec["execution_id"] = (
        "e3-membership-density-"
        f"rep_{replication:03d}-"
        "portfolio-timing-stage10-v1"
    )

    derived_spec["workload_path"] = str(
        derived_workload_path.resolve()
    )

    derived_spec["output_dir"] = str(
        timing_output_dir.resolve()
    )

    source_workload_invariant = {
        key: value
        for key, value in source_workload.items()
        if key not in {"workload_id", "steps"}
    }

    derived_workload_invariant = {
        key: value
        for key, value in derived_workload.items()
        if key not in {"workload_id", "steps"}
    }

    if (
        source_workload_invariant
        != derived_workload_invariant
    ):
        raise SystemExit(
            f"Replication {replication}: unauthorized "
            "workload-field modification."
        )

    source_spec_invariant = {
        key: value
        for key, value in source_spec.items()
        if key not in {
            "execution_id",
            "workload_path",
            "output_dir",
        }
    }

    derived_spec_invariant = {
        key: value
        for key, value in derived_spec.items()
        if key not in {
            "execution_id",
            "workload_path",
            "output_dir",
        }
    }

    if source_spec_invariant != derived_spec_invariant:
        raise SystemExit(
            f"Replication {replication}: unauthorized "
            "execution-spec modification."
        )

    write_json(derived_workload_path, derived_workload)
    write_json(derived_spec_path, derived_spec)

    reloaded_workload = load_json(derived_workload_path)
    reloaded_spec = load_json(derived_spec_path)

    if reloaded_workload != derived_workload:
        raise SystemExit(
            f"Replication {replication}: derived workload "
            "round-trip mismatch."
        )

    if reloaded_spec != derived_spec:
        raise SystemExit(
            f"Replication {replication}: derived spec "
            "round-trip mismatch."
        )

    if Path(
        reloaded_spec["workload_path"]
    ).resolve() != derived_workload_path.resolve():
        raise SystemExit(
            f"Replication {replication}: derived spec "
            "references another workload."
        )

    if Path(
        reloaded_spec["campaign_dir"]
    ).resolve() != Path(
        source_spec["campaign_dir"]
    ).resolve():
        raise SystemExit(
            f"Replication {replication}: campaign path changed."
        )

    excluded_indexes = source_indexes[23:]

    record = {
        "replication_index": replication,
        "structural_seed": expected_seeds[replication],
        "density_levels": expected_levels,
        "canonical_instance_ids": canonical_instance_ids,
        "canonical_instance_count": 4,
        "source_workload": {
            "path": (
                source_workload_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": source_workload_sha,
            "step_count": source_step_count,
        },
        "source_execution_spec": {
            "path": (
                source_spec_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": source_spec_sha,
            "output_dir": source_spec["output_dir"],
        },
        "derived_workload": {
            "path": (
                derived_workload_path
                .relative_to(root)
                .as_posix()
            ),
            "absolute_path": str(
                derived_workload_path.resolve()
            ),
            "sha256": sha256_file(
                derived_workload_path
            ),
            "workload_id": (
                derived_workload["workload_id"]
            ),
            "step_count": 23,
        },
        "derived_execution_spec": {
            "path": (
                derived_spec_path
                .relative_to(root)
                .as_posix()
            ),
            "absolute_path": str(
                derived_spec_path.resolve()
            ),
            "sha256": sha256_file(
                derived_spec_path
            ),
            "execution_id": (
                derived_spec["execution_id"]
            ),
            "campaign_dir": (
                derived_spec["campaign_dir"]
            ),
            "workload_path": (
                derived_spec["workload_path"]
            ),
            "timing_output_dir": (
                derived_spec["output_dir"]
            ),
        },
        "selected_step_indexes": expected_steps,
        "selected_query_digests": (
            selected_query_digests
        ),
        "excluded_step_indexes": excluded_indexes,
        "instance_selection_sha256": sha256_payload(
            source_spec.get("instance_selection")
        ),
        "future_timing_parameters": {
            "warmups": 10,
            "measurements": 100,
            "order_seed": 20260728 + replication,
            "reuse_successful": True,
        },
    }

    records.append(record)

    total_source_steps += source_step_count
    total_derived_steps += 23
    total_excluded_steps += len(excluded_indexes)
    total_instance_count += 4

if total_source_steps != 238:
    raise SystemExit(
        f"Expected 238 source workload steps, got "
        f"{total_source_steps}."
    )

if total_derived_steps != 230:
    raise SystemExit(
        f"Expected 230 derived workload steps, got "
        f"{total_derived_steps}."
    )

if total_excluded_steps != 8:
    raise SystemExit(
        f"Expected eight excluded step occurrences, got "
        f"{total_excluded_steps}."
    )

if total_instance_count != 40:
    raise SystemExit(
        f"Expected forty selected instances, got "
        f"{total_instance_count}."
    )

source_hashes_after = {
    path: sha256_file(Path(path))
    for path in source_hashes_before
}

if source_hashes_before != source_hashes_after:
    raise SystemExit(
        "Immutable functional source files changed during "
        "timing-input materialization."
    )

if timing_run_root.exists():
    raise SystemExit(
        "Timing run root must not be created during "
        "input materialization."
    )

manifest = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "timing-input-materialization-manifest-v1"
    ),
    "status": (
        "membership_density_timing_inputs_"
        "materialized"
    ),
    "created_utc": created_utc,
    "source_commit": source_commit,
    "campaign_id": (
        "membership_density_stage10_c4_nv24"
    ),
    "factor": "membership_density",
    "input_contract": {
        "replication_count": 10,
        "density_levels": expected_levels,
        "density_level_count": 4,
        "selected_step_indexes": expected_steps,
        "selected_step_count_per_replication": 23,
        "derived_workload_count": 10,
        "derived_execution_spec_count": 10,
        "selected_instance_count": 40,
        "raw_timing_cell_count": 920,
        "warmups_per_raw_cell": 10,
        "measurements_per_raw_cell": 100,
        "warmup_observation_count": 9200,
        "measurement_observation_count": 92000,
    },
    "source_balance": {
        "source_workload_step_count": 238,
        "derived_workload_step_count": 230,
        "excluded_step_occurrence_count": 8,
        "source_step_count_histogram": {
            "23": 2,
            "24": 8,
        },
    },
    "implementation_identity": {
        "timing_runner": (
            runner_path.relative_to(root).as_posix()
        ),
        "timing_runner_sha256": expected_runner_sha,
    },
    "source_artifacts": {
        "formal_preregistration": {
            "path": (
                prereg_path.relative_to(root).as_posix()
            ),
            "sha256": sha256_file(prereg_path),
        },
        "timing_preflight": {
            "path": (
                preflight_path.relative_to(root).as_posix()
            ),
            "sha256": sha256_file(preflight_path),
        },
        "replication_execution_plan": {
            "path": (
                execution_plan_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                execution_plan_path
            ),
        },
    },
    "replications": records,
    "immutability_controls": {
        "source_workload_files_modified": False,
        "source_execution_specs_modified": False,
        "source_functional_output_dirs_modified": False,
        "source_hashes_verified_before_and_after": True,
        "timing_run_directories_created": False,
    },
    "scientific_controls": {
        "timing_input_materialization_authorized": True,
        "timing_input_materialization_performed": True,
        "functional_execution_rerun_performed": False,
        "timing_execution_authorized": False,
        "timing_execution_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "materialization_decision": {
        "derived_inputs_complete": True,
        "derived_inputs_auditable": True,
        "timing_execution_ready_for_authorization": True,
        "timing_execution_authorized": False,
    },
    "next_stage": (
        "audit_and_authorize_"
        "membership_density_timing_execution"
    ),
}

write_json(input_manifest_path, manifest)

report = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "timing-input-materialization-report-v1"
    ),
    "status": (
        "membership_density_timing_input_"
        "materialization_complete"
    ),
    "created_utc": created_utc,
    "source_commit": source_commit,
    "manifest_path": (
        input_manifest_path.relative_to(root).as_posix()
    ),
    "manifest_sha256": sha256_file(
        input_manifest_path
    ),
    "derived_workload_count": 10,
    "derived_execution_spec_count": 10,
    "selected_step_count_per_replication": 23,
    "selected_instance_count": 40,
    "raw_timing_cell_count": 920,
    "warmup_observation_count": 9200,
    "measurement_observation_count": 92000,
    "excluded_step_occurrence_count": 8,
    "source_files_modified": False,
    "timing_run_directories_created": False,
    "timing_execution_authorized": False,
    "timing_execution_performed": False,
    "precision_analysis_authorized": False,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "next_stage": (
        "audit_and_authorize_"
        "membership_density_timing_execution"
    ),
}

write_json(output_json, report)

output_md.write_text(
    "\n".join([
        "# SA4 membership-density timing-input materialization",
        "",
        "- Status: `PASS`",
        "- Derived workloads: `10`",
        "- Derived execution specs: `10`",
        "- Selected steps per workload: `23`",
        "- Selected canonical instances: `40`",
        "- Raw timing cells: `920`",
        "- Planned warmup observations: `9,200`",
        "- Planned measurements: `92,000`",
        "- Excluded workload-step occurrences: `8`",
        "- Functional source files modified: `false`",
        "- Timing directories created: `false`",
        "- Timing execution authorized: `false`",
        "",
        "## Materialization rule",
        "",
        (
            "Each derived workload preserves its canonical "
            "payload while retaining local positions "
            "`Q001..Q023` only."
        ),
        "",
        (
            "Each derived execution specification preserves "
            "the original campaign and instance selection, "
            "but references the new balanced workload and a "
            "dedicated future timing-output directory."
        ),
        "",
        "## Next stage",
        "",
        (
            "`audit_and_authorize_"
            "membership_density_timing_execution`"
        ),
        "",
    ]),
    encoding="utf-8",
)

print(
    "membership_density_timing_input_"
    "materialization=PASS"
)
print("derived_workload_count=10")
print("derived_execution_spec_count=10")
print("source_workload_step_count=238")
print("derived_workload_step_count=230")
print("excluded_step_occurrence_count=8")
print("selected_instance_count=40")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print("source_files_modified=false")
print("timing_run_directories_created=false")
print("timing_execution_authorized=false")
print("timing_execution_performed=false")
print("precision_analysis_performed=false")
print(
    "next_stage="
    "audit_and_authorize_"
    "membership_density_timing_execution"
)
PY

echo
echo "=== 4. Validate materialized inputs ==="

test "$(
  find "$DERIVED_WORKLOADS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

test "$(
  find "$DERIVED_SPECS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

test -f "$INPUT_MANIFEST"
test -f "$OUTPUT_JSON"
test -f "$OUTPUT_MD"
test ! -e "$TIMING_RUN_ROOT"

jq -e '
  .status
    == "membership_density_timing_inputs_materialized"
  and .input_contract.derived_workload_count == 10
  and .input_contract.derived_execution_spec_count == 10
  and .input_contract.selected_step_count_per_replication == 23
  and .input_contract.selected_instance_count == 40
  and .input_contract.raw_timing_cell_count == 920
  and .input_contract.warmup_observation_count == 9200
  and .input_contract.measurement_observation_count == 92000
  and .source_balance.source_workload_step_count == 238
  and .source_balance.derived_workload_step_count == 230
  and .source_balance.excluded_step_occurrence_count == 8
  and .immutability_controls.source_workload_files_modified == false
  and .immutability_controls.source_execution_specs_modified == false
  and .immutability_controls.source_functional_output_dirs_modified
      == false
  and .immutability_controls.timing_run_directories_created == false
  and .scientific_controls.timing_input_materialization_performed
      == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .materialization_decision.derived_inputs_complete == true
  and .materialization_decision.derived_inputs_auditable == true
  and .materialization_decision.timing_execution_ready_for_authorization
      == true
  and .materialization_decision.timing_execution_authorized == false
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$INPUT_MANIFEST" >/dev/null

jq -e '
  .status
    == "membership_density_timing_input_materialization_complete"
  and .derived_workload_count == 10
  and .derived_execution_spec_count == 10
  and .selected_step_count_per_replication == 23
  and .raw_timing_cell_count == 920
  and .measurement_observation_count == 92000
  and .source_files_modified == false
  and .timing_run_directories_created == false
  and .timing_execution_authorized == false
  and .timing_execution_performed == false
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$OUTPUT_JSON" >/dev/null

echo "timing_input_materialization_validation=PASS"

echo
echo "=== 5. Commit materialized inputs ==="

git add -f \
  "$INPUT_ROOT" \
  "$OUTPUT_JSON" \
  "$OUTPUT_MD"

git diff --cached --check
git diff --cached --stat

EXPECTED_FILE_COUNT=23

ACTUAL_FILE_COUNT="$(
  git diff --cached --name-only | wc -l
)"

test "$ACTUAL_FILE_COUNT" -eq "$EXPECTED_FILE_COUNT"

git commit \
  -m "chore(experiments): materialize membership-density timing inputs"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 6. Push branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

MANIFEST_SHA="$(
  sha256sum "$INPUT_MANIFEST" | awk '{print $1}'
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Materialize membership-density timing inputs" \
    --body "$(cat <<EOF
## Scope

- creates ten balanced timing-only workloads;
- creates ten timing-only execution specifications;
- retains local positions \`Q001..Q023\`;
- preserves campaign and instance-selection semantics;
- creates no timing run directories;
- performs no functional or timing execution.

## Materialized dimensions

- workloads: \`10\`;
- execution specs: \`10\`;
- canonical instances: \`40\`;
- raw timing cells: \`920\`;
- planned warmups: \`9,200\`;
- planned measurements: \`92,000\`;
- excluded step occurrences: \`8\`.

## Integrity

- source workload modifications: \`false\`;
- source execution-spec modifications: \`false\`;
- timing execution authorized: \`false\`;
- timing execution performed: \`false\`;
- precision analysis performed: \`false\`;
- materialization manifest SHA-256: \`$MANIFEST_SHA\`.

## Next stage

\`audit_and_authorize_membership_density_timing_execution\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

echo "membership_density_timing_input_materialization=PASS"
echo "commit=$COMMIT"
echo "materialization_manifest_sha256=$MANIFEST_SHA"
echo "derived_workload_count=10"
echo "derived_execution_spec_count=10"
echo "raw_timing_cell_count=920"
echo "measurement_observation_count=92000"
echo "source_files_modified=false"
echo "timing_run_directories_created=false"
echo "timing_execution_authorized=false"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_timing_inputs"

git status --short --branch
git log --oneline --decorate -4
