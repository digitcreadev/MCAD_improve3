#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=10

BASE="paper/phase3-controlled-execution"
BRANCH="paper/authorize-virtual-node-count-stage10-timing-20260802T151549Z"
EXPECTED_HEAD="c4b504e6c8163fd72db5ee722dab888b6817a359"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"

trap 'echo "[ERROR] Merge script stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$AUTH"

echo "branch=$BRANCH"
echo "head=$EXPECTED_HEAD"
echo "local_gate=PASS"
echo "tests_rerun=false"
echo "functional_execution_rerun=false"
echo "timing_execution=false"

echo
echo "=== 2. Wait for PR head propagation ==="

PR_HEAD=""

for ATTEMPT in $(seq 1 60); do
  PR_HEAD="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json headRefOid \
      --jq '.headRefOid'
  )"

  echo "head_poll_attempt=$ATTEMPT pr_head=$PR_HEAD"

  if [ "$PR_HEAD" = "$EXPECTED_HEAD" ]; then
    break
  fi

  sleep 5
done

test "$PR_HEAD" = "$EXPECTED_HEAD"

echo "pr_head_propagation=PASS"

echo
echo "=== 3. Discover CI run for authorization commit ==="

RUN_ID=""

for ATTEMPT in $(seq 1 60); do
  RUNS="$(
    gh run list \
      --repo "$REPO" \
      --branch "$BRANCH" \
      --event pull_request \
      --limit 20 \
      --json databaseId,headSha,name,status,conclusion,url
  )"

  RUN_ID="$(
    jq -r \
      --arg sha "$EXPECTED_HEAD" \
      '
      [
        .[]
        | select(
            .headSha == $sha
            and .name == "Phase 3 regression"
          )
      ]
      | first
      | .databaseId // ""
      ' <<<"$RUNS"
  )"

  echo "ci_discovery_attempt=$ATTEMPT run_id=$RUN_ID"

  if [ -n "$RUN_ID" ]; then
    break
  fi

  sleep 5
done

test -n "$RUN_ID"

echo "authorization_ci_run_id=$RUN_ID"

echo
echo "=== 4. Wait for CI result ==="

gh run watch "$RUN_ID" \
  --repo "$REPO" \
  --interval 10 \
  --exit-status

RUN_DATA="$(
  gh run view "$RUN_ID" \
    --repo "$REPO" \
    --json headSha,status,conclusion,name,url
)"

RUN_HEAD="$(jq -r '.headSha' <<<"$RUN_DATA")"
RUN_STATUS="$(jq -r '.status' <<<"$RUN_DATA")"
RUN_CONCLUSION="$(jq -r '.conclusion' <<<"$RUN_DATA")"

echo "ci_head=$RUN_HEAD"
echo "ci_status=$RUN_STATUS"
echo "ci_conclusion=$RUN_CONCLUSION"

test "$RUN_HEAD" = "$EXPECTED_HEAD"
test "$RUN_STATUS" = "completed"
test "$RUN_CONCLUSION" = "success"

echo "authorization_ci=PASS"

echo
echo "=== 5. Final merge gate ==="

MERGE_READY=0

for ATTEMPT in $(seq 1 30); do
  PR_DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
  PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
  PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"

  echo \
    "merge_poll_attempt=$ATTEMPT " \
    "state=$PR_STATE " \
    "head=$PR_HEAD " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$PR_STATE" = "OPEN" ] \
     && [ "$PR_HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$PR_BASE" = "$BASE" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    MERGE_READY=1
    break
  fi

  sleep 5
done

test "$MERGE_READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 6. Merge PR #10 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 7. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "base_head=$BASE_HEAD"
echo "authorization_commit_is_ancestor=PASS"

echo
echo "=== 8. Verify merged authorization ==="

"$PYTHON" - "$AUTH" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

if not path.is_file():
    raise SystemExit(f"Missing authorization: {path}")

authorization = json.loads(
    path.read_text(encoding="utf-8")
)

scope = authorization["scope"]
execution = authorization["execution_state"]
prohibitions = authorization["prohibitions"]
precision = authorization["precision_analysis"]

assert authorization["status"] == "authorized"
assert authorization["campaign_id"] == (
    "virtual_node_count_stage10_c4"
)
assert authorization["factor"] == "virtual_node_count"

assert scope["replication_count"] == 10
assert scope["timing_cell_count"] == 60
assert scope["warmup_runs_per_cell"] == 10
assert scope["measurement_runs_per_cell"] == 100
assert scope["expected_warmup_count"] == 600
assert scope["expected_measurement_count"] == 6000

assert precision["bootstrap_replications"] == 10000
assert precision["confidence_level"] == 0.95
assert precision["median_relative_half_width_target"] == 0.10
assert precision["p95_relative_half_width_target"] == 0.15

assert execution == {
    "timing_execution_performed": False,
    "warmup_count_observed": 0,
    "measurement_count_observed": 0,
}

for field in (
    "functional_execution_rerun_authorized",
    "historical_prefix_rerun_authorized",
    "stage20_execution_authorized",
    "latency_claim_authorized",
    "scientific_freeze_authorized",
):
    assert prohibitions[field] is False

print("merged_timing_authorization=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 9. Cleanup local authorization branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 10. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "stage10_timing_authorization_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=prepare_and_validate_stage10_timing_runner"

git status --short --branch
git log --oneline --decorate -5
