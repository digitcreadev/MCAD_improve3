#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="f2942f1c895c7643332f89490e68bd17ea88f9b2"

AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"
PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"

cd "$ROOT"

echo "=== 1. Repository gate ==="

CURRENT_BRANCH="$(git branch --show-current)"
CURRENT_HEAD="$(git rev-parse HEAD)"
DIRTY_COUNT="$(git status --porcelain | wc -l | tr -d ' ')"

echo "branch=$CURRENT_BRANCH"
echo "head=$CURRENT_HEAD"
echo "dirty_count=$DIRTY_COUNT"

test "$CURRENT_BRANCH" = "$BASE"
test "$CURRENT_HEAD" = "$EXPECTED_HEAD"
test "$DIRTY_COUNT" -eq 0
test -f "$AUTH"
test -f "$PREREG"

echo "repository_gate=PASS"

echo
echo "=== 2. Authorized Stage-10 timing contract ==="

python - "$AUTH" "$PREREG" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

auth_path = Path(sys.argv[1])
prereg_path = Path(sys.argv[2])

auth = json.loads(
    auth_path.read_text(encoding="utf-8")
)
prereg = json.loads(
    prereg_path.read_text(encoding="utf-8")
)

print(
    json.dumps(
        {
            "authorization": {
                "status": auth["status"],
                "campaign_id": auth["campaign_id"],
                "scope": auth["scope"],
                "execution_order": auth[
                    "execution_order"
                ],
                "precision_analysis": auth[
                    "precision_analysis"
                ],
                "prohibitions": auth["prohibitions"],
                "execution_state": auth[
                    "execution_state"
                ],
            },
            "preregistered_timing_protocol": (
                prereg.get("timing_protocol")
            ),
            "preregistered_precision_protocol": (
                prereg.get("precision_protocol")
            ),
        },
        indent=2,
        sort_keys=True,
    )
)
PY

echo
echo "=== 3. Existing timing-related tools ==="

find backend/harness/sensitivity_execution \
  -type f \
  \( \
    -iname '*timing*.py' \
    -o -iname '*benchmark*.py' \
    -o -iname '*constraint_count*.py' \
  \) \
  | sort

echo
echo "=== 4. Files implementing timing semantics ==="

grep -RIl \
  --include='*.py' \
  -e 'warmups_per_cell' \
  -e 'measurements_per_cell' \
  -e 'measurement_runs_per_cell' \
  -e 'order_seed_base' \
  -e 'reuse_successful' \
  -e 'perf_counter_ns' \
  backend/harness/sensitivity_execution \
  | sort

echo
echo "=== 5. Relevant timing implementation lines ==="

grep -RIn \
  --include='*.py' \
  -E \
'warmups_per_cell|measurements_per_cell|measurement_runs_per_cell|order_seed_base|reuse_successful|perf_counter_ns|timing_observation|measurement_observation' \
  backend/harness/sensitivity_execution \
  | head -n 300

echo
echo "=== 6. Constraint-count timing precedent artifacts ==="

find \
  reports/article_experiments \
  experiments/article/frozen_campaigns \
  -type f \
  \( \
    -iname '*constraint_count*timing*' \
    -o -iname '*timing*constraint_count*' \
    -o -iname '*stage20*timing*' \
    -o -iname '*timing_protocol*' \
  \) \
  2>/dev/null \
  | sort \
  | head -n 200

echo
echo "=== 7. Candidate runner entry points ==="

grep -RIl \
  --include='*.py' \
  -E \
'argparse|warmup|measurement|perf_counter|timing' \
  backend/harness/sensitivity_execution/tools \
  backend/harness \
  2>/dev/null \
  | grep -E \
'constraint_count|timing|benchmark|sensitivity' \
  | sort \
  | head -n 100

echo
echo "timing_runner_precedent_inspection=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=implement_stage10_timing_runner_from_existing_precedent"
