#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"

FILES=(
  "backend/harness/sensitivity_design/design_matrix.yaml"
  "backend/harness/sensitivity_design/SENSITIVITY_GENERATOR_DESIGN.md"
  "backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml"
  "backend/harness/sensitivity_generator/structural_generator.py"
  "backend/harness/sensitivity_generator/families/controlled_families.py"
  "backend/harness/sensitivity_generator/families/CONTROLLED_FAMILIES_E2_2.md"
  "backend/harness/sensitivity_generator/tests/test_controlled_families.py"
  "backend/harness/sensitivity_execution/execute_controlled_family.py"
  "backend/harness/sensitivity_execution/validate_e3_contract.py"
  "backend/harness/sensitivity_execution/tests/test_execute_controlled_family.py"
)

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="/workspaces/sa5_objective_count_implementation_surface_${STAMP}"

trap 'echo "[ERROR] SA5 implementation-surface inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only implementation preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in "${FILES[@]}"; do
  if [ ! -f "$FILE" ]; then
    echo "[ERROR] Missing required file: $FILE"
    exit 1
  fi
done

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" | awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}'
)"

echo "implementation_preflight_gate=PASS"
echo "repository_modified=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Initialize detached inspection output ==="

rm -rf "$OUT"

mkdir -p \
  "$OUT/files" \
  "$OUT/extracts"

echo "inspection_root=$OUT"

echo
echo "=== 3. Record exact source identities ==="

{
  printf 'sha256\tsize_bytes\tpath\n'

  for FILE in "${FILES[@]}"; do
    printf '%s\t%s\t%s\n' \
      "$(sha256sum "$FILE" | awk '{print $1}')" \
      "$(stat -c '%s' "$FILE")" \
      "$FILE"
  done
} > "$OUT/source_inventory.tsv"

column -t -s $'\t' "$OUT/source_inventory.tsv"

echo
echo "=== 4. Extract Python API and dispatch surfaces ==="

python3 - \
  "$ROOT" \
  "$OUT" \
  "${FILES[@]}" <<'PY'
from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
output_root = Path(sys.argv[2]).resolve()
relative_paths = sys.argv[3:]

target_patterns = (
    r"\bobjective_count\b",
    r"\bn_objectives\b",
    r"\bconstraint_count\b",
    r"\bvirtual_node_count\b",
    r"\bmembership_density\b",
    r"\bprimary_factor\b",
    r"\bfactor\b",
    r"\bcampaign_generator_version\b",
    r"\bstructural_generator_version\b",
    r"\baccepted_profiles\b",
    r"\bgenerator_profile\b",
)

combined = re.compile(
    "|".join(target_patterns),
    flags=re.IGNORECASE,
)


def signature(node: ast.AST) -> str:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        args: list[str] = []

        positional = [
            *node.args.posonlyargs,
            *node.args.args,
        ]

        defaults_offset = (
            len(positional) - len(node.args.defaults)
        )

        for index, argument in enumerate(positional):
            rendered = argument.arg

            default_index = index - defaults_offset

            if default_index >= 0:
                try:
                    rendered += (
                        "="
                        + ast.unparse(
                            node.args.defaults[default_index]
                        )
                    )
                except Exception:
                    rendered += "=<default>"

            args.append(rendered)

        if node.args.vararg is not None:
            args.append("*" + node.args.vararg.arg)

        for argument, default in zip(
            node.args.kwonlyargs,
            node.args.kw_defaults,
        ):
            rendered = argument.arg

            if default is not None:
                try:
                    rendered += "=" + ast.unparse(default)
                except Exception:
                    rendered += "=<default>"

            args.append(rendered)

        if node.args.kwarg is not None:
            args.append("**" + node.args.kwarg.arg)

        prefix = (
            "async def"
            if isinstance(node, ast.AsyncFunctionDef)
            else "def"
        )

        return f"{prefix} {node.name}({', '.join(args)})"

    if isinstance(node, ast.ClassDef):
        return f"class {node.name}"

    return type(node).__name__


def merged_ranges(
    line_numbers: list[int],
    *,
    radius: int,
    maximum: int,
) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []

    for line_number in sorted(set(line_numbers)):
        start = max(1, line_number - radius)
        end = min(maximum, line_number + radius)

        if ranges and start <= ranges[-1][1] + 1:
            previous_start, previous_end = ranges[-1]
            ranges[-1] = (
                previous_start,
                max(previous_end, end),
            )
        else:
            ranges.append((start, end))

    return ranges


report: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "implementation-surface-v1"
    ),
    "files": {},
}

for relative_path in relative_paths:
    path = root / relative_path
    suffix = path.suffix.lower()

    text = path.read_text(
        encoding="utf-8",
        errors="replace",
    )

    lines = text.splitlines()

    record: dict[str, Any] = {
        "path": relative_path,
        "line_count": len(lines),
        "matching_lines": [],
        "python_definitions": [],
        "module_assignments": [],
    }

    matching_line_numbers: list[int] = []

    for number, line in enumerate(lines, start=1):
        if combined.search(line):
            matching_line_numbers.append(number)
            record["matching_lines"].append({
                "line": number,
                "text": line[:1000],
            })

    extract_path = (
        output_root
        / "extracts"
        / (relative_path.replace("/", "__") + ".txt")
    )

    extract_lines: list[str] = [
        "=" * 100,
        f"FILE={relative_path}",
        f"LINE_COUNT={len(lines)}",
        "=" * 100,
    ]

    for start, end in merged_ranges(
        matching_line_numbers,
        radius=18,
        maximum=len(lines),
    ):
        extract_lines.append(
            f"\n--- LINES {start}-{end} ---"
        )

        for index in range(start - 1, end):
            extract_lines.append(
                f"{index + 1:05d}: {lines[index]}"
            )

    if suffix == ".py":
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            record["python_parse_error"] = str(exc)
        else:
            relevant_nodes: list[ast.AST] = []

            for node in ast.walk(tree):
                if not isinstance(
                    node,
                    (
                        ast.FunctionDef,
                        ast.AsyncFunctionDef,
                        ast.ClassDef,
                    ),
                ):
                    continue

                source = ast.get_source_segment(text, node) or ""

                if combined.search(source):
                    relevant_nodes.append(node)

                    record["python_definitions"].append({
                        "signature": signature(node),
                        "start_line": getattr(
                            node,
                            "lineno",
                            None,
                        ),
                        "end_line": getattr(
                            node,
                            "end_lineno",
                            None,
                        ),
                    })

            for node in tree.body:
                if not isinstance(
                    node,
                    (ast.Assign, ast.AnnAssign),
                ):
                    continue

                source = ast.get_source_segment(text, node) or ""

                if combined.search(source):
                    record["module_assignments"].append({
                        "start_line": getattr(
                            node,
                            "lineno",
                            None,
                        ),
                        "end_line": getattr(
                            node,
                            "end_lineno",
                            None,
                        ),
                        "source": source,
                    })

            extract_lines.append(
                "\n--- RELEVANT COMPLETE PYTHON DEFINITIONS ---"
            )

            for node in sorted(
                relevant_nodes,
                key=lambda item: getattr(
                    item,
                    "lineno",
                    0,
                ),
            ):
                source = ast.get_source_segment(text, node)

                if source is None:
                    continue

                extract_lines.extend([
                    "",
                    (
                        f"### {signature(node)} "
                        f"[{node.lineno}-"
                        f"{getattr(node, 'end_lineno', node.lineno)}]"
                    ),
                    source,
                ])

            extract_lines.append(
                "\n--- RELEVANT MODULE-LEVEL ASSIGNMENTS ---"
            )

            for assignment in record["module_assignments"]:
                extract_lines.extend([
                    "",
                    assignment["source"],
                ])

    extract_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    extract_path.write_text(
        "\n".join(extract_lines) + "\n",
        encoding="utf-8",
    )

    record["extract_path"] = str(extract_path)
    report["files"][relative_path] = record

(output_root / "implementation_surface.json").write_text(
    json.dumps(report, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

print("implementation_surface_extraction=PASS")

for relative_path, record in report["files"].items():
    print(
        "surface_file="
        f"{relative_path}"
        " matching_lines="
        f"{len(record['matching_lines'])}"
        " relevant_definitions="
        f"{len(record['python_definitions'])}"
        " assignments="
        f"{len(record['module_assignments'])}"
    )
PY

echo
echo "=== 5. Show exact controlled-generator surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_generator__families__controlled_families.py.txt"

echo
echo "=== 6. Show exact controlled-generator test surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_generator__tests__test_controlled_families.py.txt"

echo
echo "=== 7. Show exact E3 executor surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_execution__execute_controlled_family.py.txt"

echo
echo "=== 8. Show exact E3 contract-validation surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_execution__validate_e3_contract.py.txt"

echo
echo "=== 9. Show structural-generator surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_generator__structural_generator.py.txt"

echo
echo "=== 10. Show objective-count design blocks ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_design__design_matrix.yaml.txt"

echo
cat \
  "$OUT/extracts/backend__harness__sensitivity_design__semantic_binding__semantic_binding.yaml.txt"

echo
echo "=== 11. Compact implementation matrix ==="

python3 - \
  "$OUT/implementation_surface.json" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

report = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

for path, record in report["files"].items():
    definitions = record.get("python_definitions", [])

    if not definitions:
        continue

    print(f"\nFILE={path}")

    for definition in definitions:
        print(
            "  "
            f"{definition['signature']} "
            f"[{definition['start_line']}-"
            f"{definition['end_line']}]"
        )
PY

echo
echo "=== 12. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$MANUSCRIPT" | awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "sa5_objective_count_implementation_surface=PASS"
echo "repository_modified=false"
echo "manuscript_modified=false"
echo "scientific_execution_performed=false"
echo "campaign_execution_authorized=false"
echo "inspection_root=$OUT"
echo "implementation_surface_report=$OUT/implementation_surface.json"
echo "next_stage=implement_sa5_objective_count_controlled_family_and_e3_support"

git status --short --branch
