#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6d244ec318cf3986900b3220924050974b141cd1"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"
LEDGER="$REPORTS/timing_runs/membership_density_stage10_portfolio/stage10_execution_ledger.json"
AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

trap 'echo "[ERROR] Focused analyzer inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Focused inspection gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$PREREG"
test -f "$LEDGER"
test -f "$AUDIT"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

echo "focused_inspection_gate=PASS"
echo "adapter_materialization_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Extract exact analyzer functions ==="

"$PYTHON" - \
  "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
lines = source.splitlines()

tree = ast.parse(source)

required_functions = {
    "stage_contract",
    "read_measurements",
    "validate_and_group",
    "analyze_precision",
    "main",
}

found: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}

for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        if node.name in required_functions:
            found[node.name] = node

missing = required_functions - set(found)

if missing:
    raise SystemExit(
        "Missing functions: " + ", ".join(sorted(missing))
    )

for name in [
    "stage_contract",
    "read_measurements",
    "validate_and_group",
    "analyze_precision",
]:
    node = found[name]

    if node.end_lineno is None:
        raise SystemExit(f"No end line for {name}")

    print()
    print(f"--- FUNCTION {name} lines {node.lineno}-{node.end_lineno} ---")

    for number in range(node.lineno, node.end_lineno + 1):
        print(f"{number}:{lines[number - 1]}")

main_node = found["main"]

keywords = {
    "timing_report",
    "expected_totals",
    "reported_totals",
    "totals_key",
    "factor",
    "constraint_count",
    "report_json",
    "report_md",
    "intervals_csv",
    "observations",
    "measurement_observation_count",
    "cell_count",
    "structural_seed_count",
}

print()
print("--- MAIN CONTRACT CONTEXTS ---")

selected_lines: set[int] = set()

for number in range(
    main_node.lineno,
    (main_node.end_lineno or main_node.lineno) + 1,
):
    line = lines[number - 1]

    if any(keyword in line for keyword in keywords):
        for context_line in range(
            max(main_node.lineno, number - 5),
            min(main_node.end_lineno or number, number + 5) + 1,
        ):
            selected_lines.add(context_line)

last = None

for number in sorted(selected_lines):
    if last is not None and number > last + 1:
        print("...")

    print(f"{number}:{lines[number - 1]}")
    last = number

print()
print("exact_analyzer_function_extraction=PASS")
PY

echo
echo "=== 3. Audit every hard-coded factor occurrence ==="

"$PYTHON" - \
  "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
lines = source.splitlines()
tree = ast.parse(source)

occurrences: list[tuple[int, str, str]] = []

for node in ast.walk(tree):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        value = node.value

        if (
            "constraint_count" in value
            or "constraint-count" in value
            or "Constraint count" in value
            or "constraint count" in value
        ):
            occurrences.append((
                node.lineno,
                type(node).__name__,
                value,
            ))

print(f"hardcoded_factor_occurrence_count={len(occurrences)}")

for line_number, node_type, value in sorted(occurrences):
    print(
        f"line={line_number} "
        f"node={node_type} "
        f"value={value!r}"
    )

    start = max(1, line_number - 4)
    end = min(len(lines), line_number + 4)

    for number in range(start, end + 1):
        print(f"{number}:{lines[number - 1]}")

    print("...")

if not occurrences:
    raise SystemExit(
        "Expected at least one hard-coded constraint-count label."
    )

print("hardcoded_factor_occurrence_audit=PASS")
PY

echo
echo "=== 4. Locate existing analyzer reports and timing-report schemas ==="

"$PYTHON" - \
  "$ROOT" \
  "$ANALYZER" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
analyzer_path = Path(sys.argv[2]).resolve()


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


candidates: list[dict[str, Any]] = []

for path in root.rglob("*.json"):
    if ".git" in path.parts:
        continue

    payload = load_json(path)

    if not isinstance(payload, dict):
        continue

    serialized = json.dumps(payload, sort_keys=True)

    has_precision_shape = (
        "bootstrap_contract" in payload
        or "all_precision_targets_met" in serialized
        or "median_relative_half_width" in serialized
        or "p95_relative_half_width" in serialized
    )

    has_timing_report_shape = (
        "successful_run_count" in serialized
        and "measurement_observation_count" in serialized
        and "functional_mismatch_count" in serialized
    )

    if has_precision_shape or has_timing_report_shape:
        candidates.append({
            "path": str(path.relative_to(root)),
            "precision_shape": has_precision_shape,
            "timing_report_shape": has_timing_report_shape,
            "top_level_keys": sorted(payload.keys()),
            "status": payload.get("status"),
            "factor": payload.get("factor"),
            "stage_size": payload.get("stage_size"),
        })

print(f"candidate_report_count={len(candidates)}")

for record in candidates[:80]:
    print(json.dumps(record, sort_keys=True))

print("existing_report_schema_search=PASS")
PY

echo
echo "=== 5. Verify membership-density scientific contract ==="

jq -e '
  .derived_analysis_adapter.required == true
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .derived_analysis_adapter.analyzer_levels_argument
      == "25,50,75,100"
  and .derived_analysis_adapter.analyzer_steps_argument == "0"
  and .derived_analysis_adapter.analyzer_measurements_per_cluster_argument
      == 2300
  and .derived_analysis_adapter.derived_observation_count == 92000
  and .derived_analysis_adapter.raw_timing_csv_modification_allowed
      == false
  and .precision_protocol.bootstrap_repetitions == 10000
  and .precision_protocol.bootstrap_seed == 20260728
  and .precision_protocol.confidence_level == 0.95
  and .precision_protocol.median_relative_half_width_target == 0.10
  and .precision_protocol.p95_relative_half_width_target == 0.15
' "$PREREG" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.measurement_observation_count == 92000
  and .scientific_controls.precision_analysis_performed == false
' "$LEDGER" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$AUDIT" >/dev/null

echo "membership_density_scientific_contract=PASS"
echo "expected_factor=membership_density"
echo "expected_stage_size=10"
echo "expected_analyzer_cell_count=40"
echo "expected_measurement_observation_count=92000"
echo "expected_step_index=0"
echo "expected_measurements_per_cluster=2300"

echo
echo "=== 6. Final read-only state ==="

test -z "$(git status --porcelain)"

echo "membership_density_analyzer_factor_and_report_contract_inspection=PASS"
echo "source_files_modified=false"
echo "adapter_artifact_created=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "next_stage=choose_non_mutating_membership_density_analyzer_integration_strategy"

git status --short --branch
