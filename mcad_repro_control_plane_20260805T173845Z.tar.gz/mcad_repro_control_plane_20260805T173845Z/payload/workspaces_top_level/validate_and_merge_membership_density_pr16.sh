#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=16

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-membership-density-portfolio-timing-20260802T201747Z"

EXPECTED_HEAD="97b3143fa9e588786263f6c73345b2f092e1de7e"
EXPECTED_BASE_HEAD="13be44a20db08589b8c452ea8299bbfc61adf164"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_portfolio_timing_preregistration.json"

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$PREREG"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

echo "local_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Synthetic step parser gate ==="

"$PYTHON" - "$ANALYZER" <<'PY'
from __future__ import annotations

import runpy
import sys
from pathlib import Path

path = Path(sys.argv[1])
namespace = runpy.run_path(str(path))

parse_integer_sequence = namespace[
    "parse_integer_sequence"
]

steps = tuple(
    parse_integer_sequence(
        "0",
        field="steps",
    )
)

levels = tuple(
    parse_integer_sequence(
        "25,50,75,100",
        field="levels",
    )
)

if steps != (0,):
    raise SystemExit(
        f"Unexpected parsed synthetic steps: {steps!r}"
    )

if levels != (25, 50, 75, 100):
    raise SystemExit(
        f"Unexpected parsed levels: {levels!r}"
    )

print("synthetic_step_zero_parser_gate=PASS")
print("parsed_steps=(0,)")
print("parsed_levels=(25,50,75,100)")
print("analyzer_steps_argument=0")
print("analyzer_measurements_per_cluster_argument=2300")
PY

echo
echo "=== 3. Formal preregistration gate ==="

jq -e '
  .status
    == "membership_density_portfolio_timing_preregistration_complete"
  and .preflight_revision.preflight_precision_cell_count == 92
  and .preflight_revision.formal_precision_cell_count == 4
  and .preflight_revision.supersedes_preflight_precision_cell_definition
      == true
  and .semantic_support_audit.distinct_query_digest_count == 207
  and .semantic_support_audit.globally_supported_digest_count == 0
  and .semantic_support_audit.globally_aligned_local_position_count == 0
  and .primary_estimand.inferential_cell_count == 4
  and .primary_estimand.cluster_count_per_density_level == 10
  and .primary_estimand.within_cluster_observation_count == 2300
  and .raw_timing_protocol.raw_timing_cell_count == 920
  and .raw_timing_protocol.warmup_observation_count == 9200
  and .raw_timing_protocol.measurement_observation_count == 92000
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .derived_analysis_adapter.analyzer_steps_argument == "0"
  and .derived_analysis_adapter.analyzer_measurements_per_cluster_argument
      == 2300
  and .derived_analysis_adapter.raw_timing_csv_modification_allowed
      == false
  and .precision_protocol.steps == [0]
  and .precision_protocol.precision_cell_count == 4
  and .precision_protocol.measurements_per_cluster == 2300
  and .precision_protocol.bootstrap_repetitions == 10000
  and .scientific_controls.timing_input_materialization_authorized
      == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.precision_analysis_authorized == false
  and .preregistration_decision.formal_timing_preregistration_complete
      == true
  and .preregistration_decision.timing_input_materialization_ready
      == true
  and .preregistration_decision.timing_execution_ready == false
  and .next_stage == "prepare_membership_density_timing_inputs"
' "$PREREG" >/dev/null

echo "formal_preregistration_gate=PASS"
echo "raw_timing_cell_count=920"
echo "measurement_observation_count=92000"
echo "formal_precision_cell_count=4"
echo "timing_execution_authorized=false"

echo
echo "=== 4. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 5. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "portfolio_preregistration_ci=PASS"
else
  echo "portfolio_preregistration_ci=NOT_APPLICABLE"
fi

echo
echo "=== 6. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 7. Merge PR #16 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 8. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "preregistration_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 9. Verify merged preregistration ==="

test -f "$PREREG"

jq -e '
  .status
    == "membership_density_portfolio_timing_preregistration_complete"
  and .raw_timing_protocol.raw_timing_cell_count == 920
  and .raw_timing_protocol.measurement_observation_count == 92000
  and .primary_estimand.inferential_cell_count == 4
  and .primary_estimand.within_cluster_observation_count == 2300
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .precision_protocol.steps == [0]
  and .precision_protocol.precision_cell_count == 4
  and .scientific_controls.timing_input_materialization_authorized
      == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.precision_analysis_authorized == false
  and .next_stage == "prepare_membership_density_timing_inputs"
' "$PREREG" >/dev/null

echo "merged_portfolio_preregistration=PASS"
echo "synthetic_step_index=0"
echo "portfolio_measurements_per_cluster=2300"
echo "formal_precision_cell_count=4"
echo "timing_input_materialization_authorized=true"
echo "timing_execution_authorized=false"

echo
echo "=== 10. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 11. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "membership_density_portfolio_preregistration_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=prepare_membership_density_timing_inputs"

git status --short --branch
git log --oneline --decorate -5
