#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_BASE_HEAD="729b73b7716a4c32c610241256b7e42dd9ba6bfc"

BRANCH="paper/fix-sa5-objective-count-bootstrap-20260804T201003Z"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
OBJECTIVE_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
SMOKE_ROOT="/workspaces/sa5_objective_count_bootstrap_contract_resume_smoke_${STAMP}"
TMP_ROOT="$(mktemp -d /workspaces/resume_sa5_bootstrap_fix.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 bootstrap-fix resume stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Resume gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

test -f "$EXECUTOR"
test -f "$OBJECTIVE_TEST"
test -f "$PREREG"
test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

test -z "$(git diff --cached --name-only)"

printf '%s\n' \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST" |
  sort \
  > "$TMP_ROOT/expected_modified_files.txt"

git diff --name-only |
  sort \
  > "$TMP_ROOT/actual_modified_files.txt"

diff -u \
  "$TMP_ROOT/expected_modified_files.txt" \
  "$TMP_ROOT/actual_modified_files.txt"

grep -F \
  'def _expected_bootstrap_objective_ids(' \
  "$EXECUTOR" >/dev/null

grep -F \
  'expected_objective_ids = (' \
  "$EXECUTOR" >/dev/null

grep -F \
  'def test_objective_count_bootstrap_loads_complete_catalogue(' \
  "$OBJECTIVE_TEST" >/dev/null

grep -F \
  'assert ckg.history == {}' \
  "$OBJECTIVE_TEST" >/dev/null

test -z "$(
  git diff --name-only -- "$MANUSCRIPT"
)"

test -z "$(
  git diff --name-only -- "$DEFERRED_FRAGMENT"
)"

echo "resume_gate=PASS"
echo "current_head=$EXPECTED_BASE_HEAD"
echo "modified_file_count=2"
echo "executor_patch_preserved=true"
echo "failure_classification=test_container_type_assumption"
echo "canonical_campaign_generated=false"
echo "functional_execution_performed=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Correct test-only state assertions ==="

"$PYTHON" - \
  "$OBJECTIVE_TEST" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

path = Path(sys.argv[1])

source = path.read_text(
    encoding="utf-8"
)

old = '''    assert ckg.history == {}
    assert ckg.session_coverage == {}
    assert ckg.session_weighted_coverage == {}
    assert ckg.session_resource_coverage == {}
'''

new = '''    assert not ckg.history
    assert not ckg.session_coverage
    assert not ckg.session_weighted_coverage
    assert not ckg.session_resource_coverage
'''

count = source.count(old)

if count != 1:
    raise SystemExit(
        "Expected exactly one strict empty-container "
        f"assertion block; found {count}."
    )

path.write_text(
    source.replace(
        old,
        new,
        1,
    ),
    encoding="utf-8",
)

print("test_state_assertion_patch=PASS")
print("semantic_requirement=runtime_state_is_empty")
print("concrete_container_type_required=false")
PY

grep -F \
  'assert not ckg.history' \
  "$OBJECTIVE_TEST" >/dev/null

! grep -F \
  'assert ckg.history == {}' \
  "$OBJECTIVE_TEST" >/dev/null

echo
echo "=== 3. Compile preserved correction ==="

"$PYTHON" -m py_compile \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

echo "bootstrap_patch_compile=PASS"

echo
echo "=== 4. Re-run targeted objective-count tests ==="

"$PYTHON" -m pytest \
  "$OBJECTIVE_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  -q \
  -p no:cacheprovider

echo "targeted_objective_count_bootstrap_tests=PASS"

echo
echo "=== 5. Run complete sensitivity regression ==="

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

echo "complete_sensitivity_regression=PASS"

echo
echo "=== 6. Re-run explicit runtime-contract smoke ==="

rm -rf "$SMOKE_ROOT"

"$PYTHON" - \
  "$SMOKE_ROOT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

import backend.harness.sensitivity_execution.execute_controlled_family as executor
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)

root = Path(sys.argv[1]).resolve()
campaign_dir = root / "campaign"

generate_controlled_family(
    ControlledFamilySpec(
        campaign_id=(
            "sa5_objective_count_bootstrap_resume_smoke"
        ),
        factor="objective_count",
        levels=(1, 2, 5),
        seeds=(101,),
        baseline_constraint_count=2,
        baseline_virtual_node_count=6,
        output_dir=str(campaign_dir),
    )
)

campaign_manifest = json.loads(
    (
        campaign_dir
        / "campaign_manifest.json"
    ).read_text(encoding="utf-8")
)

instances = executor._discover_all_instances(
    campaign_dir=campaign_dir,
    campaign_manifest=campaign_manifest,
)

assert [
    instance.factor_level
    for instance in instances
] == [1, 2, 5]

for instance in instances:
    ckg = executor._build_instance_ckg(
        instance=instance,
        runtime_output_dir=(
            root
            / "runtime"
            / instance.canonical_instance_id
        ),
    )

    instance_manifest = json.loads(
        instance.manifest_path.read_text(
            encoding="utf-8"
        )
    )

    expected_objective_ids = set(
        instance_manifest["objective_ids"]
    )

    assert len(ckg.objectives) == (
        instance.factor_level
    )

    assert set(ckg.objectives) == (
        expected_objective_ids
    )

    assert instance.objective_id == (
        instance_manifest[
            "selected_objective_id"
        ]
    )

    assert instance.objective_id in (
        ckg.objectives
    )

    assert not ckg.history
    assert not ckg.session_coverage
    assert not ckg.session_weighted_coverage
    assert not ckg.session_resource_coverage

print("objective_count_bootstrap_contract_smoke=PASS")
print("tested_levels=1,2,5")
print("tested_instance_count=3")
print("complete_objective_catalogue_loaded=true")
print("selected_objective_present=true")
print("runtime_state_empty=true")
print("workload_execution_performed=false")
print("canonical_campaign_generated=false")
print("scientific_execution_performed=false")
PY

echo
echo "=== 7. Repository scope gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

git diff --name-only |
  sort \
  > "$TMP_ROOT/final_modified_files.txt"

diff -u \
  "$TMP_ROOT/expected_modified_files.txt" \
  "$TMP_ROOT/final_modified_files.txt"

test -z "$(
  git diff --name-only -- "$MANUSCRIPT"
)"

test -z "$(
  git diff --name-only -- "$DEFERRED_FRAGMENT"
)"

git diff --check

echo "repository_scope_gate=PASS"
echo "changed_file_count=2"
echo "canonical_campaign_generated=false"
echo "canonical_stage10_bootstrap_performed=false"
echo "workload_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Stage correction ==="

git add \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

git diff --cached --name-only |
  sort \
  > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_modified_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)" -eq 2

git diff --cached --check

echo "correction_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 9. Commit correction ==="

git commit \
  -m "fix(sensitivity): support multi-objective SA5 bootstrap"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 10. Push corrective branch ==="

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 11. Create pull request ==="

EXISTING_PR_COUNT="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state all \
    --json number \
    --jq 'length'
)"

test "$EXISTING_PR_COUNT" -eq 0

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Fix SA5 objective-count multi-objective bootstrap" \
    --body "$(cat <<'EOF'
## SA5 runtime correction

The objective-count generator stores the complete multi-objective
catalogue while selecting one objective for evaluation. The historical
E3 bootstrap invariant required a singleton catalogue and would reject
all objective-count instances above level 1.

### Correction

For `objective_count` only, E3 validates:

- the complete `objective_ids` catalogue;
- requested and realised objective counts;
- equality with the registered factor level;
- uniqueness and cardinality of objective identifiers;
- exact selected-objective binding;
- presence of the selected objective in the loaded CKG.

Historical factors retain the singleton-objective contract.

### Validation

- targeted objective-count tests;
- complete generator and E3 regression suites;
- test-only bootstrap smoke at levels `1`, `2`, and `5`;
- runtime state verified empty without assuming concrete container types;
- no workload steps executed.

### Scientific controls

- canonical SA5 campaign generated: `false`;
- canonical Stage-10 bootstrap performed: `false`;
- functional execution performed: `false`;
- timing execution performed: `false`;
- manuscript modified: `false`.

## Next stage

`author_sa5_objective_count_stage10_materializer_and_auditor`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 12. Verify pull-request scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Fix SA5 objective-count multi-objective bootstrap"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_modified_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 13. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_multi_objective_bootstrap_fix_resume=PASS"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"
echo "changed_file_count=2"
echo "historical_single_objective_contract_preserved=true"
echo "objective_count_multi_objective_contract_supported=true"
echo "runtime_state_empty=true"
echo "tested_levels=1,2,5"
echo "canonical_campaign_generated=false"
echo "canonical_stage10_bootstrap_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_bootstrap_fix"

git status --short --branch
git log --oneline --decorate -4
