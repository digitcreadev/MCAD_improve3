#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

TARGET="/workspaces/package_sa5_objective_count_v2_25_file_patch_authoring_bundle.sh"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0674825017698f25562d43400ff4e72cb6484e2f"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

trap 'echo "[ERROR] Packaging-script repair stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact recovery gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

test -f "$TARGET"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

TARGET_SHA_BEFORE="$(
  sha256sum "$TARGET" |
    awk '{print $1}'
)"

echo "recovery_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "target=$TARGET"
echo "target_sha256_before=$TARGET_SHA_BEFORE"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Confirm malformed redirections ==="

export TARGET

python3 - <<'PY'
from __future__ import annotations

import os
import re
from pathlib import Path


target = Path(os.environ["TARGET"])

text = target.read_text(
    encoding="utf-8"
)

pattern = re.compile(
    r'wc -l <[ \t]*\r?\n'
    r'[ \t]*("[^"\r\n]+")'
)

matches = list(
    pattern.finditer(text)
)

print(
    "malformed_redirection_count="
    f"{len(matches)}"
)

for index, match in enumerate(
    matches,
    start=1,
):
    line_number = (
        text.count(
            "\n",
            0,
            match.start(),
        )
        + 1
    )

    target_expression = (
        match.group(1)
    )

    print(
        "malformed_redirection_"
        f"{index}_line={line_number}"
    )

    print(
        "malformed_redirection_"
        f"{index}_target={target_expression}"
    )

assert len(matches) == 5, (
    "Expected exactly five malformed "
    f"wc redirections, found {len(matches)}."
)
PY

echo "malformed_redirection_gate=PASS"

echo
echo "=== 3. Repair all five redirections ==="

python3 - <<'PY'
from __future__ import annotations

import os
import re
from pathlib import Path


target = Path(os.environ["TARGET"])

text = target.read_text(
    encoding="utf-8"
)

pattern = re.compile(
    r'wc -l <[ \t]*\r?\n'
    r'[ \t]*("[^"\r\n]+")'
)

patched, replacement_count = (
    pattern.subn(
        r'wc -l < \1',
        text,
    )
)

assert replacement_count == 5, (
    "Expected exactly five replacements, "
    f"performed {replacement_count}."
)

assert not pattern.search(patched)

target.write_text(
    patched,
    encoding="utf-8",
)

print(
    "redirection_replacement_count="
    f"{replacement_count}"
)
PY

echo "redirection_repair=PASS"

echo
echo "=== 4. Validate repaired Bash syntax ==="

bash -n "$TARGET"

REMAINING_SPLIT_COUNT="$(
  python3 - "$TARGET" <<'PY'
from __future__ import annotations

import re
import sys
from pathlib import Path


text = Path(
    sys.argv[1]
).read_text(
    encoding="utf-8"
)

pattern = re.compile(
    r'wc -l <[ \t]*\r?\n'
)

print(
    len(pattern.findall(text))
)
PY
)"

test "$REMAINING_SPLIT_COUNT" -eq 0

TARGET_SHA_AFTER="$(
  sha256sum "$TARGET" |
    awk '{print $1}'
)"

test "$TARGET_SHA_AFTER" != "$TARGET_SHA_BEFORE"

echo "bash_syntax_gate=PASS"
echo "remaining_split_redirection_count=0"
echo "target_sha256_after=$TARGET_SHA_AFTER"

echo
echo "=== 5. Show repaired count expressions ==="

grep -nE \
  'wc -l <|PAYLOAD_FILE_COUNT=' \
  "$TARGET"

echo
echo "=== 6. Re-run complete authoring-bundle packaging ==="

bash "$TARGET"

echo
echo "=== 7. Recovery final state ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "sa5_v2_authoring_bundle_syntax_recovery=PASS"
echo "repaired_redirection_count=5"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=attach_sa5_objective_count_v2_25_file_patch_authoring_bundle"

git status --short --branch
