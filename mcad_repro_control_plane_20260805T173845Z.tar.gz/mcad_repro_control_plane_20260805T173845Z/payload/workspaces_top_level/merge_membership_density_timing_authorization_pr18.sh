#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=18

BASE="paper/phase3-controlled-execution"
BRANCH="paper/authorize-membership-density-timing-20260803T110251Z"

EXPECTED_HEAD="f02755fd2884dd53fa4c4c7953b6ce392516bed9"
EXPECTED_BASE_HEAD="ac922e39dcd7e5a6ed8734ee5a13d9866ec49222"
EXPECTED_AUTH_SHA="dc9010e319e238f1419e4fdb4d52cd184fc9470d346cef8833ef0355ff0c4be0"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

AUTH_JSON="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.json"
AUTH_MD="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.md"

TIMING_RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

cd "$ROOT"

echo "=== 1. Local authorization gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -f "$AUTH_JSON"
test -f "$AUTH_MD"
test ! -e "$TIMING_RUN_ROOT"

test "$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_authorized"
  and .authorization_scope.stage == 10
  and .authorization_scope.replication_count == 10
  and .authorization_scope.execution_order == [range(0; 10)]
  and .authorization_scope.maximum_parallel_replications == 1
  and .authorization_scope.raw_timing_cell_count == 920
  and .authorization_scope.warmup_observation_count == 9200
  and .authorization_scope.measurement_observation_count == 92000
  and (.execution_matrix | length) == 10
  and .audit_results.source_file_count_verified == 20
  and .audit_results.derived_file_count_verified == 20
  and .audit_results.runner_loaded_instance_count == 40
  and .audit_results.all_output_directories_absent == true
  and .scientific_controls.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .authorization_decision.exact_inputs_audited == true
  and .authorization_decision.runner_input_contract_validated == true
  and .authorization_decision.timing_execution_ready == true
  and .next_stage == "execute_membership_density_timing_stage10"
' "$AUTH_JSON" >/dev/null

echo "local_authorization_gate=PASS"
echo "authorization_sha256=$EXPECTED_AUTH_SHA"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"
echo "precision_analysis_authorized=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"
echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "timing_authorization_ci=PASS"
else
  echo "timing_authorization_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1
echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #18 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "authorization_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged authorization ==="

test -f "$AUTH_JSON"
test -f "$AUTH_MD"
test ! -e "$TIMING_RUN_ROOT"

test "$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_authorized"
  and .authorization_scope.maximum_parallel_replications == 1
  and .authorization_scope.measurement_observation_count == 92000
  and (.execution_matrix | length) == 10
  and .scientific_controls.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage == "execute_membership_density_timing_stage10"
' "$AUTH_JSON" >/dev/null

echo "merged_timing_authorization=PASS"
echo "authorization_sha256=$EXPECTED_AUTH_SHA"
echo "timing_run_root_absent=true"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "membership_density_timing_authorization_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=true"
echo "latency_claim_authorized=false"
echo "next_stage=execute_membership_density_timing_stage10"

git status --short --branch
git log --oneline --decorate -5
