#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="4ad3f6aa90fd47107bb767ffeb23e38d995e3120"

PACKAGE="experiments/article/frozen_campaigns/sa3_constraint_count_stage20"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -d "$PACKAGE"
test -f "$REGISTRY"

echo "repository_gate=PASS"

echo
echo "=== 2. Exact external-package files ==="

find "$PACKAGE" \
  -maxdepth 2 \
  -type f \
  -printf '%P\n' \
  | sort

echo
echo "=== 3. Metadata JSON schemas and values ==="

python - "$PACKAGE" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

package = Path(sys.argv[1])

for relative in (
    "MANIFEST.json",
    "PROVENANCE.json",
    "STATUS.json",
    "freeze/FREEZE.json",
):
    path = package / relative

    if not path.is_file():
        raise SystemExit(f"Missing precedent file: {path}")

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    print()
    print(f"--- {relative} ---")
    print(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
    )
PY

echo
echo "=== 4. Human-readable package contracts ==="

for RELATIVE in \
  README.md \
  REPRODUCE.md \
  SHA256SUMS
do
  echo
  echo "--- $RELATIVE ---"
  sed -n '1,260p' "$PACKAGE/$RELATIVE"
done

echo
echo "=== 5. Canonical archive contract ==="

python - "$PACKAGE" <<'PY'
from __future__ import annotations

import hashlib
import tarfile
import sys
from collections import Counter
from pathlib import Path

package = Path(sys.argv[1])

archives = sorted(
    (package / "archive").glob("*.tar.gz")
)

if len(archives) != 1:
    raise SystemExit(
        f"Expected one archive, got {len(archives)}."
    )

archive = archives[0]
digest = hashlib.sha256(
    archive.read_bytes()
).hexdigest()

with tarfile.open(archive, "r:gz") as stream:
    members = [
        item.name
        for item in stream.getmembers()
    ]

top_level = Counter(
    name.split("/", 1)[0]
    for name in members
    if name
)

print(f"archive_path={archive}")
print(f"archive_sha256={digest}")
print(f"archive_member_count={len(members)}")
print(
    "archive_top_level_entries="
    + ",".join(sorted(top_level))
)

print()
print("--- first archive members ---")

for name in members[:80]:
    print(name)
PY

echo
echo "=== 6. Package-creation commit precedent ==="

CREATION_COMMIT="$(
  git log \
    --diff-filter=A \
    --format='%H' \
    -- "$PACKAGE" \
    | tail -n 1
)"

test -n "$CREATION_COMMIT"

echo "creation_commit=$CREATION_COMMIT"

git show \
  --stat \
  --summary \
  --format=fuller \
  "$CREATION_COMMIT" \
  -- "$PACKAGE" "$REGISTRY" \
  | sed -n '1,260p'

echo
echo "=== 7. Final state ==="

echo "freeze_metadata_schema_inspection=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_rerun_performed=false"
echo "scientific_freeze_performed=false"
echo "next_stage=create_virtual_node_count_stage10_freeze_package"

git status --short --branch
