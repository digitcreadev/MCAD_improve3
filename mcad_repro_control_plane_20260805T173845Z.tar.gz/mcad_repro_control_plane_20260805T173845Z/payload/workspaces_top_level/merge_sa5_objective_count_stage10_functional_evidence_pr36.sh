#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=36

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-functional-evidence-20260805T140248Z"

EXPECTED_BASE_HEAD="809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
EXPECTED_FEATURE_HEAD="539c928a118ffcf45bfedc7a98a5cac9aee5e1de"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

RUN_ROOT="$E3/runs"
EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/functional_execution"
CANONICAL_RUN_MANIFEST="$EVIDENCE_ROOT/source_post_execution/canonical_functional_run_file_manifest.sha256"

EVIDENCE_MANIFEST="$EVIDENCE_ROOT/functional_execution_evidence_manifest.json"
EXPECTED_EVIDENCE_MANIFEST_SHA="d2b66ccf52bde34aee15596a898ddf7fa95cb51aad6ce6bd4b0fa14f59e37dbc"

MATERIALIZATION_REPORT="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="69fd9c4d291adefefef50fb595c779b222cfc1e4299796f9e9fa525a1c150e07"

MATERIALIZATION_SUMMARY="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="24faa78e4e2a2f01efd8842fa2ece035c4f04d4038af73c67f8aaccbe93b4869"

EXPECTED_CANONICAL_RUN_MANIFEST_SHA="10f2795a20c27c7ba2222636eee8d0800709e12f3fe290138bf4e31c29db6bf1"

SPEC_MANIFEST="$E3/execution_specs/objective_count_stage10_execution_spec_manifest.json"
EXPECTED_SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

CAMPAIGN_HASHES="$E3/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_HASHES_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

AUTH_REPORT="$EVIDENCE_ROOT/source_authorization/sa5_objective_count_stage10_functional_execution_authorization.json"
EXPECTED_AUTH_REPORT_SHA="e21998b445f199253894aa40dbfeb4508c1cd6e64b7002ce1c438bbe05e7cb04"

AUTH_SURFACE="$EVIDENCE_ROOT/source_authorization/sa5_objective_count_stage10_functional_execution_authorization.txt"
EXPECTED_AUTH_SURFACE_SHA="5defd8ff1c5107d6b257343f8e05336644cfb58f943190d85eff34bcc78ea0a7"

EXEC_LEDGER="$EVIDENCE_ROOT/source_execution/sa5_objective_count_stage10_functional_execution_ledger.json"
EXPECTED_EXEC_LEDGER_SHA="6432e399be10798362a27d00ca55208909c85d9a538de0c53c89b8f7c90d85e0"

EXEC_SURFACE="$EVIDENCE_ROOT/source_execution/sa5_objective_count_stage10_functional_execution_ledger.txt"
EXPECTED_EXEC_SURFACE_SHA="3db78e3df9c4bff3c33e88a9845d1ae7c4e2a4d08b243a7bf37c2d1a8739199b"

POST_REPORT="$EVIDENCE_ROOT/source_post_execution/sa5_objective_count_stage10_post_functional_execution_audit.json"
EXPECTED_POST_REPORT_SHA="f53ed50765ed41fc253de969a7a5f8858b6627bab774bd3add013d5177872647"

POST_SURFACE="$EVIDENCE_ROOT/source_post_execution/sa5_objective_count_stage10_post_functional_execution_audit.txt"
EXPECTED_POST_SURFACE_SHA="5c4e2493d673efadc523552976a887cf55864b0d807fad8ad1b499e5904606cb"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CI_AUDIT_ROOT="/workspaces/sa5_objective_count_pr36_ci_eligibility_audit_${STAMP}"
CI_AUDIT_REPORT="$CI_AUDIT_ROOT/sa5_objective_count_pr36_ci_eligibility_audit.json"
CI_AUDIT_SURFACE="$CI_AUDIT_ROOT/sa5_objective_count_pr36_ci_eligibility_audit.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_pr36_controlled_merge.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #36 controlled merge stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact local functional-evidence gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

verify_sha "$EVIDENCE_MANIFEST" "$EXPECTED_EVIDENCE_MANIFEST_SHA"
verify_sha "$MATERIALIZATION_REPORT" "$EXPECTED_MATERIALIZATION_REPORT_SHA"
verify_sha "$MATERIALIZATION_SUMMARY" "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
verify_sha "$CANONICAL_RUN_MANIFEST" "$EXPECTED_CANONICAL_RUN_MANIFEST_SHA"
verify_sha "$SPEC_MANIFEST" "$EXPECTED_SPEC_MANIFEST_SHA"
verify_sha "$CAMPAIGN_HASHES" "$EXPECTED_CAMPAIGN_HASHES_SHA"
verify_sha "$AUTH_REPORT" "$EXPECTED_AUTH_REPORT_SHA"
verify_sha "$AUTH_SURFACE" "$EXPECTED_AUTH_SURFACE_SHA"
verify_sha "$EXEC_LEDGER" "$EXPECTED_EXEC_LEDGER_SHA"
verify_sha "$EXEC_SURFACE" "$EXPECTED_EXEC_SURFACE_SHA"
verify_sha "$POST_REPORT" "$EXPECTED_POST_REPORT_SHA"
verify_sha "$POST_SURFACE" "$EXPECTED_POST_SURFACE_SHA"

sha256sum -c "$CAMPAIGN_HASHES" >/dev/null
sha256sum -c "$CANONICAL_RUN_MANIFEST" >/dev/null

test -f "$MANUSCRIPT"
test -f "$DEFERRED"

MANUSCRIPT_SHA_BEFORE="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA_BEFORE="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "local_functional_evidence_gate=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "feature_head=$EXPECTED_FEATURE_HEAD"

echo
echo "=== 2. Reconstruct exact 300-file scope ==="

awk '{print $2}' "$CANONICAL_RUN_MANIFEST" |
  sort > "$TMP_ROOT/run_files.txt"

find "$EVIDENCE_ROOT" -type f |
  sort > "$TMP_ROOT/evidence_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/run_files.txt" \
  "$TMP_ROOT/evidence_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/run_files.txt")" -eq 280
test "$(wc -l < "$TMP_ROOT/evidence_files.txt")" -eq 18
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 300

git diff --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/feature_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/feature_files.txt"

echo "exact_scope_reconstruction=PASS"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_changed_file_count=300"

echo
echo "=== 3. Canonical evidence decision gate ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .completion.successful_execution_spec_count == 10
  and .completion.failed_execution_spec_count == 0
  and .completion.canonical_run_count == 10
  and .completion.total_instance_count == 60
  and .completion.total_step_evaluations == 1920
  and .completion.canonical_run_file_count == 280
  and .completion.canonical_run_total_bytes == 25018782
  and .repository_scope.canonical_run_file_count == 280
  and .repository_scope.canonical_evidence_file_count == 18
  and .repository_scope.planning_file_count == 2
  and .repository_scope.total_materialized_file_count == 300
  and .scientific_controls.canonical_stage10_functional_execution_performed == true
  and .scientific_controls.functional_execution_completion_audited == true
  and .scientific_controls.functional_execution_evidence_materialized == true
  and .scientific_controls.functional_execution_evidence_committed == false
  and .scientific_controls.timing_analysis_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.scientific_result_interpretation_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization.functional_execution_evidence_commit_authorized == true
  and .authorization.timing_analysis_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$EVIDENCE_MANIFEST" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .repository_scope.total_materialized_file_count == 300
  and .scientific_controls.functional_execution_evidence_committed == false
  and .authorization.functional_execution_evidence_commit_authorized == true
  and .blocker_count == 0
  and .materialization_complete == true
  and .next_stage
    == "wait_for_ci_then_merge_sa5_objective_count_stage10_functional_execution_evidence"
' "$MATERIALIZATION_REPORT" >/dev/null

echo "canonical_evidence_decision_gate=PASS"
echo "timing_analysis_authorized=false"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"

echo
echo "=== 4. Pull-request identity and exact-scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .isDraft == false
    and .headRefOid == $feature
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 functional evidence"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 300

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=300"

echo
echo "=== 5. Detect registered CI or prove workflow ineligibility ==="

CI_OBJECT_COUNT=0
PR_CHECK_COUNT=0
ACTIONS_RUN_COUNT=0
CHECK_RUN_COUNT=0
LEGACY_STATUS_COUNT=0

for ATTEMPT in $(seq 1 6); do
  PR_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || printf '[]'
  )"

  if ! jq -e 'type == "array"' >/dev/null <<<"$PR_CHECKS"; then
    PR_CHECKS='[]'
  fi

  PR_CHECK_COUNT="$(jq 'length' <<<"$PR_CHECKS")"

  ACTIONS_RUNS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
  )"
  ACTIONS_RUN_COUNT="$(jq '.total_count' <<<"$ACTIONS_RUNS")"

  CHECK_RUNS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
  )"
  CHECK_RUN_COUNT="$(jq '.total_count' <<<"$CHECK_RUNS")"

  COMBINED_STATUS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
  )"
  LEGACY_STATUS_COUNT="$(jq '.statuses | length' <<<"$COMBINED_STATUS")"

  CI_OBJECT_COUNT="$(
    printf '%s\n' \
      "$PR_CHECK_COUNT" \
      "$ACTIONS_RUN_COUNT" \
      "$CHECK_RUN_COUNT" \
      "$LEGACY_STATUS_COUNT" |
      awk '{sum += $1} END {print sum + 0}'
  )"

  echo \
    "ci_detection_attempt=$ATTEMPT " \
    "pr_checks=$PR_CHECK_COUNT " \
    "actions_runs=$ACTIONS_RUN_COUNT " \
    "check_runs=$CHECK_RUN_COUNT " \
    "legacy_statuses=$LEGACY_STATUS_COUNT"

  [ "$CI_OBJECT_COUNT" -gt 0 ] && break
  sleep 5
done

CI_MODE=""

if [ "$CI_OBJECT_COUNT" -gt 0 ]; then
  CI_MODE="registered"
  COMPLETE=0

  for ATTEMPT in $(seq 1 60); do
    ACTIONS_RUNS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
    )"
    CHECK_RUNS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
    )"
    COMBINED_STATUS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
    )"

    ACTION_PENDING="$(
      jq '[.workflow_runs[] | select(.status != "completed")] | length' \
        <<<"$ACTIONS_RUNS"
    )"
    ACTION_FAILURE="$(
      jq '
        [
          .workflow_runs[]
          | select(
              .status == "completed"
              and (
                .conclusion
                | IN("success", "neutral", "skipped")
                | not
              )
            )
        ] | length
      ' <<<"$ACTIONS_RUNS"
    )"
    CHECK_PENDING="$(
      jq '[.check_runs[] | select(.status != "completed")] | length' \
        <<<"$CHECK_RUNS"
    )"
    CHECK_FAILURE="$(
      jq '
        [
          .check_runs[]
          | select(
              .status == "completed"
              and (
                .conclusion
                | IN("success", "neutral", "skipped")
                | not
              )
            )
        ] | length
      ' <<<"$CHECK_RUNS"
    )"
    LEGACY_FAILURE="$(
      jq '[.statuses[] | select(.state != "success")] | length' \
        <<<"$COMBINED_STATUS"
    )"

    echo \
      "ci_completion_attempt=$ATTEMPT " \
      "action_pending=$ACTION_PENDING " \
      "action_failure=$ACTION_FAILURE " \
      "check_pending=$CHECK_PENDING " \
      "check_failure=$CHECK_FAILURE " \
      "legacy_failure=$LEGACY_FAILURE"

    test "$ACTION_FAILURE" -eq 0
    test "$CHECK_FAILURE" -eq 0

    if [ "$ACTION_PENDING" -eq 0 ] \
       && [ "$CHECK_PENDING" -eq 0 ] \
       && [ "$LEGACY_FAILURE" -eq 0 ]; then
      COMPLETE=1
      break
    fi

    sleep 10
  done

  test "$COMPLETE" -eq 1
  echo "registered_ci_completion_gate=PASS"
else
  CI_MODE="workflow_ineligible"
  mkdir -p "$CI_AUDIT_ROOT"

  export ROOT BASE EXPECTED_BASE_HEAD EXPECTED_FEATURE_HEAD PR REPO
  export CI_AUDIT_REPORT CI_AUDIT_SURFACE
  export EXPECTED_FILES_PATH="$TMP_ROOT/expected_files.txt"

  "$PYTHON" - <<'PY'
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
base_branch = os.environ["BASE"]
changed_files = Path(
    os.environ["EXPECTED_FILES_PATH"]
).read_text(encoding="utf-8").splitlines()

report_path = Path(os.environ["CI_AUDIT_REPORT"])
surface_path = Path(os.environ["CI_AUDIT_SURFACE"])

workflow_root = root / ".github" / "workflows"
workflow_files = sorted([
    *workflow_root.glob("*.yml"),
    *workflow_root.glob("*.yaml"),
])
assert workflow_files


def as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def match(value: str, pattern: str) -> bool:
    # Conservative over-approximation: a false positive blocks merging.
    return fnmatch.fnmatchcase(value, pattern)


def ordered(value: str, patterns: list[str]) -> bool:
    included = False
    for raw in patterns:
        negated = raw.startswith("!")
        pattern = raw[1:] if negated else raw
        if match(value, pattern):
            included = not negated
    return included


def ignored(value: str, patterns: list[str]) -> bool:
    return any(match(value, pattern) for pattern in patterns)


def event_config(on_value: Any, event: str) -> tuple[bool, Any]:
    if isinstance(on_value, str):
        return on_value == event, None
    if isinstance(on_value, list):
        return event in [str(item) for item in on_value], None
    if isinstance(on_value, dict):
        return event in on_value, on_value.get(event)
    return False, None


results = []

for workflow_path in workflow_files:
    document = yaml.load(
        workflow_path.read_text(encoding="utf-8"),
        Loader=yaml.BaseLoader,
    )
    assert isinstance(document, dict)

    event_rows = []

    for event in ("pull_request", "pull_request_target"):
        present, config = event_config(document.get("on"), event)
        if not present:
            continue
        if not isinstance(config, dict):
            config = {}

        branches = as_list(config.get("branches"))
        branches_ignore = as_list(config.get("branches-ignore"))
        paths = as_list(config.get("paths"))
        paths_ignore = as_list(config.get("paths-ignore"))

        branch_ok = True
        branch_reason = "no_branch_filter"

        if branches:
            branch_ok = ordered(base_branch, branches)
            branch_reason = "branch_included" if branch_ok else "branch_not_included"
        elif branches_ignore:
            branch_ok = not ignored(base_branch, branches_ignore)
            branch_reason = "branch_not_ignored" if branch_ok else "branch_ignored"

        path_ok = True
        path_reason = "no_path_filter"
        matched_files: list[str] = []

        if paths:
            matched_files = [
                path for path in changed_files if ordered(path, paths)
            ]
            path_ok = bool(matched_files)
            path_reason = "paths_match" if path_ok else "paths_no_match"
        elif paths_ignore:
            matched_files = [
                path for path in changed_files
                if not ignored(path, paths_ignore)
            ]
            path_ok = bool(matched_files)
            path_reason = (
                "at_least_one_path_not_ignored"
                if path_ok else "all_paths_ignored"
            )

        event_rows.append({
            "event": event,
            "eligible": branch_ok and path_ok,
            "branch_reason": branch_reason,
            "path_reason": path_reason,
            "matched_file_count": len(matched_files),
            "branches": branches,
            "branches_ignore": branches_ignore,
            "paths": paths,
            "paths_ignore": paths_ignore,
        })

    results.append({
        "workflow": workflow_path.relative_to(root).as_posix(),
        "name": document.get("name"),
        "has_pull_request_event": bool(event_rows),
        "eligible": any(row["eligible"] for row in event_rows),
        "pull_request_events": event_rows,
    })

pr_workflows = [row for row in results if row["has_pull_request_event"]]
eligible = [row for row in results if row["eligible"]]

assert len(changed_files) == 300
assert pr_workflows
assert not eligible, (
    "At least one pull-request workflow is eligible; "
    "the merge must wait for registered CI."
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-pr36-ci-eligibility-audit-v1"
    ),
    "status": (
        "no_ci_registration_expected_from_workflow_trigger_filters"
    ),
    "repository": os.environ["REPO"],
    "pull_request": int(os.environ["PR"]),
    "base_branch": base_branch,
    "base_head": os.environ["EXPECTED_BASE_HEAD"],
    "feature_head": os.environ["EXPECTED_FEATURE_HEAD"],
    "changed_file_count": len(changed_files),
    "workflow_file_count": len(results),
    "pull_request_workflow_count": len(pr_workflows),
    "eligible_pull_request_workflow_count": 0,
    "workflow_results": results,
    "registered_ci": {
        "object_count": 0,
        "failure_count": 0,
    },
    "decision": {
        "ci_absence_is_expected": True,
        "merge_requires_full_local_regression": True,
        "merge_requires_exact_scope_and_hash_validation": True,
        "merge_requires_mergeable_clean": True,
    },
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT PR #36 CI ELIGIBILITY AUDIT",
        "=" * 82,
        f"repository={report['repository']}",
        "pull_request=36",
        f"base_branch={base_branch}",
        f"base_head={report['base_head']}",
        f"feature_head={report['feature_head']}",
        "changed_file_count=300",
        f"workflow_file_count={len(results)}",
        f"pull_request_workflow_count={len(pr_workflows)}",
        "eligible_pull_request_workflow_count=0",
        "registered_ci_object_count=0",
        "ci_failure_count=0",
        "ci_absence_is_expected=true",
        "blocker_count=0",
        "audit_complete=true",
        "",
    ]),
    encoding="utf-8",
)

print("workflow_trigger_eligibility_audit=PASS")
print(f"workflow_file_count={len(results)}")
print(f"pull_request_workflow_count={len(pr_workflows)}")
print("eligible_pull_request_workflow_count=0")
print("registered_ci_object_count=0")
print("ci_absence_is_expected=true")
print(f"ci_audit_report={report_path}")
print(
    "ci_audit_report_sha256="
    + hashlib.sha256(report_path.read_bytes()).hexdigest()
)
print(f"ci_audit_surface={surface_path}")
print(
    "ci_audit_surface_sha256="
    + hashlib.sha256(surface_path.read_bytes()).hexdigest()
)
PY

  jq -e '
    .pull_request == 36
    and .changed_file_count == 300
    and .eligible_pull_request_workflow_count == 0
    and .registered_ci.object_count == 0
    and .registered_ci.failure_count == 0
    and .decision.ci_absence_is_expected == true
    and .blocker_count == 0
    and .audit_complete == true
  ' "$CI_AUDIT_REPORT" >/dev/null

  echo "workflow_ineligibility_gate=PASS"
fi

echo "ci_mode=$CI_MODE"

echo
echo "=== 6. Full local regression before merge ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

verify_sha "$EVIDENCE_MANIFEST" "$EXPECTED_EVIDENCE_MANIFEST_SHA"
verify_sha "$MATERIALIZATION_REPORT" "$EXPECTED_MATERIALIZATION_REPORT_SHA"
verify_sha "$MATERIALIZATION_SUMMARY" "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
verify_sha "$CANONICAL_RUN_MANIFEST" "$EXPECTED_CANONICAL_RUN_MANIFEST_SHA"

sha256sum -c "$CANONICAL_RUN_MANIFEST" >/dev/null
test -z "$(git status --porcelain)"

echo "pre_merge_full_regression_gate=PASS"

echo
echo "=== 7. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1
echo "mergeability_gate=PASS"

echo
echo "=== 8. Merge exact PR #36 head ==="

MERGE_RESULT="$(
  gh api \
    --method PUT \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/pulls/$PR/merge" \
    -f merge_method=merge \
    -f sha="$EXPECTED_FEATURE_HEAD"
)"

jq -e '.merged == true' <<<"$MERGE_RESULT" >/dev/null

REMOTE_MERGE_COMMIT="$(jq -r '.sha' <<<"$MERGE_RESULT")"
test -n "$REMOTE_MERGE_COMMIT"
test "$REMOTE_MERGE_COMMIT" != "null"

echo "merge_command=PASS"
echo "remote_merge_commit=$REMOTE_MERGE_COMMIT"

echo
echo "=== 9. Delete remote evidence branch ==="

git fetch origin --prune

if [ -n "$(git ls-remote --heads origin "$BRANCH")" ]; then
  git push origin --delete "$BRANCH"
fi

test -z "$(git ls-remote --heads origin "$BRANCH")"
echo "remote_branch_cleanup=PASS"

echo
echo "=== 10. Update and validate base lineage ==="

git switch "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"
test "$BASE_HEAD" = "$REMOTE_MERGE_COMMIT"

read -r MERGE_COMMIT FIRST_PARENT SECOND_PARENT EXTRA_PARENT \
  <<<"$(git rev-list --parents -n 1 "$BASE_HEAD")"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 11. Post-merge exact functional-evidence integrity ==="

while IFS= read -r FILE; do
  test -f "$FILE"
  git ls-files --error-unmatch "$FILE" >/dev/null
done < "$TMP_ROOT/expected_files.txt"

verify_sha "$EVIDENCE_MANIFEST" "$EXPECTED_EVIDENCE_MANIFEST_SHA"
verify_sha "$MATERIALIZATION_REPORT" "$EXPECTED_MATERIALIZATION_REPORT_SHA"
verify_sha "$MATERIALIZATION_SUMMARY" "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
verify_sha "$CANONICAL_RUN_MANIFEST" "$EXPECTED_CANONICAL_RUN_MANIFEST_SHA"
verify_sha "$AUTH_REPORT" "$EXPECTED_AUTH_REPORT_SHA"
verify_sha "$AUTH_SURFACE" "$EXPECTED_AUTH_SURFACE_SHA"
verify_sha "$EXEC_LEDGER" "$EXPECTED_EXEC_LEDGER_SHA"
verify_sha "$EXEC_SURFACE" "$EXPECTED_EXEC_SURFACE_SHA"
verify_sha "$POST_REPORT" "$EXPECTED_POST_REPORT_SHA"
verify_sha "$POST_SURFACE" "$EXPECTED_POST_SURFACE_SHA"

sha256sum -c "$CAMPAIGN_HASHES" >/dev/null
sha256sum -c "$CANONICAL_RUN_MANIFEST" >/dev/null

test "$(find "$RUN_ROOT" -type f | wc -l)" -eq 280
test "$(find "$EVIDENCE_ROOT" -type f | wc -l)" -eq 18

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA_BEFORE"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA_BEFORE"
test -z "$(git status --porcelain)"

echo "post_merge_functional_evidence_integrity_gate=PASS"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "total_merged_file_count=300"

echo
echo "=== 12. Post-merge full regression ==="

"$PYTHON" backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"
echo "post_merge_full_regression_gate=PASS"

echo
echo "=== 13. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

echo "pr_final_state=PASS"

echo
echo "=== 14. Cleanup local evidence branch ==="

if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"
echo "local_branch_cleanup=PASS"

echo
echo "=== 15. Final state ==="

echo "sa5_objective_count_stage10_functional_evidence_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "pull_request=$PR"
echo "ci_mode=$CI_MODE"

if [ "$CI_MODE" = "workflow_ineligible" ]; then
  echo "ci_audit_report=$CI_AUDIT_REPORT"
  echo "ci_audit_report_sha256=$(sha256sum "$CI_AUDIT_REPORT" | awk '{print $1}')"
  echo "ci_audit_surface=$CI_AUDIT_SURFACE"
  echo "ci_audit_surface_sha256=$(sha256sum "$CI_AUDIT_SURFACE" | awk '{print $1}')"
fi

echo "pre_merge_full_regression=PASS"
echo "post_merge_full_regression=PASS"

echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_merged_file_count=300"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"
echo "total_output_bytes=25018782"

echo "evidence_manifest_sha256=$EXPECTED_EVIDENCE_MANIFEST_SHA"
echo "materialization_report_sha256=$EXPECTED_MATERIALIZATION_REPORT_SHA"
echo "materialization_summary_sha256=$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

echo "canonical_stage10_functional_execution_performed=true"
echo "functional_execution_completion_audited=true"
echo "functional_execution_evidence_materialized=true"
echo "functional_execution_evidence_committed=true"

echo "timing_analysis_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"

echo "analysis_readiness_audit_eligible=true"
echo "next_stage=audit_sa5_objective_count_stage10_post_merge_analysis_readiness"

git status --short --branch
git log --oneline --decorate -6
