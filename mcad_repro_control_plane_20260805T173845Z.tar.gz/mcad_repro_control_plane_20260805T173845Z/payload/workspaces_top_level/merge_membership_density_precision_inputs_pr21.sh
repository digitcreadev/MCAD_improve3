#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=21

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-membership-density-precision-adapter-20260804T135930Z"

EXPECTED_HEAD="6d4c90629672ff27e846ca73af668975b3446dd4"
EXPECTED_BASE_HEAD="4f1b8fef37f0feac0be7019ac3d6d9fe51dc12a4"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/membership_density/timing_stage10/precision_analysis"

OBSERVATIONS="$PRECISION_ROOT/stage10_portfolio_measurement_observations.csv"
TIMING_ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"

EXPECTED_OBSERVATIONS_SHA="757c8e7684396cf1b5d7a923a4b7935a95b746896fac357c7ef4ea93df36133a"
EXPECTED_TIMING_ADAPTER_SHA="0bd99f578b6aca3913536fd8b237f89a9607db369a1fa4ad2243b9ceb295f9c3"
EXPECTED_MANIFEST_SHA="449d0d54bb10df84327e3d757382e33c78abe9d2c9b3c5f55e3d8d5ee6ac2451"
EXPECTED_OBSERVATIONS_SIZE=55447769

trap 'echo "[ERROR] PR #21 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local materialization gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$OBSERVATIONS" | awk '{print $1}'
)" = "$EXPECTED_OBSERVATIONS_SHA"

test "$(
  sha256sum "$TIMING_ADAPTER" | awk '{print $1}'
)" = "$EXPECTED_TIMING_ADAPTER_SHA"

test "$(
  sha256sum "$INPUT_MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

test "$(stat -c '%s' "$OBSERVATIONS")" -eq "$EXPECTED_OBSERVATIONS_SIZE"

CHANGED_FILES="$(
  git diff --name-only "$EXPECTED_BASE_HEAD..$EXPECTED_HEAD"
)"

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)" -eq 3

for FILE in \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"
do
  test "$(
    printf '%s\n' "$CHANGED_FILES" |
      grep -Fx "$FILE" |
      wc -l
  )" -eq 1
done

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_inputs_materialized"
  and .factor == "membership_density"
  and .adapter_contract.source_timing_csv_count == 10
  and .adapter_contract.source_total_observation_count == 101200
  and .adapter_contract.source_warmup_observation_count == 9200
  and .adapter_contract.source_measurement_observation_count == 92000
  and .adapter_contract.derived_measurement_observation_count == 92000
  and .adapter_contract.analyzer_timing_cell_count == 40
  and .adapter_contract.inferential_cell_count == 4
  and .adapter_contract.structural_seed_count == 10
  and .adapter_contract.measurements_per_cluster == 2300
  and .adapter_contract.measurements_per_inferential_cell == 23000
  and .join_audit.unmatched_row_count == 0
  and .join_audit.ambiguous_plan_key_count == 0
  and .join_audit.step_id_mismatch_count == 0
  and .join_audit.duplicate_source_row_count == 0
  and .immutability_audit.raw_timing_csv_files_modified == false
  and .immutability_audit.precision_analyzer_modified == false
  and .materialization_decision.adapter_inputs_complete == true
  and .materialization_decision.adapter_inputs_validated == true
  and .materialization_decision.precision_analysis_ready_for_authorization
      == true
  and .materialization_decision.precision_analysis_authorized == false
  and .scientific_controls.adapter_materialization_performed == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "audit_and_authorize_membership_density_portfolio_precision_analysis"
' "$INPUT_MANIFEST" >/dev/null

jq -e '
  .status == "stage10_formal_timing_execution_success"
  and .factor == "membership_density"
  and .totals.run_count == 10
  and .totals.successful_run_count == 10
  and .totals.cell_count == 40
  and .totals.measurement_observation_count == 92000
  and .totals.functional_mismatch_count == 0
  and .totals.exactly_balanced_run_count == 10
  and .totals.structural_seed_count == 10
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$TIMING_ADAPTER" >/dev/null

echo "local_materialization_gate=PASS"
echo "changed_file_count=3"
echo "observations_size_bytes=$EXPECTED_OBSERVATIONS_SIZE"
echo "derived_measurement_observation_count=92000"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS=""

if CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null
)"; then
  :
fi

if [ -z "$CHECKS" ]; then
  CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$CHECKS"
)"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "precision_adapter_inputs_ci=PASS"
else
  echo "precision_adapter_inputs_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #21 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "materialization_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged adapter inputs ==="

for FILE in \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$OBSERVATIONS" | awk '{print $1}'
)" = "$EXPECTED_OBSERVATIONS_SHA"

test "$(
  sha256sum "$TIMING_ADAPTER" | awk '{print $1}'
)" = "$EXPECTED_TIMING_ADAPTER_SHA"

test "$(
  sha256sum "$INPUT_MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

test "$(stat -c '%s' "$OBSERVATIONS")" -eq "$EXPECTED_OBSERVATIONS_SIZE"

jq -e '
  .materialization_decision.adapter_inputs_materialized == true
  and .materialization_decision.adapter_inputs_complete == true
  and .materialization_decision.adapter_inputs_validated == true
  and .materialization_decision.precision_analysis_ready_for_authorization
      == true
  and .materialization_decision.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "audit_and_authorize_membership_density_portfolio_precision_analysis"
' "$INPUT_MANIFEST" >/dev/null

echo "merged_precision_adapter_inputs=PASS"
echo "observations_sha256=$EXPECTED_OBSERVATIONS_SHA"
echo "timing_adapter_sha256=$EXPECTED_TIMING_ADAPTER_SHA"
echo "precision_input_manifest_sha256=$EXPECTED_MANIFEST_SHA"
echo "derived_measurement_observation_count=92000"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

test -z "$(git status --porcelain)"

echo "membership_density_precision_adapter_inputs_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "adapter_materialization_performed=true"
echo "derived_measurement_observation_count=92000"
echo "analyzer_timing_cell_count=40"
echo "inferential_cell_count=4"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=audit_and_authorize_membership_density_portfolio_precision_analysis"

git status --short --branch
git log --oneline --decorate -5
