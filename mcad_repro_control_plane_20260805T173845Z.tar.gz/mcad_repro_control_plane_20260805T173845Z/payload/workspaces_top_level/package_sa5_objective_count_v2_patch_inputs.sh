#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

SURFACE_ROOT="/workspaces/sa5_objective_count_v2_implementation_surface_20260804T211657Z"

REPORT="$SURFACE_ROOT/sa5_objective_count_v2_implementation_surface.json"
SURFACE="$SURFACE_ROOT/sa5_objective_count_v2_implementation_surface.txt"

EXPECTED_REPORT_SHA="3a5268fc56810719dc5532872a0b4d92fb43aec9f7f8dcbd90757f458c3e1866"
EXPECTED_SURFACE_SHA="f5268603b03774f5152456fc341f9507cd34c23e394b0035d99f606bf5317c5c"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BUNDLE_ROOT="/workspaces/sa5_objective_count_v2_patch_input_bundle_${STAMP}"
PAYLOAD="$BUNDLE_ROOT/payload"

ARCHIVE="/workspaces/sa5_objective_count_v2_patch_input_bundle_${STAMP}.tar.gz"

trap 'echo "[ERROR] SA5 v2 patch-input packaging stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact read-only packaging gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$REPORT" \
  "$SURFACE" \
  "$PREREG" \
  "$AMENDMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_REPORT_SHA"

test "$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_SURFACE_SHA"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "packaging_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report_sha256=$EXPECTED_REPORT_SHA"
echo "surface_sha256=$EXPECTED_SURFACE_SHA"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Confirm resolved workload contract ==="

jq -e '
  .status
    == "sa5_objective_count_v2_implementation_surface_resolved"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .blockers == []
  and .implementation_strategy.expected_total_patch_file_count
    == 13
  and .implementation_strategy.new_file_count
    == 9
  and .implementation_strategy.modified_file_count
    == 4
  and .resolved_workload_contract.replication_count
    == 10
  and .resolved_workload_contract.workload_count
    == 10
  and .resolved_workload_contract.workload_length
    == 40
  and .resolved_workload_contract.contributive_query_count
    == 30
  and .resolved_workload_contract.non_contributive_query_count
    == 10
  and .resolved_workload_contract.stage10_noise_query_count
    == 100
  and .resolved_workload_contract.integer_allocation_method
    == "base_one_per_class_plus_two_cyclic_extras_by_replication_index"
  and .amendment_binding.canonical_materialization_authorized
    == false
  and .amendment_binding.functional_execution_authorized
    == false
  and .canonical_campaign_generated
    == false
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch"
' "$REPORT" >/dev/null

echo "resolved_workload_contract_gate=PASS"
echo "replication_count=$(jq -r '.resolved_workload_contract.replication_count' "$REPORT")"
echo "workload_count=$(jq -r '.resolved_workload_contract.workload_count' "$REPORT")"
echo "workload_length=$(jq -r '.resolved_workload_contract.workload_length' "$REPORT")"
echo "contributive_query_count=$(jq -r '.resolved_workload_contract.contributive_query_count' "$REPORT")"
echo "non_contributive_query_count=$(jq -r '.resolved_workload_contract.non_contributive_query_count' "$REPORT")"
echo "stage10_noise_query_count=$(jq -r '.resolved_workload_contract.stage10_noise_query_count' "$REPORT")"
echo "compact_null_classification=jq_projection_only"

echo
echo "=== 3. Initialize detached bundle ==="

rm -rf "$BUNDLE_ROOT"
rm -f "$ARCHIVE"

mkdir -p \
  "$PAYLOAD/repository" \
  "$PAYLOAD/detached_projection" \
  "$PAYLOAD/metadata"

echo "bundle_root=$BUNDLE_ROOT"

echo
echo "=== 4. Resolve exact source and import closure ==="

cat > "$BUNDLE_ROOT/seed_files.txt" <<'EOF'
.github/workflows/phase3-regression.yml
backend/harness/sensitivity_design/design_matrix.yaml
backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml
backend/harness/sensitivity_execution/execute_controlled_family.py
backend/harness/sensitivity_execution/validate_e3_contract.py
backend/harness/sensitivity_execution/validate_execution_spec.py
backend/harness/sensitivity_execution/validate_workload_spec.py
backend/harness/sensitivity_execution/workload_spec.schema.json
backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py
backend/harness/sensitivity_execution/tests/test_workload_spec.py
backend/harness/sensitivity_execution/tools/prepare_virtual_node_count_stage10_common_workloads.py
backend/harness/sensitivity_execution/tools/audit_membership_density_common_workload.py
backend/harness/sensitivity_generator/objective_count_generator.py
backend/harness/sensitivity_generator/families/objective_count_family.py
backend/harness/sensitivity_generator/families/controlled_families.py
backend/harness/sensitivity_generator/tests/test_objective_count_family.py
backend/ckg/ckg_updater.py
reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json
reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json
EOF

export ROOT
export SEED_LIST="$BUNDLE_ROOT/seed_files.txt"
export RESOLVED_LIST="$BUNDLE_ROOT/resolved_files.txt"

python3 - <<'PY'
from __future__ import annotations

import ast
import os
from collections import deque
from pathlib import Path

root = Path(os.environ["ROOT"]).resolve()
seed_list = Path(os.environ["SEED_LIST"])
resolved_list = Path(os.environ["RESOLVED_LIST"])

seed_paths = [
    Path(line.strip())
    for line in seed_list.read_text(
        encoding="utf-8"
    ).splitlines()
    if line.strip()
]

for relative in seed_paths:
    path = root / relative

    if not path.is_file():
        raise SystemExit(
            f"Missing seed file: {relative}"
        )


def module_candidates(
    module_name: str,
) -> tuple[Path, ...]:
    relative = Path(
        *module_name.split(".")
    )

    return (
        relative.with_suffix(".py"),
        relative / "__init__.py",
    )


def resolve_relative_import(
    *,
    current_file: Path,
    level: int,
    module: str | None,
) -> str | None:
    try:
        relative_current = current_file.relative_to(
            root
        )
    except ValueError:
        return None

    package_parts = list(
        relative_current.parent.parts
    )

    if level < 1:
        return module

    remove_count = level - 1

    if remove_count > len(package_parts):
        return None

    if remove_count:
        package_parts = package_parts[
            : -remove_count
        ]

    if module:
        package_parts.extend(
            module.split(".")
        )

    if not package_parts:
        return None

    return ".".join(package_parts)


resolved: set[Path] = set(seed_paths)
queue: deque[Path] = deque(
    relative
    for relative in seed_paths
    if relative.suffix == ".py"
)

while queue:
    relative = queue.popleft()
    path = root / relative

    try:
        tree = ast.parse(
            path.read_text(encoding="utf-8"),
            filename=str(path),
        )
    except (SyntaxError, UnicodeDecodeError) as exc:
        raise SystemExit(
            f"Cannot parse {relative}: {exc}"
        ) from exc

    modules: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(
                alias.name
                for alias in node.names
                if alias.name.startswith(
                    ("backend.",)
                )
            )

        elif isinstance(node, ast.ImportFrom):
            module_name = resolve_relative_import(
                current_file=path,
                level=node.level,
                module=node.module,
            )

            if module_name:
                modules.add(module_name)

                for alias in node.names:
                    if alias.name == "*":
                        continue

                    modules.add(
                        f"{module_name}.{alias.name}"
                    )

    for module_name in sorted(modules):
        for candidate in module_candidates(
            module_name
        ):
            candidate_path = root / candidate

            if not candidate_path.is_file():
                continue

            if candidate not in resolved:
                resolved.add(candidate)

                if candidate.suffix == ".py":
                    queue.append(candidate)

            break

resolved_list.write_text(
    "\n".join(
        sorted(
            path.as_posix()
            for path in resolved
        )
    )
    + "\n",
    encoding="utf-8",
)

print(
    "source_import_closure_resolution=PASS"
)
print(
    f"seed_file_count={len(seed_paths)}"
)
print(
    f"resolved_file_count={len(resolved)}"
)
PY

RESOLVED_FILE_COUNT="$(
  wc -l < "$BUNDLE_ROOT/resolved_files.txt"
)"

test "$RESOLVED_FILE_COUNT" -ge 21

echo "source_import_closure_gate=PASS"
echo "resolved_file_count=$RESOLVED_FILE_COUNT"

echo
echo "=== 5. Copy exact repository sources ==="

while IFS= read -r RELATIVE; do
  test -n "$RELATIVE"
  test -f "$ROOT/$RELATIVE"

  mkdir -p \
    "$PAYLOAD/repository/$(dirname "$RELATIVE")"

  cp \
    "$ROOT/$RELATIVE" \
    "$PAYLOAD/repository/$RELATIVE"
done < "$BUNDLE_ROOT/resolved_files.txt"

cp \
  "$BUNDLE_ROOT/resolved_files.txt" \
  "$PAYLOAD/metadata/resolved_files.txt"

cp \
  "$BUNDLE_ROOT/seed_files.txt" \
  "$PAYLOAD/metadata/seed_files.txt"

echo "repository_source_copy=PASS"

echo
echo "=== 6. Copy detached projection artifacts ==="

cp \
  "$REPORT" \
  "$PAYLOAD/detached_projection/sa5_objective_count_v2_implementation_surface.json"

cp \
  "$SURFACE" \
  "$PAYLOAD/detached_projection/sa5_objective_count_v2_implementation_surface.txt"

echo "detached_projection_copy=PASS"

echo
echo "=== 7. Generate integrity metadata ==="

git status --short --branch \
  > "$PAYLOAD/metadata/git_status.txt"

git log \
  --oneline \
  --decorate \
  -12 \
  > "$PAYLOAD/metadata/git_log.txt"

git show \
  --no-ext-diff \
  --stat \
  --summary \
  "$EXPECTED_HEAD" \
  > "$PAYLOAD/metadata/base_head_summary.txt"

git show \
  --no-ext-diff \
  --format=fuller \
  --no-patch \
  "$EXPECTED_HEAD" \
  > "$PAYLOAD/metadata/base_head_commit.txt"

(
  cd "$PAYLOAD"

  find . \
    -type f \
    ! -path './metadata/PAYLOAD_SHA256SUMS' \
    -print0 |
    sort -z |
    xargs -0 sha256sum \
    > metadata/PAYLOAD_SHA256SUMS
)

PAYLOAD_FILE_COUNT="$(
  find "$PAYLOAD" \
    -type f |
    wc -l
)"

PAYLOAD_SIZE_BYTES="$(
  du -sb "$PAYLOAD" |
    awk '{print $1}'
)"

export PAYLOAD
export PAYLOAD_FILE_COUNT
export PAYLOAD_SIZE_BYTES
export EXPECTED_HEAD
export EXPECTED_REPORT_SHA
export EXPECTED_SURFACE_SHA
export EXPECTED_PREREG_SHA
export EXPECTED_AMENDMENT_SHA
export RESOLVED_FILE_COUNT

python3 - <<'PY'
from __future__ import annotations

import json
import os
from pathlib import Path

payload = Path(os.environ["PAYLOAD"])

manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "patch-input-bundle-v1"
    ),
    "source_commit": os.environ[
        "EXPECTED_HEAD"
    ],
    "repository_branch": (
        "paper/phase3-controlled-execution"
    ),
    "read_only_collection": True,
    "implementation_surface_report_sha256": (
        os.environ["EXPECTED_REPORT_SHA"]
    ),
    "implementation_surface_text_sha256": (
        os.environ["EXPECTED_SURFACE_SHA"]
    ),
    "preregistration_sha256": (
        os.environ["EXPECTED_PREREG_SHA"]
    ),
    "amendment_sha256": (
        os.environ["EXPECTED_AMENDMENT_SHA"]
    ),
    "resolved_repository_file_count": int(
        os.environ["RESOLVED_FILE_COUNT"]
    ),
    "payload_file_count_before_manifest": int(
        os.environ["PAYLOAD_FILE_COUNT"]
    ),
    "payload_size_bytes_before_manifest": int(
        os.environ["PAYLOAD_SIZE_BYTES"]
    ),
    "implementation_plan": {
        "new_file_count": 9,
        "modified_file_count": 4,
        "expected_total_patch_file_count": 13,
        "preserve_v1_module_bytes": True,
        "canonical_campaign_materialization_authorized": False,
        "functional_execution_authorized": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "campaign_materialization_performed": False,
        "functional_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": (
        "author_sa5_objective_count_"
        "materialization_contract_v2_patch"
    ),
}

(
    payload
    / "metadata"
    / "BUNDLE_MANIFEST.json"
).write_text(
    json.dumps(
        manifest,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)
PY

(
  cd "$PAYLOAD"

  sha256sum \
    metadata/BUNDLE_MANIFEST.json \
    >> metadata/PAYLOAD_SHA256SUMS
)

echo "integrity_metadata_generation=PASS"
echo "payload_file_count=$(find "$PAYLOAD" -type f | wc -l)"
echo "payload_size_bytes=$(du -sb "$PAYLOAD" | awk '{print $1}')"

echo
echo "=== 8. Create deterministic archive ==="

tar \
  --sort=name \
  --mtime='UTC 1970-01-01' \
  --owner=0 \
  --group=0 \
  --numeric-owner \
  -czf "$ARCHIVE" \
  -C "$BUNDLE_ROOT" \
  payload

ARCHIVE_SHA="$(
  sha256sum "$ARCHIVE" |
    awk '{print $1}'
)"

ARCHIVE_SIZE="$(
  stat -c '%s' "$ARCHIVE"
)"

test "$ARCHIVE_SIZE" -gt 0

echo "archive_creation=PASS"
echo "archive=$ARCHIVE"
echo "archive_sha256=$ARCHIVE_SHA"
echo "archive_size_bytes=$ARCHIVE_SIZE"

echo
echo "=== 9. Verify archive independently ==="

VERIFY_ROOT="$BUNDLE_ROOT/verify"

mkdir -p "$VERIFY_ROOT"

tar \
  -xzf "$ARCHIVE" \
  -C "$VERIFY_ROOT"

test -f \
  "$VERIFY_ROOT/payload/metadata/BUNDLE_MANIFEST.json"

test -f \
  "$VERIFY_ROOT/payload/detached_projection/sa5_objective_count_v2_implementation_surface.json"

test -f \
  "$VERIFY_ROOT/payload/detached_projection/sa5_objective_count_v2_implementation_surface.txt"

(
  cd "$VERIFY_ROOT/payload"

  sha256sum \
    --check \
    metadata/PAYLOAD_SHA256SUMS
)

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-patch-input-bundle-v1"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .read_only_collection
    == true
  and .implementation_plan.new_file_count
    == 9
  and .implementation_plan.modified_file_count
    == 4
  and .implementation_plan.expected_total_patch_file_count
    == 13
  and .implementation_plan.preserve_v1_module_bytes
    == true
  and .implementation_plan.canonical_campaign_materialization_authorized
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch"
' \
  "$VERIFY_ROOT/payload/metadata/BUNDLE_MANIFEST.json" \
  >/dev/null

echo "archive_independent_verification=PASS"

echo
echo "=== 10. Final repository immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 11. Final state ==="

echo "sa5_objective_count_v2_patch_input_bundle=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "bundle_root=$BUNDLE_ROOT"
echo "archive=$ARCHIVE"
echo "archive_sha256=$ARCHIVE_SHA"
echo "archive_size_bytes=$ARCHIVE_SIZE"
echo "resolved_file_count=$RESOLVED_FILE_COUNT"
echo "expected_patch_file_count=13"
echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=author_sa5_objective_count_materialization_contract_v2_patch"

git status --short --branch
