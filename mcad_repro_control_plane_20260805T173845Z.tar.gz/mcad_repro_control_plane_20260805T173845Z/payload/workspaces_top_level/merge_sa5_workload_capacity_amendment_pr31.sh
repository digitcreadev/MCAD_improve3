#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PR=31

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-sa5-objective-count-workload-capacity-amendment-20260804T224846Z"

EXPECTED_BASE_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"
EXPECTED_FEATURE_HEAD="dead48d1145cc0022e83ac97feac041cbbea0235"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_capacity_pr31.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #31 merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

printf '%s\n' \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_002" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

echo "=== 1. Local capacity-amendment gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort \
  > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(
  wc -l < "$TMP_ROOT/actual_files.txt"
)" -eq 2

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_capacity_amendment_gate=PASS"
echo "changed_file_count=2"
echo "capacity_amendment_sha256=$EXPECTED_AMENDMENT_002_SHA"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Exact capacity-amendment content gate ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-workload-contribution-capacity-amendment-v1"
  and .amendment_id
    == "sa5_objective_count_workload_contribution_capacity_amendment_002"
  and .status
    == "preregistered_implementation_required"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"

  and .amends.original_preregistration.artifact_sha256
    == "a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"
  and .amends.materialization_contract_amendment_001.artifact_sha256
    == "2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

  and .capacity_audit_provenance.old_workload_length
    == 40
  and .capacity_audit_provenance.old_non_contributive_query_count
    == 10
  and .capacity_audit_provenance.old_oracle_contributive_query_count
    == 30
  and .capacity_audit_provenance.useful_union_capacity
    == 24
  and .capacity_audit_provenance.current_evaluator_support_capacity
    == 16
  and .capacity_audit_provenance.useful_union_deficit
    == 6
  and .capacity_audit_provenance.current_evaluator_support_deficit
    == 14

  and .factor_scoped_support_contract.metadata_field
    == "session_support_policy"
  and .factor_scoped_support_contract.objective_count_v2_value
    == "union_requirement_sets"
  and .factor_scoped_support_contract.historical_default_value
    == "shortest_requirement_set_then_lexicographic_tie_break"
  and .factor_scoped_support_contract.requirement_set_membership_indices
    == [[0, 1], [1, 2]]
  and .factor_scoped_support_contract.support_local_virtual_node_indices
    == [0, 1, 2]
  and .factor_scoped_support_contract.support_resources_per_constraint
    == 3
  and .factor_scoped_support_contract.constraint_count
    == 8
  and .factor_scoped_support_contract.support_resources_per_objective
    == 24
  and .factor_scoped_support_contract.historical_profiles_must_remain_unchanged
    == true
  and .factor_scoped_support_contract.factor_local_dispatch_required
    == true
  and .factor_scoped_support_contract.missing_or_unknown_policy_must_use_historical_default
    == true

  and .revised_workload_contract.workload_length
    == 32
  and .revised_workload_contract.requested_noise_ratio
    == 0.25
  and .revised_workload_contract.non_contributive_query_count
    == 8
  and .revised_workload_contract.oracle_contributive_query_count
    == 24
  and .revised_workload_contract.realised_noise_ratio
    == 0.25
  and .revised_workload_contract.contributive_capacity
    == 24
  and .revised_workload_contract.capacity_equality_required
    == true
  and (
    .revised_workload_contract.support_coordinates
    | length
  ) == 24
  and .revised_workload_contract.integer_allocation_method
    == "exact_one_per_class_per_replication"
  and (
    .revised_workload_contract.counts_by_replication
    | length
  ) == 10
  and .revised_workload_contract.stage10_total_noise_query_count
    == 80
  and .revised_workload_contract.stage10_minimum_class_count
    == 10
  and .revised_workload_contract.stage10_maximum_class_count
    == 10
  and .revised_workload_contract.stage10_maximum_pairwise_class_imbalance
    == 0
  and .revised_workload_contract.noise_position_selection.position_domain
    == "1..32"
  and .revised_workload_contract.noise_position_selection.selection_count
    == 8

  and .implementation_contract.target_structural_generator_version
    == "mcad-sensitivity-e2.1-objective-count-v2"
  and .implementation_contract.target_campaign_generator_version
    == "mcad-sensitivity-e2.2-objective-count-v2"
  and .implementation_contract.prior_17_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true
  and .implementation_contract.preserve_v1_generator_module_bytes
    == true
  and .implementation_contract.preserve_historical_factor_behavior
    == true
  and .implementation_contract.preserve_membership_density_profile
    == true

  and .authorization.amendment_persistence_authorized
    == true
  and .authorization.v2_implementation_authorized_after_amendment_merge
    == true
  and .authorization.v2_patch_authoring_authorized_before_amendment_merge
    == false
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.stage20_execution_authorized
    == false
  and .authorization.latency_claim_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false

  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.campaign_materialization_performed
    == false
  and .scientific_controls.canonical_stage10_bootstrap_performed
    == false
  and .scientific_controls.functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_capacity_amendment_merge"
' "$AMENDMENT_002" >/dev/null

echo "capacity_amendment_content_gate=PASS"
echo "revised_workload_length=32"
echo "revised_contributive_query_count=24"
echo "revised_non_contributive_query_count=8"
echo "revised_noise_ratio=0.25"
echo "factor_scoped_support_policy=union_requirement_sets"
echo "prior_17_file_scope_authoritative=false"

echo
echo "=== 3. Pre-merge amendment test gate ==="

"$PYTHON" -m py_compile \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST"

"$PYTHON" -m pytest \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

echo "pre_merge_capacity_amendment_tests=PASS"

echo
echo "=== 4. Remote lineage gate ==="

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_BASE_HEAD"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$EXPECTED_FEATURE_HEAD"

echo "remote_lineage_gate=PASS"
echo "remote_base_head=$EXPECTED_BASE_HEAD"
echo "remote_feature_head=$EXPECTED_FEATURE_HEAD"

echo
echo "=== 5. Pull-request identity and scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count workload-capacity amendment"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 6. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' \
  >/dev/null 2>&1 \
  <<<"$CHECKS"
then
  CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$CHECKS"
)"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '
      [
        .[]
        | select(.bucket != "pass")
      ]
      | length
    ' <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "sa5_capacity_amendment_ci=PASS"
else
  echo "sa5_capacity_amendment_ci=NOT_APPLICABLE"
fi

echo
echo "=== 7. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 8. Merge PR #31 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 9. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 10. Post-merge capacity-amendment validation ==="

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST"
do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" >/dev/null
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

"$PYTHON" -m pytest \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "post_merge_capacity_amendment_validation=PASS"
echo "capacity_amendment_tracked=true"
echo "prior_artifacts_modified=false"
echo "canonical_campaign_generated=false"
echo "canonical_campaign_materialization_authorized=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 11. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 12. Cleanup local capacity-amendment branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo
echo "=== 13. Final state ==="

echo "sa5_workload_capacity_amendment_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "capacity_amendment_sha256=$EXPECTED_AMENDMENT_002_SHA"

echo "revised_workload_length=32"
echo "revised_contributive_query_count=24"
echo "revised_non_contributive_query_count=8"
echo "revised_noise_ratio=0.25"

echo "factor_scoped_support_policy=union_requirement_sets"
echo "support_resources_per_constraint=3"
echo "support_resources_per_objective=24"

echo "prior_17_file_scope_authoritative=false"
echo "scope_reprojection_eligible=true"
echo "v2_implementation_eligible=true"
echo "v2_patch_authoring_authorized=false"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"

echo "functional_execution_authorized=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=reproject_sa5_objective_count_v2_implementation_scope_after_capacity_amendment_merge"

git status --short --branch
git log --oneline --decorate -5
