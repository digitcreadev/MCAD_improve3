#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="bbe66c639c729322aeacb5f269e8e78ef3a3e42c"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

CAMPAIGN="$REPORTS/planning/formal_campaigns/membership_density_stage10_c4_nv24"
COMMON_AUDIT="$CAMPAIGN/audit/membership_density_common_workload_audit.json"

FUNCTIONAL_AUDIT="$REPORTS/planning/sa4_membership_density_controlled_execution_audit.json"
FUNCTIONAL_FREEZE="$REPORTS/planning/sa4_membership_density_controlled_execution_freeze.json"
FROZEN_MANIFEST="$REPORTS/planning/sa4_membership_density_controlled_execution_frozen_manifest.json"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

OUTPUT_JSON="$REPORTS/planning/sa4_membership_density_timing_preregistration_preflight.json"
OUTPUT_MD="$REPORTS/planning/sa4_membership_density_timing_preregistration_preflight.md"

trap 'echo "[ERROR] Temporal preflight stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$CAMPAIGN/campaign_manifest.json" \
  "$CAMPAIGN/campaign_spec.json" \
  "$COMMON_AUDIT" \
  "$FUNCTIONAL_AUDIT" \
  "$FUNCTIONAL_FREEZE" \
  "$FROZEN_MANIFEST" \
  "$RUNNER" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test -x "$PYTHON"
test ! -e "$OUTPUT_JSON"
test ! -e "$OUTPUT_MD"

echo "repository_gate=PASS"
echo "membership_density_functional_rerun_performed=false"
echo "membership_density_timing_execution_performed=false"
echo "membership_density_precision_analysis_performed=false"

echo
echo "=== 2. Create preflight branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-membership-density-timing-preflight-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Resolve balanced temporal design ==="

"$PYTHON" - \
  "$ROOT" \
  "$CAMPAIGN" \
  "$COMMON_AUDIT" \
  "$FUNCTIONAL_AUDIT" \
  "$FUNCTIONAL_FREEZE" \
  "$FROZEN_MANIFEST" \
  "$RUNNER" \
  "$ANALYZER" \
  "$OUTPUT_JSON" \
  "$OUTPUT_MD" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
campaign_root = root / sys.argv[2]
common_audit_path = root / sys.argv[3]
functional_audit_path = root / sys.argv[4]
functional_freeze_path = root / sys.argv[5]
frozen_manifest_path = root / sys.argv[6]
runner_path = root / sys.argv[7]
analyzer_path = root / sys.argv[8]
output_json = root / sys.argv[9]
output_md = root / sys.argv[10]
source_commit = sys.argv[11]
created_utc = sys.argv[12]

reports_root = (
    root
    / "reports/article_experiments/sensitivity/"
      "e3_controlled_execution"
)

execution_plan_path = (
    reports_root
    / "audits/membership_density/by_replication/"
      "replication_execution_plan.json"
)

workloads_root = reports_root / "workloads"
specs_root = reports_root / "execution_specs"


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


manifest = load_json(
    campaign_root / "campaign_manifest.json"
)

campaign_spec = load_json(
    campaign_root / "campaign_spec.json"
)

common_audit = load_json(common_audit_path)
functional_audit = load_json(functional_audit_path)
functional_freeze = load_json(functional_freeze_path)
frozen_manifest = load_json(frozen_manifest_path)
execution_plan = load_json(execution_plan_path)

levels = (
    manifest.get("levels")
    or campaign_spec.get("levels")
)

seeds = (
    manifest.get("seeds")
    or campaign_spec.get("seeds")
)

expected_levels = [25, 50, 75, 100]

expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

if levels != expected_levels:
    raise SystemExit(
        f"Unexpected levels: {levels}"
    )

if seeds != expected_seeds:
    raise SystemExit(
        f"Unexpected seeds: {seeds}"
    )

if manifest.get("factor") != "membership_density":
    raise SystemExit(
        "Unexpected campaign factor."
    )

if manifest.get("replication_count") != 10:
    raise SystemExit(
        "Expected ten structural replications."
    )

if manifest.get("realised_instance_count") != 40:
    raise SystemExit(
        "Expected forty structural instances."
    )

if functional_audit.get("status") != (
    "sa4_membership_density_"
    "controlled_execution_audit_success"
):
    raise SystemExit(
        "Functional audit is not successful."
    )

if functional_audit.get("instance_count") != 40:
    raise SystemExit(
        "Functional audit instance count mismatch."
    )

if functional_audit.get("partition_count") != 10:
    raise SystemExit(
        "Functional audit partition count mismatch."
    )

if functional_audit.get("total_step_count") != 952:
    raise SystemExit(
        "Expected 952 frozen functional steps."
    )

if functional_audit.get("scientific_freeze") is not False:
    raise SystemExit(
        "Temporal scientific freeze must remain false."
    )

if functional_freeze.get(
    "timing_execution_authorized"
) is not False:
    raise SystemExit(
        "Existing evidence unexpectedly authorizes timing."
    )

partitions = execution_plan.get("partitions")

if not isinstance(partitions, list):
    raise SystemExit(
        "Replication execution plan lacks partitions."
    )

if len(partitions) != 10:
    raise SystemExit(
        "Expected ten common-workload partitions."
    )

partitions_by_replication = {
    int(item["replication_index"]): item
    for item in partitions
}

if sorted(partitions_by_replication) != list(range(10)):
    raise SystemExit(
        "Common-workload replication matrix is incomplete."
    )

replication_records: list[dict[str, Any]] = []
step_sets: list[set[int]] = []
digest_sets: list[set[str]] = []
digest_by_replication_and_step: dict[
    tuple[int, int],
    str,
] = {}

for replication in range(10):
    partition = partitions_by_replication[
        replication
    ]

    workload_path = (
        workloads_root
        / f"membership_density_rep_"
          f"{replication:03d}_canonical.json"
    )

    execution_spec_path = (
        specs_root
        / f"membership_density_rep_"
          f"{replication:03d}_canonical.json"
    )

    if not workload_path.is_file():
        raise SystemExit(
            f"Missing workload: {workload_path}"
        )

    if not execution_spec_path.is_file():
        raise SystemExit(
            f"Missing execution spec: "
            f"{execution_spec_path}"
        )

    workload = load_json(workload_path)
    execution_spec = load_json(execution_spec_path)

    steps = workload.get("steps")

    if not isinstance(steps, list):
        raise SystemExit(
            f"Replication {replication}: "
            "workload lacks steps."
        )

    workload_indexes = [
        int(step["step_index"])
        for step in steps
    ]

    expected_indexes = list(
        range(1, len(steps) + 1)
    )

    if workload_indexes != expected_indexes:
        raise SystemExit(
            f"Replication {replication}: "
            "workload indexes are not contiguous."
        )

    equivalence = partition.get(
        "equivalence_metadata"
    )

    if not isinstance(equivalence, list):
        raise SystemExit(
            f"Replication {replication}: "
            "missing equivalence metadata."
        )

    audit_indexes = [
        int(item["step_index"])
        for item in equivalence
    ]

    if audit_indexes != expected_indexes:
        raise SystemExit(
            f"Replication {replication}: "
            "audit/workload step mismatch."
        )

    if int(partition["step_count"]) != len(steps):
        raise SystemExit(
            f"Replication {replication}: "
            "partition step-count mismatch."
        )

    canonical_instances = partition.get(
        "canonical_instance_ids"
    )

    if not isinstance(canonical_instances, list):
        raise SystemExit(
            f"Replication {replication}: "
            "missing canonical instances."
        )

    if len(canonical_instances) != 4:
        raise SystemExit(
            f"Replication {replication}: "
            "expected four density instances."
        )

    observed_instance_levels = sorted(
        int(
            instance_id.split(
                "level_",
                1,
            )[1].split("/", 1)[0]
        )
        for instance_id in canonical_instances
    )

    if observed_instance_levels != expected_levels:
        raise SystemExit(
            f"Replication {replication}: "
            "density-level matrix mismatch."
        )

    digests: set[str] = set()

    for item in equivalence:
        step_index = int(item["step_index"])
        digest = str(item["query_spec_digest"])

        if not digest:
            raise SystemExit(
                f"Replication {replication}: "
                f"empty digest at step {step_index}."
            )

        digest_by_replication_and_step[
            (replication, step_index)
        ] = digest

        digests.add(digest)

    referenced_workload = Path(
        execution_spec["workload_path"]
    )

    if referenced_workload.is_absolute():
        resolved_reference = referenced_workload
    else:
        resolved_reference = (
            root / referenced_workload
        ).resolve()

    if (
        resolved_reference
        != workload_path.resolve()
    ):
        raise SystemExit(
            f"Replication {replication}: "
            "execution spec references another workload."
        )

    step_set = set(workload_indexes)

    step_sets.append(step_set)
    digest_sets.append(digests)

    replication_records.append(
        {
            "replication_index": replication,
            "structural_seed": expected_seeds[
                replication
            ],
            "functional_workload_path": (
                workload_path
                .relative_to(root)
                .as_posix()
            ),
            "functional_workload_sha256": (
                sha256_file(workload_path)
            ),
            "functional_execution_spec_path": (
                execution_spec_path
                .relative_to(root)
                .as_posix()
            ),
            "functional_execution_spec_sha256": (
                sha256_file(
                    execution_spec_path
                )
            ),
            "available_workload_step_count": (
                len(steps)
            ),
            "available_step_indexes": (
                workload_indexes
            ),
            "canonical_instance_count": 4,
            "query_digest_count": len(digests),
        }
    )

balanced_step_indexes = sorted(
    set.intersection(*step_sets)
)

if balanced_step_indexes != list(range(1, 24)):
    raise SystemExit(
        "Expected balanced local-step intersection "
        "1..23."
    )

global_digest_intersection = sorted(
    set.intersection(*digest_sets)
)

step_digest_cardinalities: dict[str, int] = {}

for step_index in balanced_step_indexes:
    digest_count = len(
        {
            digest_by_replication_and_step[
                (replication, step_index)
            ]
            for replication in range(10)
        }
    )

    step_digest_cardinalities[
        str(step_index)
    ] = digest_count

available_step_histogram: dict[str, int] = {}

for record in replication_records:
    key = str(
        record["available_workload_step_count"]
    )

    available_step_histogram[key] = (
        available_step_histogram.get(key, 0)
        + 1
    )

if available_step_histogram != {
    "23": 2,
    "24": 8,
}:
    raise SystemExit(
        "Unexpected workload step-count histogram: "
        f"{available_step_histogram}"
    )

replication_count = 10
level_count = 4
selected_step_count = 23

timing_cluster_cell_count = (
    replication_count
    * level_count
    * selected_step_count
)

precision_cell_count = (
    level_count
    * selected_step_count
)

warmups_per_cell = 10
measurements_per_cell = 100

warmup_observation_count = (
    timing_cluster_cell_count
    * warmups_per_cell
)

measurement_observation_count = (
    timing_cluster_cell_count
    * measurements_per_cell
)

excluded_workload_step_count = sum(
    record["available_workload_step_count"]
    - selected_step_count
    for record in replication_records
)

excluded_functional_level_step_count = (
    excluded_workload_step_count
    * level_count
)

preflight = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "timing-preregistration-preflight-v1"
    ),
    "status": (
        "membership_density_timing_"
        "preregistration_preflight_complete"
    ),
    "stage": (
        "SA4_membership_density_"
        "timing_preregistration_preflight"
    ),
    "created_utc": created_utc,
    "source_commit": source_commit,
    "campaign_id": (
        "membership_density_stage10_c4_nv24"
    ),
    "factor": "membership_density",
    "frozen_functional_evidence": {
        "run_count": 10,
        "structural_seed_count": 10,
        "instance_count": 40,
        "functional_step_count": 952,
        "functional_mismatch_count": 0,
        "functional_execution_rerun_required": False,
        "functional_execution_rerun_performed": False,
    },
    "structural_contract": {
        "stage_size": 10,
        "levels": expected_levels,
        "level_count": 4,
        "seeds": expected_seeds,
        "fixed_constraint_count": 4,
        "fixed_virtual_node_count": 24,
    },
    "workload_balance_audit": {
        "available_step_count_histogram": (
            available_step_histogram
        ),
        "balanced_local_step_indexes": (
            balanced_step_indexes
        ),
        "balanced_step_count": (
            selected_step_count
        ),
        "excluded_workload_step_count": (
            excluded_workload_step_count
        ),
        "excluded_functional_level_step_count": (
            excluded_functional_level_step_count
        ),
        "global_query_digest_intersection": (
            global_digest_intersection
        ),
        "global_query_digest_intersection_count": (
            len(global_digest_intersection)
        ),
        "distinct_digest_count_by_local_step": (
            step_digest_cardinalities
        ),
        "within_replication_cross_level_"
        "equivalence_required": True,
        "cross_replication_query_digest_"
        "identity_required": False,
        "primary_estimand": (
            "Density-level latency distribution under "
            "seed-specific canonical workloads, with "
            "structural seed as the resampling cluster."
        ),
    },
    "timing_input_materialization": {
        "required": True,
        "use_existing_functional_specs_directly": False,
        "reason": (
            "Existing workloads contain 23 or 24 "
            "steps and point to functional output "
            "directories. Timing requires ten new "
            "balanced, immutable workloads and specs."
        ),
        "derived_step_indexes": (
            balanced_step_indexes
        ),
        "derived_workload_count": 10,
        "derived_execution_spec_count": 10,
        "functional_outputs_must_not_be_modified": True,
    },
    "proposed_timing_protocol": {
        "replication_count": 10,
        "level_count": 4,
        "selected_step_count": 23,
        "timing_cluster_cell_count": (
            timing_cluster_cell_count
        ),
        "precision_cell_count": (
            precision_cell_count
        ),
        "warmups_per_cell": (
            warmups_per_cell
        ),
        "measurements_per_cell": (
            measurements_per_cell
        ),
        "warmup_observation_count": (
            warmup_observation_count
        ),
        "measurement_observation_count": (
            measurement_observation_count
        ),
        "order_seed_base": 20260728,
        "order_seed_rule": (
            "20260728 + replication_index"
        ),
        "fresh_state_required": True,
        "semantic_match_required": True,
        "reuse_successful": True,
    },
    "proposed_precision_protocol": {
        "analyzer": (
            analyzer_path
            .relative_to(root)
            .as_posix()
        ),
        "analyzer_sha256": (
            sha256_file(analyzer_path)
        ),
        "unit_of_resampling": (
            "structural seed cluster"
        ),
        "within_cluster_measurements": (
            "retained together"
        ),
        "bootstrap_repetitions": 10000,
        "bootstrap_seed": 20260728,
        "confidence_level": 0.95,
        "median_relative_half_width_target": 0.10,
        "p95_relative_half_width_target": 0.15,
        "gate_rule": (
            "Every one of the 92 level-step "
            "precision cells must meet both targets."
        ),
        "stage20_extension_only_if_stage10_fails": (
            True
        ),
        "stage20_execution_authorized": False,
    },
    "implementation_identities": {
        "timing_runner": (
            runner_path.relative_to(root).as_posix()
        ),
        "timing_runner_sha256": (
            sha256_file(runner_path)
        ),
        "precision_analyzer": (
            analyzer_path
            .relative_to(root)
            .as_posix()
        ),
        "precision_analyzer_sha256": (
            sha256_file(analyzer_path)
        ),
    },
    "source_artifacts": {
        "replication_execution_plan": {
            "path": (
                execution_plan_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                execution_plan_path
            ),
        },
        "common_workload_audit": {
            "path": (
                common_audit_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                common_audit_path
            ),
        },
        "functional_execution_audit": {
            "path": (
                functional_audit_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                functional_audit_path
            ),
        },
        "functional_freeze": {
            "path": (
                functional_freeze_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                functional_freeze_path
            ),
        },
        "frozen_manifest": {
            "path": (
                frozen_manifest_path
                .relative_to(root)
                .as_posix()
            ),
            "sha256": sha256_file(
                frozen_manifest_path
            ),
        },
    },
    "replications": replication_records,
    "scientific_controls": {
        "timing_execution_authorized": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "preflight_decision": {
        "formal_timing_preregistration_ready": True,
        "timing_input_materialization_ready": False,
        "timing_execution_ready": False,
    },
    "next_stage": (
        "formalize_membership_density_"
        "timing_preregistration"
    ),
}

write_json(output_json, preflight)

lines = [
    (
        "# SA4 membership-density timing "
        "preregistration preflight"
    ),
    "",
    "- Status: `PASS`",
    "- Structural replications: `10`",
    "- Density levels: `25, 50, 75, 100`",
    "- Frozen functional steps: `952`",
    (
        "- Available workload lengths: "
        "`23 steps × 2`, `24 steps × 8`"
    ),
    "- Balanced timing steps: `1..23`",
    "- Timing cluster cells: `920`",
    "- Precision cells: `92`",
    "- Warmup observations: `9200`",
    "- Measurement observations: `92000`",
    "- Functional rerun required: `false`",
    "- Timing execution authorized: `false`",
    "- Latency claims authorized: `false`",
    "",
    "## Required preparation",
    "",
    (
        "Create ten new timing-only workloads and "
        "execution specifications restricted to "
        "steps `1..23`. Existing functional outputs "
        "must remain immutable."
    ),
    "",
    "## Precision protocol proposed",
    "",
    "- Cluster unit: structural seed",
    "- Bootstrap repetitions: `10000`",
    "- Confidence level: `95%`",
    "- Median RHW target: `10%`",
    "- p95 RHW target: `15%`",
    "",
    "## Next stage",
    "",
    "`formalize_membership_density_timing_preregistration`",
    "",
]

output_md.write_text(
    "\n".join(lines),
    encoding="utf-8",
)

print(
    "membership_density_timing_"
    "preregistration_preflight=PASS"
)
print("structural_replication_count=10")
print("density_level_count=4")
print("frozen_functional_step_count=952")
print("available_step_count_23_replications=2")
print("available_step_count_24_replications=8")
print("balanced_timing_step_count=23")
print("balanced_timing_step_indexes=1..23")
print("timing_cluster_cell_count=920")
print("precision_cell_count=92")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print(
    "global_query_digest_intersection_count="
    f"{len(global_digest_intersection)}"
)
print("timing_input_materialization_required=true")
print("functional_execution_rerun_performed=false")
print("timing_execution_authorized=false")
print("timing_execution_performed=false")
print("precision_analysis_performed=false")
print("latency_claim_authorized=false")
print(
    "next_stage="
    "formalize_membership_density_"
    "timing_preregistration"
)
PY

echo
echo "=== 4. Commit preflight ==="

git add "$OUTPUT_JSON" "$OUTPUT_MD"

git diff --cached --check
git diff --cached --stat

git commit \
  -m "chore(experiments): preflight membership-density timing preregistration"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 5. Push branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 6. Create pull request ==="

GLOBAL_INTERSECTION="$(
  jq -r \
    '.workload_balance_audit.global_query_digest_intersection_count' \
    "$OUTPUT_JSON"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preflight membership-density timing preregistration" \
    --body "$(cat <<EOF
## Scope

- audits the frozen ten-replication membership-density workload;
- performs no functional or timing execution;
- resolves the imbalance between 23-step and 24-step workloads;
- identifies the balanced local-step intersection \`1..23\`;
- proposes ten timing-only derived workloads and specs;
- fixes the proposed Stage-10 timing and precision dimensions.

## Proposed temporal dimensions

- structural replications: \`10\`;
- density levels: \`4\`;
- selected local steps: \`23\`;
- timing cluster cells: \`920\`;
- precision cells: \`92\`;
- warmup observations: \`9200\`;
- formal measurements: \`92000\`;
- global cross-replication digest intersection: \`$GLOBAL_INTERSECTION\`.

## Controls

- functional rerun: \`false\`;
- timing execution authorized: \`false\`;
- timing execution performed: \`false\`;
- precision analysis performed: \`false\`;
- latency claims authorized: \`false\`.

## Next stage

\`formalize_membership_density_timing_preregistration\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 7. Final state ==="

echo "membership_density_timing_preregistration_preflight=PASS"
echo "commit=$COMMIT"
echo "balanced_timing_step_count=23"
echo "timing_cluster_cell_count=920"
echo "precision_cell_count=92"
echo "measurement_observation_count=92000"
echo "timing_execution_authorized=false"
echo "timing_execution_performed=false"
echo "functional_execution_rerun_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_timing_preflight"

git status --short --branch
git log --oneline --decorate -4
