#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=20

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-membership-density-precision-adapter-20260803T195150Z"

EXPECTED_HEAD="6428fa5b7141005a1bd95a5ee9b8f6d9c2fb02d6"
EXPECTED_BASE_HEAD="6d244ec318cf3986900b3220924050974b141cd1"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_non_mutating_precision_adapter_preregistration.json"
EXPECTED_SHA="4e7041988c388837f5d4d71c07a659a209b479ddf4dd1f1cd7798cbb8aa2695b"

trap 'echo "[ERROR] PR #20 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$PREREG"

test "$(
  sha256sum "$PREREG" | awk '{print $1}'
)" = "$EXPECTED_SHA"

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_preregistered"
  and .materialization_authorization.authorized == true
  and .materialization_authorization.precision_analyzer_execution_authorized
      == false
  and .scientific_controls.adapter_materialization_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$PREREG" >/dev/null

echo "local_gate=PASS"
echo "precision_analysis_performed=false"

echo
echo "=== 2. PR identity ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

set +e
CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null
)"
CHECK_STATUS=$?
set -e

if [ "$CHECK_STATUS" -eq 0 ] && [ "$(jq 'length' <<<"$CHECKS")" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "ci_gate=PASS"
else
  echo "ci_gate=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1
echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #20 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

test "$(
  sha256sum "$PREREG" | awk '{print $1}'
)" = "$EXPECTED_SHA"

echo "merged_preregistration=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Cleanup and final state ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "membership_density_precision_adapter_preregistration_merge=PASS"
echo "adapter_materialization_authorized=true"
echo "adapter_materialization_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "next_stage=materialize_membership_density_non_mutating_precision_adapter_inputs"

git status --short --branch
git log --oneline --decorate -5
