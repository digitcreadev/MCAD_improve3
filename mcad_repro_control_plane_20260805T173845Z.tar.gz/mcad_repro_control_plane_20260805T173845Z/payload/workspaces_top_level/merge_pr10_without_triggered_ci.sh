#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=10

BASE="paper/phase3-controlled-execution"
BRANCH="paper/authorize-virtual-node-count-stage10-timing-20260802T151549Z"
EXPECTED_HEAD="c4b504e6c8163fd72db5ee722dab888b6817a359"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"

trap 'echo "[ERROR] Merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$AUTH"
test -x "$PYTHON"

echo "local_gate=PASS"
echo "tests_rerun=false"
echo "functional_execution_rerun=false"
echo "timing_execution=false"

echo
echo "=== 2. GitHub merge gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
)"

PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"

CHECK_JSON="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if [ -n "$CHECK_JSON" ]; then
  CHECK_COUNT="$(jq 'length' <<<"$CHECK_JSON")"
  NON_PASSING="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$CHECK_JSON"
  )"
else
  CHECK_COUNT=0
  NON_PASSING=0
fi

echo "pr_state=$PR_STATE"
echo "pr_head=$PR_HEAD"
echo "pr_base=$PR_BASE"
echo "is_draft=$IS_DRAFT"
echo "mergeable=$MERGEABLE"
echo "merge_state=$MERGE_STATE"
echo "check_count=$CHECK_COUNT"
echo "non_passing_check_count=$NON_PASSING"

test "$PR_STATE" = "OPEN"
test "$PR_HEAD" = "$EXPECTED_HEAD"
test "$PR_BASE" = "$BASE"
test "$IS_DRAFT" = "false"
test "$MERGEABLE" = "MERGEABLE"
test "$MERGE_STATE" = "CLEAN"
test "$NON_PASSING" -eq 0

if [ "$CHECK_COUNT" -eq 0 ]; then
  echo "ci_status=NOT_TRIGGERED_FOR_THIS_CHANGESET"
else
  echo "ci_status=PASS"
fi

echo "merge_gate=PASS"

echo
echo "=== 3. Merge PR #10 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 4. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "base_head=$BASE_HEAD"
echo "authorization_commit_is_ancestor=PASS"

echo
echo "=== 5. Verify merged authorization ==="

"$PYTHON" - "$AUTH" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

if not path.is_file():
    raise SystemExit(f"Missing authorization: {path}")

authorization = json.loads(
    path.read_text(encoding="utf-8")
)

scope = authorization["scope"]
execution = authorization["execution_state"]
prohibitions = authorization["prohibitions"]
precision = authorization["precision_analysis"]

expected_scope = {
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_runs_per_cell": 10,
    "measurement_runs_per_cell": 100,
    "expected_warmup_count": 600,
    "expected_measurement_count": 6000,
}

assert authorization["status"] == "authorized"
assert authorization["campaign_id"] == (
    "virtual_node_count_stage10_c4"
)
assert authorization["factor"] == "virtual_node_count"

for key, expected in expected_scope.items():
    assert scope[key] == expected

assert precision["bootstrap_replications"] == 10000
assert precision["confidence_level"] == 0.95
assert precision["median_relative_half_width_target"] == 0.10
assert precision["p95_relative_half_width_target"] == 0.15

assert execution == {
    "timing_execution_performed": False,
    "warmup_count_observed": 0,
    "measurement_count_observed": 0,
}

for field in (
    "functional_execution_rerun_authorized",
    "historical_prefix_rerun_authorized",
    "stage20_execution_authorized",
    "latency_claim_authorized",
    "scientific_freeze_authorized",
):
    assert prohibitions[field] is False

print("merged_timing_authorization=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 6. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 7. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "stage10_timing_authorization_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=prepare_and_validate_stage10_timing_runner"

git status --short --branch
git log --oneline --decorate -5
