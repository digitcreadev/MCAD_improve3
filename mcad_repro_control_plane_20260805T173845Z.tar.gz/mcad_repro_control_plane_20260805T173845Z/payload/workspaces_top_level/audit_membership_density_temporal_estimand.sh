#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="13be44a20db08589b8c452ea8299bbfc61adf164"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREFLIGHT="$REPORTS/planning/sa4_membership_density_timing_preregistration_preflight.json"

EXECUTION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PREFLIGHT"
test -f "$EXECUTION_PLAN"

echo "repository_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Audit semantic support across structural seeds ==="

"$PYTHON" - \
  "$PREFLIGHT" \
  "$EXECUTION_PLAN" <<'PY'
from __future__ import annotations

import itertools
import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def load(path: str) -> dict[str, Any]:
    payload = json.loads(
        Path(path).read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


preflight = load(sys.argv[1])
plan = load(sys.argv[2])

if (
    preflight
    .get("workload_balance_audit", {})
    .get("global_query_digest_intersection_count")
    != 0
):
    raise SystemExit(
        "Expected the merged preflight to record "
        "zero globally common digests."
    )

if (
    preflight
    .get("workload_balance_audit", {})
    .get(
        "cross_replication_query_digest_"
        "identity_required"
    )
    is not False
):
    raise SystemExit(
        "Unexpected cross-replication identity rule."
    )

selected_steps = list(range(1, 24))

partitions = plan.get("partitions")

if not isinstance(partitions, list):
    raise SystemExit(
        "Execution plan lacks partitions."
    )

if len(partitions) != 10:
    raise SystemExit(
        f"Expected 10 partitions, got "
        f"{len(partitions)}."
    )

by_replication: dict[int, dict[int, str]] = {}

for partition in partitions:
    replication = int(
        partition["replication_index"]
    )

    equivalence = partition.get(
        "equivalence_metadata"
    )

    if not isinstance(equivalence, list):
        raise SystemExit(
            f"Replication {replication} lacks "
            "equivalence metadata."
        )

    digest_by_step = {
        int(item["step_index"]): str(
            item["query_spec_digest"]
        )
        for item in equivalence
        if int(item["step_index"])
        in selected_steps
    }

    if sorted(digest_by_step) != selected_steps:
        raise SystemExit(
            f"Replication {replication} does not "
            "contain the complete selected range 1..23."
        )

    by_replication[replication] = digest_by_step

if sorted(by_replication) != list(range(10)):
    raise SystemExit(
        "Replication index set is incomplete."
    )

digest_support: Counter[str] = Counter()

for digest_by_step in by_replication.values():
    digest_support.update(
        set(digest_by_step.values())
    )

support_histogram = Counter(
    digest_support.values()
)

globally_supported = sorted(
    digest
    for digest, support
    in digest_support.items()
    if support == 10
)

position_support: dict[int, int] = {}

for step_index in selected_steps:
    digests = {
        by_replication[replication][step_index]
        for replication in range(10)
    }

    position_support[step_index] = len(digests)

aligned_positions = [
    step_index
    for step_index, distinct_count
    in position_support.items()
    if distinct_count == 1
]

pairwise_overlap_counts: list[int] = []
pairwise_jaccards: list[float] = []

replication_digest_sets = {
    replication: set(mapping.values())
    for replication, mapping
    in by_replication.items()
}

for left, right in itertools.combinations(
    range(10),
    2,
):
    left_set = replication_digest_sets[left]
    right_set = replication_digest_sets[right]

    intersection = left_set & right_set
    union = left_set | right_set

    pairwise_overlap_counts.append(
        len(intersection)
    )

    pairwise_jaccards.append(
        len(intersection) / len(union)
        if union
        else 0.0
    )

print("replication_count=10")
print("selected_local_step_count=23")
print(
    "distinct_query_digest_count="
    f"{len(digest_support)}"
)

print(
    "globally_supported_digest_count="
    f"{len(globally_supported)}"
)

print(
    "semantically_aligned_local_position_count="
    f"{len(aligned_positions)}"
)

print(
    "digest_support_histogram="
    + json.dumps(
        {
            str(support): count
            for support, count
            in sorted(support_histogram.items())
        },
        sort_keys=True,
    )
)

for threshold in (2, 5, 8, 10):
    count = sum(
        1
        for support in digest_support.values()
        if support >= threshold
    )

    print(
        f"digest_count_supported_by_at_least_"
        f"{threshold}_replications={count}"
    )

print(
    "pairwise_digest_overlap_min="
    f"{min(pairwise_overlap_counts)}"
)

print(
    "pairwise_digest_overlap_median="
    f"{statistics.median(pairwise_overlap_counts)}"
)

print(
    "pairwise_digest_overlap_max="
    f"{max(pairwise_overlap_counts)}"
)

print(
    "pairwise_jaccard_min="
    f"{min(pairwise_jaccards):.6f}"
)

print(
    "pairwise_jaccard_median="
    f"{statistics.median(pairwise_jaccards):.6f}"
)

print(
    "pairwise_jaccard_max="
    f"{max(pairwise_jaccards):.6f}"
)

if globally_supported:
    raise SystemExit(
        "Unexpected globally common query digest."
    )

if aligned_positions:
    raise SystemExit(
        "Unexpected globally aligned local position."
    )

print()
print("temporal_estimand_audit=PASS")
print(
    "per_step_cross_seed_precision_supported=false"
)
print(
    "reason=no_semantically_identical_query_"
    "or_position_is_observed_in_all_10_clusters"
)
print(
    "portfolio_level_precision_supported=true"
)
print(
    "recommended_primary_estimand="
    "density_level_latency_distribution_over_"
    "seed_specific_23_query_portfolios"
)
print("recommended_precision_cell_count=4")
print("raw_timing_cluster_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print(
    "structural_seed_resampling_cluster=true"
)
print(
    "all_23_queries_retained_within_each_"
    "seed_level_cluster=true"
)
print(
    "timing_execution_authorized=false"
)
print(
    "next_stage=formalize_portfolio_level_"
    "membership_density_timing_preregistration"
)
PY

echo
echo "=== 3. Final state ==="

echo "membership_density_temporal_estimand_resolution=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=formalize_portfolio_level_membership_density_timing_preregistration"

git status --short --branch
