#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

PRIOR_SCOPE_ROOT="/workspaces/sa5_objective_count_v2_binding_candidate_classification_20260804T223518Z"
PRIOR_SCOPE_REPORT="$PRIOR_SCOPE_ROOT/sa5_objective_count_v2_binding_candidate_classification.json"
EXPECTED_PRIOR_SCOPE_REPORT_SHA="7cbd688bfe149b2a21d8306ccadb4534da890f3d2608725f2c74e540a05cff36"

CKG_SOURCE="backend/ckg/ckg_updater.py"
OBJECTIVE_MODEL="backend/mcad/models.py"
OBJECTIVE_REGISTRY="backend/mcad/objectives.py"

OBJECTIVE_COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"
CAPACITY_AMENDMENT_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"
MATERIALIZATION_AMENDMENT_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
CONTROLLED_FAMILIES_TEST="backend/harness/sensitivity_generator/tests/test_controlled_families.py"

PROPOSED_POLICY_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_scope_reprojection_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_scope_reprojection.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_scope_reprojection.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_v2_scope_reprojection.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 v2 scope reprojection stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Post-capacity-amendment repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$PRIOR_SCOPE_REPORT" \
  "$CKG_SOURCE" \
  "$OBJECTIVE_MODEL" \
  "$OBJECTIVE_REGISTRY" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$CAPACITY_AMENDMENT_TEST" \
  "$MATERIALIZATION_AMENDMENT_TEST" \
  "$CONTROLLED_FAMILIES_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$PRIOR_SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_PRIOR_SCOPE_REPORT_SHA"

test ! -e "$PROPOSED_POLICY_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status == "preregistered_implementation_required"
  and .factor == "objective_count"
  and .stage == 10

  and .factor_scoped_support_contract.metadata_field
    == "session_support_policy"
  and .factor_scoped_support_contract.objective_count_v2_value
    == "union_requirement_sets"
  and .factor_scoped_support_contract.historical_default_value
    == "shortest_requirement_set_then_lexicographic_tie_break"
  and .factor_scoped_support_contract.support_resources_per_constraint
    == 3
  and .factor_scoped_support_contract.support_resources_per_objective
    == 24
  and .factor_scoped_support_contract.historical_profiles_must_remain_unchanged
    == true

  and .revised_workload_contract.workload_length == 32
  and .revised_workload_contract.oracle_contributive_query_count == 24
  and .revised_workload_contract.non_contributive_query_count == 8
  and .revised_workload_contract.realised_noise_ratio == 0.25

  and .implementation_contract.prior_17_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true

  and .authorization.v2_implementation_authorized_after_amendment_merge
    == true
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false

  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_capacity_amendment_merge"
' "$AMENDMENT_002" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_v2_binding_candidate_classification_resolved"
  and .final_scope.new_file_count == 9
  and .final_scope.modified_file_count == 8
  and .final_scope.total_patch_file_count == 17
  and .scope_complete == true
' "$PRIOR_SCOPE_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "capacity_amendment_sha256=$EXPECTED_AMENDMENT_002_SHA"
echo "prior_17_file_scope_authoritative=false"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Baseline regression gate ==="

"$PYTHON" -m pytest \
  "$CAPACITY_AMENDMENT_TEST" \
  "$MATERIALIZATION_AMENDMENT_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$CONTROLLED_FAMILIES_TEST" \
  -q \
  -p no:cacheprovider

echo "baseline_regression_gate=PASS"

echo
echo "=== 3. Run detached metadata-retention and support-policy probe ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export PRIOR_SCOPE_REPORT
export AMENDMENT_002
export CKG_SOURCE
export OBJECTIVE_MODEL
export OBJECTIVE_REGISTRY
export PROPOSED_POLICY_TEST
export TMP_ROOT
export REPORT
export SURFACE

"$PYTHON" - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any

import yaml

from backend.ckg.ckg_updater import CKGGraph
from backend.mcad.models import Objective


root = Path(os.environ["ROOT"]).resolve()
source_commit = os.environ["EXPECTED_HEAD"]

prior_scope_path = Path(
    os.environ["PRIOR_SCOPE_REPORT"]
).resolve()

amendment_path = root / os.environ["AMENDMENT_002"]

ckg_path = root / os.environ["CKG_SOURCE"]
model_path = root / os.environ["OBJECTIVE_MODEL"]
registry_path = root / os.environ["OBJECTIVE_REGISTRY"]

proposed_policy_test = os.environ[
    "PROPOSED_POLICY_TEST"
]

tmp_root = Path(os.environ["TMP_ROOT"])

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])


def sha256(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def class_source(
    path: Path,
    class_name: str,
) -> str:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()

    tree = ast.parse(
        text,
        filename=str(path),
    )

    for node in tree.body:
        if (
            isinstance(node, ast.ClassDef)
            and node.name == class_name
        ):
            start = int(node.lineno)
            end = int(
                getattr(node, "end_lineno", start)
            )

            return "\n".join(
                lines[start - 1 : end]
            )

    raise AssertionError(
        f"Missing class {class_name} in {path}"
    )


def function_source(
    path: Path,
    function_name: str,
    *,
    class_name: str | None = None,
) -> str:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()

    tree = ast.parse(
        text,
        filename=str(path),
    )

    nodes: list[ast.AST]

    if class_name is None:
        nodes = list(tree.body)
    else:
        class_node = next(
            (
                node
                for node in tree.body
                if (
                    isinstance(node, ast.ClassDef)
                    and node.name == class_name
                )
            ),
            None,
        )

        if class_node is None:
            raise AssertionError(
                f"Missing class {class_name}"
            )

        nodes = list(class_node.body)

    for node in nodes:
        if (
            isinstance(
                node,
                (
                    ast.FunctionDef,
                    ast.AsyncFunctionDef,
                ),
            )
            and node.name == function_name
        ):
            start = int(node.lineno)
            end = int(
                getattr(node, "end_lineno", start)
            )

            return "\n".join(
                lines[start - 1 : end]
            )

    raise AssertionError(
        f"Missing function {function_name} in {path}"
    )


prior_scope = json.loads(
    prior_scope_path.read_text(
        encoding="utf-8"
    )
)

amendment = json.loads(
    amendment_path.read_text(
        encoding="utf-8"
    )
)

prior_new_files = set(
    prior_scope["final_scope"]["new_files"]
)

prior_modified_files = set(
    prior_scope["final_scope"]["modified_files"]
)

assert len(prior_new_files) == 9
assert len(prior_modified_files) == 8

assert prior_scope[
    "final_scope"
]["total_patch_file_count"] == 17

assert amendment[
    "implementation_contract"
]["prior_17_file_scope_authoritative"] is False


required_new_files = {
    proposed_policy_test,
}

required_modified_files = {
    "backend/ckg/ckg_updater.py",
    "backend/mcad/models.py",
    "backend/mcad/objectives.py",
}

final_new_files = (
    prior_new_files
    | required_new_files
)

final_modified_files = (
    prior_modified_files
    | required_modified_files
)

assert len(final_new_files) == 10
assert len(final_modified_files) == 11

final_total_patch_file_count = (
    len(final_new_files)
    + len(final_modified_files)
)

assert final_total_patch_file_count == 21

for relative in final_new_files:
    if (root / relative).exists():
        raise AssertionError(
            "Proposed new file already exists: "
            f"{relative}"
        )


# ------------------------------------------------------------------
# Current CKG behavior probe
# ------------------------------------------------------------------

objective_id = "O_SA5_SUPPORT_POLICY_SCOPE_PROBE"

virtual_node_ids = [
    f"{objective_id}_C0001_NV{index:04d}"
    for index in range(1, 5)
]

probe_document = {
    "objectives": [
        {
            "id": objective_id,
            "name": objective_id,
            "description": "Detached support-policy probe",
            "session_support_policy": (
                "union_requirement_sets"
            ),
            "kpis": [
                f"{objective_id}_KPI0001",
            ],
            "constraints": [
                {
                    "id": f"{objective_id}_C0001",
                    "kpi_id": (
                        f"{objective_id}_KPI0001"
                    ),
                    "description": "Probe constraint",
                    "weight": 1.0,
                    "requirement_sets": [
                        [
                            virtual_node_ids[0],
                            virtual_node_ids[1],
                        ],
                        [
                            virtual_node_ids[1],
                            virtual_node_ids[2],
                        ],
                    ],
                    "virtual_nodes": [
                        {
                            "id": virtual_node_id,
                            "fact": "SyntheticFact",
                            "grain": [
                                "Time.Month",
                                "Geography.Region",
                            ],
                            "measure": "Sales",
                            "aggregator": "SUM",
                            "unit": "USD",
                            "slicers": {
                                "Geography.Region": (
                                    "Region_01"
                                ),
                                "Time.Year": "2020",
                            },
                            "window_start": "2020-01-01",
                            "window_end": "2020-12-31",
                        }
                        for virtual_node_id
                        in virtual_node_ids
                    ],
                }
            ],
        }
    ]
}

probe_path = tmp_root / "objectives.yaml"

probe_path.write_text(
    yaml.safe_dump(
        probe_document,
        allow_unicode=True,
        sort_keys=False,
    ),
    encoding="utf-8",
)

ckg = CKGGraph(
    output_dir=str(
        tmp_root / "runtime"
    )
)

for attribute_name in (
    "G",
    "objectives",
    "history",
    "session_coverage",
    "session_weighted_coverage",
    "session_resource_coverage",
):
    getattr(
        ckg,
        attribute_name,
    ).clear()

ckg.bootstrap_objectives(
    str(probe_path)
)

cached_objective = ckg.objectives[
    objective_id
]

cached_policy = cached_objective.get(
    "session_support_policy"
)

constraint_id = f"{objective_id}_C0001"

current_support = ckg._constraint_support(
    objective_id,
    constraint_id,
)

assert cached_policy is None
assert len(current_support) == 2

ckg.clone_objective(
    objective_id,
    f"{objective_id}_CLONE",
)

cloned_policy = ckg.objectives[
    f"{objective_id}_CLONE"
].get("session_support_policy")

assert cloned_policy is None


# ------------------------------------------------------------------
# Current Pydantic model behavior probe
# ------------------------------------------------------------------

model_fields = getattr(
    Objective,
    "model_fields",
    None,
)

if model_fields is None:
    model_fields = getattr(
        Objective,
        "__fields__",
        {},
    )

objective_model_declares_policy = (
    "session_support_policy"
    in model_fields
)

model_instantiation_error: str | None = None
model_dump: dict[str, Any] = {}

try:
    model_instance = Objective(
        id=objective_id,
        name=objective_id,
        description="Model probe",
        session_support_policy=(
            "union_requirement_sets"
        ),
    )

    if hasattr(
        model_instance,
        "model_dump",
    ):
        model_dump = model_instance.model_dump()
    else:
        model_dump = model_instance.dict()

except Exception as exc:
    model_instantiation_error = (
        f"{type(exc).__name__}: {exc}"
    )

objective_model_preserves_policy = (
    model_dump.get(
        "session_support_policy"
    )
    == "union_requirement_sets"
)

assert objective_model_declares_policy is False
assert objective_model_preserves_policy is False


# ------------------------------------------------------------------
# Current source ownership
# ------------------------------------------------------------------

bootstrap_source = function_source(
    ckg_path,
    "bootstrap_objectives",
    class_name="CKGGraph",
)

support_source = function_source(
    ckg_path,
    "_constraint_support",
    class_name="CKGGraph",
)

ckg_clone_source = function_source(
    ckg_path,
    "clone_objective",
    class_name="CKGGraph",
)

objective_class_source = class_source(
    model_path,
    "Objective",
)

registry_clone_source = function_source(
    registry_path,
    "clone_objective",
)

assert "session_support_policy" not in (
    bootstrap_source
)

assert "session_support_policy" not in (
    support_source
)

assert "session_support_policy" not in (
    ckg_clone_source
)

assert "session_support_policy" not in (
    objective_class_source
)

assert "session_support_policy" not in (
    registry_clone_source
)


# ------------------------------------------------------------------
# Definition-owner closure
# ------------------------------------------------------------------

tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]

definition_owners: list[dict[str, Any]] = []
reference_hits: list[dict[str, Any]] = []

search_tokens = (
    "session_support_policy",
    "_constraint_support",
    "bootstrap_objectives",
    "clone_objective",
    "class Objective",
)

for relative in tracked_files:
    path = root / relative

    if path.suffix not in {
        ".py",
        ".yaml",
        ".yml",
        ".json",
        ".md",
    }:
        continue

    try:
        text = path.read_text(
            encoding="utf-8"
        )
    except (
        UnicodeDecodeError,
        OSError,
    ):
        continue

    lines = text.splitlines()

    for line_number, line in enumerate(
        lines,
        start=1,
    ):
        matched = [
            token
            for token in search_tokens
            if token in line
        ]

        if matched:
            reference_hits.append(
                {
                    "path": relative.as_posix(),
                    "line": line_number,
                    "tokens": matched,
                    "text": line.rstrip(),
                }
            )

    if path.suffix != ".py":
        continue

    try:
        tree = ast.parse(
            text,
            filename=str(path),
        )
    except SyntaxError:
        continue

    for node in ast.walk(tree):
        owner_name: str | None = None

        if (
            isinstance(node, ast.ClassDef)
            and node.name == "Objective"
        ):
            owner_name = "class Objective"

        elif (
            isinstance(
                node,
                (
                    ast.FunctionDef,
                    ast.AsyncFunctionDef,
                ),
            )
            and node.name in {
                "bootstrap_objectives",
                "_constraint_support",
                "clone_objective",
            }
        ):
            owner_name = (
                f"function {node.name}"
            )

        if owner_name is None:
            continue

        definition_owners.append(
            {
                "path": relative.as_posix(),
                "owner": owner_name,
                "line": int(node.lineno),
            }
        )


known_required_owner_paths = {
    "backend/ckg/ckg_updater.py",
    "backend/mcad/models.py",
    "backend/mcad/objectives.py",
}

additional_production_owner_paths = sorted(
    {
        owner["path"]
        for owner in definition_owners
        if (
            "/tests/" not in owner["path"]
            and owner["path"]
            not in known_required_owner_paths
        )
    }
)

review_only_test_files = sorted(
    {
        hit["path"]
        for hit in reference_hits
        if (
            "/tests/" in hit["path"]
            and hit["path"]
            not in final_modified_files
            and hit["path"]
            not in final_new_files
        )
    }
)

blockers: list[str] = []

if additional_production_owner_paths:
    blockers.append(
        "additional_support_policy_production_"
        "owners_require_classification"
    )

current_gaps = {
    "ckg_bootstrap_drops_policy": (
        cached_policy is None
    ),
    "ckg_constraint_support_uses_"
    "historical_shortest_set": (
        len(current_support) == 2
    ),
    "ckg_clone_drops_policy": (
        cloned_policy is None
    ),
    "objective_model_drops_policy": (
        not objective_model_preserves_policy
    ),
    "objective_registry_clone_drops_policy": (
        "session_support_policy"
        not in registry_clone_source
    ),
}

if not all(current_gaps.values()):
    blockers.append(
        "unexpected_current_policy_behavior"
    )

scope_complete = not blockers

if scope_complete:
    status = (
        "sa5_objective_count_v2_"
        "post_capacity_scope_resolved"
    )

    next_stage = (
        "author_sa5_objective_count_"
        "materialization_contract_v2_patch_"
        "with_21_file_scope"
    )

else:
    status = (
        "sa5_objective_count_v2_"
        "post_capacity_scope_requires_"
        "additional_classification"
    )

    next_stage = (
        "classify_additional_sa5_v2_"
        "support_policy_owners"
    )


report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "post-capacity-scope-reprojection-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "amendment_sha256": sha256(
        amendment_path
    ),
    "prior_scope": {
        "authoritative": False,
        "new_files": sorted(
            prior_new_files
        ),
        "modified_files": sorted(
            prior_modified_files
        ),
        "new_file_count": len(
            prior_new_files
        ),
        "modified_file_count": len(
            prior_modified_files
        ),
        "total_patch_file_count": 17,
    },
    "capacity_semantics": {
        "support_policy_metadata_field": (
            "session_support_policy"
        ),
        "objective_count_v2_policy": (
            "union_requirement_sets"
        ),
        "historical_default_policy": (
            "shortest_requirement_set_"
            "then_lexicographic_tie_break"
        ),
        "workload_length": 32,
        "contributive_query_count": 24,
        "non_contributive_query_count": 8,
        "support_resources_per_constraint": 3,
        "support_resources_per_objective": 24,
    },
    "current_behavior_probe": {
        "cached_policy": cached_policy,
        "current_support_ids": (
            current_support
        ),
        "current_support_count": len(
            current_support
        ),
        "cloned_policy": cloned_policy,
        "objective_model_declares_policy": (
            objective_model_declares_policy
        ),
        "objective_model_preserves_policy": (
            objective_model_preserves_policy
        ),
        "objective_model_instantiation_error": (
            model_instantiation_error
        ),
        "objective_model_dump": model_dump,
        "gaps": current_gaps,
    },
    "required_scope_additions": {
        "new_files": sorted(
            required_new_files
        ),
        "modified_files": sorted(
            required_modified_files
        ),
        "new_file_count": len(
            required_new_files
        ),
        "modified_file_count": len(
            required_modified_files
        ),
        "rationale": {
            "backend/ckg/ckg_updater.py": [
                (
                    "preserve session_support_policy "
                    "during bootstrap"
                ),
                (
                    "dispatch union_requirement_sets "
                    "factor-locally"
                ),
                (
                    "preserve policy during CKG "
                    "objective cloning"
                ),
                (
                    "retain historical default for "
                    "missing or unknown policy"
                ),
            ],
            "backend/mcad/models.py": [
                (
                    "declare optional objective-level "
                    "session_support_policy metadata"
                ),
            ],
            "backend/mcad/objectives.py": [
                (
                    "preserve session_support_policy "
                    "when cloning registry objectives"
                ),
            ],
            proposed_policy_test: [
                (
                    "independently test bootstrap, "
                    "support dispatch, model retention, "
                    "clone retention and historical "
                    "fallback"
                ),
            ],
        },
    },
    "final_scope": {
        "new_files": sorted(
            final_new_files
        ),
        "modified_files": sorted(
            final_modified_files
        ),
        "review_only_test_files": (
            review_only_test_files
        ),
        "new_file_count": len(
            final_new_files
        ),
        "modified_file_count": len(
            final_modified_files
        ),
        "total_patch_file_count": (
            final_total_patch_file_count
        ),
    },
    "definition_owners": (
        definition_owners
    ),
    "additional_production_owner_paths": (
        additional_production_owner_paths
    ),
    "reference_hits": reference_hits,
    "blockers": blockers,
    "blocker_count": len(blockers),
    "scope_complete": scope_complete,
    "preserve_v1_generator_module_bytes": True,
    "preserve_historical_support_behavior": True,
    "preserve_membership_density_profile": True,
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 POST-CAPACITY SCOPE REPROJECTION",
    "=" * 92,
    f"source_commit={source_commit}",
    f"status={status}",
    "prior_17_file_scope_authoritative=false",
    "",
    "=== CURRENT POLICY GAPS ===",
]

for key, value in current_gaps.items():
    surface_lines.append(
        f"{key}={str(value).lower()}"
    )

surface_lines.extend(
    [
        "",
        "=== REQUIRED NEW FILES ===",
        *sorted(required_new_files),
        "",
        "=== REQUIRED ADDITIONAL MODIFIED FILES ===",
        *sorted(required_modified_files),
        "",
        "=== FINAL NEW FILES ===",
        *sorted(final_new_files),
        "",
        "=== FINAL MODIFIED FILES ===",
        *sorted(final_modified_files),
        "",
        "=== SCOPE COUNTS ===",
        (
            "final_new_file_count="
            f"{len(final_new_files)}"
        ),
        (
            "final_modified_file_count="
            f"{len(final_modified_files)}"
        ),
        (
            "final_total_patch_file_count="
            f"{final_total_patch_file_count}"
        ),
        (
            "additional_production_owner_count="
            f"{len(additional_production_owner_paths)}"
        ),
        (
            "review_only_test_file_count="
            f"{len(review_only_test_files)}"
        ),
        (
            "blocker_count="
            f"{len(blockers)}"
        ),
        (
            "scope_complete="
            f"{str(scope_complete).lower()}"
        ),
        "",
        "=== DEFINITION OWNERS ===",
    ]
)

for owner in definition_owners:
    surface_lines.append(
        (
            f"{owner['path']}:{owner['line']}:"
            f"{owner['owner']}"
        )
    )

surface_lines.extend(
    [
        "",
        "=== ADDITIONAL PRODUCTION OWNERS ===",
    ]
)

if additional_production_owner_paths:
    surface_lines.extend(
        additional_production_owner_paths
    )
else:
    surface_lines.append(
        "additional_production_owner_count=0"
    )

surface_lines.extend(
    [
        "",
        "=== REVIEW-ONLY TEST FILES ===",
    ]
)

if review_only_test_files:
    surface_lines.extend(
        review_only_test_files
    )
else:
    surface_lines.append(
        "review_only_test_file_count=0"
    )

surface_lines.extend(
    [
        "",
        "=== EXACT CURRENT BOOTSTRAP SOURCE ===",
        bootstrap_source,
        "",
        "=== EXACT CURRENT SUPPORT SOURCE ===",
        support_source,
        "",
        "=== EXACT CURRENT CKG CLONE SOURCE ===",
        ckg_clone_source,
        "",
        "=== EXACT CURRENT OBJECTIVE MODEL ===",
        objective_class_source,
        "",
        "=== EXACT CURRENT REGISTRY CLONE SOURCE ===",
        registry_clone_source,
        "",
        "=== FINAL SCIENTIFIC CONTROLS ===",
        "canonical_campaign_materialization_authorized=false",
        "canonical_campaign_generated=false",
        "campaign_materialization_performed=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("post_capacity_scope_reprojection=PASS")
print(f"status={status}")
print("prior_17_file_scope_authoritative=false")
print(
    "required_additional_new_file_count="
    f"{len(required_new_files)}"
)
print(
    "required_additional_modified_file_count="
    f"{len(required_modified_files)}"
)
print(
    "final_new_file_count="
    f"{len(final_new_files)}"
)
print(
    "final_modified_file_count="
    f"{len(final_modified_files)}"
)
print(
    "final_total_patch_file_count="
    f"{final_total_patch_file_count}"
)
print(
    "additional_production_owner_count="
    f"{len(additional_production_owner_paths)}"
)
print(
    "review_only_test_file_count="
    f"{len(review_only_test_files)}"
)
print(
    "blocker_count="
    f"{len(blockers)}"
)
print(
    "scope_complete="
    f"{str(scope_complete).lower()}"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate post-capacity scope report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-post-capacity-scope-reprojection-v1"
  and .status
    == "sa5_objective_count_v2_post_capacity_scope_resolved"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .read_only == true

  and .prior_scope.authoritative == false
  and .prior_scope.new_file_count == 9
  and .prior_scope.modified_file_count == 8
  and .prior_scope.total_patch_file_count == 17

  and .capacity_semantics.support_policy_metadata_field
    == "session_support_policy"
  and .capacity_semantics.objective_count_v2_policy
    == "union_requirement_sets"
  and .capacity_semantics.workload_length == 32
  and .capacity_semantics.contributive_query_count == 24
  and .capacity_semantics.non_contributive_query_count == 8

  and .current_behavior_probe.current_support_count == 2
  and .current_behavior_probe.objective_model_declares_policy
    == false
  and .current_behavior_probe.objective_model_preserves_policy
    == false
  and .current_behavior_probe.gaps.ckg_bootstrap_drops_policy
    == true
  and .current_behavior_probe.gaps.ckg_constraint_support_uses_historical_shortest_set
    == true
  and .current_behavior_probe.gaps.ckg_clone_drops_policy
    == true
  and .current_behavior_probe.gaps.objective_model_drops_policy
    == true
  and .current_behavior_probe.gaps.objective_registry_clone_drops_policy
    == true

  and .required_scope_additions.new_files
    == [
      "backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py"
    ]
  and .required_scope_additions.modified_files
    == [
      "backend/ckg/ckg_updater.py",
      "backend/mcad/models.py",
      "backend/mcad/objectives.py"
    ]

  and .final_scope.new_file_count == 10
  and .final_scope.modified_file_count == 11
  and .final_scope.total_patch_file_count == 21

  and .additional_production_owner_paths == []
  and .blocker_count == 0
  and .scope_complete == true

  and .preserve_v1_generator_module_bytes == true
  and .preserve_historical_support_behavior == true
  and .preserve_membership_density_profile == true

  and .canonical_campaign_materialization_authorized
    == false
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false

  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_21_file_scope"
' "$REPORT" >/dev/null

echo "post_capacity_scope_report_validation=PASS"

echo
echo "=== 5. Compact final implementation scope ==="

jq '{
  status,
  source_commit,
  prior_scope,
  capacity_semantics,
  current_behavior_probe,
  required_scope_additions,
  final_scope,
  additional_production_owner_paths,
  blocker_count,
  scope_complete,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value reprojection surface ==="

grep -nE \
  '^(status=|prior_17|ckg_|objective_|backend/|final_new|final_modified|final_total|additional_production|review_only|blocker_count=|scope_complete=|next_stage=)' \
  "$SURFACE" |
  head -n 500 || true

echo
echo "=== 7. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$PROPOSED_POLICY_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_objective_count_v2_post_capacity_scope_reprojection=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo "prior_17_file_scope_authoritative=false"
echo "required_additional_new_file_count=1"
echo "required_additional_modified_file_count=3"
echo "final_new_file_count=10"
echo "final_modified_file_count=11"
echo "final_total_patch_file_count=21"
echo "blocker_count=0"
echo "scope_complete=true"

echo "v2_patch_authoring_authorized=true"
echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo "next_stage=author_sa5_objective_count_materialization_contract_v2_patch_with_21_file_scope"

git status --short --branch
