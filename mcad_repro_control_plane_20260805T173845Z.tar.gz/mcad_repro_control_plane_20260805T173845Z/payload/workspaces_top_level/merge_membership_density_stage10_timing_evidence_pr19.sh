#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=19

BASE="paper/phase3-controlled-execution"
BRANCH="paper/execute-membership-density-timing-stage10-20260803T111214Z"

EXPECTED_HEAD="d4213cb975f8eb3a259f2b0dd39d0857918efb60"
EXPECTED_BASE_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"
AUDIT_ROOT="$REPORTS/audits/membership_density/timing_stage10"

LEDGER="$RUN_ROOT/stage10_execution_ledger.json"
LEDGER_MD="$RUN_ROOT/stage10_execution_ledger.md"
AUDIT="$AUDIT_ROOT/stage10_output_audit.json"
AUDIT_MD="$AUDIT_ROOT/stage10_output_audit.md"

EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"
EXPECTED_AUDIT_SHA="fd3bf7ef8ee06e09ffe88548b361516ee9ad0760964932fed1ed3b7e83477888"

trap 'echo "[ERROR] PR #19 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local evidence gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -f "$LEDGER"
test -f "$LEDGER_MD"
test -f "$AUDIT"
test -f "$AUDIT_MD"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$AUDIT" | awk '{print $1}'
)" = "$EXPECTED_AUDIT_SHA"

CSV_COUNT="$(
  find "$RUN_ROOT" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    -name 'timing_observations.csv' |
    wc -l
)"

BUNDLE_FILE_COUNT="$(
  find "$RUN_ROOT" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    \( \
      -name 'timing_observations.csv' \
      -o -name 'timing_manifest.json' \
      -o -name 'timing_summary.json' \
      -o -name 'functional_references.json' \
    \) |
    wc -l
)"

test "$CSV_COUNT" -eq 10
test "$BUNDLE_FILE_COUNT" -eq 40

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.failed_replication_count == 0
  and .execution_totals.raw_timing_cell_count == 920
  and .execution_totals.warmup_observation_count == 9200
  and .execution_totals.measurement_observation_count == 92000
  and .execution_totals.total_observation_count == 101200
  and (.replications | length) == 10
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
' "$LEDGER" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .execution_results.successful_replication_count == 10
  and .execution_results.functional_mismatch_count == 0
  and .execution_results.measurement_observation_count == 92000
  and .execution_results.direct_cell_count_balance == true
  and .balance_flag_interpretation.scientific_defect == false
  and .balance_flag_interpretation.timing_rerun_required == false
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.timing_reexecution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "prepare_membership_density_portfolio_analysis_adapter"
' "$AUDIT" >/dev/null

echo "local_evidence_gate=PASS"
echo "canonical_timing_csv_count=10"
echo "canonical_bundle_file_count=40"
echo "execution_ledger_sha256=$EXPECTED_LEDGER_SHA"
echo "output_audit_sha256=$EXPECTED_AUDIT_SHA"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "stage10_timing_evidence_ci=PASS"
else
  echo "stage10_timing_evidence_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #19 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "timing_evidence_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged evidence ==="

test -f "$LEDGER"
test -f "$LEDGER_MD"
test -f "$AUDIT"
test -f "$AUDIT_MD"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$AUDIT" | awk '{print $1}'
)" = "$EXPECTED_AUDIT_SHA"

test "$(
  find "$RUN_ROOT" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    -name 'timing_observations.csv' |
    wc -l
)" -eq 10

jq -e '
  .execution_totals.successful_replication_count == 10
  and .execution_totals.measurement_observation_count == 92000
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.precision_analysis_performed == false
' "$LEDGER" >/dev/null

jq -e '
  .audit_decision.stage10_timing_execution_accepted == true
  and .balance_flag_interpretation.scientific_defect == false
  and .balance_flag_interpretation.timing_rerun_required == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "prepare_membership_density_portfolio_analysis_adapter"
' "$AUDIT" >/dev/null

echo "merged_stage10_timing_evidence=PASS"
echo "execution_ledger_sha256=$EXPECTED_LEDGER_SHA"
echo "output_audit_sha256=$EXPECTED_AUDIT_SHA"
echo "measurement_observation_count=92000"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

test -z "$(git status --porcelain)"

echo "membership_density_stage10_timing_evidence_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "successful_replication_count=10"
echo "measurement_observation_count=92000"
echo "timing_execution_performed=true"
echo "timing_reexecution_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "next_stage=prepare_membership_density_portfolio_analysis_adapter"

git status --short --branch
git log --oneline --decorate -5
