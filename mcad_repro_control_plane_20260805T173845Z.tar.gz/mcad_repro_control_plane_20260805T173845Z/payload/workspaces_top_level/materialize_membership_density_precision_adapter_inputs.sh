#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="4f1b8fef37f0feac0be7019ac3d6d9fe51dc12a4"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREREG="$REPORTS/planning/sa4_membership_density_non_mutating_precision_adapter_preregistration.json"

LEDGER="$REPORTS/timing_runs/membership_density_stage10_portfolio/stage10_execution_ledger.json"

OUTPUT_AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

REPLICATION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

EXPECTED_PREREG_SHA="4e7041988c388837f5d4d71c07a659a209b479ddf4dd1f1cd7798cbb8aa2695b"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

trap 'echo "[ERROR] Adapter materialization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Materialization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"

for FILE in \
  "$PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$REPLICATION_PLAN" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" | awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_preregistered"
  and .materialization_authorization.authorized == true
  and .materialization_authorization.precision_analyzer_execution_authorized
      == false
  and .scientific_controls.adapter_materialization_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$PREREG" >/dev/null

OBSERVATIONS="$(
  jq -r '.planned_artifacts.observations_csv' "$PREREG"
)"

TIMING_ADAPTER="$(
  jq -r '.planned_artifacts.timing_report_adapter_json' "$PREREG"
)"

INPUT_MANIFEST="$(
  jq -r '.planned_artifacts.precision_input_manifest_json' "$PREREG"
)"

for OUTPUT in \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"
do
  test "$OUTPUT" != "null"
  test ! -e "$OUTPUT"
done

echo "materialization_gate=PASS"
echo "adapter_materialization_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create materialization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/materialize-membership-density-precision-adapter-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Materialize non-mutating adapter inputs ==="

"$PYTHON" - \
  "$ROOT" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$REPLICATION_PLAN" \
  "$ANALYZER" \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
source_commit = sys.argv[2]
created_utc = sys.argv[3]

prereg_path = (root / sys.argv[4]).resolve()
ledger_path = (root / sys.argv[5]).resolve()
output_audit_path = (root / sys.argv[6]).resolve()
replication_plan_path = (root / sys.argv[7]).resolve()
analyzer_path = (root / sys.argv[8]).resolve()

observations_path = (root / sys.argv[9]).resolve()
timing_adapter_path = (root / sys.argv[10]).resolve()
manifest_path = (root / sys.argv[11]).resolve()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.resolve().relative_to(root).as_posix()


def parse_bool(value: Any, *, label: str) -> bool:
    if isinstance(value, bool):
        return value

    normalized = str(value).strip().lower()

    if normalized in {"true", "1", "yes"}:
        return True

    if normalized in {"false", "0", "no"}:
        return False

    raise SystemExit(f"Invalid boolean {label}: {value!r}")


prereg = load_object(prereg_path)
ledger = load_object(ledger_path)
output_audit = load_object(output_audit_path)
replication_plan = load_object(replication_plan_path)

if prereg.get("status") != (
    "membership_density_non_mutating_"
    "precision_adapter_preregistered"
):
    raise SystemExit("Precision-adapter preregistration is invalid.")

if ledger.get("status") != (
    "membership_density_stage10_timing_execution_complete"
):
    raise SystemExit("Timing ledger is not complete.")

if output_audit.get("status") != (
    "membership_density_stage10_output_audit_complete"
):
    raise SystemExit("Timing-output audit is not complete.")

if (
    output_audit.get("audit_decision", {})
    .get("stage10_timing_execution_accepted")
    is not True
):
    raise SystemExit("Stage-10 timing execution is not accepted.")

expected_levels = [25, 50, 75, 100]
expected_replications = list(range(10))
expected_steps = list(range(1, 24))

expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

# ------------------------------------------------------------------
# Resolve the replication-plan query-spec-digest join.
# ------------------------------------------------------------------

partitions = replication_plan.get("partitions")

if not isinstance(partitions, list) or len(partitions) != 10:
    raise SystemExit("Expected ten replication-plan partitions.")

query_digest_by_replication_step: dict[
    tuple[int, int],
    str,
] = {}

step_id_by_replication_step: dict[
    tuple[int, int],
    str,
] = {}

join_json_path_by_replication_step: dict[
    tuple[int, int],
    str,
] = {}

ambiguous_plan_key_count = 0

for partition_position, partition in enumerate(partitions):
    if not isinstance(partition, dict):
        raise SystemExit("Invalid replication-plan partition.")

    replication_index = int(
        partition["replication_index"]
    )

    metadata = partition.get("equivalence_metadata")

    if not isinstance(metadata, list):
        raise SystemExit(
            f"Replication {replication_index}: "
            "equivalence_metadata absent."
        )

    for metadata_position, item in enumerate(metadata):
        if not isinstance(item, dict):
            raise SystemExit("Invalid equivalence metadata.")

        step_index = int(item["step_index"])

        if step_index not in expected_steps:
            continue

        query_digest = str(item["query_spec_digest"])
        step_id = str(item["step_id"])
        key = (replication_index, step_index)

        if (
            key in query_digest_by_replication_step
            and query_digest_by_replication_step[key]
            != query_digest
        ):
            ambiguous_plan_key_count += 1
            continue

        query_digest_by_replication_step[key] = query_digest
        step_id_by_replication_step[key] = step_id
        join_json_path_by_replication_step[key] = (
            f"$.partitions[{partition_position}]"
            f".equivalence_metadata[{metadata_position}]"
        )

if ambiguous_plan_key_count != 0:
    raise SystemExit(
        "Ambiguous replication-plan digest mappings."
    )

expected_join_keys = {
    (replication, step)
    for replication in expected_replications
    for step in expected_steps
}

missing_plan_keys = sorted(
    expected_join_keys
    - set(query_digest_by_replication_step)
)

if missing_plan_keys:
    raise SystemExit(
        "Replication plan lacks selected steps: "
        f"{missing_plan_keys[:10]}"
    )

# ------------------------------------------------------------------
# Resolve the ten immutable timing CSV sources.
# ------------------------------------------------------------------

source_records = (
    prereg.get("source_artifacts", {})
    .get("timing_csv_files")
)

if (
    not isinstance(source_records, list)
    or len(source_records) != 10
):
    raise SystemExit(
        "Preregistration must declare ten timing CSV files."
    )

ledger_replications = ledger.get("replications")

if (
    not isinstance(ledger_replications, list)
    or len(ledger_replications) != 10
):
    raise SystemExit("Ledger must contain ten replications.")

ledger_by_replication = {
    int(record["replication_index"]): record
    for record in ledger_replications
}

source_record_by_replication = {
    int(record["replication_index"]): record
    for record in source_records
}

if sorted(source_record_by_replication) != expected_replications:
    raise SystemExit("Source timing CSV replication set differs.")

output_fieldnames = [
    # Analyzer-facing columns.
    "formal_replication_index",
    "formal_structural_seed",
    "formal_order_seed",
    "phase",
    "factor_level",
    "step_index",
    "wall_latency_ms",
    "fresh_state",
    "semantic_match",

    # Immutable row-level provenance.
    "source_replication_index",
    "source_structural_seed",
    "source_order_seed",
    "source_step_position",
    "source_step_index",
    "source_step_id",
    "source_query_spec_digest",
    "source_query_digest_json_path",
    "source_semantic_digest",
    "source_timing_csv",
    "source_timing_csv_sha256",
    "source_row_number",
    "source_observation_index",
    "source_cell_id",
    "source_canonical_instance_id",
]

observations_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

source_file_audit: list[dict[str, Any]] = []

source_total_row_count = 0
source_warmup_count = 0
source_measurement_count = 0
derived_row_count = 0

unmatched_join_count = 0
step_id_mismatch_count = 0
duplicate_source_row_count = 0

seen_source_rows: set[tuple[str, int]] = set()

cluster_counts: Counter[
    tuple[int, int, int]
] = Counter()

inferential_cell_counts: Counter[int] = Counter()

source_step_counts: Counter[
    tuple[int, int, int]
] = Counter()

with observations_path.open(
    "w",
    encoding="utf-8",
    newline="",
) as output_handle:
    writer = csv.DictWriter(
        output_handle,
        fieldnames=output_fieldnames,
        lineterminator="\n",
        extrasaction="raise",
    )

    writer.writeheader()

    for replication_index in expected_replications:
        source_record = source_record_by_replication[
            replication_index
        ]

        ledger_record = ledger_by_replication[
            replication_index
        ]

        source_path = Path(source_record["path"])

        if not source_path.is_absolute():
            source_path = root / source_path

        source_path = source_path.resolve()

        if not source_path.is_file():
            raise SystemExit(
                f"Missing source timing CSV: {source_path}"
            )

        declared_sha = str(source_record["sha256"])
        actual_sha = sha256(source_path)

        if actual_sha != declared_sha:
            raise SystemExit(
                f"Replication {replication_index}: "
                "source timing CSV SHA mismatch."
            )

        structural_seed = int(
            source_record["structural_seed"]
        )

        if structural_seed != expected_seeds[replication_index]:
            raise SystemExit(
                f"Replication {replication_index}: "
                "structural seed mismatch."
            )

        formal_order_seed = int(
            source_record["formal_order_seed"]
        )

        expected_order_seed = 20260728 + replication_index

        if formal_order_seed != expected_order_seed:
            raise SystemExit(
                f"Replication {replication_index}: "
                "order seed mismatch."
            )

        if int(ledger_record["order_seed"]) != formal_order_seed:
            raise SystemExit(
                f"Replication {replication_index}: "
                "ledger order seed mismatch."
            )

        phase_counts: Counter[str] = Counter()
        source_rows_for_file = 0
        derived_rows_for_file = 0

        with source_path.open(
            "r",
            encoding="utf-8",
            newline="",
        ) as source_handle:
            reader = csv.DictReader(source_handle)

            required_source_fields = {
                "phase",
                "factor_level",
                "replication_index",
                "seed",
                "step_position",
                "step_index",
                "step_id",
                "fresh_state",
                "wall_latency_ms",
                "semantic_digest",
                "semantic_match",
                "observation_index",
                "cell_id",
                "canonical_instance_id",
            }

            if reader.fieldnames is None:
                raise SystemExit(
                    f"Replication {replication_index}: "
                    "CSV header absent."
                )

            missing_fields = (
                required_source_fields
                - set(reader.fieldnames)
            )

            if missing_fields:
                raise SystemExit(
                    f"Replication {replication_index}: "
                    f"missing fields {sorted(missing_fields)}."
                )

            for source_row_number, row in enumerate(
                reader,
                start=2,
            ):
                source_rows_for_file += 1
                source_total_row_count += 1

                phase = str(row["phase"])
                phase_counts[phase] += 1

                if phase == "warmup":
                    source_warmup_count += 1
                    continue

                if phase != "measurement":
                    raise SystemExit(
                        f"Replication {replication_index}: "
                        f"unexpected phase {phase!r}."
                    )

                source_measurement_count += 1

                row_replication = int(
                    row["replication_index"]
                )

                row_seed = int(row["seed"])
                factor_level = int(row["factor_level"])
                source_step_index = int(row["step_index"])
                source_step_position = int(
                    row["step_position"]
                )

                if row_replication != replication_index:
                    raise SystemExit(
                        "Source-row replication mismatch."
                    )

                if row_seed != structural_seed:
                    raise SystemExit(
                        "Source-row structural-seed mismatch."
                    )

                if factor_level not in expected_levels:
                    raise SystemExit(
                        f"Unexpected factor level: {factor_level}"
                    )

                if source_step_index not in expected_steps:
                    raise SystemExit(
                        f"Unexpected source step: "
                        f"{source_step_index}"
                    )

                fresh_state = parse_bool(
                    row["fresh_state"],
                    label="fresh_state",
                )

                semantic_match = parse_bool(
                    row["semantic_match"],
                    label="semantic_match",
                )

                if not fresh_state:
                    raise SystemExit(
                        "Derived observation lacks fresh state."
                    )

                if not semantic_match:
                    raise SystemExit(
                        "Derived observation lacks semantic match."
                    )

                wall_latency_ms = float(
                    row["wall_latency_ms"]
                )

                if (
                    not math.isfinite(wall_latency_ms)
                    or wall_latency_ms < 0
                ):
                    raise SystemExit(
                        "Invalid wall-latency measurement."
                    )

                join_key = (
                    replication_index,
                    source_step_index,
                )

                query_spec_digest = (
                    query_digest_by_replication_step.get(
                        join_key
                    )
                )

                if query_spec_digest is None:
                    unmatched_join_count += 1
                    continue

                expected_step_id = (
                    step_id_by_replication_step[join_key]
                )

                source_step_id = str(row["step_id"])

                if source_step_id != expected_step_id:
                    step_id_mismatch_count += 1
                    continue

                source_identity = (
                    relative(source_path),
                    source_row_number,
                )

                if source_identity in seen_source_rows:
                    duplicate_source_row_count += 1
                    continue

                seen_source_rows.add(source_identity)

                output_row = {
                    "formal_replication_index": (
                        replication_index
                    ),
                    "formal_structural_seed": (
                        structural_seed
                    ),
                    "formal_order_seed": (
                        formal_order_seed
                    ),
                    "phase": "measurement",
                    "factor_level": factor_level,
                    "step_index": 0,
                    "wall_latency_ms": (
                        row["wall_latency_ms"]
                    ),
                    "fresh_state": "True",
                    "semantic_match": "True",
                    "source_replication_index": (
                        replication_index
                    ),
                    "source_structural_seed": (
                        structural_seed
                    ),
                    "source_order_seed": formal_order_seed,
                    "source_step_position": (
                        source_step_position
                    ),
                    "source_step_index": (
                        source_step_index
                    ),
                    "source_step_id": source_step_id,
                    "source_query_spec_digest": (
                        query_spec_digest
                    ),
                    "source_query_digest_json_path": (
                        join_json_path_by_replication_step[
                            join_key
                        ]
                    ),
                    "source_semantic_digest": (
                        row["semantic_digest"]
                    ),
                    "source_timing_csv": (
                        relative(source_path)
                    ),
                    "source_timing_csv_sha256": actual_sha,
                    "source_row_number": source_row_number,
                    "source_observation_index": (
                        row["observation_index"]
                    ),
                    "source_cell_id": row["cell_id"],
                    "source_canonical_instance_id": (
                        row["canonical_instance_id"]
                    ),
                }

                writer.writerow(output_row)

                derived_rows_for_file += 1
                derived_row_count += 1

                cluster_counts[
                    (
                        factor_level,
                        0,
                        replication_index,
                    )
                ] += 1

                inferential_cell_counts[
                    factor_level
                ] += 1

                source_step_counts[
                    (
                        replication_index,
                        factor_level,
                        source_step_index,
                    )
                ] += 1

        if source_rows_for_file != 10120:
            raise SystemExit(
                f"Replication {replication_index}: "
                f"expected 10,120 source rows, "
                f"got {source_rows_for_file}."
            )

        if phase_counts != Counter({
            "warmup": 920,
            "measurement": 9200,
        }):
            raise SystemExit(
                f"Replication {replication_index}: "
                f"phase imbalance {dict(phase_counts)}."
            )

        if derived_rows_for_file != 9200:
            raise SystemExit(
                f"Replication {replication_index}: "
                f"expected 9,200 derived rows, "
                f"got {derived_rows_for_file}."
            )

        source_file_audit.append({
            "replication_index": replication_index,
            "structural_seed": structural_seed,
            "formal_order_seed": formal_order_seed,
            "path": relative(source_path),
            "sha256": actual_sha,
            "source_row_count": source_rows_for_file,
            "warmup_row_count": phase_counts["warmup"],
            "measurement_row_count": (
                phase_counts["measurement"]
            ),
            "derived_row_count": derived_rows_for_file,
            "source_file_modified": False,
        })

if unmatched_join_count != 0:
    raise SystemExit(
        f"Unmatched digest joins: {unmatched_join_count}"
    )

if step_id_mismatch_count != 0:
    raise SystemExit(
        f"Step-ID mismatches: {step_id_mismatch_count}"
    )

if duplicate_source_row_count != 0:
    raise SystemExit(
        f"Duplicate source rows: {duplicate_source_row_count}"
    )

if source_total_row_count != 101200:
    raise SystemExit("Expected 101,200 source rows.")

if source_warmup_count != 9200:
    raise SystemExit("Expected 9,200 warmup rows.")

if source_measurement_count != 92000:
    raise SystemExit("Expected 92,000 measurement rows.")

if derived_row_count != 92000:
    raise SystemExit("Expected 92,000 derived observations.")

expected_clusters = {
    (level, 0, replication)
    for level in expected_levels
    for replication in expected_replications
}

if set(cluster_counts) != expected_clusters:
    raise SystemExit("Derived cluster set differs.")

if any(
    cluster_counts[cell] != 2300
    for cell in expected_clusters
):
    raise SystemExit(
        "Every analyzer cluster must contain 2,300 rows."
    )

if any(
    inferential_cell_counts[level] != 23000
    for level in expected_levels
):
    raise SystemExit(
        "Every inferential level must contain 23,000 rows."
    )

expected_source_step_keys = {
    (replication, level, step)
    for replication in expected_replications
    for level in expected_levels
    for step in expected_steps
}

if set(source_step_counts) != expected_source_step_keys:
    raise SystemExit("Source-step coverage differs.")

if any(
    source_step_counts[key] != 100
    for key in expected_source_step_keys
):
    raise SystemExit(
        "Every source query must contribute 100 measurements."
    )

observations_sha = sha256(observations_path)

# Guard against GitHub's 100-MiB single-file hard limit.
observations_size = observations_path.stat().st_size

if observations_size >= 95_000_000:
    raise SystemExit(
        "Derived observation CSV is too close to "
        "the GitHub single-file size limit: "
        f"{observations_size} bytes."
    )

timing_adapter = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "analyzer-timing-report-adapter-v1"
    ),
    "status": "stage10_formal_timing_execution_success",
    "factor": "membership_density",
    "stage": 10,
    "created_utc": created_utc,
    "source_commit": source_commit,
    "totals": {
        "run_count": 10,
        "successful_run_count": 10,
        "cell_count": 40,
        "measurement_observation_count": 92000,
        "functional_mismatch_count": 0,
        "exactly_balanced_run_count": 10,
        "structural_seed_count": 10,
    },
    "balance_semantics": {
        "exactly_balanced_run_count_means": (
            "Every replication contributes exactly 2,300 "
            "measurement observations to every density-level "
            "synthetic-step cluster."
        ),
        "does_not_claim_exact_order_position_balance": True,
    },
    "source_artifacts": {
        "precision_adapter_preregistration": {
            "path": relative(prereg_path),
            "sha256": sha256(prereg_path),
        },
        "execution_ledger": {
            "path": relative(ledger_path),
            "sha256": sha256(ledger_path),
        },
        "stage10_output_audit": {
            "path": relative(output_audit_path),
            "sha256": sha256(output_audit_path),
        },
        "derived_observations": {
            "path": relative(observations_path),
            "sha256": observations_sha,
            "row_count": 92000,
        },
    },
    "scientific_controls": {
        "timing_reexecution_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "latency_claim_authorized": False,
    },
}

timing_adapter_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

timing_adapter_path.write_text(
    json.dumps(
        timing_adapter,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

timing_adapter_sha = sha256(timing_adapter_path)

manifest = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "precision-adapter-input-manifest-v1"
    ),
    "status": (
        "membership_density_non_mutating_"
        "precision_adapter_inputs_materialized"
    ),
    "factor": "membership_density",
    "stage": 10,
    "created_utc": created_utc,
    "source_commit": source_commit,
    "source_artifacts": {
        "precision_adapter_preregistration": {
            "path": relative(prereg_path),
            "sha256": sha256(prereg_path),
        },
        "execution_ledger": {
            "path": relative(ledger_path),
            "sha256": sha256(ledger_path),
        },
        "stage10_output_audit": {
            "path": relative(output_audit_path),
            "sha256": sha256(output_audit_path),
        },
        "replication_execution_plan": {
            "path": relative(replication_plan_path),
            "sha256": sha256(replication_plan_path),
        },
        "precision_analyzer": {
            "path": relative(analyzer_path),
            "sha256": sha256(analyzer_path),
        },
        "timing_csv_files": source_file_audit,
    },
    "materialized_artifacts": {
        "observations_csv": {
            "path": relative(observations_path),
            "sha256": observations_sha,
            "size_bytes": observations_size,
            "row_count_excluding_header": 92000,
            "line_ending": "LF",
        },
        "timing_report_adapter": {
            "path": relative(timing_adapter_path),
            "sha256": timing_adapter_sha,
        },
    },
    "adapter_contract": {
        "source_timing_csv_count": 10,
        "source_total_observation_count": 101200,
        "source_warmup_observation_count": 9200,
        "source_measurement_observation_count": 92000,
        "derived_measurement_observation_count": 92000,
        "factor_levels": expected_levels,
        "synthetic_step_indexes": [0],
        "analyzer_timing_cell_count": 40,
        "inferential_cell_count": 4,
        "structural_seed_count": 10,
        "measurements_per_cluster": 2300,
        "measurements_per_inferential_cell": 23000,
        "source_query_count_per_cluster": 23,
        "measurements_per_source_query": 100,
    },
    "join_audit": {
        "replication_plan_key_count": len(
            query_digest_by_replication_step
        ),
        "required_join_key_count": 230,
        "unmatched_row_count": unmatched_join_count,
        "ambiguous_plan_key_count": (
            ambiguous_plan_key_count
        ),
        "step_id_mismatch_count": (
            step_id_mismatch_count
        ),
        "duplicate_source_row_count": (
            duplicate_source_row_count
        ),
        "actual_json_paths_recorded": True,
    },
    "immutability_audit": {
        "raw_timing_csv_files_modified": False,
        "raw_timing_csv_normalized": False,
        "raw_timing_csv_line_endings_changed": False,
        "precision_analyzer_modified": False,
        "source_sha256_values_preserved": True,
    },
    "materialization_decision": {
        "adapter_inputs_materialized": True,
        "adapter_inputs_complete": True,
        "adapter_inputs_validated": True,
        "precision_analysis_ready_for_authorization": True,
        "precision_analysis_authorized": False,
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_execution_performed": True,
        "timing_reexecution_performed": False,
        "adapter_materialization_performed": True,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "audit_and_authorize_membership_density_"
        "portfolio_precision_analysis"
    ),
}

manifest_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

manifest_path.write_text(
    json.dumps(
        manifest,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

print(
    "membership_density_precision_"
    "adapter_input_materialization=PASS"
)
print("source_timing_csv_count=10")
print("source_total_observation_count=101200")
print("source_warmup_observation_count=9200")
print("source_measurement_observation_count=92000")
print("derived_measurement_observation_count=92000")
print("analyzer_timing_cell_count=40")
print("inferential_cell_count=4")
print("structural_seed_count=10")
print("measurements_per_cluster=2300")
print("measurements_per_inferential_cell=23000")
print("unmatched_join_count=0")
print("ambiguous_plan_key_count=0")
print("step_id_mismatch_count=0")
print("duplicate_source_row_count=0")
print(f"observations_size_bytes={observations_size}")
print(f"observations_sha256={observations_sha}")
print(f"timing_adapter_sha256={timing_adapter_sha}")
print("raw_timing_csv_files_modified=false")
print("precision_analyzer_modified=false")
print("precision_analysis_authorized=false")
print("precision_analysis_performed=false")
PY

echo
echo "=== 4. Validate materialized artifacts ==="

test -f "$OBSERVATIONS"
test -f "$TIMING_ADAPTER"
test -f "$INPUT_MANIFEST"

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_inputs_materialized"
  and .factor == "membership_density"
  and .adapter_contract.source_timing_csv_count == 10
  and .adapter_contract.source_total_observation_count == 101200
  and .adapter_contract.source_warmup_observation_count == 9200
  and .adapter_contract.source_measurement_observation_count == 92000
  and .adapter_contract.derived_measurement_observation_count == 92000
  and .adapter_contract.analyzer_timing_cell_count == 40
  and .adapter_contract.inferential_cell_count == 4
  and .adapter_contract.structural_seed_count == 10
  and .adapter_contract.measurements_per_cluster == 2300
  and .adapter_contract.measurements_per_inferential_cell == 23000
  and .join_audit.unmatched_row_count == 0
  and .join_audit.ambiguous_plan_key_count == 0
  and .join_audit.step_id_mismatch_count == 0
  and .join_audit.duplicate_source_row_count == 0
  and .immutability_audit.raw_timing_csv_files_modified == false
  and .immutability_audit.precision_analyzer_modified == false
  and .materialization_decision.adapter_inputs_complete == true
  and .materialization_decision.adapter_inputs_validated == true
  and .materialization_decision.precision_analysis_ready_for_authorization
      == true
  and .materialization_decision.precision_analysis_authorized == false
  and .scientific_controls.adapter_materialization_performed == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "audit_and_authorize_membership_density_portfolio_precision_analysis"
' "$INPUT_MANIFEST" >/dev/null

jq -e '
  .status == "stage10_formal_timing_execution_success"
  and .factor == "membership_density"
  and .totals.run_count == 10
  and .totals.successful_run_count == 10
  and .totals.cell_count == 40
  and .totals.measurement_observation_count == 92000
  and .totals.functional_mismatch_count == 0
  and .totals.exactly_balanced_run_count == 10
  and .totals.structural_seed_count == 10
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$TIMING_ADAPTER" >/dev/null

"$PYTHON" - "$OBSERVATIONS" <<'PY'
from __future__ import annotations

import csv
import sys
from collections import Counter
from pathlib import Path

path = Path(sys.argv[1])
raw = path.read_bytes()

if b"\r\n" in raw:
    raise SystemExit("Derived CSV contains CRLF line endings.")

with path.open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    reader = csv.DictReader(handle)

    rows = 0
    clusters: Counter[tuple[int, int, int]] = Counter()

    for row in reader:
        rows += 1

        if row["phase"] != "measurement":
            raise SystemExit("Non-measurement row detected.")

        if int(row["step_index"]) != 0:
            raise SystemExit("Synthetic step is not zero.")

        clusters[(
            int(row["factor_level"]),
            int(row["step_index"]),
            int(row["formal_replication_index"]),
        )] += 1

if rows != 92000:
    raise SystemExit(f"Unexpected row count: {rows}")

if len(clusters) != 40:
    raise SystemExit(
        f"Unexpected analyzer timing-cell count: {len(clusters)}"
    )

if set(clusters.values()) != {2300}:
    raise SystemExit("Derived cluster counts are not 2,300.")

print("derived_observation_csv_validation=PASS")
print("derived_observation_row_count=92000")
print("derived_analyzer_timing_cell_count=40")
print("derived_measurements_per_cluster=2300")
print("derived_csv_line_ending=LF")
PY

MANIFEST_SHA="$(
  sha256sum "$INPUT_MANIFEST" | awk '{print $1}'
)"

OBSERVATIONS_SHA="$(
  sha256sum "$OBSERVATIONS" | awk '{print $1}'
)"

TIMING_ADAPTER_SHA="$(
  sha256sum "$TIMING_ADAPTER" | awk '{print $1}'
)"

echo "materialized_artifact_validation=PASS"
echo "precision_input_manifest_sha256=$MANIFEST_SHA"
echo "observations_sha256=$OBSERVATIONS_SHA"
echo "timing_adapter_sha256=$TIMING_ADAPTER_SHA"

echo
echo "=== 5. Stage materialized inputs ==="

git add -f \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"

STAGED_FILE_COUNT="$(
  git diff --cached --name-only | wc -l
)"

test "$STAGED_FILE_COUNT" -eq 3

# Validate JSON whitespace using Git. The large generated CSV has already
# received an explicit LF/count/cluster validation above.
git diff --cached --check -- \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST"

echo "adapter_input_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"
echo "large_csv_git_whitespace_check=NOT_APPLICABLE"
echo "large_csv_explicit_validation=PASS"

echo
echo "=== 6. Commit materialized inputs ==="

git commit \
  -m "chore(experiments): materialize membership-density precision inputs"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 7. Push branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Materialize membership-density precision adapter inputs" \
    --body "$(cat <<EOF
## Materialized non-mutating inputs

- source timing CSV files: \`10\`;
- source observations: \`101,200\`;
- warmups excluded: \`9,200\`;
- measurement observations retained: \`92,000\`;
- analyzer timing cells: \`40\`;
- inferential density cells: \`4\`;
- structural clusters per level: \`10\`;
- measurements per cluster: \`2,300\`;
- measurements per inferential cell: \`23,000\`.

## Join audit

- unmatched rows: \`0\`;
- ambiguous mappings: \`0\`;
- step-ID mismatches: \`0\`;
- duplicate source rows: \`0\`.

## Immutability

- raw timing CSV modification: \`false\`;
- raw timing CSV normalization: \`false\`;
- analyzer source modification: \`false\`;
- timing re-execution: \`false\`.

## Integrity

- preregistration SHA-256:
  \`$EXPECTED_PREREG_SHA\`;
- observation adapter SHA-256:
  \`$OBSERVATIONS_SHA\`;
- timing-report adapter SHA-256:
  \`$TIMING_ADAPTER_SHA\`;
- input-manifest SHA-256:
  \`$MANIFEST_SHA\`.

## Authorization

- adapter materialization: \`performed\`;
- precision analysis: \`not authorized\`;
- Stage-20 execution: \`not authorized\`;
- latency claims: \`not authorized\`.

## Next stage

\`audit_and_authorize_membership_density_portfolio_precision_analysis\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_precision_adapter_input_materialization=PASS"
echo "commit=$COMMIT"
echo "precision_input_manifest_sha256=$MANIFEST_SHA"
echo "observations_sha256=$OBSERVATIONS_SHA"
echo "timing_adapter_sha256=$TIMING_ADAPTER_SHA"
echo "source_timing_csv_count=10"
echo "derived_measurement_observation_count=92000"
echo "analyzer_timing_cell_count=40"
echo "inferential_cell_count=4"
echo "adapter_materialization_performed=true"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_precision_adapter_inputs"

git status --short --branch
git log --oneline --decorate -4
