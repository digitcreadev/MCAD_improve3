#!/usr/bin/env bash
set -u
set -o pipefail

ROOT="/workspaces/MCAD_improve3"
BASE_BRANCH="paper/phase3-controlled-execution"
EXPECTED_HEAD="696b6f83e0ee4a3a61e042680468bb4b28111036"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
RUNNER="backend.harness.sensitivity_execution.execute_controlled_family"

E3_REL="reports/article_experiments/sensitivity/e3_controlled_execution"
SPEC_REL="$E3_REL/execution_specs"
RUNS_REL="$E3_REL/runs"

AUTH_REL="$E3_REL/planning/virtual_node_count_stage10_functional_authorization.json"
EVIDENCE_REL="$E3_REL/audits/virtual_node_count_stage10/functional_execution"
REPORT_REL="$EVIDENCE_REL/new_replications_functional_execution_report.json"
SUMMARY_REL="$EVIDENCE_REL/new_replications_functional_execution_report.md"

REPLICATIONS=(002 003 004 005 006 007 008 009)

fail() {
  echo "[ERROR] $*" >&2
  exit 1
}

cd "$ROOT" || fail "Cannot enter repository."

echo "=== 1. Repository and execution gate ==="

CURRENT_BRANCH="$(git branch --show-current)"
CURRENT_HEAD="$(git rev-parse HEAD)"

echo "branch=$CURRENT_BRANCH"
echo "head=$CURRENT_HEAD"

[ "$CURRENT_BRANCH" = "$BASE_BRANCH" ] ||
  fail "Unexpected branch."

[ "$CURRENT_HEAD" = "$EXPECTED_HEAD" ] ||
  fail "Unexpected base HEAD."

[ -z "$(git status --porcelain)" ] ||
  fail "Repository is not clean."

[ -x "$PYTHON" ] ||
  fail "Validation environment is unavailable."

for REP in "${REPLICATIONS[@]}"; do
  SPEC="$ROOT/$SPEC_REL/virtual_node_count_stage10_rep_${REP}_strict_common.json"

  [ -f "$SPEC" ] ||
    fail "Missing execution spec for rep_${REP}."

  OUTPUT_DIR="$(
    "$PYTHON" - "$SPEC" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
print(payload["output_dir"])
PY
  )"

  EXPECTED_OUTPUT="$ROOT/$RUNS_REL/virtual_node_count_stage10_rep_${REP}_strict_common"

  [ "$OUTPUT_DIR" = "$EXPECTED_OUTPUT" ] ||
    fail "Unexpected output path for rep_${REP}: $OUTPUT_DIR"

  [ ! -e "$OUTPUT_DIR" ] ||
    fail "Output already exists; refusing rerun: $OUTPUT_DIR"
done

echo "execution_gate=PASS"
echo "authorized_replications=002,003,004,005,006,007,008,009"
echo "historical_replications_000_001_rerun=false"

echo
echo "=== 2. Create authorization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
STARTED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
BRANCH="paper/execute-virtual-node-count-stage10-functional-${STAMP}"
LOG_ROOT="/workspaces/virtual_node_count_stage10_functional_logs_${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD" ||
  fail "Cannot create authorization branch."

mkdir -p "$(dirname "$AUTH_REL")"
mkdir -p "$LOG_ROOT"

echo "branch=$BRANCH"
echo "log_root=$LOG_ROOT"

echo
echo "=== 3. Write explicit functional authorization ==="

"$PYTHON" - \
  "$ROOT" \
  "$AUTH_REL" \
  "$EXPECTED_HEAD" \
  "$BRANCH" \
  "$STARTED_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
output_path = root / sys.argv[2]
base_commit = sys.argv[3]
branch = sys.argv[4]
created_utc = sys.argv[5]

e3 = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution"
)

replications = list(range(2, 10))
seeds = [
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


entries = []

for replication, seed in zip(replications, seeds):
    token = f"rep_{replication:03d}"

    execution_spec = (
        e3
        / "execution_specs"
        / (
            "virtual_node_count_stage10_"
            f"{token}_strict_common.json"
        )
    )

    workload = (
        e3
        / "workloads"
        / (
            "virtual_node_count_stage10_"
            f"{token}_strict_common.json"
        )
    )

    entries.append(
        {
            "replication_index": replication,
            "seed": seed,
            "factor_levels": [6, 12, 24],
            "instance_count": 3,
            "steps_per_instance": 2,
            "expected_step_count": 6,
            "execution_spec_path": execution_spec.as_posix(),
            "execution_spec_sha256": sha256_file(
                root / execution_spec
            ),
            "workload_path": workload.as_posix(),
            "workload_sha256": sha256_file(
                root / workload
            ),
        }
    )

common_audit = (
    e3
    / "audits"
    / "virtual_node_count_stage10"
    / "common_workloads"
    / "stage10_common_workload_audit.json"
)

payload = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "functional-authorization-v1"
    ),
    "authorization_id": (
        "virtual_node_count_stage10_"
        "new_functional_replications_002_009"
    ),
    "status": "authorized",
    "created_utc": created_utc,
    "source_base_commit": base_commit,
    "authorization_branch": branch,
    "authorization_model": (
        "post-preregistration functional gate release"
    ),
    "preregistration_is_not_modified": True,
    "authorization_basis": {
        "common_workload_audit_path": (
            common_audit.as_posix()
        ),
        "common_workload_audit_sha256": sha256_file(
            root / common_audit
        ),
        "common_workload_preparation_merged": True,
        "all_replications_have_two_common_queries": True,
        "historical_prefix_compatibility_passed": True,
    },
    "scope": {
        "factor": "virtual_node_count",
        "campaign_id": "virtual_node_count_stage10_c4",
        "authorized_replications": replications,
        "authorized_seeds": seeds,
        "authorized_instance_count": 24,
        "authorized_functional_step_count": 48,
        "expected_combined_instance_count": 30,
        "expected_combined_functional_step_count": 60,
    },
    "historical_prefix": {
        "replications": [0, 1],
        "reuse_required": True,
        "rerun_required": False,
        "rerun_authorized": False,
        "functional_step_count": 12,
    },
    "prohibitions": {
        "replications_000_001_execution_authorized": False,
        "formal_timing_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
    },
    "execution_entries": entries,
    "next_stage": (
        "execute_only_functional_replications_002_to_009"
    ),
}

output_path.parent.mkdir(parents=True, exist_ok=True)
output_path.write_text(
    json.dumps(
        payload,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print(f"authorization_path={output_path}")
print("authorized_replication_count=8")
print("authorized_instance_count=24")
print("authorized_functional_step_count=48")
print("historical_prefix_rerun_authorized=false")
print("timing_execution_authorized=false")
PY

AUTH_WRITE_STATUS=$?
echo "authorization_write_exit_status=$AUTH_WRITE_STATUS"

[ "$AUTH_WRITE_STATUS" -eq 0 ] ||
  fail "Authorization creation failed."

git add -f "$AUTH_REL"
git diff --cached --check ||
  fail "Authorization diff check failed."

git commit \
  -m "chore(experiments): authorize virtual-node-count Stage-10 functional completion" ||
  fail "Authorization commit failed."

AUTH_COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH" ||
  fail "Authorization push failed."

echo "authorization_commit=$AUTH_COMMIT"
echo "authorization_commit_pushed=true"

echo
echo "=== 4. Execute only rep_002 through rep_009 ==="

SUCCESSFUL_REPLICATIONS=0

for REP in "${REPLICATIONS[@]}"; do
  SPEC="$ROOT/$SPEC_REL/virtual_node_count_stage10_rep_${REP}_strict_common.json"
  OUTPUT_DIR="$ROOT/$RUNS_REL/virtual_node_count_stage10_rep_${REP}_strict_common"
  LOG="$LOG_ROOT/virtual_node_count_stage10_rep_${REP}_functional.log"

  echo
  echo "--- EXECUTE rep_${REP} ---"
  echo "execution_spec=$SPEC"
  echo "output_dir=$OUTPUT_DIR"
  echo "log=$LOG"

  PYTHONPATH="$ROOT" \
    "$PYTHON" -m "$RUNNER" "$SPEC" \
    2>&1 | tee "$LOG"

  RUN_STATUS="${PIPESTATUS[0]}"

  echo "rep_${REP}_execution_exit_status=$RUN_STATUS"

  if [ "$RUN_STATUS" -ne 0 ]; then
    echo "functional_execution=PARTIAL_OR_FAIL"
    echo "successful_replication_count=$SUCCESSFUL_REPLICATIONS"
    echo "failed_replication=$REP"
    echo "authorization_commit=$AUTH_COMMIT"
    echo "partial_outputs_preserved=true"
    exit 1
  fi

  "$PYTHON" - "$OUTPUT_DIR" "$REP" <<'PY'
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

output_dir = Path(sys.argv[1])
replication = int(sys.argv[2])

required = [
    output_dir / "execution_manifest.json",
    output_dir / "campaign_metrics.json",
    output_dir / "execution_spec.json",
    output_dir / "instance_results.csv",
]

for path in required:
    if not path.is_file():
        raise SystemExit(
            f"Missing execution artifact: {path}"
        )

manifest = json.loads(
    (output_dir / "execution_manifest.json").read_text(
        encoding="utf-8"
    )
)

metrics = json.loads(
    (output_dir / "campaign_metrics.json").read_text(
        encoding="utf-8"
    )
)

with (
    output_dir / "instance_results.csv"
).open(
    newline="",
    encoding="utf-8",
) as stream:
    rows = list(csv.DictReader(stream))

instance_manifests = list(
    output_dir.glob(
        "instances/**/execution_manifest.json"
    )
)
timelines = list(
    output_dir.glob("instances/**/timeline.json")
)
instance_metrics = list(
    output_dir.glob("instances/**/metrics.json")
)
instance_audits = list(
    output_dir.glob("instances/**/audit.json")
)

errors = []

if manifest.get("selected_instance_count") != 3:
    errors.append(
        "selected_instance_count must equal 3"
    )

if metrics.get("step_count") != 6:
    errors.append("campaign step_count must equal 6")

if len(rows) != 3:
    errors.append("instance_results row count must equal 3")

for label, values in (
    ("execution manifests", instance_manifests),
    ("timelines", timelines),
    ("instance metrics", instance_metrics),
    ("instance audits", instance_audits),
):
    if len(values) != 3:
        errors.append(
            f"{label} count must equal 3; "
            f"got {len(values)}"
        )

if errors:
    for error in errors:
        print(f"ERROR={error}")
    raise SystemExit(1)

print(
    f"rep_{replication:03d}_validation=PASS"
)
print(
    "selected_instance_count="
    f"{manifest['selected_instance_count']}"
)
print(f"step_count={metrics['step_count']}")
print(
    "deterministic_execution_digest="
    f"{manifest['deterministic_execution_digest']}"
)
PY

  VALIDATION_STATUS=$?
  echo "rep_${REP}_validation_exit_status=$VALIDATION_STATUS"

  if [ "$VALIDATION_STATUS" -ne 0 ]; then
    echo "functional_execution=PARTIAL_OR_FAIL"
    echo "failed_validation_replication=$REP"
    echo "partial_outputs_preserved=true"
    exit 1
  fi

  SUCCESSFUL_REPLICATIONS=$((SUCCESSFUL_REPLICATIONS + 1))
done

echo
echo "new_functional_replication_count=$SUCCESSFUL_REPLICATIONS"

[ "$SUCCESSFUL_REPLICATIONS" -eq 8 ] ||
  fail "Not all eight new replications succeeded."

echo
echo "=== 5. Build canonical execution audit ==="

COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

mkdir -p "$EVIDENCE_REL/logs"
cp "$LOG_ROOT"/*.log "$EVIDENCE_REL/logs/"

"$PYTHON" - \
  "$ROOT" \
  "$AUTH_REL" \
  "$REPORT_REL" \
  "$SUMMARY_REL" \
  "$AUTH_COMMIT" \
  "$STARTED_UTC" \
  "$COMPLETED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
authorization_path = root / sys.argv[2]
report_path = root / sys.argv[3]
summary_path = root / sys.argv[4]
authorization_commit = sys.argv[5]
started_utc = sys.argv[6]
completed_utc = sys.argv[7]

e3 = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution"
)


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")

    return value


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


replication_reports = []
total_instances = 0
total_steps = 0

for replication in range(2, 10):
    token = f"rep_{replication:03d}"
    stem = (
        "virtual_node_count_stage10_"
        f"{token}_strict_common"
    )

    spec_path = (
        e3 / "execution_specs" / f"{stem}.json"
    )
    output_dir = e3 / "runs" / stem
    log_path = (
        e3
        / "audits"
        / "virtual_node_count_stage10"
        / "functional_execution"
        / "logs"
        / f"virtual_node_count_stage10_{token}_functional.log"
    )

    manifest = load_json(
        root / output_dir / "execution_manifest.json"
    )
    metrics = load_json(
        root / output_dir / "campaign_metrics.json"
    )

    with (
        root / output_dir / "instance_results.csv"
    ).open(
        newline="",
        encoding="utf-8",
    ) as stream:
        rows = list(csv.DictReader(stream))

    selected_instances = int(
        manifest["selected_instance_count"]
    )
    step_count = int(metrics["step_count"])

    if selected_instances != 3:
        raise SystemExit(
            f"Invalid instance count for {token}"
        )

    if step_count != 6:
        raise SystemExit(
            f"Invalid step count for {token}"
        )

    if len(rows) != 3:
        raise SystemExit(
            f"Invalid CSV row count for {token}"
        )

    total_instances += selected_instances
    total_steps += step_count

    replication_reports.append(
        {
            "replication_index": replication,
            "execution_id": manifest["execution_id"],
            "selected_instance_count": selected_instances,
            "step_count": step_count,
            "deterministic_execution_digest": (
                manifest[
                    "deterministic_execution_digest"
                ]
            ),
            "execution_spec_path": spec_path.as_posix(),
            "execution_spec_sha256": sha256_file(
                root / spec_path
            ),
            "output_dir": output_dir.as_posix(),
            "execution_manifest_sha256": sha256_file(
                root
                / output_dir
                / "execution_manifest.json"
            ),
            "campaign_metrics_sha256": sha256_file(
                root
                / output_dir
                / "campaign_metrics.json"
            ),
            "instance_results_sha256": sha256_file(
                root
                / output_dir
                / "instance_results.csv"
            ),
            "execution_log_path": log_path.as_posix(),
            "execution_log_sha256": sha256_file(
                root / log_path
            ),
            "status": "pass",
        }
    )

if total_instances != 24:
    raise SystemExit(
        f"Expected 24 instances; got {total_instances}"
    )

if total_steps != 48:
    raise SystemExit(
        f"Expected 48 steps; got {total_steps}"
    )

authorization = load_json(authorization_path)

report = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "new-functional-execution-report-v1"
    ),
    "status": "pass",
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "authorization_path": (
        authorization_path.relative_to(root).as_posix()
    ),
    "authorization_sha256": sha256_file(
        authorization_path
    ),
    "authorization_commit": authorization_commit,
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "executed_replications": list(range(2, 10)),
    "executed_replication_count": 8,
    "executed_instance_count": total_instances,
    "executed_functional_step_count": total_steps,
    "expected_instance_count": 24,
    "expected_functional_step_count": 48,
    "all_new_replications_passed": True,
    "historical_prefix": {
        "replications": [0, 1],
        "rerun_performed": False,
        "rerun_required": False,
        "reuse_required": True,
        "historical_functional_step_count": 12,
    },
    "combined_target": {
        "replication_count": 10,
        "instance_count": 30,
        "functional_step_count": 60,
        "combined_audit_completed": False,
    },
    "timing_execution_performed": False,
    "latency_claim_authorized": False,
    "replications": replication_reports,
    "authorization_snapshot": authorization,
    "next_stage": (
        "reuse_historical_prefix_and_audit_"
        "combined_60_functional_steps"
    ),
}

report_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

summary = f"""# Virtual-node-count Stage-10 functional execution

- Status: `PASS`
- Newly executed replications: `002` through `009`
- New replication count: `8`
- New instance count: `{total_instances}`
- New functional step count: `{total_steps}`
- Historical replications rerun: `false`
- Historical functional prefix reuse required: `true`
- Timing execution performed: `false`
- Latency claim authorized: `false`

## Next stage

`reuse_historical_prefix_and_audit_combined_60_functional_steps`
"""

summary_path.write_text(
    summary,
    encoding="utf-8",
)

print("functional_execution_audit=PASS")
print(f"executed_instance_count={total_instances}")
print(f"executed_functional_step_count={total_steps}")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=false")
PY

AUDIT_STATUS=$?
echo "functional_execution_audit_exit_status=$AUDIT_STATUS"

[ "$AUDIT_STATUS" -eq 0 ] ||
  fail "Functional execution audit failed."

echo
echo "=== 6. Commit functional evidence ==="

RUN_PATHS=()

for REP in "${REPLICATIONS[@]}"; do
  RUN_PATHS+=(
    "$RUNS_REL/virtual_node_count_stage10_rep_${REP}_strict_common"
  )
done

git add -f \
  "$EVIDENCE_REL" \
  "${RUN_PATHS[@]}"

git diff --cached --check ||
  fail "Evidence diff check failed."

git commit \
  -m "evidence(experiments): execute virtual-node-count Stage-10 functional reps 002-009" ||
  fail "Evidence commit failed."

EVIDENCE_COMMIT="$(git rev-parse HEAD)"

git push origin "$BRANCH" ||
  fail "Evidence push failed."

echo "evidence_commit=$EVIDENCE_COMMIT"
echo "evidence_commit_pushed=true"

echo
echo "=== 7. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE_BRANCH" \
    --title "Execute virtual-node-count Stage-10 functional reps 002-009" \
    --body "$(cat <<'EOF'
## Scope

- records a versioned functional authorization before execution;
- executes only virtual-node-count Stage-10 rep_002 through rep_009;
- evaluates 24 new structural instances and 48 functional steps;
- preserves rep_000 and rep_001 without rerunning them;
- versions complete controlled-execution outputs and logs;
- performs no timing execution.

## Validation

- new replication count: 8;
- new instance count: 24;
- new functional step count: 48;
- successful new replications: 8/8;
- historical prefix rerun performed: false;
- timing execution performed: false.

## Next stage

Reuse the valid historical prefix for rep_000 and rep_001 and audit the combined 60 functional steps.
EOF
)"
)"

PR_STATUS=$?
PR_NUMBER="${PR_URL##*/}"

echo "pr_creation_exit_status=$PR_STATUS"
echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

[ "$PR_STATUS" -eq 0 ] ||
  fail "PR creation failed."

echo
echo "=== 8. Final state ==="

echo "virtual_node_count_stage10_new_functional_execution=PASS"
echo "authorization_commit=$AUTH_COMMIT"
echo "evidence_commit=$EVIDENCE_COMMIT"
echo "executed_replications=002,003,004,005,006,007,008,009"
echo "new_replication_count=8"
echo "new_instance_count=24"
echo "new_functional_step_count=48"
echo "historical_prefix_rerun_performed=false"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_functional_evidence_pr"

git status --short --branch
