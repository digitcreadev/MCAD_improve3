#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
SNAPSHOT_ROOT="/workspaces/mcad_repro_control_plane_${STAMP}"
PAYLOAD="$SNAPSHOT_ROOT/payload"
ARCHIVE="/workspaces/mcad_repro_control_plane_${STAMP}.tar.gz"
ARCHIVE_SHA="${ARCHIVE}.sha256"

trap 'echo "[ERROR] Emergency reproducibility snapshot stopped at line $LINENO."' ERR

mkdir -p \
  "$PAYLOAD/workspaces_top_level" \
  "$PAYLOAD/detached_metadata" \
  "$PAYLOAD/repository_metadata" \
  "$PAYLOAD/repository_repro_assets"

cd "$ROOT"

echo "=== 1. Non-interference gate ==="

TIMING_PID="$(
  pgrep -n -f 'python.*[r]un_timing_repetitions' || true
)"

echo "timing_pid=${TIMING_PID:-absent}"
echo "repository_head=$(git rev-parse HEAD)"
echo "repository_branch=$(git branch --show-current)"
echo "repository_clean=$(
  test -z "$(git status --porcelain)" && echo true || echo false
)"

echo "tests_executed=false"
echo "timing_outputs_copied=false"
echo "git_repository_modified=false"

echo
echo "=== 2. Copy orchestration scripts stored outside the repository ==="

find /workspaces \
  -maxdepth 1 \
  -type f \
  \( -name '*.sh' -o -name '*.py' -o -name '*.txt' \) \
  -size -8M \
  -print0 |
while IFS= read -r -d '' FILE; do
  cp -p "$FILE" "$PAYLOAD/workspaces_top_level/"
done

TOP_LEVEL_COUNT="$(
  find "$PAYLOAD/workspaces_top_level" -maxdepth 1 -type f | wc -l
)"

echo "workspaces_top_level_file_count=$TOP_LEVEL_COUNT"

echo
echo "=== 3. Copy detached audit and recovery metadata only ==="

find /workspaces \
  -mindepth 2 \
  -maxdepth 4 \
  -type f \
  \( \
    -name '*.json' -o \
    -name '*.txt' -o \
    -name '*.md' -o \
    -name '*.sha256' \
  \) \
  -size -8M \
  \( \
    -path '/workspaces/sa5_*/*' -o \
    -path '/workspaces/robustness_*/*' \
  \) \
  ! -path '*/timing_runs/*' \
  ! -path '*/logs/*' \
  -print0 |
while IFS= read -r -d '' FILE; do
  RELATIVE="${FILE#/workspaces/}"
  DEST="$PAYLOAD/detached_metadata/$RELATIVE"
  mkdir -p "$(dirname "$DEST")"
  cp -p "$FILE" "$DEST"
done

DETACHED_COUNT="$(
  find "$PAYLOAD/detached_metadata" -type f | wc -l
)"

echo "detached_metadata_file_count=$DETACHED_COUNT"

echo
echo "=== 4. Capture repository state and reproducibility index ==="

{
  echo "captured_at_utc=$STAMP"
  echo "repository=$ROOT"
  echo "head=$(git rev-parse HEAD)"
  echo "branch=$(git branch --show-current)"
  echo "origin_url=$(git remote get-url origin)"
  echo "timing_pid=${TIMING_PID:-absent}"
} > "$PAYLOAD/repository_metadata/state.txt"

git status --short --branch \
  > "$PAYLOAD/repository_metadata/git_status.txt"

git remote -v \
  > "$PAYLOAD/repository_metadata/git_remotes.txt"

git show-ref \
  > "$PAYLOAD/repository_metadata/git_show_ref.txt"

git log \
  --all \
  --date=iso-strict \
  --format='%H%x09%ad%x09%s' \
  > "$PAYLOAD/repository_metadata/git_history.tsv"

git ls-files \
  > "$PAYLOAD/repository_metadata/tracked_files.txt"

git ls-files |
  grep -E \
    '(^|/)(reproduc|experiment|campaign|audit|planning|timing|precision|bootstrap|sensitivity|workflow|requirements|lock|pyproject|Dockerfile|compose)' \
  > "$PAYLOAD/repository_metadata/tracked_reproducibility_assets.txt" \
  || true

git ls-files -o -i --exclude-standard |
  grep -E '\.(sh|py|json|md|txt|sha256)$' \
  > "$PAYLOAD/repository_metadata/ignored_orchestration_candidates.txt" \
  || true

while IFS= read -r FILE; do
  [ -f "$FILE" ] || continue

  case "$FILE" in
    backend/harness/sensitivity_execution/*.py|\
    backend/harness/sensitivity_execution/tools/*.py|\
    .github/workflows/*.yml|\
    .github/workflows/*.yaml|\
    reports/article_experiments/sensitivity/e3_controlled_execution/planning/*.json|\
    reports/article_experiments/sensitivity/e3_controlled_execution/planning/*.md|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*.json|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*.sha256|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*/*.json|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*/*.sha256|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*/*/*.json|\
    reports/article_experiments/sensitivity/e3_controlled_execution/timing_setup/*/*/*.sha256)
      ;;
    *)
      continue
      ;;
  esac

  SIZE="$(stat -c '%s' "$FILE")"
  [ "$SIZE" -le 8388608 ] || continue

  DEST="$PAYLOAD/repository_repro_assets/$FILE"
  mkdir -p "$(dirname "$DEST")"
  cp -p "$FILE" "$DEST"
done < "$PAYLOAD/repository_metadata/tracked_files.txt"

REPO_ASSET_COUNT="$(
  find "$PAYLOAD/repository_repro_assets" -type f | wc -l
)"

echo "repository_repro_asset_copy_count=$REPO_ASSET_COUNT"

echo
echo "=== 5. Build checksummed emergency archive ==="

(
  cd "$PAYLOAD"
  find . -type f -print0 |
    sort -z |
    xargs -0 sha256sum \
      > ../MANIFEST.sha256
)

cat > "$SNAPSHOT_ROOT/README.txt" <<EOF
MCAD emergency reproducibility control-plane snapshot
=====================================================

Captured at UTC: $STAMP
Repository: $ROOT
Repository HEAD: $(git rev-parse HEAD)
Repository branch: $(git branch --show-current)
Timing process PID: ${TIMING_PID:-absent}

Contents
--------
- orchestration scripts stored directly under /workspaces;
- detached SA5/robustness audit and recovery metadata;
- repository state, refs, history and reproducibility indexes;
- a small copy of tracked control-plane sources and planning manifests.

Deliberate exclusions
---------------------
- current timing output files;
- large campaign payloads already committed in Git;
- Git object database and full git bundle;
- virtual environments;
- execution of tests or analyses.

This archive protects against Codespace loss only after it is downloaded
outside the Codespace. After the timing campaign, create a full Git bundle
and commit canonical orchestration scripts into the repository.
EOF

tar \
  -C /workspaces \
  -I 'gzip -1' \
  -cf "$ARCHIVE" \
  "$(basename "$SNAPSHOT_ROOT")"

sha256sum "$ARCHIVE" > "$ARCHIVE_SHA"

echo "snapshot_archive=$ARCHIVE"
echo "snapshot_archive_sha256=$(
  sha256sum "$ARCHIVE" | awk '{print $1}'
)"
echo "snapshot_archive_size_bytes=$(stat -c '%s' "$ARCHIVE")"
echo "snapshot_manifest=$SNAPSHOT_ROOT/MANIFEST.sha256"
echo "snapshot_manifest_line_count=$(
  wc -l < "$SNAPSHOT_ROOT/MANIFEST.sha256"
)"

echo
echo "=== 6. Final state ==="

test -z "$(git status --porcelain)"

echo "emergency_reproducibility_snapshot=PASS"
echo "repository_modified=false"
echo "timing_process_signalled=false"
echo "timing_outputs_copied=false"
echo "tests_executed=false"
echo "required_action=download_archive_outside_codespace_now"

git status --short --branch
