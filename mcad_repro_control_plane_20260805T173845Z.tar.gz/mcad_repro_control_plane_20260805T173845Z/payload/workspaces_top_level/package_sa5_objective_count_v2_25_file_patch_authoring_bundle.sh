#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0674825017698f25562d43400ff4e72cb6484e2f"
HEAD_SHORT="${EXPECTED_HEAD:0:7}"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"
AMENDMENT_003_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py"

FINAL_SCOPE_ROOT="/workspaces/sa5_objective_count_v2_post_noise_scope_reprojection_20260804T235857Z"

FINAL_SCOPE_REPORT="$FINAL_SCOPE_ROOT/sa5_objective_count_v2_post_noise_scope_reprojection.json"
EXPECTED_FINAL_SCOPE_REPORT_SHA="37660c8e83dee687cc7ac4bbf07be54c667e4bf83f9c3fd5d64324f596587025"

FINAL_SCOPE_SURFACE="$FINAL_SCOPE_ROOT/sa5_objective_count_v2_post_noise_scope_reprojection.txt"
EXPECTED_FINAL_SCOPE_SURFACE_SHA="4bfc0f13a7d7a660ccc40268bd135d6b05cb5fdae11ab7042084d093c4d617e1"

PRIOR_SCOPE_ROOT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z"

PRIOR_SCOPE_REPORT="$PRIOR_SCOPE_ROOT/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_PRIOR_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

PRIOR_SCOPE_SURFACE="$PRIOR_SCOPE_ROOT/sa5_objective_count_v2_scope_reprojection.txt"
EXPECTED_PRIOR_SCOPE_SURFACE_SHA="39b16b812355b4149c98401ed4da32fe8d2623edd4977e5859a68ce2fa66ac1f"

BINDING_ROOT="/workspaces/sa5_objective_count_v2_binding_candidate_classification_20260804T223518Z"

BINDING_REPORT="$BINDING_ROOT/sa5_objective_count_v2_binding_candidate_classification.json"
EXPECTED_BINDING_REPORT_SHA="7cbd688bfe149b2a21d8306ccadb4534da890f3d2608725f2c74e540a05cff36"

BINDING_SURFACE="$BINDING_ROOT/sa5_objective_count_v2_binding_candidate_classification.txt"
EXPECTED_BINDING_SURFACE_SHA="351e4542eefdf2bea80e987ee5e1e48c95ea1b8c4ab7986e2fe8f061f4cb2ef9"

CAPACITY_ROOT="/workspaces/sa5_objective_count_workload_contribution_capacity_20260804T224333Z"

CAPACITY_REPORT="$CAPACITY_ROOT/sa5_objective_count_workload_contribution_capacity.json"
EXPECTED_CAPACITY_REPORT_SHA="ee16b7c41d5c02bad6e3f8a525f5d59283f3ffce9acb365d30dfce6abe469a98"

CAPACITY_SURFACE="$CAPACITY_ROOT/sa5_objective_count_workload_contribution_capacity.txt"
EXPECTED_CAPACITY_SURFACE_SHA="5a6fdb2cacf9c76243ee235125eed7a541f77231b5faef194abbf070f8ad45ab"

LINE456_ROOT="/workspaces/sa5_noise_operator_line456_diagnosis_20260804T232101Z"

LINE456_REPORT="$LINE456_ROOT/sa5_noise_operator_line456_diagnosis.json"
EXPECTED_LINE456_REPORT_SHA="1389e242220906b675e9178da05f8776619c7ecfa8c033daf5a25202a9707432"

LINE456_SURFACE="$LINE456_ROOT/sa5_noise_operator_line456_diagnosis.txt"
EXPECTED_LINE456_SURFACE_SHA="018cbba8e25d07dc4c62ea514742228e68f8e4a1de6e4aadb51af06b06b862aa"

NOISE_CLASSIFICATION_ROOT="/workspaces/sa5_existing_noise_production_hit_classification_20260804T233007Z"

NOISE_CLASSIFICATION_REPORT="$NOISE_CLASSIFICATION_ROOT/sa5_existing_noise_production_hit_classification.json"
EXPECTED_NOISE_CLASSIFICATION_REPORT_SHA="b89b96e727e5fc460dab1c32ba957a8b8e8f287e1eff4f5ce2580706ee3020fb"

NOISE_CLASSIFICATION_SURFACE="$NOISE_CLASSIFICATION_ROOT/sa5_existing_noise_production_hit_classification.txt"
EXPECTED_NOISE_CLASSIFICATION_SURFACE_SHA="8d20be9e3f07f3633de7d05e541efe402b07edfc278b5c552b63ff0449c7ac3e"

PRIOR_INPUT_BUNDLE="/workspaces/sa5_objective_count_v2_patch_input_bundle_20260804T212430Z.tar.gz"
EXPECTED_PRIOR_INPUT_BUNDLE_SHA="e406dff67c13a444ce7054da33b23afe1619c5b26cdddf7324d06ff61a26dd6b"

WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

BUNDLE_NAME="sa5_objective_count_v2_25_file_patch_authoring_bundle_${HEAD_SHORT}"
BUNDLE_ROOT="/workspaces/$BUNDLE_NAME"
ARCHIVE="/workspaces/${BUNDLE_NAME}.tar.gz"

VERIFY_ROOT="$(mktemp -d /workspaces/sa5_v2_authoring_bundle_verify.XXXXXX)"

cleanup() {
  rm -rf "$VERIFY_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 v2 authoring-bundle packaging stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact post-reprojection gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_003" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_003_TEST" \
  "$WORKLOAD_SCHEMA" \
  "$FINAL_SCOPE_REPORT" \
  "$FINAL_SCOPE_SURFACE" \
  "$PRIOR_SCOPE_REPORT" \
  "$PRIOR_SCOPE_SURFACE" \
  "$BINDING_REPORT" \
  "$BINDING_SURFACE" \
  "$CAPACITY_REPORT" \
  "$CAPACITY_SURFACE" \
  "$LINE456_REPORT" \
  "$LINE456_SURFACE" \
  "$NOISE_CLASSIFICATION_REPORT" \
  "$NOISE_CLASSIFICATION_SURFACE" \
  "$PRIOR_INPUT_BUNDLE" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

verify_sha \
  "$FINAL_SCOPE_REPORT" \
  "$EXPECTED_FINAL_SCOPE_REPORT_SHA"

verify_sha \
  "$FINAL_SCOPE_SURFACE" \
  "$EXPECTED_FINAL_SCOPE_SURFACE_SHA"

verify_sha \
  "$PRIOR_SCOPE_REPORT" \
  "$EXPECTED_PRIOR_SCOPE_REPORT_SHA"

verify_sha \
  "$PRIOR_SCOPE_SURFACE" \
  "$EXPECTED_PRIOR_SCOPE_SURFACE_SHA"

verify_sha \
  "$BINDING_REPORT" \
  "$EXPECTED_BINDING_REPORT_SHA"

verify_sha \
  "$BINDING_SURFACE" \
  "$EXPECTED_BINDING_SURFACE_SHA"

verify_sha \
  "$CAPACITY_REPORT" \
  "$EXPECTED_CAPACITY_REPORT_SHA"

verify_sha \
  "$CAPACITY_SURFACE" \
  "$EXPECTED_CAPACITY_SURFACE_SHA"

verify_sha \
  "$LINE456_REPORT" \
  "$EXPECTED_LINE456_REPORT_SHA"

verify_sha \
  "$LINE456_SURFACE" \
  "$EXPECTED_LINE456_SURFACE_SHA"

verify_sha \
  "$NOISE_CLASSIFICATION_REPORT" \
  "$EXPECTED_NOISE_CLASSIFICATION_REPORT_SHA"

verify_sha \
  "$NOISE_CLASSIFICATION_SURFACE" \
  "$EXPECTED_NOISE_CLASSIFICATION_SURFACE_SHA"

verify_sha \
  "$PRIOR_INPUT_BUNDLE" \
  "$EXPECTED_PRIOR_INPUT_BUNDLE_SHA"

jq -e '
  .status
    == "sa5_objective_count_v2_post_noise_operator_scope_resolved"
  and .source_commit
    == "0674825017698f25562d43400ff4e72cb6484e2f"
  and .final_scope.new_file_count == 12
  and .final_scope.modified_file_count == 13
  and .final_scope.total_patch_file_count == 25
  and .blocker_count == 0
  and .scope_complete == true
  and .semantic_materializability_proven == true
  and .v2_patch_authoring_authorized == true
  and .canonical_campaign_materialization_authorized == false
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_25_file_scope"
' "$FINAL_SCOPE_REPORT" >/dev/null

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "post_reprojection_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "final_patch_file_count=25"
echo "semantic_materializability_proven=true"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Materialize exact scope manifests outside repository ==="

rm -rf "$BUNDLE_ROOT"
rm -f "$ARCHIVE"

mkdir -p \
  "$BUNDLE_ROOT/payload/repository" \
  "$BUNDLE_ROOT/payload/detached_provenance" \
  "$BUNDLE_ROOT/payload/prior_input_bundle" \
  "$BUNDLE_ROOT/metadata"

cat > "$BUNDLE_ROOT/metadata/modified_files.txt" <<'EOF'
.github/workflows/phase3-regression.yml
backend/ckg/ckg_updater.py
backend/harness/sensitivity_execution/e3_contract.yaml
backend/harness/sensitivity_execution/execute_controlled_family.py
backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
backend/harness/sensitivity_execution/tests/test_workload_spec.py
backend/harness/sensitivity_execution/validate_e3_contract.py
backend/harness/sensitivity_execution/validate_workload_spec.py
backend/harness/sensitivity_generator/families/controlled_families.py
backend/harness/sensitivity_generator/tests/test_controlled_families.py
backend/mcad/models.py
backend/mcad/objectives.py
EOF

cat > "$BUNDLE_ROOT/metadata/new_files.txt" <<'EOF'
backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_generator/families/objective_count_family_v2.py
backend/harness/sensitivity_generator/objective_count_generator_v2.py
backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
EOF

cat > "$BUNDLE_ROOT/metadata/review_only_unchanged_files.txt" <<'EOF'
backend/harness/sensitivity_execution/workload_spec.schema.json
EOF

cat > "$BUNDLE_ROOT/metadata/authoritative_repo_files.txt" <<EOF
$PREREG
$AMENDMENT_001
$AMENDMENT_002
$AMENDMENT_003
$PREREG_TEST
$AMENDMENT_001_TEST
$AMENDMENT_002_TEST
$AMENDMENT_003_TEST
EOF

jq -r \
  '.final_scope.modified_files[]' \
  "$FINAL_SCOPE_REPORT" |
  sort \
  > "$VERIFY_ROOT/report_modified_files.txt"

sort \
  "$BUNDLE_ROOT/metadata/modified_files.txt" \
  > "$VERIFY_ROOT/expected_modified_files.txt"

diff -u \
  "$VERIFY_ROOT/expected_modified_files.txt" \
  "$VERIFY_ROOT/report_modified_files.txt"

jq -r \
  '.final_scope.new_files[]' \
  "$FINAL_SCOPE_REPORT" |
  sort \
  > "$VERIFY_ROOT/report_new_files.txt"

sort \
  "$BUNDLE_ROOT/metadata/new_files.txt" \
  > "$VERIFY_ROOT/expected_new_files.txt"

diff -u \
  "$VERIFY_ROOT/expected_new_files.txt" \
  "$VERIFY_ROOT/report_new_files.txt"

jq -r \
  '.final_scope.review_only_unchanged_files[]' \
  "$FINAL_SCOPE_REPORT" |
  sort \
  > "$VERIFY_ROOT/report_review_only_files.txt"

sort \
  "$BUNDLE_ROOT/metadata/review_only_unchanged_files.txt" \
  > "$VERIFY_ROOT/expected_review_only_files.txt"

diff -u \
  "$VERIFY_ROOT/expected_review_only_files.txt" \
  "$VERIFY_ROOT/report_review_only_files.txt"

test "$(
  wc -l < "$BUNDLE_ROOT/metadata/modified_files.txt"
)" -eq 13

test "$(
  wc -l < "$BUNDLE_ROOT/metadata/new_files.txt"
)" -eq 12

test "$(
  wc -l < "$BUNDLE_ROOT/metadata/review_only_unchanged_files.txt"
)" -eq 1

while IFS= read -r FILE; do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" >/dev/null
done < "$BUNDLE_ROOT/metadata/modified_files.txt"

while IFS= read -r FILE; do
  test ! -e "$FILE"
done < "$BUNDLE_ROOT/metadata/new_files.txt"

while IFS= read -r FILE; do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" >/dev/null
done < "$BUNDLE_ROOT/metadata/review_only_unchanged_files.txt"

cat \
  "$BUNDLE_ROOT/metadata/modified_files.txt" \
  "$BUNDLE_ROOT/metadata/review_only_unchanged_files.txt" \
  "$BUNDLE_ROOT/metadata/authoritative_repo_files.txt" |
  sort -u \
  > "$BUNDLE_ROOT/metadata/repository_snapshot_files.txt"

test "$(
  wc -l < "$BUNDLE_ROOT/metadata/repository_snapshot_files.txt"
)" -eq 21

echo "scope_manifest_gate=PASS"
echo "modified_file_count=13"
echo "new_file_count=12"
echo "review_only_file_count=1"
echo "repository_snapshot_file_count=21"

echo
echo "=== 3. Copy exact current repository sources ==="

mapfile -t SNAPSHOT_FILES \
  < "$BUNDLE_ROOT/metadata/repository_snapshot_files.txt"

(
  cd "$ROOT"

  tar -cf - \
    "${SNAPSHOT_FILES[@]}"
) |
(
  cd "$BUNDLE_ROOT/payload/repository"

  tar -xf -
)

for FILE in "${SNAPSHOT_FILES[@]}"; do
  cmp \
    "$ROOT/$FILE" \
    "$BUNDLE_ROOT/payload/repository/$FILE"
done

(
  cd "$ROOT"

  sha256sum \
    "${SNAPSHOT_FILES[@]}"
) > "$BUNDLE_ROOT/metadata/repository_snapshot_sha256sums.txt"

git ls-tree \
  -r \
  "$EXPECTED_HEAD" \
  -- \
  "${SNAPSHOT_FILES[@]}" \
  > "$BUNDLE_ROOT/metadata/repository_snapshot_git_tree.txt"

git show \
  -s \
  --format=fuller \
  "$EXPECTED_HEAD" \
  > "$BUNDLE_ROOT/metadata/git_head.txt"

git log \
  --oneline \
  --decorate \
  -10 \
  > "$BUNDLE_ROOT/metadata/git_log.txt"

git status \
  --short \
  --branch \
  > "$BUNDLE_ROOT/metadata/git_status.txt"

echo "repository_snapshot_copy=PASS"
echo "repository_snapshot_file_count=${#SNAPSHOT_FILES[@]}"

echo
echo "=== 4. Copy detached provenance chain ==="

copy_detached() {
  local SOURCE="$1"
  local EXPECTED_SHA="$2"
  local DESTINATION_NAME="$3"
  local DESTINATION

  verify_sha "$SOURCE" "$EXPECTED_SHA"

  DESTINATION="$BUNDLE_ROOT/payload/detached_provenance/$DESTINATION_NAME"

  cp -p \
    "$SOURCE" \
    "$DESTINATION"

  verify_sha \
    "$DESTINATION" \
    "$EXPECTED_SHA"
}

copy_detached \
  "$BINDING_REPORT" \
  "$EXPECTED_BINDING_REPORT_SHA" \
  "01_binding_candidate_classification.json"

copy_detached \
  "$BINDING_SURFACE" \
  "$EXPECTED_BINDING_SURFACE_SHA" \
  "01_binding_candidate_classification.txt"

copy_detached \
  "$CAPACITY_REPORT" \
  "$EXPECTED_CAPACITY_REPORT_SHA" \
  "02_workload_contribution_capacity.json"

copy_detached \
  "$CAPACITY_SURFACE" \
  "$EXPECTED_CAPACITY_SURFACE_SHA" \
  "02_workload_contribution_capacity.txt"

copy_detached \
  "$PRIOR_SCOPE_REPORT" \
  "$EXPECTED_PRIOR_SCOPE_REPORT_SHA" \
  "03_post_capacity_scope_reprojection.json"

copy_detached \
  "$PRIOR_SCOPE_SURFACE" \
  "$EXPECTED_PRIOR_SCOPE_SURFACE_SHA" \
  "03_post_capacity_scope_reprojection.txt"

copy_detached \
  "$LINE456_REPORT" \
  "$EXPECTED_LINE456_REPORT_SHA" \
  "04_noise_operator_line456_diagnosis.json"

copy_detached \
  "$LINE456_SURFACE" \
  "$EXPECTED_LINE456_SURFACE_SHA" \
  "04_noise_operator_line456_diagnosis.txt"

copy_detached \
  "$NOISE_CLASSIFICATION_REPORT" \
  "$EXPECTED_NOISE_CLASSIFICATION_REPORT_SHA" \
  "05_existing_noise_production_hit_classification.json"

copy_detached \
  "$NOISE_CLASSIFICATION_SURFACE" \
  "$EXPECTED_NOISE_CLASSIFICATION_SURFACE_SHA" \
  "05_existing_noise_production_hit_classification.txt"

copy_detached \
  "$FINAL_SCOPE_REPORT" \
  "$EXPECTED_FINAL_SCOPE_REPORT_SHA" \
  "06_post_noise_scope_reprojection.json"

copy_detached \
  "$FINAL_SCOPE_SURFACE" \
  "$EXPECTED_FINAL_SCOPE_SURFACE_SHA" \
  "06_post_noise_scope_reprojection.txt"

cp -p \
  "$PRIOR_INPUT_BUNDLE" \
  "$BUNDLE_ROOT/payload/prior_input_bundle/"

verify_sha \
  "$BUNDLE_ROOT/payload/prior_input_bundle/$(basename "$PRIOR_INPUT_BUNDLE")" \
  "$EXPECTED_PRIOR_INPUT_BUNDLE_SHA"

echo "detached_provenance_copy=PASS"
echo "detached_provenance_file_count=12"
echo "prior_input_bundle_sha256=$EXPECTED_PRIOR_INPUT_BUNDLE_SHA"

echo
echo "=== 5. Author machine-readable bundle contract ==="

export BUNDLE_ROOT
export BUNDLE_NAME
export EXPECTED_HEAD
export BASE
export EXPECTED_PREREG_SHA
export EXPECTED_AMENDMENT_001_SHA
export EXPECTED_AMENDMENT_002_SHA
export EXPECTED_AMENDMENT_003_SHA
export EXPECTED_FINAL_SCOPE_REPORT_SHA
export EXPECTED_FINAL_SCOPE_SURFACE_SHA
export EXPECTED_PRIOR_INPUT_BUNDLE_SHA

python3 - <<'PY'
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path


bundle_root = Path(
    os.environ["BUNDLE_ROOT"]
)

metadata_root = bundle_root / "metadata"


def read_lines(name: str) -> list[str]:
    return [
        line
        for line in (
            metadata_root / name
        ).read_text(
            encoding="utf-8"
        ).splitlines()
        if line
    ]


source_commit = os.environ[
    "EXPECTED_HEAD"
]

source_commit_date = subprocess.run(
    [
        "git",
        "-C",
        "/workspaces/MCAD_improve3",
        "show",
        "-s",
        "--format=%cI",
        source_commit,
    ],
    check=True,
    capture_output=True,
    text=True,
).stdout.strip()

contract = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "25-file-patch-authoring-bundle-v1"
    ),
    "bundle_name": os.environ[
        "BUNDLE_NAME"
    ],
    "source_branch": os.environ["BASE"],
    "source_commit": source_commit,
    "source_commit_date": source_commit_date,
    "final_scope": {
        "new_files": read_lines(
            "new_files.txt"
        ),
        "modified_files": read_lines(
            "modified_files.txt"
        ),
        "review_only_unchanged_files": (
            read_lines(
                "review_only_unchanged_files.txt"
            )
        ),
        "new_file_count": 12,
        "modified_file_count": 13,
        "total_patch_file_count": 25,
    },
    "repository_snapshot": {
        "files": read_lines(
            "repository_snapshot_files.txt"
        ),
        "file_count": 21,
    },
    "authoritative_hashes": {
        "original_preregistration": (
            os.environ[
                "EXPECTED_PREREG_SHA"
            ]
        ),
        "materialization_amendment_001": (
            os.environ[
                "EXPECTED_AMENDMENT_001_SHA"
            ]
        ),
        "capacity_amendment_002": (
            os.environ[
                "EXPECTED_AMENDMENT_002_SHA"
            ]
        ),
        "noise_operator_amendment_003": (
            os.environ[
                "EXPECTED_AMENDMENT_003_SHA"
            ]
        ),
        "final_scope_report": (
            os.environ[
                "EXPECTED_FINAL_SCOPE_REPORT_SHA"
            ]
        ),
        "final_scope_surface": (
            os.environ[
                "EXPECTED_FINAL_SCOPE_SURFACE_SHA"
            ]
        ),
        "prior_input_bundle": (
            os.environ[
                "EXPECTED_PRIOR_INPUT_BUNDLE_SHA"
            ]
        ),
    },
    "implementation_contract": {
        "target_structural_generator_version": (
            "mcad-sensitivity-e2.1-"
            "objective-count-v2"
        ),
        "target_campaign_generator_version": (
            "mcad-sensitivity-e2.2-"
            "objective-count-v2"
        ),
        "workload_length": 32,
        "oracle_contributive_query_count": 24,
        "non_contributive_query_count": 8,
        "noise_class_count": 8,
        "session_support_policy": (
            "union_requirement_sets"
        ),
        "support_resources_per_objective": 24,
        "operator_oracle_mismatch_count": 0,
        "semantic_materializability_proven": True,
        "workload_schema_modification_required": False,
        "v2_patch_authoring_authorized": True,
    },
    "preservation_contract": {
        "preserve_v1_generator_module_bytes": True,
        "preserve_historical_support_behavior": True,
        "preserve_historical_workload_validation": True,
        "preserve_membership_density_profile": True,
        "manuscript_must_remain_unchanged": True,
    },
    "prohibitions": {
        "canonical_campaign_materialization_authorized": False,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "scientific_execution_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "next_stage": (
        "attach_sa5_objective_count_v2_"
        "25_file_patch_authoring_bundle"
    ),
}

(
    metadata_root
    / "AUTHORING_CONTRACT.json"
).write_text(
    json.dumps(
        contract,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

print("bundle_contract_authoring=PASS")
print("final_new_file_count=12")
print("final_modified_file_count=13")
print("final_total_patch_file_count=25")
print("v2_patch_authoring_authorized=true")
print(
    "canonical_campaign_materialization_"
    "authorized=false"
)
PY

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-25-file-patch-authoring-bundle-v1"
  and .source_branch
    == "paper/phase3-controlled-execution"
  and .source_commit
    == "0674825017698f25562d43400ff4e72cb6484e2f"
  and .final_scope.new_file_count == 12
  and .final_scope.modified_file_count == 13
  and .final_scope.total_patch_file_count == 25
  and .repository_snapshot.file_count == 21
  and .implementation_contract.workload_length == 32
  and .implementation_contract.oracle_contributive_query_count == 24
  and .implementation_contract.non_contributive_query_count == 8
  and .implementation_contract.operator_oracle_mismatch_count == 0
  and .implementation_contract.semantic_materializability_proven
    == true
  and .implementation_contract.workload_schema_modification_required
    == false
  and .implementation_contract.v2_patch_authoring_authorized
    == true
  and .prohibitions.canonical_campaign_materialization_authorized
    == false
  and .prohibitions.scientific_execution_authorized
    == false
  and .prohibitions.manuscript_integration_authorized
    == false
  and .next_stage
    == "attach_sa5_objective_count_v2_25_file_patch_authoring_bundle"
' "$BUNDLE_ROOT/metadata/AUTHORING_CONTRACT.json" >/dev/null

echo "bundle_contract_validation=PASS"

echo
echo "=== 6. Build complete payload hash manifest ==="

(
  cd "$BUNDLE_ROOT"

  find \
    payload \
    metadata \
    -type f \
    -print0 |
    sort -z |
    xargs -0 sha256sum \
      > PAYLOAD_SHA256SUMS
)

test -s "$BUNDLE_ROOT/PAYLOAD_SHA256SUMS"

(
  cd "$BUNDLE_ROOT"

  sha256sum \
    -c \
    PAYLOAD_SHA256SUMS \
    >/dev/null
)

PAYLOAD_FILE_COUNT="$(
  wc -l < "$BUNDLE_ROOT/PAYLOAD_SHA256SUMS"
)"

echo "payload_hash_manifest=PASS"
echo "payload_file_count=$PAYLOAD_FILE_COUNT"

echo
echo "=== 7. Create deterministic archive ==="

(
  cd /workspaces

  tar \
    --sort=name \
    --mtime='1970-01-01 00:00:00 UTC' \
    --owner=0 \
    --group=0 \
    --numeric-owner \
    -cf - \
    "$BUNDLE_NAME"
) |
gzip -n \
  > "$ARCHIVE"

test -s "$ARCHIVE"

ARCHIVE_SHA="$(
  sha256sum "$ARCHIVE" |
    awk '{print $1}'
)"

ARCHIVE_SIZE="$(
  stat -c '%s' "$ARCHIVE"
)"

echo "deterministic_archive_creation=PASS"
echo "archive=$ARCHIVE"
echo "archive_sha256=$ARCHIVE_SHA"
echo "archive_size=$ARCHIVE_SIZE"

echo
echo "=== 8. Independent archive extraction and verification ==="

tar \
  -xzf "$ARCHIVE" \
  -C "$VERIFY_ROOT"

EXTRACTED_ROOT="$VERIFY_ROOT/$BUNDLE_NAME"

test -d "$EXTRACTED_ROOT"
test -f "$EXTRACTED_ROOT/PAYLOAD_SHA256SUMS"
test -f "$EXTRACTED_ROOT/metadata/AUTHORING_CONTRACT.json"

(
  cd "$EXTRACTED_ROOT"

  sha256sum \
    -c \
    PAYLOAD_SHA256SUMS \
    >/dev/null
)

jq -e \
  --arg archive_sha "$ARCHIVE_SHA" \
  '
    .source_commit
      == "0674825017698f25562d43400ff4e72cb6484e2f"
    and .final_scope.total_patch_file_count
      == 25
    and .implementation_contract.v2_patch_authoring_authorized
      == true
    and .prohibitions.canonical_campaign_materialization_authorized
      == false
  ' "$EXTRACTED_ROOT/metadata/AUTHORING_CONTRACT.json" >/dev/null

cmp \
  "$BUNDLE_ROOT/metadata/AUTHORING_CONTRACT.json" \
  "$EXTRACTED_ROOT/metadata/AUTHORING_CONTRACT.json"

echo "archive_extraction_verification=PASS"
echo "archive_payload_hashes=PASS"

echo
echo "=== 9. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 10. Final state ==="

echo "sa5_objective_count_v2_25_file_patch_authoring_bundle=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "bundle_root=$BUNDLE_ROOT"
echo "archive=$ARCHIVE"
echo "archive_sha256=$ARCHIVE_SHA"
echo "archive_size=$ARCHIVE_SIZE"
echo "payload_file_count=$PAYLOAD_FILE_COUNT"

echo "final_new_file_count=12"
echo "final_modified_file_count=13"
echo "final_total_patch_file_count=25"

echo "operator_oracle_mismatch_count=0"
echo "semantic_materializability_proven=true"
echo "v2_patch_authoring_authorized=true"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=attach_sa5_objective_count_v2_25_file_patch_authoring_bundle"

git status --short --branch
