#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PREMATURE_PR=25

BASE="paper/phase3-controlled-execution"
EXPECTED_BASE_HEAD="791dade992f0de8ed80f5f675ebda0cef7654b1d"

OLD_BRANCH="paper/integrate-membership-density-stage10-manuscript-20260804T163131Z"
EXPECTED_OLD_HEAD="b1f697e5a4ac3a060723aee31c0f6a48cf88203d"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"

DRAFT_DIR="experiments/article/deferred_manuscript_fragments"
DRAFT_FILE="$DRAFT_DIR/sa4_membership_density_stage10_results_deferred.tex"

SECTION_START="\\subsection{Sensibilité à la densité d'appartenance des ensembles d'exigences}"
SECTION_LABEL="\\label{subsec:sa4-membership-density}"
TABLE_LABEL="\\label{tab:membership-density-stage10}"
SECTION_END="\\section{Discussion, limites et perspectives}"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

TEMP_ROOT="/workspaces/defer_membership_density_manuscript_${STAMP}"
TEMP_FRAGMENT="$TEMP_ROOT/sa4_membership_density_stage10_results_deferred.tex"

NEW_BRANCH="paper/preserve-membership-density-stage10-draft-${STAMP}"

trap 'echo "[ERROR] Manuscript deferral stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Premature-PR gate ==="

test "$(git branch --show-current)" = "$OLD_BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_OLD_HEAD"
test -z "$(git status --porcelain)"

test -f "$MANUSCRIPT"

test "$(
  grep -Fc "$SECTION_LABEL" "$MANUSCRIPT"
)" -eq 1

test "$(
  grep -Fc "$TABLE_LABEL" "$MANUSCRIPT"
)" -eq 1

PR_DATA="$(
  gh pr view "$PREMATURE_PR" \
    --repo "$REPO" \
    --json state,mergedAt,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_OLD_HEAD" \
  --arg branch "$OLD_BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "premature_pr_gate=PASS"
echo "premature_pr=$PREMATURE_PR"
echo "premature_manuscript_commit=$EXPECTED_OLD_HEAD"
echo "manuscript_integration_authorized=false"
echo "scientific_execution_performed=false"
echo "bootstrap_rerun_performed=false"

echo
echo "=== 2. Extract deferred editorial fragment ==="

rm -rf "$TEMP_ROOT"
mkdir -p "$TEMP_ROOT"

python3 - \
  "$ROOT" \
  "$MANUSCRIPT" \
  "$TEMP_FRAGMENT" \
  "$CREATED_UTC" \
  "$EXPECTED_BASE_HEAD" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
manuscript = (root / sys.argv[2]).resolve()
output = Path(sys.argv[3]).resolve()
created_utc = sys.argv[4]
frozen_base_commit = sys.argv[5]

section_start = (
    "\\subsection{Sensibilité à la densité "
    "d'appartenance des ensembles d'exigences}"
)

section_end = (
    "\\section{Discussion, limites et perspectives}"
)

text = manuscript.read_text(encoding="utf-8")

start_count = text.count(section_start)
end_count = text.count(section_end)

if start_count != 1:
    raise SystemExit(
        f"Expected one deferred section, got {start_count}."
    )

if end_count != 1:
    raise SystemExit(
        f"Expected one discussion anchor, got {end_count}."
    )

start = text.index(section_start)
end = text.index(section_end, start)

fragment = text[start:end].rstrip() + "\n"

required_values = (
    "92\\,000",
    "10\\,000",
    "0.456054",
    "0.897460",
    "0.459504",
    "0.907403",
    "0.462777",
    "0.910817",
    "0.465190",
    "0.916927",
)

for value in required_values:
    if value not in fragment:
        raise SystemExit(
            f"Deferred fragment lacks required value: {value}"
        )

header = "\n".join([
    "% DEFERRED MANUSCRIPT FRAGMENT — NOT INTEGRATED",
    "%",
    "% This fragment preserves a preliminary editorial rendering",
    "% of the frozen SA4 membership-density Stage-10 results.",
    "%",
    "% It must not be included in the canonical manuscript before:",
    "%   1. completion of all remaining sensitivity campaigns;",
    "%   2. consolidated statistical and cross-factor review;",
    "%   3. global scientific audit and freeze;",
    "%   4. final editorial refinement.",
    "%",
    f"% Preserved UTC: {created_utc}",
    f"% Frozen base commit: {frozen_base_commit}",
    "% Campaign scientific freeze: true",
    "% Global scientific freeze: false",
    "% Manuscript integration authorized at this stage: false",
    "%",
    "",
])

output.write_text(
    header + fragment,
    encoding="utf-8",
)

print("deferred_fragment_extraction=PASS")
print("fragment_status=deferred_not_integrated")
print("canonical_manuscript_target_modified=true_pending_restore")
PY

test -s "$TEMP_FRAGMENT"

grep -F \
  "% DEFERRED MANUSCRIPT FRAGMENT — NOT INTEGRATED" \
  "$TEMP_FRAGMENT" >/dev/null

grep -F "$SECTION_LABEL" "$TEMP_FRAGMENT" >/dev/null
grep -F "$TABLE_LABEL" "$TEMP_FRAGMENT" >/dev/null

echo "deferred_fragment=$TEMP_FRAGMENT"

echo
echo "=== 3. Close PR #25 without merge ==="

gh pr close "$PREMATURE_PR" \
  --repo "$REPO" \
  --delete-branch \
  --comment "$(cat <<'EOF'
Closed without merge.

The manuscript integration was scheduled prematurely. The frozen
membership-density result text will be preserved as a separate deferred
editorial fragment. The canonical manuscript will remain unchanged until
all experimental campaigns, consolidated analyses, and the global
scientific freeze are complete.
EOF
)"

CLOSED_PR_DATA="$(
  gh pr view "$PREMATURE_PR" \
    --repo "$REPO" \
    --json state,mergedAt
)"

jq -e '
  .state == "CLOSED"
  and .mergedAt == null
' <<<"$CLOSED_PR_DATA" >/dev/null

echo "premature_manuscript_pr_closed=PASS"
echo "premature_pr_merged=false"

echo
echo "=== 4. Restore exact base and create clean fragment branch ==="

git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$OLD_BRANCH"
then
  git branch -D "$OLD_BRANCH"
fi

git switch -c "$NEW_BRANCH" "$EXPECTED_BASE_HEAD"

mkdir -p "$DRAFT_DIR"
cp "$TEMP_FRAGMENT" "$DRAFT_FILE"

BASE_MANUSCRIPT_BLOB="$(
  git rev-parse "$EXPECTED_BASE_HEAD:$MANUSCRIPT"
)"

CURRENT_MANUSCRIPT_BLOB="$(
  git hash-object "$MANUSCRIPT"
)"

test "$CURRENT_MANUSCRIPT_BLOB" = "$BASE_MANUSCRIPT_BLOB"

test "$(
  grep -Fc "$SECTION_LABEL" "$MANUSCRIPT" || true
)" -eq 0

test "$(
  grep -Fc "$TABLE_LABEL" "$MANUSCRIPT" || true
)" -eq 0

test "$(
  grep -Fc "$SECTION_LABEL" "$DRAFT_FILE"
)" -eq 1

test "$(
  grep -Fc "$TABLE_LABEL" "$DRAFT_FILE"
)" -eq 1

CHANGED_FILE_COUNT="$(
  git status --porcelain |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 1

echo "canonical_manuscript_restoration=PASS"
echo "canonical_manuscript_modified=false"
echo "deferred_fragment_preserved=true"
echo "new_branch=$NEW_BRANCH"

echo
echo "=== 5. Commit deferred fragment only ==="

git add "$DRAFT_FILE"

test "$(
  git diff --cached --name-only |
    wc -l
)" -eq 1

test "$(
  git diff --cached --name-only
)" = "$DRAFT_FILE"

git diff --cached --check

git commit \
  -m "docs(experiments): preserve deferred membership-density results fragment"

FRAGMENT_COMMIT="$(git rev-parse HEAD)"
FRAGMENT_SHA="$(sha256sum "$DRAFT_FILE" | awk '{print $1}')"

echo "fragment_commit=PASS"
echo "fragment_commit=$FRAGMENT_COMMIT"
echo "deferred_fragment_sha256=$FRAGMENT_SHA"

echo
echo "=== 6. Push clean preservation branch ==="

git push -u origin "$NEW_BRANCH"

echo "fragment_push=PASS"

echo
echo "=== 7. Create preservation pull request ==="

PRESERVATION_PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$NEW_BRANCH" \
    --base "$BASE" \
    --title "Preserve deferred membership-density results fragment" \
    --body "$(cat <<EOF
## Purpose

Preserve the preliminary SA4 membership-density result prose outside the
canonical manuscript for later refinement.

## Net repository change

- added:
  \`$DRAFT_FILE\`;
- canonical manuscript modified:
  \`false\`.

## Deferral controls

- manuscript integration authorized now: \`false\`;
- all remaining campaigns completed: \`false\`;
- global scientific freeze: \`false\`;
- scientific re-execution: \`false\`;
- bootstrap rerun: \`false\`.

The fragment may be reconsidered only after completion of SA5–SA10,
consolidated cross-factor analysis, and the final global scientific
freeze.

## Integrity

- fragment SHA-256:
  \`$FRAGMENT_SHA\`.
EOF
)"
)"

PRESERVATION_PR="${PRESERVATION_PR_URL##*/}"

echo "preservation_pull_request=$PRESERVATION_PR"
echo "preservation_pull_request_url=$PRESERVATION_PR_URL"

echo
echo "=== 8. Verify clean PR scope ==="

for ATTEMPT in $(seq 1 20); do
  NEW_PR_DATA="$(
    gh pr view "$PRESERVATION_PR" \
      --repo "$REPO" \
      --json state,headRefOid,headRefName,baseRefName,isDraft,files
  )"

  REMOTE_HEAD="$(jq -r '.headRefOid' <<<"$NEW_PR_DATA")"

  if [ "$REMOTE_HEAD" = "$FRAGMENT_COMMIT" ]; then
    break
  fi

  sleep 3
done

jq -e \
  --arg head "$FRAGMENT_COMMIT" \
  --arg branch "$NEW_BRANCH" \
  --arg base "$BASE" \
  --arg file "$DRAFT_FILE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and (.files | length) == 1
    and .files[0].path == $file
  ' <<<"$NEW_PR_DATA" >/dev/null

echo "preservation_pr_scope=PASS"
echo "preservation_pr_changed_file_count=1"
echo "canonical_manuscript_in_pr=false"

echo
echo "=== 9. CI and mergeability gate ==="

CHECKS="$(
  gh pr checks "$PRESERVATION_PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' >/dev/null 2>&1 <<<"$CHECKS"; then
  CHECKS='[]'
fi

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PRESERVATION_PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PRESERVATION_PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  test "$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )" -eq 0

  echo "preservation_ci=PASS"
else
  echo "preservation_ci=NOT_APPLICABLE"
fi

READY=0

for ATTEMPT in $(seq 1 30); do
  MERGE_DATA="$(
    gh pr view "$PRESERVATION_PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$MERGE_DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$MERGE_DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$MERGE_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$MERGE_DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$MERGE_DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$FRAGMENT_COMMIT" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "preservation_merge_gate=PASS"

echo
echo "=== 10. Merge deferred fragment PR ==="

gh pr merge "$PRESERVATION_PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "preservation_merge_command=PASS"

echo
echo "=== 11. Update and validate base ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$FRAGMENT_COMMIT" \
  "$BASE_HEAD"

test -f "$DRAFT_FILE"

test "$(sha256sum "$DRAFT_FILE" | awk '{print $1}')" \
  = "$FRAGMENT_SHA"

POST_MERGE_MANUSCRIPT_BLOB="$(
  git hash-object "$MANUSCRIPT"
)"

test "$POST_MERGE_MANUSCRIPT_BLOB" \
  = "$BASE_MANUSCRIPT_BLOB"

test "$(
  grep -Fc "$SECTION_LABEL" "$MANUSCRIPT" || true
)" -eq 0

test "$(
  grep -Fc "$TABLE_LABEL" "$MANUSCRIPT" || true
)" -eq 0

test "$(
  grep -Fc "$SECTION_LABEL" "$DRAFT_FILE"
)" -eq 1

test "$(
  grep -Fc "$TABLE_LABEL" "$DRAFT_FILE"
)" -eq 1

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$NEW_BRANCH"
then
  git branch -d "$NEW_BRANCH"
fi

test -z "$(git status --porcelain)"

echo "deferred_fragment_merge_validation=PASS"
echo "base_head=$BASE_HEAD"
echo "canonical_manuscript_modified=false"
echo "deferred_fragment_preserved=true"

echo
echo "=== 12. Final state ==="

gh pr view "$PREMATURE_PR" \
  --repo "$REPO" \
  --json state,mergedAt \
  --jq '{
    prematurePrState: .state,
    prematurePrMergedAt: .mergedAt
  }'

gh pr view "$PRESERVATION_PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    preservationPrState: .state,
    preservationPrMergedAt: .mergedAt,
    preservationMergeCommit: .mergeCommit.oid
  }'

echo "membership_density_manuscript_deferral=PASS"
echo "premature_pr=$PREMATURE_PR"
echo "premature_pr_merged=false"
echo "preservation_pr=$PRESERVATION_PR"
echo "canonical_manuscript_modified=false"
echo "deferred_fragment=$DRAFT_FILE"
echo "deferred_fragment_sha256=$FRAGMENT_SHA"
echo "campaign_scientific_freeze=true"
echo "global_scientific_freeze=false"
echo "scientific_execution_performed=false"
echo "bootstrap_rerun_performed=false"
echo "next_campaign=SA5_objective_count"
echo "next_stage=audit_objective_count_capability_and_preregister_sa5"

git status --short --branch
git log --oneline --decorate -5
