#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="11ab786e5c56b30fe7222238d687c9a9d1526828"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"
FUNCTIONAL_AUDIT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"
AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"

trap 'echo "[ERROR] Timing authorization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Authorization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PREREG"
test -f "$FUNCTIONAL_AUDIT"
test ! -e "$AUTH"

echo "branch=$BASE"
echo "head=$EXPECTED_HEAD"
echo "authorization_gate=PASS"
echo "timing_execution_performed=false"

echo
echo "=== 2. Create authorization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
BRANCH="paper/authorize-virtual-node-count-stage10-timing-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Create formal timing authorization ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$FUNCTIONAL_AUDIT" \
  "$AUTH" \
  "$EXPECTED_HEAD" \
  "$BRANCH" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
prereg_path = root / sys.argv[2]
functional_path = root / sys.argv[3]
authorization_path = root / sys.argv[4]
source_commit = sys.argv[5]
branch = sys.argv[6]
created_utc = sys.argv[7]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


prereg = load_json(prereg_path)
functional = load_json(functional_path)

campaign = prereg["campaign_contract"]
timing = prereg["formal_timing_contract"]
precision = prereg["precision_contract"]
gates = prereg["authorization_gates"]

expected_levels = [6, 12, 24]
expected_replications = 10
expected_cells = 60
expected_warmups = 600
expected_measurements = 6000

if campaign["levels"] != expected_levels:
    raise SystemExit("Unexpected virtual-node-count levels.")

if campaign["stage10_replication_count"] != expected_replications:
    raise SystemExit("Expected 10 structural replications.")

if functional["status"] != "pass":
    raise SystemExit("Functional completion audit is not passing.")

if functional["replication_count"] != 10:
    raise SystemExit("Functional audit must contain 10 replications.")

if functional["instance_count"] != 30:
    raise SystemExit("Functional audit must contain 30 instances.")

if functional["functional_step_count"] != 60:
    raise SystemExit("Functional audit must contain 60 steps.")

if functional["all_replications_passed"] is not True:
    raise SystemExit("Not all functional replications passed.")

if functional["historical_prefix"]["rerun_performed"] is not False:
    raise SystemExit("Historical prefix was marked as rerun.")

if functional["timing_execution_performed"] is not False:
    raise SystemExit("Timing was already marked as executed.")

warmups_per_cell = int(timing["warmup_runs_per_cell"])
measurements_per_cell = int(
    timing["measurement_runs_per_cell"]
)

if warmups_per_cell != 10:
    raise SystemExit("Expected 10 warmups per cell.")

if measurements_per_cell != 100:
    raise SystemExit("Expected 100 measurements per cell.")

if int(timing["expected_cell_count"]) != expected_cells:
    raise SystemExit("Expected 60 timing cells.")

if int(timing["expected_warmup_count"]) != expected_warmups:
    raise SystemExit("Expected 600 warmups.")

if (
    int(timing["expected_measurement_count"])
    != expected_measurements
):
    raise SystemExit("Expected 6000 measurements.")

if gates["stage20_execution_authorized"] is not False:
    raise SystemExit("Stage-20 must remain unauthorized.")

replication_entries = []

for replication, seed in enumerate(
    campaign["stage10_seeds"]
):
    replication_entries.append(
        {
            "replication_index": replication,
            "structural_seed": int(seed),
            "factor_levels": expected_levels,
            "workload_step_count": 2,
            "timing_cell_count": 6,
            "warmup_runs_per_cell": warmups_per_cell,
            "measurement_runs_per_cell": (
                measurements_per_cell
            ),
            "expected_warmup_count": 60,
            "expected_measurement_count": 600,
            "execution_order_seed": (
                20260728 + replication
            ),
        }
    )

authorization = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "formal-timing-authorization-v1"
    ),
    "authorization_id": (
        "virtual_node_count_stage10_formal_timing"
    ),
    "status": "authorized",
    "created_utc": created_utc,
    "source_commit": source_commit,
    "authorization_branch": branch,
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "authorization_basis": {
        "preregistration_path": (
            prereg_path.relative_to(root).as_posix()
        ),
        "preregistration_sha256": sha256_file(
            prereg_path
        ),
        "functional_completion_audit_path": (
            functional_path.relative_to(root).as_posix()
        ),
        "functional_completion_audit_sha256": (
            sha256_file(functional_path)
        ),
        "functional_replication_count": 10,
        "functional_instance_count": 30,
        "functional_step_count": 60,
        "all_functional_replications_passed": True,
        "historical_prefix_rerun_performed": False,
    },
    "scope": {
        "replication_count": 10,
        "factor_levels": expected_levels,
        "steps_per_instance": 2,
        "timing_cell_count": expected_cells,
        "warmup_runs_per_cell": warmups_per_cell,
        "measurement_runs_per_cell": (
            measurements_per_cell
        ),
        "expected_warmup_count": expected_warmups,
        "expected_measurement_count": (
            expected_measurements
        ),
        "reuse_successful_functional_results": True,
    },
    "execution_order": {
        "policy": timing["execution_order_policy"],
        "base_seed": 20260728,
        "seed_formula": (
            "20260728 + replication_index"
        ),
    },
    "precision_analysis": {
        "method": precision["method"],
        "cluster_unit": precision["cluster_unit"],
        "bootstrap_replications": (
            precision["bootstrap_replications"]
        ),
        "bootstrap_seed": precision["bootstrap_seed"],
        "confidence_level": (
            precision["confidence_level"]
        ),
        "median_relative_half_width_target": (
            precision[
                "median_relative_half_width_target"
            ]
        ),
        "p95_relative_half_width_target": (
            precision[
                "p95_relative_half_width_target"
            ]
        ),
    },
    "replications": replication_entries,
    "prohibitions": {
        "functional_execution_rerun_authorized": False,
        "historical_prefix_rerun_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze_authorized": False,
    },
    "execution_state": {
        "timing_execution_performed": False,
        "warmup_count_observed": 0,
        "measurement_count_observed": 0,
    },
    "next_stage": (
        "prepare_and_validate_stage10_timing_runner"
    ),
}

authorization_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

authorization_path.write_text(
    json.dumps(
        authorization,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print("stage10_formal_timing_authorization=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("warmup_runs_per_cell=10")
print("measurement_runs_per_cell=100")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("functional_execution_rerun_authorized=false")
print("historical_prefix_rerun_authorized=false")
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 4. Validate authorization artifact ==="

"$PYTHON" - "$AUTH" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
authorization = json.loads(
    path.read_text(encoding="utf-8")
)

expected = {
    "status": "authorized",
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
}

for key, expected_value in expected.items():
    actual = authorization.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

scope = authorization["scope"]

if scope["replication_count"] != 10:
    raise SystemExit("Expected 10 replications.")

if scope["timing_cell_count"] != 60:
    raise SystemExit("Expected 60 cells.")

if scope["expected_warmup_count"] != 600:
    raise SystemExit("Expected 600 warmups.")

if scope["expected_measurement_count"] != 6000:
    raise SystemExit("Expected 6000 measurements.")

if len(authorization["replications"]) != 10:
    raise SystemExit("Expected 10 replication entries.")

if authorization["execution_state"] != {
    "timing_execution_performed": False,
    "warmup_count_observed": 0,
    "measurement_count_observed": 0,
}:
    raise SystemExit("Invalid initial execution state.")

prohibitions = authorization["prohibitions"]

for field in (
    "functional_execution_rerun_authorized",
    "historical_prefix_rerun_authorized",
    "stage20_execution_authorized",
    "latency_claim_authorized",
    "scientific_freeze_authorized",
):
    if prohibitions[field] is not False:
        raise SystemExit(
            f"{field} must remain false."
        )

print("timing_authorization_validation=PASS")
print("timing_execution_performed=false")
PY

echo
echo "=== 5. Commit and push ==="

git add -f "$AUTH"
git diff --cached --check

git commit \
  -m "chore(experiments): authorize virtual-node-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 6. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Authorize virtual-node-count Stage-10 formal timing" \
    --body "$(cat <<'EOF'
## Scope

- records formal authorization for the virtual-node-count Stage-10 timing campaign;
- relies on the completed 10-replication, 30-instance, 60-step functional audit;
- authorizes 60 timing cells;
- preregisters 10 warmups and 100 measurements per cell;
- authorizes 600 warmups and 6000 measurements in total;
- preserves the execution-order seed policy;
- performs no timing execution.

## Prohibitions retained

- functional rerun: unauthorized;
- historical-prefix rerun: unauthorized;
- Stage-20: unauthorized;
- latency claims: unauthorized;
- scientific freeze: unauthorized.

## Next stage

Prepare and validate the Stage-10 timing runner.
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 7. Final state ==="

echo "virtual_node_count_stage10_timing_authorization=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_authorization"

git status --short --branch
