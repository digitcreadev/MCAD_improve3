#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=33

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_BASE_PARENT="0674825017698f25562d43400ff4e72cb6484e2f"
EXPECTED_FEATURE_COMMIT="2b3150b83108fe50e6f6db7841b9fa5076693628"
EXPECTED_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"
EXPECTED_WORKLOAD_SCHEMA_SHA="df4f868365594f629dc0b9d5946e6b5fd90ee16d759fce6bd0b0c34f8de81027"

V1_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
EXPECTED_V1_GENERATOR_SHA="556654c4286adaeb88ebc9dd70939df96d70d8e8ba94265cd1684b763e826788"

V1_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
EXPECTED_V1_FAMILY_SHA="e2389ca35cdfcff14dcb0ee940482a374470f32a49af5e70ddffcb685d8bfdb5"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_post_merge_materialization_readiness_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_post_merge_materialization_readiness.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_post_merge_materialization_readiness.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_v2_readiness.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 objective-count v2 readiness audit stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"
  ACTUAL="$(sha256sum "$FILE" | awk '{print $1}')"
  test "$ACTUAL" = "$EXPECTED"
}

cat > "$TMP_ROOT/patch_files.txt" <<'EOF'
.github/workflows/phase3-regression.yml
backend/ckg/ckg_updater.py
backend/harness/sensitivity_execution/e3_contract.yaml
backend/harness/sensitivity_execution/execute_controlled_family.py
backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
backend/harness/sensitivity_execution/tests/test_workload_spec.py
backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/validate_e3_contract.py
backend/harness/sensitivity_execution/validate_workload_spec.py
backend/harness/sensitivity_generator/families/controlled_families.py
backend/harness/sensitivity_generator/families/objective_count_family_v2.py
backend/harness/sensitivity_generator/objective_count_generator_v2.py
backend/harness/sensitivity_generator/tests/test_controlled_families.py
backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
backend/mcad/models.py
backend/mcad/objectives.py
EOF

cat > "$TMP_ROOT/final_sha256sums.txt" <<'EOF'
b9fc580f1e178da0f4701a427389a5b5f78055d16341fa16734c9e4889927560  .github/workflows/phase3-regression.yml
6faaa8b7dea5b682ac9ea6ecf3cf790ff6d7a4c5c56d105a52c4e7acf2ad739d  backend/ckg/ckg_updater.py
261a3883b070c739937e24245a47483ed904194e3ea0840bae788c2b5bcdea57  backend/harness/sensitivity_execution/e3_contract.yaml
dde835674506c5167aa4065146d494ab4a932837e392c28e099d09a176b8162d  backend/harness/sensitivity_execution/execute_controlled_family.py
835a5c8315f01582d9114b159fa874c8a4c30afcce234a43547227a2954ded48  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
1dc1ffd9ca9dec985eb8d8fb998997958651a9aa2e5b51e4119d430004cd5c49  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
35ef4af11bb2b0d3197895676d033d3abf92f01e42e7e8918b7bb9dea1f8307b  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
2fd703d251ada566a84bdf4e73ace78a0a7f3163becf8a769ffb71a45bd1fa7d  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
d869f5e839dc86546295deb9ccc66360b11d3ebd2bf43fbb3504737cdb885c77  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
aec33a7e254a5e55a56c7962429f10f60c5fc23f009cc83d5742d39541087341  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
326bf6337fc58a0282f0f0b6a743a61873b2545b2532d2f21086f567b9409d5b  backend/harness/sensitivity_execution/tests/test_workload_spec.py
b8aa28b16f78df5a5ba4acc71807818b39282925bea8f0f798fd24a82892b616  backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
63c1e7674b2861b7e3dbfcd9009e31cd2676f27d5d90eb5b27de30de6ead1e4e  backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
de7ebaab3218d4f533ba83910015cdb45a7aff6479f62d3e0b653fceaed4b691  backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
d9952914589f185a64bc7735331ba25e490656d822030fee5e73f5f51d1e35a5  backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
98d87e9ce01277bdeafd94eed4cab1516fb4bb871f378e2bf04ece4b0a0940a2  backend/harness/sensitivity_execution/validate_e3_contract.py
e725bedfff82a75708c2e889469fc0f8441619a98215addf059017297f974d1f  backend/harness/sensitivity_execution/validate_workload_spec.py
2bc6a431e18f4cd8cca646d8b47d19dc5a4e2cf5e120cfa466848fa6772420df  backend/harness/sensitivity_generator/families/controlled_families.py
7ed4a8756f7426739d4c8f4914d59a86eeef448491915bc23ef776ba8654b12f  backend/harness/sensitivity_generator/families/objective_count_family_v2.py
7fbbe99c0ea6c4d7505c8290c791ec8826a4d36b8f85c888543524a30cc03863  backend/harness/sensitivity_generator/objective_count_generator_v2.py
cbfc114661cef0ddf673bd377c97e9a8a4d60521057da33c2e045613da86ce9b  backend/harness/sensitivity_generator/tests/test_controlled_families.py
55a90bca7518c44a387976f7762d41fdedb6b0121563d9cb9789e7b2c7a0326f  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
a8eb5d296c4e50c8468b3e51c6f8c0ece73231a2d294430403279eba6d3b13eb  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
a76fd8d752941cd9673cbb6dcfae227a3d1f1e7818d70d467868234e884e8b95  backend/mcad/models.py
9de16bdc0a03994d3e3eebd92a9036394801e0f4750d7698470dec663acaf8b4  backend/mcad/objectives.py
EOF

sort "$TMP_ROOT/patch_files.txt" > "$TMP_ROOT/expected_files.txt"
awk '{print $2}' "$TMP_ROOT/final_sha256sums.txt" | sort > "$TMP_ROOT/hash_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/hash_files.txt"
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 25

echo "=== 1. Exact post-merge repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(git rev-list --parents -n 1 "$EXPECTED_HEAD")"

test "$MERGE_COMMIT" = "$EXPECTED_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_PARENT"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_COMMIT"
test -z "${EXTRA_PARENT:-}"

git diff \
  --name-only \
  "$EXPECTED_BASE_PARENT..$EXPECTED_HEAD" |
  sort > "$TMP_ROOT/merged_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/merged_files.txt"

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
FRAGMENT_SHA_BEFORE="$(sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}')"

echo "post_merge_repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_COMMIT"
echo "patch_file_count=25"
echo "patch_sha256=$EXPECTED_PATCH_SHA"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Merged PR and CI evidence gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,mergeCommit,headRefOid,baseRefName,title,files
)"

jq -e \
  --arg merge "$EXPECTED_HEAD" \
  --arg feature "$EXPECTED_FEATURE_COMMIT" \
  --arg base "$BASE" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge
    and .headRefOid == $feature
    and .baseRefName == $base
    and .title
      == "Implement SA5 objective-count v2 materialization contract"
    and (.files | length) == 25
  ' <<<"$PR_DATA" >/dev/null

jq -r '.files[].path' <<<"$PR_DATA" |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/pr_files.txt"

PR_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link
)"

test "$(jq 'length' <<<"$PR_CHECKS")" -gt 0

NON_PASS_COUNT="$(
  jq '
    [
      .[]
      | select(.bucket != "pass")
    ]
    | length
  ' <<<"$PR_CHECKS"
)"

test "$NON_PASS_COUNT" -eq 0

echo "merged_pr_identity_gate=PASS"
echo "merged_pr_scope_gate=PASS"
echo "merged_pr_ci_gate=PASS"
echo "merged_pr_check_count=$(jq 'length' <<<"$PR_CHECKS")"

echo
echo "=== 3. Targeted post-merge regression gate ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py \
  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_workload_spec.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py \
  -q \
  -p no:cacheprovider

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null
test -z "$(git status --porcelain)"

echo "targeted_post_merge_regression_gate=PASS"

echo
echo "=== 4. Detached noncanonical materialization-readiness probe ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export OUTPUT_ROOT
export REPORT
export SURFACE
export EXPECTED_HEAD
export EXPECTED_FEATURE_COMMIT
export EXPECTED_PATCH_SHA
export PREREG
export AMENDMENT_001
export AMENDMENT_002
export AMENDMENT_003
export CANONICAL_CAMPAIGN_ROOT

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path
from typing import Any, Iterable

from backend.harness.sensitivity_execution.execute_controlled_family import (
    ACTIVE_GENERATOR_VERSION_OVERRIDES,
    SUPPORTED_GENERATOR_VERSION_PAIRS,
    _expected_generator_versions,
)
from backend.harness.sensitivity_execution.tools.audit_objective_count_stage10_common_workloads_v2 import (
    audit_common_workloads,
)
from backend.harness.sensitivity_execution.tools.audit_objective_count_structure_v2 import (
    audit_objective_count_structure_v2,
)
from backend.harness.sensitivity_execution.tools.objective_count_noise_operators_v2 import (
    CONTRIBUTIVE_STEP_COUNT,
    NOISE_CLASS_ORDER,
    NOISE_STEP_COUNT,
    OPERATOR_REGISTRY_VERSION,
    WORKLOAD_LENGTH,
    build_noise_schedule,
)
from backend.harness.sensitivity_execution.tools.prepare_objective_count_stage10_common_workloads_v2 import (
    prepare_common_workloads,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)


output_root = Path(os.environ["OUTPUT_ROOT"]).resolve()
report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])

source_commit = os.environ["EXPECTED_HEAD"]
feature_commit = os.environ["EXPECTED_FEATURE_COMMIT"]
patch_sha = os.environ["EXPECTED_PATCH_SHA"]

levels = (1, 2, 5, 10, 20, 50)
seeds = (
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
)

expected_campaign_version = "mcad-sensitivity-e2.2-objective-count-v2"
expected_structural_version = "mcad-sensitivity-e2.1-objective-count-v2"


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_tree_digest(
    root: Path,
    *,
    include_names: set[str],
) -> str:
    entries: list[dict[str, str]] = []

    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.name not in include_names:
            continue
        entries.append(
            {
                "path": path.relative_to(root).as_posix(),
                "sha256": sha256_file(path),
            }
        )

    payload = json.dumps(
        entries,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    return hashlib.sha256(payload).hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def generate_probe(
    *,
    name: str,
    campaign_id: str,
    probe_levels: tuple[int, ...],
    probe_seeds: tuple[int, ...],
) -> tuple[Path, Any]:
    campaign_dir = output_root / name / "campaign"

    manifest = generate_controlled_family(
        ControlledFamilySpec(
            campaign_id=campaign_id,
            factor="objective_count",
            levels=probe_levels,
            seeds=probe_seeds,
            baseline_constraint_count=8,
            baseline_virtual_node_count=32,
            output_dir=str(campaign_dir),
        )
    )

    assert manifest.campaign_generator_version == expected_campaign_version
    assert manifest.structural_generator_version == expected_structural_version
    assert manifest.factor == "objective_count"
    assert tuple(manifest.levels) == probe_levels
    assert tuple(manifest.seeds) == probe_seeds
    assert manifest.expected_instance_count == len(probe_levels) * len(probe_seeds)
    assert manifest.realised_instance_count == manifest.expected_instance_count

    return campaign_dir, manifest


historical_pair = SUPPORTED_GENERATOR_VERSION_PAIRS["objective_count"]
active_pair = ACTIVE_GENERATOR_VERSION_OVERRIDES["objective_count"]
resolved_pair = _expected_generator_versions("objective_count")

assert historical_pair == (
    "mcad-sensitivity-e2.2-objective-count-v1",
    "mcad-sensitivity-e2.1-objective-count-v1",
)

assert active_pair == (
    expected_campaign_version,
    expected_structural_version,
)

assert resolved_pair == active_pair


level_a_dir, level_a = generate_probe(
    name="level_sweep_a",
    campaign_id="sa5_objective_count_v2_readiness_level_sweep",
    probe_levels=levels,
    probe_seeds=(101,),
)

level_b_dir, level_b = generate_probe(
    name="level_sweep_b",
    campaign_id="sa5_objective_count_v2_readiness_level_sweep",
    probe_levels=levels,
    probe_seeds=(101,),
)

seed_dir, seed_manifest = generate_probe(
    name="seed_sweep",
    campaign_id="sa5_objective_count_v2_readiness_seed_sweep",
    probe_levels=(1,),
    probe_seeds=seeds,
)

generator_names = {
    "campaign_spec.json",
    "campaign_manifest.json",
    "instances.csv",
    "manifest.json",
    "objectives.yaml",
}

level_a_tree_digest = stable_tree_digest(
    level_a_dir,
    include_names=generator_names,
)

level_b_tree_digest = stable_tree_digest(
    level_b_dir,
    include_names=generator_names,
)

assert level_a.campaign_spec_digest == level_b.campaign_spec_digest
assert level_a.campaign_digest == level_b.campaign_digest
assert level_a_tree_digest == level_b_tree_digest
assert read_csv(level_a_dir / "instances.csv") == read_csv(
    level_b_dir / "instances.csv"
)


level_a_workloads = output_root / "level_sweep_a" / "workloads"
level_b_workloads = output_root / "level_sweep_b" / "workloads"
seed_workloads = output_root / "seed_sweep" / "workloads"

level_a_workload_manifest = prepare_common_workloads(
    level_a_dir,
    level_a_workloads,
)

level_b_workload_manifest = prepare_common_workloads(
    level_b_dir,
    level_b_workloads,
)

seed_workload_manifest = prepare_common_workloads(
    seed_dir,
    seed_workloads,
)

workload_names = {
    "common_workloads_manifest.json",
}

level_a_workload_digest = stable_tree_digest(
    level_a_workloads,
    include_names=workload_names
    | {
        entry["workload_path"]
        for entry in level_a_workload_manifest["entries"]
    },
)

level_b_workload_digest = stable_tree_digest(
    level_b_workloads,
    include_names=workload_names
    | {
        entry["workload_path"]
        for entry in level_b_workload_manifest["entries"]
    },
)

assert level_a_workload_digest == level_b_workload_digest
assert level_a_workload_manifest == level_b_workload_manifest

assert level_a_workload_manifest["workload_count"] == 1
assert seed_workload_manifest["workload_count"] == 10

assert level_a_workload_manifest["workload_length"] == WORKLOAD_LENGTH
assert seed_workload_manifest["workload_length"] == WORKLOAD_LENGTH

assert (
    level_a_workload_manifest["contributive_query_count_per_workload"]
    == CONTRIBUTIVE_STEP_COUNT
)

assert (
    level_a_workload_manifest["non_contributive_query_count_per_workload"]
    == NOISE_STEP_COUNT
)

assert level_a_workload_manifest["entries"][0]["shared_factor_levels"] == list(
    levels
)


level_structure_report = audit_objective_count_structure_v2(level_a_dir)
seed_structure_report = audit_objective_count_structure_v2(seed_dir)

level_workload_report = audit_common_workloads(
    level_a_dir,
    level_a_workloads,
)

seed_workload_report = audit_common_workloads(
    seed_dir,
    seed_workloads,
)

assert level_structure_report["status"] == "PASS"
assert seed_structure_report["status"] == "PASS"
assert level_workload_report["status"] == "PASS"
assert seed_workload_report["status"] == "PASS"

assert level_structure_report["instance_count"] == 6
assert seed_structure_report["instance_count"] == 10

assert level_workload_report["workload_count"] == 1
assert seed_workload_report["workload_count"] == 10

assert all(
    item["support_resource_count"] == 24
    for item in level_structure_report["instance_reports"]
    + seed_structure_report["instance_reports"]
)

assert all(
    item["support_query_signature_count"] == 24
    for item in level_structure_report["instance_reports"]
    + seed_structure_report["instance_reports"]
)

assert all(
    item["operator_oracle_mismatch_count"] == 0
    for item in level_workload_report["workload_reports"]
    + seed_workload_report["workload_reports"]
)

assert all(
    item["oracle_contributive_query_count"] == 24
    for item in level_workload_report["workload_reports"]
    + seed_workload_report["workload_reports"]
)

assert all(
    item["non_contributive_query_count"] == 8
    for item in level_workload_report["workload_reports"]
    + seed_workload_report["workload_reports"]
)

assert all(
    item["realised_noise_ratio"] == 0.25
    for item in level_workload_report["workload_reports"]
    + seed_workload_report["workload_reports"]
)

assert seed_workload_report["stage10_noise_class_counts"] == {
    item: 10 for item in sorted(NOISE_CLASS_ORDER)
}

schedule_rows = []
for replication_index, seed in enumerate(seeds):
    schedule = build_noise_schedule(seed)

    assert len(schedule.noise_positions) == 8
    assert len(schedule.contributive_positions) == 24
    assert schedule.redundant_contribution_position > min(
        schedule.contributive_positions
    )
    assert schedule.redundant_source_step_index < (
        schedule.redundant_contribution_position
    )
    assert set(schedule.class_by_position.values()) == set(NOISE_CLASS_ORDER)

    schedule_rows.append(
        {
            "replication_index": replication_index,
            "seed": seed,
            "noise_positions": list(schedule.noise_positions),
            "redundant_contribution_position": (
                schedule.redundant_contribution_position
            ),
            "redundant_source_step_index": (
                schedule.redundant_source_step_index
            ),
        }
    )

old_failure = schedule_rows[2]

assert old_failure == {
    "replication_index": 2,
    "seed": 1198202409,
    "noise_positions": [1, 8, 9, 13, 14, 17, 29, 32],
    "redundant_contribution_position": 8,
    "redundant_source_step_index": 7,
}


for name, payload in (
    ("level_structure_audit.json", level_structure_report),
    ("seed_structure_audit.json", seed_structure_report),
    ("level_workload_audit.json", level_workload_report),
    ("seed_workload_audit.json", seed_workload_report),
):
    (output_root / name).write_text(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "post-merge-materialization-readiness-v1"
    ),
    "status": (
        "sa5_objective_count_v2_"
        "canonical_materialization_ready"
    ),
    "source_commit": source_commit,
    "feature_commit": feature_commit,
    "patch_sha256": patch_sha,
    "read_only_repository_audit": True,
    "active_binding": {
        "historical_profile": list(historical_pair),
        "active_override": list(active_pair),
        "resolved_profile": list(resolved_pair),
        "factor_local_dispatch_confirmed": True,
    },
    "detached_noncanonical_probe": {
        "performed": True,
        "scientific_campaign": False,
        "level_sweep": {
            "levels": list(levels),
            "seeds": [101],
            "instance_count": level_a.realised_instance_count,
            "campaign_digest": level_a.campaign_digest,
            "generator_tree_digest": level_a_tree_digest,
            "workload_count": level_a_workload_manifest["workload_count"],
            "workload_tree_digest": level_a_workload_digest,
            "structure_audit_status": level_structure_report["status"],
            "workload_audit_status": level_workload_report["status"],
        },
        "deterministic_replay": {
            "campaign_digest_equal": (
                level_a.campaign_digest == level_b.campaign_digest
            ),
            "generator_tree_digest_equal": (
                level_a_tree_digest == level_b_tree_digest
            ),
            "workload_tree_digest_equal": (
                level_a_workload_digest == level_b_workload_digest
            ),
        },
        "seed_sweep": {
            "levels": [1],
            "seeds": list(seeds),
            "instance_count": seed_manifest.realised_instance_count,
            "workload_count": seed_workload_manifest["workload_count"],
            "structure_audit_status": seed_structure_report["status"],
            "workload_audit_status": seed_workload_report["status"],
            "stage10_noise_class_counts": (
                seed_workload_report["stage10_noise_class_counts"]
            ),
        },
        "schedule_rows": schedule_rows,
        "operator_registry_version": OPERATOR_REGISTRY_VERSION,
        "operator_oracle_mismatch_count": sum(
            item["operator_oracle_mismatch_count"]
            for item in level_workload_report["workload_reports"]
            + seed_workload_report["workload_reports"]
        ),
        "structure_failure_count": (
            level_structure_report["failure_count"]
            + seed_structure_report["failure_count"]
        ),
        "workload_failure_count": (
            level_workload_report["failure_count"]
            + seed_workload_report["failure_count"]
        ),
    },
    "effective_contract": {
        "levels": list(levels),
        "seeds": list(seeds),
        "expected_canonical_instance_count": 60,
        "expected_common_workload_count": 10,
        "workload_length": 32,
        "oracle_contributive_query_count": 24,
        "non_contributive_query_count": 8,
        "noise_ratio": 0.25,
        "noise_classes": list(NOISE_CLASS_ORDER),
        "session_support_policy": "union_requirement_sets",
        "campaign_generator_version": expected_campaign_version,
        "structural_generator_version": expected_structural_version,
    },
    "authorization": {
        "canonical_campaign_materialization_authorized": True,
        "canonical_structure_materialization_authorized": True,
        "canonical_common_workload_materialization_authorized": True,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "scientific_execution_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "canonical_campaign_materialization_performed": False,
        "canonical_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_execution_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "canonical_target": os.environ["CANONICAL_CAMPAIGN_ROOT"],
    "blockers": [],
    "blocker_count": 0,
    "readiness_complete": True,
    "next_stage": (
        "materialize_sa5_objective_count_"
        "stage10_structure_and_common_workloads"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 POST-MERGE MATERIALIZATION READINESS",
    "=" * 96,
    f"source_commit={source_commit}",
    f"feature_commit={feature_commit}",
    f"status={report['status']}",
    "",
    "=== ACTIVE BINDING ===",
    f"historical_profile={json.dumps(list(historical_pair))}",
    f"active_override={json.dumps(list(active_pair))}",
    f"resolved_profile={json.dumps(list(resolved_pair))}",
    "factor_local_dispatch_confirmed=true",
    "",
    "=== DETACHED LEVEL SWEEP ===",
    f"levels={json.dumps(list(levels))}",
    "seeds=[101]",
    f"instance_count={level_a.realised_instance_count}",
    f"campaign_digest={level_a.campaign_digest}",
    f"generator_tree_digest={level_a_tree_digest}",
    f"workload_count={level_a_workload_manifest['workload_count']}",
    f"workload_tree_digest={level_a_workload_digest}",
    "structure_audit_status=PASS",
    "workload_audit_status=PASS",
    "",
    "=== DETERMINISTIC REPLAY ===",
    "campaign_digest_equal=true",
    "generator_tree_digest_equal=true",
    "workload_tree_digest_equal=true",
    "",
    "=== DETACHED SEED SWEEP ===",
    f"seeds={json.dumps(list(seeds))}",
    f"instance_count={seed_manifest.realised_instance_count}",
    f"workload_count={seed_workload_manifest['workload_count']}",
    "structure_audit_status=PASS",
    "workload_audit_status=PASS",
    (
        "stage10_noise_class_counts="
        + json.dumps(
            seed_workload_report["stage10_noise_class_counts"],
            sort_keys=True,
        )
    ),
    "",
    "=== OLD ORDERING FAILURE ===",
    "failure_seed=1198202409",
    "redundant_contribution_position=8",
    "redundant_source_step_index=7",
    "ordering_failure_resolved=true",
    "",
    "=== EFFECTIVE CANONICAL CONTRACT ===",
    "expected_canonical_instance_count=60",
    "expected_common_workload_count=10",
    "workload_length=32",
    "oracle_contributive_query_count=24",
    "non_contributive_query_count=8",
    "noise_ratio=0.25",
    "session_support_policy=union_requirement_sets",
    f"operator_registry_version={OPERATOR_REGISTRY_VERSION}",
    "operator_oracle_mismatch_count=0",
    "structure_failure_count=0",
    "workload_failure_count=0",
    "",
    "=== AUTHORIZATION ===",
    "canonical_campaign_materialization_authorized=true",
    "canonical_structure_materialization_authorized=true",
    "canonical_common_workload_materialization_authorized=true",
    "functional_execution_authorized=false",
    "timing_execution_authorized=false",
    "precision_analysis_authorized=false",
    "bootstrap_execution_authorized=false",
    "scientific_execution_authorized=false",
    "manuscript_integration_authorized=false",
    "",
    "canonical_campaign_generated=false",
    "canonical_campaign_materialization_performed=false",
    "scientific_execution_performed=false",
    "manuscript_modified=false",
    "blocker_count=0",
    "readiness_complete=true",
    f"next_stage={report['next_stage']}",
    "",
]

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("detached_materialization_readiness_probe=PASS")
print("active_objective_count_profile_binding=PASS")
print("factor_local_dispatch_confirmed=true")
print("level_sweep_instance_count=6")
print("seed_sweep_instance_count=10")
print("deterministic_campaign_replay=PASS")
print("deterministic_workload_replay=PASS")
print("structure_failure_count=0")
print("workload_failure_count=0")
print("operator_oracle_mismatch_count=0")
print("old_ordering_failure_resolved=true")
print("canonical_campaign_materialization_authorized=true")
print("functional_execution_authorized=false")
print(f"report={report_path}")
print(f"surface={surface_path}")
print(f"report_sha256={sha256_file(report_path)}")
print(f"surface_sha256={sha256_file(surface_path)}")
print(f"next_stage={report['next_stage']}")
PY

echo
echo "=== 5. Validate readiness report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-post-merge-materialization-readiness-v1"
  and .status
    == "sa5_objective_count_v2_canonical_materialization_ready"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .feature_commit
    == "2b3150b83108fe50e6f6db7841b9fa5076693628"
  and .patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .active_binding.historical_profile
    == [
      "mcad-sensitivity-e2.2-objective-count-v1",
      "mcad-sensitivity-e2.1-objective-count-v1"
    ]
  and .active_binding.active_override
    == [
      "mcad-sensitivity-e2.2-objective-count-v2",
      "mcad-sensitivity-e2.1-objective-count-v2"
    ]
  and .active_binding.resolved_profile
    == .active_binding.active_override
  and .active_binding.factor_local_dispatch_confirmed
    == true

  and .detached_noncanonical_probe.performed
    == true
  and .detached_noncanonical_probe.scientific_campaign
    == false

  and .detached_noncanonical_probe.level_sweep.levels
    == [1, 2, 5, 10, 20, 50]
  and .detached_noncanonical_probe.level_sweep.seeds
    == [101]
  and .detached_noncanonical_probe.level_sweep.instance_count
    == 6
  and .detached_noncanonical_probe.level_sweep.workload_count
    == 1
  and .detached_noncanonical_probe.level_sweep.structure_audit_status
    == "PASS"
  and .detached_noncanonical_probe.level_sweep.workload_audit_status
    == "PASS"

  and .detached_noncanonical_probe.deterministic_replay.campaign_digest_equal
    == true
  and .detached_noncanonical_probe.deterministic_replay.generator_tree_digest_equal
    == true
  and .detached_noncanonical_probe.deterministic_replay.workload_tree_digest_equal
    == true

  and .detached_noncanonical_probe.seed_sweep.levels
    == [1]
  and (
    .detached_noncanonical_probe.seed_sweep.seeds
    | length
  ) == 10
  and .detached_noncanonical_probe.seed_sweep.instance_count
    == 10
  and .detached_noncanonical_probe.seed_sweep.workload_count
    == 10
  and .detached_noncanonical_probe.seed_sweep.structure_audit_status
    == "PASS"
  and .detached_noncanonical_probe.seed_sweep.workload_audit_status
    == "PASS"

  and .detached_noncanonical_probe.operator_oracle_mismatch_count
    == 0
  and .detached_noncanonical_probe.structure_failure_count
    == 0
  and .detached_noncanonical_probe.workload_failure_count
    == 0

  and .effective_contract.expected_canonical_instance_count
    == 60
  and .effective_contract.expected_common_workload_count
    == 10
  and .effective_contract.workload_length
    == 32
  and .effective_contract.oracle_contributive_query_count
    == 24
  and .effective_contract.non_contributive_query_count
    == 8
  and .effective_contract.noise_ratio
    == 0.25
  and .effective_contract.session_support_policy
    == "union_requirement_sets"

  and .authorization.canonical_campaign_materialization_authorized
    == true
  and .authorization.canonical_structure_materialization_authorized
    == true
  and .authorization.canonical_common_workload_materialization_authorized
    == true
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.scientific_execution_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false

  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.canonical_campaign_materialization_performed
    == false
  and .scientific_controls.canonical_functional_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .canonical_target
    == "reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"
  and .blocker_count == 0
  and .readiness_complete == true
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$REPORT" >/dev/null

echo "materialization_readiness_report_validation=PASS"

echo
echo "=== 6. Compact readiness decision ==="

jq '{
  status,
  source_commit,
  feature_commit,
  active_binding,
  detached_noncanonical_probe: {
    level_sweep,
    deterministic_replay,
    seed_sweep,
    operator_registry_version,
    operator_oracle_mismatch_count,
    structure_failure_count,
    workload_failure_count
  },
  effective_contract,
  authorization,
  scientific_controls,
  canonical_target,
  blocker_count,
  readiness_complete,
  next_stage
}' "$REPORT"

echo
echo "=== 7. Repository and canonical-science immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA_BEFORE"
test "$(sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}')" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "detached_noncanonical_probe_materialized=true"
echo "canonical_campaign_materialization_performed=false"
echo "canonical_campaign_generated=false"
echo "detached_noncanonical_evaluator_probe_performed=true"
echo "canonical_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

REPORT_SHA="$(sha256sum "$REPORT" | awk '{print $1}')"
SURFACE_SHA="$(sha256sum "$SURFACE" | awk '{print $1}')"

echo "sa5_objective_count_v2_post_merge_materialization_readiness=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_COMMIT"
echo "patch_sha256=$EXPECTED_PATCH_SHA"

echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo "level_sweep_instance_count=6"
echo "seed_sweep_instance_count=10"
echo "deterministic_campaign_replay=PASS"
echo "deterministic_workload_replay=PASS"

echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"
echo "blocker_count=0"
echo "readiness_complete=true"

echo "canonical_campaign_materialization_authorized=true"
echo "canonical_structure_materialization_authorized=true"
echo "canonical_common_workload_materialization_authorized=true"

echo "canonical_campaign_generated=false"
echo "canonical_campaign_materialization_performed=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=materialize_sa5_objective_count_stage10_structure_and_common_workloads"

git status --short --branch
