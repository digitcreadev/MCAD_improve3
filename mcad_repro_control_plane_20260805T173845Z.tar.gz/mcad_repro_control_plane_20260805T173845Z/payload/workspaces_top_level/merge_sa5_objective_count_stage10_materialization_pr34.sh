#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=34

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-20260805T104339Z"

EXPECTED_BASE_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_FEATURE_HEAD="c92e90afcfb81e31c372f829a87a69d78eb9817f"
EXPECTED_IMPLEMENTATION_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/$CAMPAIGN_ID"
INSTANCES_CSV="$CAMPAIGN_ROOT/instances.csv"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/$CAMPAIGN_ID"
STRUCTURE_AUDIT="$AUDIT_ROOT/structure_audit.json"
WORKLOAD_AUDIT="$AUDIT_ROOT/common_workload_audit.json"
CAMPAIGN_FILE_MANIFEST="$AUDIT_ROOT/canonical_campaign_file_manifest.sha256"

MATERIALIZATION_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MATERIALIZATION_SUMMARY="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d4d253da2bf739d65763fa2c44d0e7df15f352bd8b48ce7e96930c4ff93e3705"

EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_objective_count_materialization_pr34.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #34 controlled merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact local materialization gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/campaign_files.txt" \
  "$TMP_ROOT/audit_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/campaign_files.txt")" -eq 134
test "$(wc -l < "$TMP_ROOT/audit_files.txt")" -eq 3
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 139

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/feature_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/feature_files.txt"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -f "$STRUCTURE_AUDIT"
test -f "$WORKLOAD_AUDIT"
test -f "$INSTANCES_CSV"
test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_materialization_gate=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "materialized_file_count=139"
echo "canonical_campaign_file_count=134"

echo
echo "=== 2. Materialization evidence and CRLF serialization gate ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-canonical-materialization-v1"
  and .status
    == "sa5_objective_count_stage10_structure_and_common_workloads_materialized"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .implementation_patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .canonical_campaign.expected_instance_count
    == 60
  and .canonical_campaign.realised_instance_count
    == 60
  and .canonical_campaign.campaign_file_count
    == 134
  and .canonical_campaign.instance_manifest_count
    == 60
  and .canonical_campaign.objectives_file_count
    == 60
  and .canonical_campaign.levels
    == [1, 2, 5, 10, 20, 50]
  and (
    .canonical_campaign.seeds
    | length
  ) == 10

  and .common_workloads.workload_count
    == 10
  and .common_workloads.workload_length
    == 32
  and .common_workloads.contributive_query_count_per_workload
    == 24
  and .common_workloads.non_contributive_query_count_per_workload
    == 8

  and .audits.structure.status
    == "PASS"
  and .audits.structure.failure_count
    == 0
  and .audits.common_workloads.status
    == "PASS"
  and .audits.common_workloads.failure_count
    == 0
  and .audits.common_workloads.operator_oracle_mismatch_count
    == 0

  and .scientific_controls.canonical_campaign_generated
    == true
  and .scientific_controls.canonical_campaign_materialization_performed
    == true
  and .scientific_controls.canonical_stage10_functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.precision_analysis_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

export INSTANCES_CSV

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import io
import os
import re
from pathlib import Path


path = Path(os.environ["INSTANCES_CSV"])
payload = path.read_bytes()

assert payload.endswith(b"\r\n")
assert payload.count(b"\r\n") == 61
assert payload.count(b"\n") == 61
assert payload.count(b"\r") == 61
assert not re.search(rb"[ \t]+\r\n", payload)

rows = list(
    csv.reader(
        io.StringIO(
            payload.decode("utf-8"),
            newline="",
        )
    )
)

assert len(rows) == 61
assert len(rows[1:]) == 60
assert all(
    len(row) == len(rows[0])
    for row in rows[1:]
)

print("instances_csv_crlf_gate=PASS")
print("instances_csv_record_count=61")
print("instances_csv_instance_count=60")
print("actual_trailing_space_or_tab_count=0")
PY

echo "materialization_evidence_gate=PASS"
echo "instances_csv_serialization_gate=PASS"
echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"

echo
echo "=== 3. Pull-request identity and paginated exact-scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .isDraft == false
    and .headRefOid == $feature
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 139

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=139"

echo
echo "=== 4. Wait for CI registration ==="

CHECKS='[]'
CHECK_COUNT=0

for ATTEMPT in $(seq 1 60); do
  CANDIDATE="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if jq -e \
    'type == "array"' \
    >/dev/null 2>&1 \
    <<<"$CANDIDATE"
  then
    CHECKS="$CANDIDATE"
    CHECK_COUNT="$(
      jq 'length' <<<"$CHECKS"
    )"
  else
    CHECKS='[]'
    CHECK_COUNT=0
  fi

  echo \
    "ci_registration_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 10
done

test "$CHECK_COUNT" -gt 0

echo "ci_registration_gate=PASS"
echo "check_count=$CHECK_COUNT"

echo
echo "=== 5. CI completion gate ==="

gh pr checks "$PR" \
  --repo "$REPO" \
  --watch \
  --interval 10

FINAL_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link
)"

test "$(jq 'length' <<<"$FINAL_CHECKS")" -gt 0

NON_PASS_COUNT="$(
  jq '
    [
      .[]
      | select(.bucket != "pass")
    ]
    | length
  ' <<<"$FINAL_CHECKS"
)"

test "$NON_PASS_COUNT" -eq 0

jq -r '
  .[]
  | [
      .name,
      .bucket,
      .state
    ]
  | @tsv
' <<<"$FINAL_CHECKS"

echo "sa5_objective_count_materialization_ci=PASS"

echo
echo "=== 6. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 7. Merge PR #34 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 8. Update and validate base lineage ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull \
  --ff-only \
  origin \
  "$BASE"

BASE_HEAD="$(
  git rev-parse HEAD
)"

git merge-base \
  --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 9. Post-merge materialization integrity gate ==="

while IFS= read -r FILE; do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" \
    >/dev/null
done < "$TMP_ROOT/expected_files.txt"

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/post_merge_campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/post_merge_audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/post_merge_planning_files.txt"

cat \
  "$TMP_ROOT/post_merge_campaign_files.txt" \
  "$TMP_ROOT/post_merge_audit_files.txt" \
  "$TMP_ROOT/post_merge_planning_files.txt" |
  sort > "$TMP_ROOT/post_merge_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/post_merge_files.txt"

test "$(wc -l < "$TMP_ROOT/post_merge_files.txt")" -eq 139

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA_BEFORE"
test "$(sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}')" = "$FRAGMENT_SHA_BEFORE"

test -z "$(git status --porcelain)"

echo "post_merge_materialization_integrity_gate=PASS"
echo "canonical_campaign_file_count=134"
echo "total_materialization_file_count=139"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"

echo
echo "=== 10. Post-merge targeted contract regression ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py \
  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"

echo "post_merge_targeted_regression_gate=PASS"

echo
echo "=== 11. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 12. Cleanup materialization branch ==="

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch \
    -d \
    "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo "branch_cleanup_gate=PASS"

echo
echo "=== 13. Final state ==="

echo "sa5_objective_count_stage10_materialization_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "implementation_patch_sha256=$EXPECTED_IMPLEMENTATION_PATCH_SHA"

echo "canonical_campaign_file_count=134"
echo "total_materialization_file_count=139"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"

echo "materialization_report_sha256=$EXPECTED_MATERIALIZATION_REPORT_SHA"
echo "materialization_summary_sha256=$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
echo "canonical_campaign_file_manifest_sha256=$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

echo "instances_csv_line_ending=CRLF"
echo "instances_csv_record_count=61"
echo "actual_trailing_space_or_tab_count=0"

echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"
echo "blocker_count=0"

echo "canonical_campaign_generated=true"
echo "canonical_campaign_materialization_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "functional_execution_authorized=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "functional_execution_readiness_audit_eligible=true"
echo "next_stage=audit_sa5_objective_count_stage10_functional_execution_readiness"

git status --short --branch
git log --oneline --decorate -6
