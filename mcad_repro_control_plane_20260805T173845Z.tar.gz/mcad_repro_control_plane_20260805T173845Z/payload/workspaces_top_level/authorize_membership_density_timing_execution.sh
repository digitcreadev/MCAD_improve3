#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ac922e39dcd7e5a6ed8734ee5a13d9866ec49222"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"
MATERIALIZATION_REPORT="$REPORTS/planning/sa4_membership_density_timing_input_materialization.json"

INPUT_ROOT="$REPORTS/timing_inputs/membership_density_stage10_portfolio"
MANIFEST="$INPUT_ROOT/materialization_manifest.json"

TIMING_RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

AUTH_JSON="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.json"
AUTH_MD="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.md"

EXPECTED_MANIFEST_SHA="b8557e6b129d7405f9f7b8fb3e82db177d8e9a69a29e808cd174ea028efa5510"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Authorization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Authorization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$PREREG"
test -f "$MATERIALIZATION_REPORT"
test -f "$MANIFEST"
test -f "$RUNNER"

test ! -e "$AUTH_JSON"
test ! -e "$AUTH_MD"
test ! -e "$TIMING_RUN_ROOT"

test "$(
  sha256sum "$MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

test "$(
  sha256sum "$RUNNER" | awk '{print $1}'
)" = "$EXPECTED_RUNNER_SHA"

jq -e '
  .status == "membership_density_timing_inputs_materialized"
  and .input_contract.replication_count == 10
  and .input_contract.density_levels == [25, 50, 75, 100]
  and .input_contract.selected_step_indexes == [range(1; 24)]
  and .input_contract.raw_timing_cell_count == 920
  and .input_contract.warmup_observation_count == 9200
  and .input_contract.measurement_observation_count == 92000
  and .scientific_controls.timing_input_materialization_performed
      == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .materialization_decision.timing_execution_ready_for_authorization
      == true
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$MANIFEST" >/dev/null

echo "authorization_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create authorization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/authorize-membership-density-timing-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Audit exact execution matrix ==="

PYTHONPATH="$ROOT" \
"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$MATERIALIZATION_REPORT" \
  "$MANIFEST" \
  "$TIMING_RUN_ROOT" \
  "$RUNNER" \
  "$AUTH_JSON" \
  "$AUTH_MD" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$EXPECTED_MANIFEST_SHA" \
  "$EXPECTED_RUNNER_SHA" <<'PY'
from __future__ import annotations

import hashlib
import json
import runpy
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
prereg_path = root / sys.argv[2]
materialization_report_path = root / sys.argv[3]
manifest_path = root / sys.argv[4]
timing_run_root = root / sys.argv[5]
runner_path = root / sys.argv[6]
auth_json = root / sys.argv[7]
auth_md = root / sys.argv[8]
source_commit = sys.argv[9]
created_utc = sys.argv[10]
expected_manifest_sha = sys.argv[11]
expected_runner_sha = sys.argv[12]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = load_json(manifest_path)
prereg = load_json(prereg_path)
materialization_report = load_json(
    materialization_report_path
)

if sha256_file(manifest_path) != expected_manifest_sha:
    raise SystemExit("Materialization-manifest SHA mismatch.")

if sha256_file(runner_path) != expected_runner_sha:
    raise SystemExit("Timing-runner SHA mismatch.")

if manifest.get("status") != (
    "membership_density_timing_inputs_materialized"
):
    raise SystemExit("Materialized-input manifest is incomplete.")

if prereg.get("status") != (
    "membership_density_portfolio_"
    "timing_preregistration_complete"
):
    raise SystemExit("Formal preregistration is incomplete.")

if materialization_report.get("status") != (
    "membership_density_timing_input_"
    "materialization_complete"
):
    raise SystemExit("Materialization report is incomplete.")

if timing_run_root.exists():
    raise SystemExit(
        "Timing-run root already exists before authorization."
    )

namespace = runpy.run_path(str(runner_path))

load_execution_inputs = namespace.get(
    "load_execution_inputs"
)

if not callable(load_execution_inputs):
    raise SystemExit(
        "Runner does not expose load_execution_inputs."
    )

records = manifest.get("replications")

if not isinstance(records, list) or len(records) != 10:
    raise SystemExit("Expected ten replication records.")

expected_levels = [25, 50, 75, 100]
expected_steps = list(range(1, 24))
expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

execution_matrix: list[dict[str, Any]] = []
source_files_verified = 0
derived_files_verified = 0
loaded_instance_count = 0

for expected_replication, record in enumerate(records):
    replication = int(record["replication_index"])

    if replication != expected_replication:
        raise SystemExit(
            "Replication ordering differs from 0..9."
        )

    if int(record["structural_seed"]) != (
        expected_seeds[replication]
    ):
        raise SystemExit(
            f"Replication {replication}: structural-seed mismatch."
        )

    if record.get("density_levels") != expected_levels:
        raise SystemExit(
            f"Replication {replication}: density-level mismatch."
        )

    if record.get("selected_step_indexes") != expected_steps:
        raise SystemExit(
            f"Replication {replication}: selected-step mismatch."
        )

    if len(record.get("selected_query_digests", [])) != 23:
        raise SystemExit(
            f"Replication {replication}: digest map is incomplete."
        )

    if int(record.get("canonical_instance_count", -1)) != 4:
        raise SystemExit(
            f"Replication {replication}: expected four instances."
        )

    source_workload = (
        root
        / record["source_workload"]["path"]
    )

    source_spec = (
        root
        / record["source_execution_spec"]["path"]
    )

    derived_workload = (
        root
        / record["derived_workload"]["path"]
    )

    derived_spec = (
        root
        / record["derived_execution_spec"]["path"]
    )

    for path in (
        source_workload,
        source_spec,
        derived_workload,
        derived_spec,
    ):
        if not path.is_file():
            raise SystemExit(
                f"Replication {replication}: missing file {path}"
            )

    if sha256_file(source_workload) != (
        record["source_workload"]["sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: source workload changed."
        )

    if sha256_file(source_spec) != (
        record["source_execution_spec"]["sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: source spec changed."
        )

    if sha256_file(derived_workload) != (
        record["derived_workload"]["sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: derived workload changed."
        )

    if sha256_file(derived_spec) != (
        record["derived_execution_spec"]["sha256"]
    ):
        raise SystemExit(
            f"Replication {replication}: derived spec changed."
        )

    source_files_verified += 2
    derived_files_verified += 2

    workload = load_json(derived_workload)
    spec = load_json(derived_spec)

    steps = workload.get("steps")

    if not isinstance(steps, list) or len(steps) != 23:
        raise SystemExit(
            f"Replication {replication}: expected 23 steps."
        )

    if [
        int(step["step_index"])
        for step in steps
    ] != expected_steps:
        raise SystemExit(
            f"Replication {replication}: indexes differ from 1..23."
        )

    if [
        str(step["step_id"])
        for step in steps
    ] != [
        f"Q{index:03d}"
        for index in expected_steps
    ]:
        raise SystemExit(
            f"Replication {replication}: IDs differ from Q001..Q023."
        )

    if Path(spec["workload_path"]).resolve() != (
        derived_workload.resolve()
    ):
        raise SystemExit(
            f"Replication {replication}: workload reference mismatch."
        )

    output_dir = Path(spec["output_dir"]).resolve()

    expected_output_dir = (
        timing_run_root
        / (
            f"membership_density_rep_{replication:03d}_"
            "portfolio_timing_stage10"
        )
    ).resolve()

    if output_dir != expected_output_dir:
        raise SystemExit(
            f"Replication {replication}: output path mismatch."
        )

    if output_dir.exists():
        raise SystemExit(
            f"Replication {replication}: output already exists."
        )

    campaign_dir = Path(spec["campaign_dir"]).resolve()

    for campaign_file in (
        campaign_dir / "campaign_spec.json",
        campaign_dir / "campaign_manifest.json",
        campaign_dir / "instances.csv",
    ):
        if not campaign_file.is_file():
            raise SystemExit(
                f"Replication {replication}: missing "
                f"campaign artifact {campaign_file}"
            )

    inputs = load_execution_inputs(derived_spec)

    instances = getattr(inputs, "instances", None)

    if instances is None or len(instances) != 4:
        raise SystemExit(
            f"Replication {replication}: runner loaded "
            "an unexpected instance count."
        )

    loaded_instance_count += len(instances)

    parameters = record["future_timing_parameters"]

    expected_order_seed = 20260728 + replication

    if parameters != {
        "warmups": 10,
        "measurements": 100,
        "order_seed": expected_order_seed,
        "reuse_successful": True,
    }:
        raise SystemExit(
            f"Replication {replication}: timing parameters differ."
        )

    argv = [
        str(Path(sys.executable).resolve()),
        str(runner_path.resolve()),
        str(derived_spec.resolve()),
        "--output-dir",
        str(output_dir),
        "--warmups",
        "10",
        "--measurements",
        "100",
        "--order-seed",
        str(expected_order_seed),
        "--reuse-successful",
    ]

    execution_matrix.append(
        {
            "sequence_index": replication,
            "replication_index": replication,
            "structural_seed": expected_seeds[replication],
            "execution_spec_path": str(
                derived_spec.resolve()
            ),
            "execution_spec_sha256": sha256_file(
                derived_spec
            ),
            "workload_path": str(
                derived_workload.resolve()
            ),
            "workload_sha256": sha256_file(
                derived_workload
            ),
            "output_dir": str(output_dir),
            "density_levels": expected_levels,
            "step_indexes": expected_steps,
            "raw_timing_cell_count": 92,
            "warmups": 10,
            "measurements": 100,
            "warmup_observation_count": 920,
            "measurement_observation_count": 9200,
            "order_seed": expected_order_seed,
            "reuse_successful": True,
            "environment": {
                "PYTHONPATH": str(root.resolve()),
            },
            "argv": argv,
        }
    )

if source_files_verified != 20:
    raise SystemExit("Expected twenty verified source files.")

if derived_files_verified != 20:
    raise SystemExit("Expected twenty verified derived files.")

if loaded_instance_count != 40:
    raise SystemExit("Expected forty runner-loaded instances.")

if timing_run_root.exists():
    raise SystemExit(
        "Input loading unexpectedly created timing outputs."
    )

authorization = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "timing-execution-authorization-v1"
    ),
    "status": (
        "membership_density_stage10_"
        "timing_execution_authorized"
    ),
    "created_utc": created_utc,
    "source_commit": source_commit,
    "campaign_id": "membership_density_stage10_c4_nv24",
    "factor": "membership_density",
    "authorization_scope": {
        "stage": 10,
        "replication_indexes": list(range(10)),
        "replication_count": 10,
        "execution_order": list(range(10)),
        "maximum_parallel_replications": 1,
        "density_levels": expected_levels,
        "step_indexes": expected_steps,
        "raw_timing_cell_count": 920,
        "warmups_per_raw_cell": 10,
        "measurements_per_raw_cell": 100,
        "warmup_observation_count": 9200,
        "measurement_observation_count": 92000,
        "reuse_successful": True,
    },
    "execution_contract": {
        "runner": str(runner_path.relative_to(root)),
        "runner_sha256": expected_runner_sha,
        "required_environment": {
            "PYTHONPATH": str(root.resolve()),
        },
        "execution_mode": (
            "Sequential replication execution; "
            "one runner process at a time."
        ),
        "fresh_output_rule": (
            "Each output directory must be absent, unless "
            "reuse-successful validates an exact completed bundle."
        ),
        "immutable_input_digest_check_required": True,
        "functional_semantic_match_required": True,
        "stop_on_first_failure": True,
    },
    "execution_matrix": execution_matrix,
    "audit_results": {
        "source_file_count_verified": 20,
        "derived_file_count_verified": 20,
        "derived_workload_count": 10,
        "derived_execution_spec_count": 10,
        "runner_loaded_instance_count": 40,
        "all_output_directories_absent": True,
        "timing_run_root_absent": True,
        "runner_input_load_gate_passed": True,
        "source_hashes_match_manifest": True,
        "derived_hashes_match_manifest": True,
    },
    "source_artifacts": {
        "formal_preregistration": {
            "path": str(prereg_path.relative_to(root)),
            "sha256": sha256_file(prereg_path),
        },
        "materialization_report": {
            "path": str(
                materialization_report_path.relative_to(root)
            ),
            "sha256": sha256_file(
                materialization_report_path
            ),
        },
        "materialization_manifest": {
            "path": str(manifest_path.relative_to(root)),
            "sha256": expected_manifest_sha,
        },
    },
    "scientific_controls": {
        "functional_execution_rerun_required": False,
        "functional_execution_rerun_performed": False,
        "timing_input_materialization_performed": True,
        "timing_execution_authorized": True,
        "timing_execution_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "authorization_decision": {
        "exact_inputs_audited": True,
        "runner_input_contract_validated": True,
        "timing_execution_ready": True,
        "timing_execution_authorized": True,
    },
    "next_stage": (
        "execute_membership_density_timing_stage10"
    ),
}

write_json(auth_json, authorization)

auth_md.write_text(
    "\n".join([
        "# SA4 membership-density timing execution authorization",
        "",
        "- Status: `PASS`",
        "- Stage: `10`",
        "- Replications: `10`",
        "- Execution order: `0..9`",
        "- Maximum parallel replications: `1`",
        "- Density levels: `25, 50, 75, 100`",
        "- Steps per replication: `23`",
        "- Raw timing cells: `920`",
        "- Planned warmups: `9,200`",
        "- Planned measurements: `92,000`",
        "- Timing execution authorized: `true`",
        "- Precision analysis authorized: `false`",
        "",
        "## Execution controls",
        "",
        (
            "Replications must run sequentially using the "
            "exact runner, inputs, output paths, parameters "
            "and order seeds recorded in the JSON artifact."
        ),
        "",
        (
            "Execution stops on the first failed replication. "
            "No precision analysis or latency claim is "
            "authorized by this artifact."
        ),
        "",
        "## Next stage",
        "",
        "`execute_membership_density_timing_stage10`",
        "",
    ]),
    encoding="utf-8",
)

print("timing_execution_authorization_audit=PASS")
print("source_file_count_verified=20")
print("derived_file_count_verified=20")
print("runner_loaded_instance_count=40")
print("execution_matrix_count=10")
print("maximum_parallel_replications=1")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print("all_output_directories_absent=true")
print("timing_execution_performed=false")
print("timing_execution_authorized=true")
print("precision_analysis_authorized=false")
print(
    "next_stage="
    "execute_membership_density_timing_stage10"
)
PY

echo
echo "=== 4. Validate authorization artifact ==="

test -f "$AUTH_JSON"
test -f "$AUTH_MD"
test ! -e "$TIMING_RUN_ROOT"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_authorized"
  and .authorization_scope.stage == 10
  and .authorization_scope.replication_indexes == [range(0; 10)]
  and .authorization_scope.execution_order == [range(0; 10)]
  and .authorization_scope.maximum_parallel_replications == 1
  and .authorization_scope.raw_timing_cell_count == 920
  and .authorization_scope.warmup_observation_count == 9200
  and .authorization_scope.measurement_observation_count == 92000
  and (.execution_matrix | length) == 10
  and ([.execution_matrix[].raw_timing_cell_count] | unique) == [92]
  and ([.execution_matrix[].warmup_observation_count] | unique)
      == [920]
  and ([.execution_matrix[].measurement_observation_count] | unique)
      == [9200]
  and ([.execution_matrix[].order_seed])
      == [range(20260728; 20260738)]
  and .audit_results.source_file_count_verified == 20
  and .audit_results.derived_file_count_verified == 20
  and .audit_results.runner_loaded_instance_count == 40
  and .audit_results.all_output_directories_absent == true
  and .audit_results.runner_input_load_gate_passed == true
  and .scientific_controls.timing_execution_authorized == true
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .authorization_decision.exact_inputs_audited == true
  and .authorization_decision.timing_execution_ready == true
  and .authorization_decision.timing_execution_authorized == true
  and .next_stage
      == "execute_membership_density_timing_stage10"
' "$AUTH_JSON" >/dev/null

echo "timing_execution_authorization_validation=PASS"

echo
echo "=== 5. Commit authorization ==="

git add -f "$AUTH_JSON" "$AUTH_MD"

git diff --cached --check
git diff --cached --stat

test "$(
  git diff --cached --name-only | wc -l
)" -eq 2

git commit \
  -m "chore(experiments): authorize membership-density Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 6. Push branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

AUTH_SHA="$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Authorize membership-density Stage-10 timing" \
    --body "$(cat <<EOF
## Authorization scope

- stage: \`10\`;
- replications: \`10\`, executed sequentially;
- density levels: \`25, 50, 75, 100\`;
- local steps per replication: \`23\`;
- raw timing cells: \`920\`;
- warmups: \`9,200\`;
- measurements: \`92,000\`.

## Audit

- source files verified: \`20\`;
- derived files verified: \`20\`;
- runner-loaded instances: \`40\`;
- existing timing output directories: \`0\`;
- materialization manifest SHA-256:
  \`$EXPECTED_MANIFEST_SHA\`;
- authorization SHA-256:
  \`$AUTH_SHA\`.

## Controls

- timing execution authorized: \`true\`;
- timing execution performed: \`false\`;
- maximum parallel replications: \`1\`;
- stop on first failure: \`true\`;
- precision analysis authorized: \`false\`;
- latency claims authorized: \`false\`.

## Next stage

\`execute_membership_density_timing_stage10\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

echo "membership_density_timing_execution_authorization=PASS"
echo "commit=$COMMIT"
echo "authorization_sha256=$AUTH_SHA"
echo "execution_matrix_count=10"
echo "maximum_parallel_replications=1"
echo "raw_timing_cell_count=920"
echo "measurement_observation_count=92000"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"
echo "precision_analysis_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_execution_authorization"

git status --short --branch
git log --oneline --decorate -4
