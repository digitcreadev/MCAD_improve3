#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PR=32

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-sa5-objective-count-noise-operators-20260804T234110Z"

EXPECTED_BASE_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"
EXPECTED_FEATURE_HEAD="24cd22ad0d746294cea61d554f0a81e803a3d94e"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"
AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"
AMENDMENT_003_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_noise_operator_pr32.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #32 merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

printf '%s\n' \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_003" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

echo "=== 1. Local noise-operator amendment gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_003" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_003_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$AMENDMENT_003" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_003_SHA"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort \
  > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(
  wc -l < "$TMP_ROOT/actual_files.txt"
)" -eq 2

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_noise_operator_amendment_gate=PASS"
echo "changed_file_count=2"
echo "noise_operator_amendment_sha256=$EXPECTED_AMENDMENT_003_SHA"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Exact amendment-content gate ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-noise-operator-and-redundancy-ordering-amendment-v1"
  and .amendment_id
    == "sa5_objective_count_noise_operator_and_redundancy_ordering_amendment_003"
  and .status
    == "preregistered_implementation_required"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"

  and .amends.original_preregistration.artifact_sha256
    == "a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"
  and .amends.materialization_contract_amendment_001.artifact_sha256
    == "2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"
  and .amends.workload_capacity_amendment_002.artifact_sha256
    == "32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

  and .audit_provenance.existing_exact_operator_classes
    == ["missing_cube"]
  and .audit_provenance.template_label_only_classes
    == ["wrong_measure"]
  and .audit_provenance.missing_exact_operator_class_count
    == 7

  and (
    .noise_operator_contract.noise_class_order
    | length
  ) == 8
  and (
    .noise_operator_contract.operator_definitions
    | keys
    | length
  ) == 8
  and .noise_operator_contract.operator_registry_version
    == "mcad-sa5-objective-count-noise-operators-v1"

  and .noise_operator_contract.operator_definitions.wrong_measure.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.wrong_context.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.insufficient_grain.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_aggregation.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_unit.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.invalid_time_window.expected_sat
    == false
  and .noise_operator_contract.operator_definitions.missing_cube.expected_sat
    == false

  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_sat
    == true
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_real_node_count
    == 1
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_gained_resource_count
    == 0
  and .noise_operator_contract.operator_definitions.redundant_contribution.expected_oracle_contributive
    == false
  and .noise_operator_contract.operator_definitions.redundant_contribution.prior_contribution_required
    == true

  and .canonical_support_query_contract.expected_base_query_outcome.sat
    == true
  and .canonical_support_query_contract.expected_base_query_outcome.real_node_count
    == 1
  and .canonical_support_query_contract.expected_base_query_outcome.oracle_contributive_on_first_use
    == true
  and .canonical_support_query_contract.expected_base_query_outcome.gained_resource_count_on_first_use
    == 1
  and .canonical_support_query_contract.unique_context_assignment.candidate_pair_count
    == 210
  and .canonical_support_query_contract.unique_context_assignment.required_distinct_context_count_per_constraint
    == 4
  and .canonical_support_query_contract.unique_context_assignment.support_query_real_node_count_required
    == 1
  and .canonical_support_query_contract.unique_context_assignment.support_query_signature_duplicate_count_required
    == 0

  and .revised_noise_schedule_contract.workload_length
    == 32
  and .revised_noise_schedule_contract.noise_step_count
    == 8
  and .revised_noise_schedule_contract.contributive_step_count
    == 24
  and (
    .revised_noise_schedule_contract.schedule_rows
    | length
  ) == 10

  and .revised_noise_schedule_contract.old_failure_resolved.replication_index
    == 2
  and .revised_noise_schedule_contract.old_failure_resolved.seed
    == 1198202409
  and .revised_noise_schedule_contract.old_failure_resolved.old_redundant_position
    == 1
  and .revised_noise_schedule_contract.old_failure_resolved.new_redundant_position
    == 8
  and .revised_noise_schedule_contract.old_failure_resolved.new_source_step_index
    == 7
  and .revised_noise_schedule_contract.old_failure_resolved.prior_contributive_step_exists
    == true

  and .materialization_acceptance_contract.required_workload_count
    == 10
  and .materialization_acceptance_contract.required_workload_length
    == 32
  and .materialization_acceptance_contract.required_contributive_query_count_per_workload
    == 24
  and .materialization_acceptance_contract.required_non_contributive_query_count_per_workload
    == 8
  and .materialization_acceptance_contract.required_count_per_noise_class_per_workload
    == 1
  and .materialization_acceptance_contract.required_unique_support_query_count
    == 24
  and .materialization_acceptance_contract.required_support_query_signature_duplicate_count
    == 0
  and .materialization_acceptance_contract.required_non_redundant_mutation_count
    == 7
  and .materialization_acceptance_contract.required_redundant_replay_count
    == 1
  and .materialization_acceptance_contract.required_redundancy_ordering_failure_count
    == 0
  and .materialization_acceptance_contract.required_operator_oracle_mismatch_count
    == 0

  and .implementation_contract.target_structural_generator_version
    == "mcad-sensitivity-e2.1-objective-count-v2"
  and .implementation_contract.target_campaign_generator_version
    == "mcad-sensitivity-e2.2-objective-count-v2"
  and .implementation_contract.required_dedicated_production_module
    == "backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py"
  and .implementation_contract.required_dedicated_test_module
    == "backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py"
  and .implementation_contract.prior_21_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true
  and .implementation_contract.preserve_v1_generator_module_bytes
    == true
  and .implementation_contract.preserve_historical_factor_behavior
    == true
  and .implementation_contract.preserve_membership_density_profile
    == true

  and .authorization.amendment_persistence_authorized
    == true
  and .authorization.v2_implementation_authorized_after_amendment_merge
    == true
  and .authorization.v2_patch_authoring_authorized_before_amendment_merge
    == false
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.stage20_execution_authorized
    == false
  and .authorization.latency_claim_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false

  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.campaign_materialization_performed
    == false
  and .scientific_controls.functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_noise_operator_amendment_merge"
' "$AMENDMENT_003" >/dev/null

echo "noise_operator_amendment_content_gate=PASS"
echo "registered_noise_operator_count=8"
echo "non_redundant_operator_count=7"
echo "redundant_operator_count=1"
echo "new_redundant_position=8"
echo "new_redundant_source_step=7"
echo "prior_21_file_scope_authoritative=false"

echo
echo "=== 3. Pre-merge amendment-chain tests ==="

"$PYTHON" -m py_compile \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_003_TEST"

"$PYTHON" -m pytest \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

echo "pre_merge_noise_operator_tests=PASS"

echo
echo "=== 4. Remote lineage gate ==="

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_BASE_HEAD"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$EXPECTED_FEATURE_HEAD"

echo "remote_lineage_gate=PASS"
echo "remote_base_head=$EXPECTED_BASE_HEAD"
echo "remote_feature_head=$EXPECTED_FEATURE_HEAD"

echo
echo "=== 5. Pull-request identity and scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count noise operators"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 6. Wait for CI registration ==="

CHECKS='[]'
CHECK_COUNT=0

for ATTEMPT in $(seq 1 60); do
  CANDIDATE="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if jq -e 'type == "array"' \
    >/dev/null 2>&1 \
    <<<"$CANDIDATE"
  then
    CHECKS="$CANDIDATE"
    CHECK_COUNT="$(
      jq 'length' <<<"$CHECKS"
    )"
  else
    CHECKS='[]'
    CHECK_COUNT=0
  fi

  echo \
    "ci_registration_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 10
done

test "$CHECK_COUNT" -gt 0

echo "ci_registration_gate=PASS"
echo "check_count=$CHECK_COUNT"

echo
echo "=== 7. CI completion gate ==="

gh pr checks "$PR" \
  --repo "$REPO" \
  --watch \
  --interval 10

FINAL_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link
)"

test "$(
  jq 'length' <<<"$FINAL_CHECKS"
)" -gt 0

NON_PASS_COUNT="$(
  jq '
    [
      .[]
      | select(.bucket != "pass")
    ]
    | length
  ' <<<"$FINAL_CHECKS"
)"

test "$NON_PASS_COUNT" -eq 0

jq -r '
  .[]
  | [
      .name,
      .bucket,
      .state
    ]
  | @tsv
' <<<"$FINAL_CHECKS"

echo "sa5_noise_operator_amendment_ci=PASS"

echo
echo "=== 8. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 9. Merge PR #32 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 10. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 11. Post-merge amendment-chain validation ==="

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_003" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_003_TEST"
do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" >/dev/null
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$AMENDMENT_003" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_003_SHA"

"$PYTHON" -m pytest \
  "$AMENDMENT_003_TEST" \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "post_merge_noise_operator_validation=PASS"
echo "noise_operator_amendment_tracked=true"
echo "prior_artifacts_modified=false"
echo "canonical_campaign_generated=false"
echo "canonical_campaign_materialization_authorized=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 12. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 13. Cleanup feature branch ==="

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo "branch_cleanup_gate=PASS"

echo
echo "=== 14. Final state ==="

echo "sa5_noise_operator_amendment_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "noise_operator_amendment_sha256=$EXPECTED_AMENDMENT_003_SHA"

echo "registered_noise_operator_count=8"
echo "non_redundant_operator_count=7"
echo "redundant_operator_count=1"

echo "support_query_real_node_count_required=1"
echo "support_query_signature_duplicate_count_required=0"

echo "old_failure_seed=1198202409"
echo "old_redundant_position=1"
echo "new_redundant_position=8"
echo "new_redundant_source_step=7"

echo "prior_21_file_scope_authoritative=false"
echo "scope_reprojection_eligible=true"
echo "v2_implementation_eligible=true"
echo "v2_patch_authoring_authorized=false"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"

echo "functional_execution_authorized=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=reproject_sa5_objective_count_v2_implementation_scope_after_noise_operator_amendment_merge"

git status --short --branch
git log --oneline --decorate -5
