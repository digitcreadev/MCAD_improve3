#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0674825017698f25562d43400ff4e72cb6484e2f"

SCRIPT_NAME="author_sa5_objective_count_v2_25_file_patch.sh"
BUNDLE_NAME="sa5_objective_count_v2_25_file_patch_authoring_bundle_0674825.tar.gz"

SOURCE_SCRIPT="$ROOT/$SCRIPT_NAME"
SOURCE_BUNDLE="$ROOT/$BUNDLE_NAME"

TARGET_SCRIPT="/workspaces/$SCRIPT_NAME"
TARGET_BUNDLE="/workspaces/$BUNDLE_NAME"

EXPECTED_SCRIPT_SHA="4b64f06e434a3d42fe1719cc71964b2dde1a3d7d24ab86bda147985476e5c2d7"
EXPECTED_BUNDLE_SHA="e7e837cd1a87774a8cc451cc70156daf8a2bf795cc2c51986fb779a84c4ac846"

TMP_ROOT="$(mktemp -d /workspaces/sa5_v2_resume.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 v2 relocation/resume stopped at line $LINENO."' ERR

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

cd "$ROOT"

echo "=== 1. Exact failed-preflight recovery gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

test -f "$SOURCE_SCRIPT"
test -f "$SOURCE_BUNDLE"

verify_sha \
  "$SOURCE_SCRIPT" \
  "$EXPECTED_SCRIPT_SHA"

verify_sha \
  "$SOURCE_BUNDLE" \
  "$EXPECTED_BUNDLE_SHA"

printf '%s\n' \
  "?? $SCRIPT_NAME" \
  "?? $BUNDLE_NAME" |
  sort \
  > "$TMP_ROOT/expected_status.txt"

git status --porcelain |
  sort \
  > "$TMP_ROOT/actual_status.txt"

diff -u \
  "$TMP_ROOT/expected_status.txt" \
  "$TMP_ROOT/actual_status.txt"

echo "failed_preflight_state_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "untracked_transfer_file_count=2"
echo "tracked_repository_changes=false"

echo
echo "=== 2. Preserve exact files outside repository ==="

if [ -e "$TARGET_SCRIPT" ]; then
  verify_sha \
    "$TARGET_SCRIPT" \
    "$EXPECTED_SCRIPT_SHA"
else
  cp -p \
    "$SOURCE_SCRIPT" \
    "$TARGET_SCRIPT"
fi

chmod +x "$TARGET_SCRIPT"

verify_sha \
  "$TARGET_SCRIPT" \
  "$EXPECTED_SCRIPT_SHA"

if [ -e "$TARGET_BUNDLE" ]; then
  verify_sha \
    "$TARGET_BUNDLE" \
    "$EXPECTED_BUNDLE_SHA"
else
  cp -p \
    "$SOURCE_BUNDLE" \
    "$TARGET_BUNDLE"
fi

verify_sha \
  "$TARGET_BUNDLE" \
  "$EXPECTED_BUNDLE_SHA"

echo "external_script_preservation=PASS"
echo "external_script=$TARGET_SCRIPT"
echo "external_script_sha256=$EXPECTED_SCRIPT_SHA"

echo "external_bundle_preservation=PASS"
echo "external_bundle=$TARGET_BUNDLE"
echo "external_bundle_sha256=$EXPECTED_BUNDLE_SHA"

echo
echo "=== 3. Remove only repository-local transfer copies ==="

rm -- \
  "$SOURCE_SCRIPT" \
  "$SOURCE_BUNDLE"

test ! -e "$SOURCE_SCRIPT"
test ! -e "$SOURCE_BUNDLE"

test -z "$(git status --porcelain)"

echo "repository_transfer_cleanup=PASS"
echo "removed_repository_local_file_count=2"
echo "repository_clean_gate=PASS"

echo
echo "=== 4. Validate external authoring script ==="

bash -n "$TARGET_SCRIPT"

verify_sha \
  "$TARGET_SCRIPT" \
  "$EXPECTED_SCRIPT_SHA"

echo "external_authoring_script_validation=PASS"

echo
echo "=== 5. Resume exact 25-file patch authoring ==="

bash "$TARGET_SCRIPT"

echo
echo "=== 6. Recovery final state ==="

test -z "$(git status --porcelain)"

CURRENT_BRANCH="$(
  git branch --show-current
)"

CURRENT_HEAD="$(
  git rev-parse HEAD
)"

case "$CURRENT_BRANCH" in
  paper/implement-sa5-objective-count-v2-*)
    ;;
  *)
    echo \
      "Unexpected post-authoring branch: " \
      "$CURRENT_BRANCH" >&2
    exit 1
    ;;
esac

test "$CURRENT_HEAD" != "$EXPECTED_HEAD"

verify_sha \
  "$TARGET_SCRIPT" \
  "$EXPECTED_SCRIPT_SHA"

verify_sha \
  "$TARGET_BUNDLE" \
  "$EXPECTED_BUNDLE_SHA"

echo "sa5_v2_patch_authoring_resume=PASS"
echo "implementation_branch=$CURRENT_BRANCH"
echo "implementation_commit=$CURRENT_HEAD"
echo "repository_clean=true"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_v2_patch"

git status --short --branch
git log --oneline --decorate -5
