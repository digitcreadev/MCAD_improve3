#!/usr/bin/env bash
set -Eeuo pipefail

HIST="/workspaces/MCAD_improve3"
BASE_BRANCH="paper/phase3-controlled-execution"
EXPECTED_HEAD="f158337532db74fadc40cd9178eea60249da256f"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/freeze-constraint-count-${STAMP}"
WORKTREE="/workspaces/MCAD_constraint_count_freeze_${STAMP}"
BUILD="/workspaces/constraint_count_freeze_build_${STAMP}"

SOURCE_ROOT_REL="reports/article_experiments/sensitivity/e3_controlled_execution"
SOURCE_ROOT="$HIST/$SOURCE_ROOT_REL"

DEST_REL="experiments/article/frozen_campaigns/sa3_constraint_count_stage20"

fail() {
  echo "[ERROR] $*" >&2
  exit 1
}

echo "=== 1. Minimal gate ==="

test "$(git -C "$HIST" branch --show-current)" = "$BASE_BRANCH" ||
  fail "Unexpected active branch."

test "$(git -C "$HIST" rev-parse HEAD)" = "$EXPECTED_HEAD" ||
  fail "Unexpected repository HEAD."

test -z "$(git -C "$HIST" status --porcelain)" ||
  fail "Historical worktree is not clean."

test -d "$SOURCE_ROOT" ||
  fail "Sensitivity evidence root is missing."

mkdir -p "$BUILD/stage/repository_snapshot"

echo "=== 2. Validate completed Stage-20 campaign ==="

python - "$HIST" "$BUILD" <<'PY'
from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path

repo = Path(sys.argv[1]).resolve()
build = Path(sys.argv[2]).resolve()

root_rel = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution"
)
root = repo / root_rel
planning = root / "planning"

timing_report = json.loads(
    (
        planning
        / "sa3_stage20_formal_timing_execution_report.json"
    ).read_text(encoding="utf-8")
)

precision_report = json.loads(
    (
        planning
        / "sa3_stage20_precision_analysis_report.json"
    ).read_text(encoding="utf-8")
)

assert timing_report["status"] == (
    "stage20_formal_timing_execution_success"
)
assert timing_report["combined_totals"]["run_count"] == 20
assert (
    timing_report["combined_totals"]["successful_run_count"]
    == 20
)
assert (
    timing_report["combined_totals"][
        "measurement_observation_count"
    ]
    == 20000
)
assert (
    timing_report["combined_totals"][
        "functional_mismatch_count"
    ]
    == 0
)
assert timing_report["latency_claim_authorized"] is False

assert precision_report["status"] == (
    "stage20_precision_targets_met"
)
assert precision_report["latency_claim_authorized"] is False
assert precision_report["next_stage"] == (
    "SA4_membership_density_design"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)

    return digest.hexdigest()


selected: set[Path] = set()

for path in root.rglob("*"):
    if not path.is_file():
        continue

    relative = path.relative_to(repo)

    if "constraint_count" in relative.as_posix():
        selected.add(relative)

for pattern in ("sa3_stage10*", "sa3_stage20*"):
    for path in planning.glob(pattern):
        if path.is_file():
            selected.add(path.relative_to(repo))

code_paths = [
    Path(
        "backend/harness/sensitivity_execution/"
        "execute_controlled_family.py"
    ),
    Path(
        "backend/harness/sensitivity_execution/"
        "analyze_clustered_timing_precision.py"
    ),
    Path(
        "backend/harness/sensitivity_execution/"
        "analyze_clustered_timing_precision_v2.py"
    ),
    Path(
        "backend/harness/sensitivity_execution/tools/"
        "audit_constraint_count_common_workload.py"
    ),
    Path(
        "backend/harness/sensitivity_execution/tools/"
        "prepare_constraint_count_replication_runs.py"
    ),
    Path(
        "backend/harness/sensitivity_generator/"
        "structural_generator.py"
    ),
    Path(
        "backend/harness/sensitivity_generator/families/"
        "controlled_families.py"
    ),
    Path(
        "backend/harness/sensitivity_generator/families/"
        "e2_2_contract.yaml"
    ),
    Path(
        "backend/harness/sensitivity_generator/families/"
        "CONTROLLED_FAMILIES_E2_2.md"
    ),
]

for relative in code_paths:
    if (repo / relative).is_file():
        selected.add(relative)

stage = build / "stage" / "repository_snapshot"
manifest_entries = []

for relative in sorted(selected):
    source = repo / relative
    destination = stage / relative

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

    manifest_entries.append(
        {
            "path": relative.as_posix(),
            "size_bytes": source.stat().st_size,
            "sha256": sha256(source),
        }
    )

source_manifest = {
    "schema_version": "mcad-constraint-count-source-v1",
    "source_commit": (
        "f158337532db74fadc40cd9178eea60249da256f"
    ),
    "file_count": len(manifest_entries),
    "files": manifest_entries,
}

(build / "stage" / "SOURCE_MANIFEST.json").write_text(
    json.dumps(
        source_manifest,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

validation = {
    "campaign_id": "sa3_constraint_count_stage20",
    "status": "completed_precision_targets_met",
    "run_count": 20,
    "successful_run_count": 20,
    "measurement_observation_count": 20000,
    "functional_mismatch_count": 0,
    "precision_targets_met": True,
    "latency_claim_authorized": False,
    "scientific_freeze_before_packaging": False,
    "rerun_required": False,
}

(build / "stage" / "VALIDATION_SUMMARY.json").write_text(
    json.dumps(
        validation,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print(f"selected_source_file_count={len(selected)}")
print("constraint_count_stage20_validation=PASS")
print("constraint_count_rerun_required=false")
PY

echo "=== 3. Create dedicated freeze worktree ==="

git -C "$HIST" worktree add \
  -b "$BRANCH" \
  "$WORKTREE" \
  "$EXPECTED_HEAD"

DEST="$WORKTREE/$DEST_REL"

mkdir -p \
  "$DEST/archive" \
  "$DEST/freeze"

ARCHIVE_NAME="constraint_count_stage20_canonical_${STAMP}.tar.gz"
ARCHIVE="$DEST/archive/$ARCHIVE_NAME"

echo "=== 4. Create canonical archive ==="

tar \
  --sort=name \
  --mtime="2026-08-01 00:00:00Z" \
  --owner=0 \
  --group=0 \
  --numeric-owner \
  -C "$BUILD/stage" \
  -czf "$ARCHIVE" \
  .

gzip -t "$ARCHIVE"

ARCHIVE_SHA="$(sha256sum "$ARCHIVE" | awk '{print $1}')"
ARCHIVE_SIZE="$(stat -c '%s' "$ARCHIVE")"

printf '%s  %s\n' \
  "$ARCHIVE_SHA" \
  "$ARCHIVE_NAME" \
  > "$DEST/archive/${ARCHIVE_NAME}.sha256"

tar -tzf "$ARCHIVE" > "$DEST/CONTENTS.txt"

echo "archive_sha256=$ARCHIVE_SHA"
echo "archive_size_bytes=$ARCHIVE_SIZE"

echo "=== 5. Create freeze metadata ==="

python - "$DEST" "$ARCHIVE_NAME" "$ARCHIVE_SHA" "$ARCHIVE_SIZE" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

destination = Path(sys.argv[1])
archive_name = sys.argv[2]
archive_sha = sys.argv[3]
archive_size = int(sys.argv[4])

status = {
    "campaign_id": "sa3_constraint_count_stage20",
    "scientific_status": "completed_precision_targets_met",
    "repository_persistence_status": "complete",
    "scientific_freeze": True,
    "freeze_scope": "constraint_count_stage20",
    "global_scientific_freeze": False,
    "run_count": 20,
    "successful_run_count": 20,
    "measurement_observation_count": 20000,
    "functional_mismatch_count": 0,
    "precision_targets_met": True,
    "latency_claim_authorized": False,
    "rerun_required": False,
}

provenance = {
    "source_commit": (
        "f158337532db74fadc40cd9178eea60249da256f"
    ),
    "canonical_archive": archive_name,
    "canonical_archive_sha256": archive_sha,
    "canonical_archive_size_bytes": archive_size,
    "campaign_regenerated_during_freeze": False,
    "packaging_mode": "existing_evidence_exact_snapshot",
}

(destination / "STATUS.json").write_text(
    json.dumps(status, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

(destination / "PROVENANCE.json").write_text(
    json.dumps(provenance, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

(destination / "README.md").write_text(
    """# SA3 constraint-count Stage-20 campaign

Canonical frozen package for the completed `constraint_count`
sensitivity campaign.

The campaign reached Stage 20 with 20 successful runs, 20,000 timing
observations, zero functional mismatches and satisfied precision targets.

No campaign execution was performed while creating this package.
""",
    encoding="utf-8",
)

(destination / "REPRODUCE.md").write_text(
    """# Reproducibility status

The archive contains the exact existing Stage-10 and Stage-20 evidence,
planning reports, workloads, execution outputs and relevant versioned
scripts.

Source commit:

`f158337532db74fadc40cd9178eea60249da256f`

The campaign must not be rerun merely to recreate this package.

Timing evidence is preserved, but no latency claim is authorized.
""",
    encoding="utf-8",
)

freeze = {
    "scientific_freeze": True,
    "freeze_scope": "constraint_count_stage20",
    "global_scientific_freeze": False,
    "precision_targets_met": True,
    "latency_claim_authorized": False,
}

(destination / "freeze" / "FREEZE.json").write_text(
    json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

entries = []

for path in sorted(destination.rglob("*")):
    if not path.is_file():
        continue

    if path.name in {"MANIFEST.json", "SHA256SUMS"}:
        continue

    data = path.read_bytes()

    entries.append(
        {
            "path": path.relative_to(destination).as_posix(),
            "size_bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        }
    )

(destination / "MANIFEST.json").write_text(
    json.dumps(
        {
            "schema_version": (
                "mcad-frozen-campaign-manifest-v1"
            ),
            "campaign_id": "sa3_constraint_count_stage20",
            "file_count": len(entries),
            "files": entries,
        },
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

checksum_lines = []

for path in sorted(destination.rglob("*")):
    if not path.is_file() or path.name == "SHA256SUMS":
        continue

    digest = hashlib.sha256(path.read_bytes()).hexdigest()

    checksum_lines.append(
        f"{digest}  "
        f"{path.relative_to(destination).as_posix()}"
    )

(destination / "SHA256SUMS").write_text(
    "\n".join(checksum_lines) + "\n",
    encoding="utf-8",
)

print("constraint_count_freeze_metadata=PASS")
PY

echo "=== 6. Update campaign registry ==="

python - "$WORKTREE/experiments/article/frozen_campaigns/REGISTRY.yaml" "$ARCHIVE_SHA" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
archive_sha = sys.argv[2]

text = path.read_text(encoding="utf-8")

campaign_id = "sa3_constraint_count_stage20"

if f"  {campaign_id}:\n" in text:
    raise SystemExit(
        "Constraint-count registry entry already exists."
    )

marker = "  remaining_sensitivity:\n"

entry = f"""  {campaign_id}:
    scientific_status: completed_precision_targets_met
    repository_persistence_status: complete
    path: sa3_constraint_count_stage20
    canonical_archive_sha256: {archive_sha}
    scientific_freeze: true
    run_count: 20
    measurement_observation_count: 20000
    functional_mismatch_count: 0
    precision_targets_met: true
    latency_claim_authorized: false
    rerun_required: false

"""

if marker not in text:
    raise SystemExit("Registry insertion marker not found.")

text = text.replace(marker, entry + marker, 1)
text = text.replace(
    "next_action: inventory_and_continue_remaining_factors",
    "next_action: continue_virtual_node_count",
    1,
)

path.write_text(text, encoding="utf-8")

print("constraint_count_registry_update=PASS")
PY

echo "=== 7. Verify and commit ==="

(
  cd "$DEST"
  sha256sum -c SHA256SUMS
)

if [ "$ARCHIVE_SIZE" -ge $((50 * 1024 * 1024)) ]; then
  git -C "$WORKTREE" lfs install --local

  (
    cd "$WORKTREE"
    git lfs track "$DEST_REL/archive/*.tar.gz"
  )
fi

git -C "$WORKTREE" add \
  "$DEST_REL" \
  experiments/article/frozen_campaigns/REGISTRY.yaml

if [ -f "$WORKTREE/.gitattributes" ]; then
  git -C "$WORKTREE" add .gitattributes
fi

git -C "$WORKTREE" diff --cached --check

git -C "$WORKTREE" commit \
  -m "chore(experiments): freeze constraint-count Stage-20 campaign"

COMMIT="$(git -C "$WORKTREE" rev-parse HEAD)"

git -C "$WORKTREE" push -u origin "$BRANCH"

echo
echo "constraint_count_freeze=PASS"
echo "constraint_count_rerun_required=false"
echo "freeze_branch=$BRANCH"
echo "freeze_commit=$COMMIT"
echo "freeze_worktree=$WORKTREE"
echo "current_historical_branch=$(git -C "$HIST" branch --show-current)"
echo "next_stage=create_constraint_count_freeze_pr"
