#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

SCOPE_ROOT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z"
SCOPE_REPORT="$SCOPE_ROOT/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

SCOPE_SURFACE="$SCOPE_ROOT/sa5_objective_count_v2_scope_reprojection.txt"
EXPECTED_SCOPE_SURFACE_SHA="39b16b812355b4149c98401ed4da32fe8d2623edd4977e5859a68ce2fa66ac1f"

CKG_SOURCE="backend/ckg/ckg_updater.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_noise_operator_feasibility_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_noise_operator_feasibility.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_noise_operator_feasibility.txt"

trap 'echo "[ERROR] SA5 v2 noise-operator audit stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Exact read-only audit gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$SCOPE_REPORT" \
  "$SCOPE_SURFACE" \
  "$CKG_SOURCE" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test "$(
  sha256sum "$SCOPE_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_SURFACE_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

grep -F \
  'contributive = bool(gained_resource_ids)' \
  "$CKG_SOURCE" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_v2_post_capacity_scope_resolved"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .final_scope.new_file_count == 10
  and .final_scope.modified_file_count == 11
  and .final_scope.total_patch_file_count == 21
  and .blocker_count == 0
  and .scope_complete == true
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_21_file_scope"
' "$SCOPE_REPORT" >/dev/null

jq -e '
  .status == "preregistered_implementation_required"
  and .revised_workload_contract.workload_length == 32
  and .revised_workload_contract.non_contributive_query_count == 8
  and .revised_workload_contract.oracle_contributive_query_count == 24
  and .revised_workload_contract.integer_allocation_method
    == "exact_one_per_class_per_replication"
  and (
    .revised_workload_contract.noise_class_order
    | length
  ) == 8
  and (
    .revised_workload_contract.counts_by_replication
    | length
  ) == 10
  and .revised_workload_contract.noise_position_selection.position_domain
    == "1..32"
  and .revised_workload_contract.noise_position_selection.selection_count
    == 8
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
' "$AMENDMENT_002" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "audit_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "scope_file_count=21"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Run detached noise-schedule and semantics audit ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export PREREG
export AMENDMENT_001
export AMENDMENT_002
export SCOPE_REPORT
export CKG_SOURCE
export REPORT
export SURFACE

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any, Mapping

from backend.ckg.ckg_updater import CKGGraph


root = Path(os.environ["ROOT"]).resolve()
source_commit = os.environ["EXPECTED_HEAD"]

prereg_path = root / os.environ["PREREG"]
amendment_001_path = root / os.environ["AMENDMENT_001"]
amendment_002_path = root / os.environ["AMENDMENT_002"]
scope_report_path = Path(
    os.environ["SCOPE_REPORT"]
).resolve()
ckg_source_path = root / os.environ["CKG_SOURCE"]

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(value, dict):
        raise AssertionError(
            f"JSON root is not an object: {path}"
        )

    return value


def recursive_keys(
    value: Any,
    *,
    prefix: tuple[str, ...] = (),
) -> list[tuple[str, ...]]:
    result: list[tuple[str, ...]] = []

    if isinstance(value, dict):
        for key, child in value.items():
            child_prefix = prefix + (str(key),)
            result.append(child_prefix)
            result.extend(
                recursive_keys(
                    child,
                    prefix=child_prefix,
                )
            )

    elif isinstance(value, list):
        for index, child in enumerate(value):
            result.extend(
                recursive_keys(
                    child,
                    prefix=prefix + (str(index),),
                )
            )

    return result


prereg = load_json(prereg_path)
amendment_001 = load_json(
    amendment_001_path
)
amendment_002 = load_json(
    amendment_002_path
)
scope_report = load_json(
    scope_report_path
)

workload = amendment_002[
    "revised_workload_contract"
]

noise_classes = list(
    workload["noise_class_order"]
)

rows = list(
    workload["counts_by_replication"]
)

assert noise_classes == [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

assert len(rows) == 10

for row in rows:
    assert set(
        row["class_counts"]
    ) == set(noise_classes)

    assert set(
        row["class_counts"].values()
    ) == {1}


def digest(value: str) -> str:
    return hashlib.sha256(
        value.encode("utf-8")
    ).hexdigest()


def selected_noise_positions(
    seed: int,
) -> list[int]:
    ranked = sorted(
        range(1, 33),
        key=lambda position: (
            digest(
                "mcad-sa5-noise-position-v2"
                f"|{seed}|{position}"
            ),
            position,
        ),
    )

    return sorted(ranked[:8])


def ranked_noise_classes(
    seed: int,
) -> list[str]:
    return sorted(
        noise_classes,
        key=lambda noise_class: (
            digest(
                "mcad-sa5-noise-class-v2"
                f"|{seed}|{noise_class}"
            ),
            noise_class,
        ),
    )


schedule_rows: list[dict[str, Any]] = []
redundancy_ordering_failures: list[
    dict[str, Any]
] = []

for row in rows:
    replication_index = int(
        row["replication_index"]
    )
    seed = int(row["seed"])

    positions = selected_noise_positions(
        seed
    )

    class_order = ranked_noise_classes(
        seed
    )

    assignment = {
        position: noise_class
        for position, noise_class
        in zip(
            positions,
            class_order,
            strict=True,
        )
    }

    redundant_positions = [
        position
        for position, noise_class
        in assignment.items()
        if noise_class
        == "redundant_contribution"
    ]

    assert len(redundant_positions) == 1

    redundant_position = (
        redundant_positions[0]
    )

    contributive_positions = [
        position
        for position in range(1, 33)
        if position not in assignment
    ]

    assert len(contributive_positions) == 24

    prior_contributive_positions = [
        position
        for position in contributive_positions
        if position < redundant_position
    ]

    row_report = {
        "replication_index": replication_index,
        "seed": seed,
        "noise_positions": positions,
        "class_order": class_order,
        "class_by_position": {
            str(position): assignment[position]
            for position in sorted(assignment)
        },
        "redundant_contribution_position": (
            redundant_position
        ),
        "first_contributive_position": (
            contributive_positions[0]
        ),
        "prior_contributive_positions": (
            prior_contributive_positions
        ),
        "has_prior_contributive_step": bool(
            prior_contributive_positions
        ),
    }

    schedule_rows.append(row_report)

    if not prior_contributive_positions:
        redundancy_ordering_failures.append(
            row_report
        )


assert len(redundancy_ordering_failures) == 1

failure = redundancy_ordering_failures[0]

assert failure["replication_index"] == 2
assert failure["seed"] == 1198202409
assert failure[
    "redundant_contribution_position"
] == 1
assert failure[
    "prior_contributive_positions"
] == []


# --------------------------------------------------------------
# Independent session-contribution semantics proof
# --------------------------------------------------------------

objective_id = (
    "O_SA5_REDUNDANCY_SEMANTICS_PROBE"
)
constraint_id = (
    "O_SA5_REDUNDANCY_SEMANTICS_PROBE_C0001"
)
resource_id = (
    "O_SA5_REDUNDANCY_SEMANTICS_PROBE_"
    "C0001_NV0001"
)
session_id = (
    "S_SA5_REDUNDANCY_SEMANTICS_PROBE"
)

ckg = CKGGraph(
    output_dir="/tmp/sa5-redundancy-probe"
)

ckg.objectives = {
    objective_id: {
        "id": objective_id,
        "kpis": [],
        "constraints": {
            constraint_id: {
                "id": constraint_id,
                "virtual_nodes": [
                    resource_id
                ],
                "requirement_sets": [
                    [resource_id]
                ],
            }
        },
    }
}

ckg.session_resource_coverage.clear()

first_observation = (
    ckg.classify_constraint_states(
        session_id,
        objective_id,
        {resource_id},
    )
)

second_observation = (
    ckg.classify_constraint_states(
        session_id,
        objective_id,
        {resource_id},
    )
)

assert first_observation[
    "is_session_contributive"
] is True

assert first_observation[
    "gained_resource_ids"
] == [resource_id]

assert second_observation[
    "is_session_contributive"
] is False

assert second_observation[
    "gained_resource_ids"
] == []


# --------------------------------------------------------------
# Authoritative operator-definition closure
# --------------------------------------------------------------

candidate_operator_keys = {
    "noise_class_operators",
    "noise_class_operator_contract",
    "noise_mutation_contract",
    "mutation_operators",
    "query_mutation_operators",
    "class_mutation_rules",
    "noise_class_semantics",
}

artifact_key_paths: dict[
    str,
    list[str],
] = {}

for label, artifact in (
    ("preregistration", prereg),
    ("amendment_001", amendment_001),
    ("amendment_002", amendment_002),
):
    paths = recursive_keys(artifact)

    artifact_key_paths[label] = [
        ".".join(path)
        for path in paths
        if path
        and path[-1]
        in candidate_operator_keys
    ]

assert not any(
    artifact_key_paths.values()
)


tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]

implementation_hits: list[
    dict[str, Any]
] = []

for relative in tracked_files:
    path = root / relative

    if path.suffix != ".py":
        continue

    try:
        text = path.read_text(
            encoding="utf-8"
        )
    except (
        OSError,
        UnicodeDecodeError,
    ):
        continue

    if not any(
        noise_class in text
        for noise_class in noise_classes
    ):
        continue

    lines = text.splitlines()

    for line_number, line in enumerate(
        lines,
        start=1,
    ):
        matched = [
            noise_class
            for noise_class in noise_classes
            if noise_class in line
        ]

        if matched:
            implementation_hits.append(
                {
                    "path": relative.as_posix(),
                    "line": line_number,
                    "classes": matched,
                    "text": line.rstrip(),
                }
            )


production_operator_hits = [
    hit
    for hit in implementation_hits
    if (
        "/tests/" not in hit["path"]
        and not hit["path"].endswith(
            "validate_design.py"
        )
        and "/planning/" not in hit["path"]
    )
]

assert production_operator_hits == []


blockers = [
    (
        "noise_class_query_mutation_operators_"
        "not_preregistered"
    ),
    (
        "redundant_contribution_assigned_to_"
        "first_step_for_replication_2"
    ),
    (
        "fresh_session_redundancy_requires_"
        "a_prior_contributive_step"
    ),
]

status = (
    "sa5_objective_count_v2_noise_"
    "operator_contract_incomplete"
)

next_stage = (
    "preregister_sa5_objective_count_"
    "noise_operator_and_redundancy_"
    "ordering_amendment"
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "noise-operator-feasibility-audit-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "source_hashes": {
        "preregistration": (
            sha256_file(prereg_path)
        ),
        "amendment_001": (
            sha256_file(
                amendment_001_path
            )
        ),
        "amendment_002": (
            sha256_file(
                amendment_002_path
            )
        ),
        "scope_report": (
            sha256_file(
                scope_report_path
            )
        ),
        "ckg_updater": (
            sha256_file(
                ckg_source_path
            )
        ),
    },
    "scope_projection": {
        "scope_status": (
            scope_report["status"]
        ),
        "new_file_count": (
            scope_report[
                "final_scope"
            ]["new_file_count"]
        ),
        "modified_file_count": (
            scope_report[
                "final_scope"
            ]["modified_file_count"]
        ),
        "total_patch_file_count": (
            scope_report[
                "final_scope"
            ]["total_patch_file_count"]
        ),
        "source_ownership_complete": True,
        "semantic_materializability_proven": False,
    },
    "noise_schedule": {
        "workload_length": 32,
        "noise_step_count": 8,
        "contributive_step_count": 24,
        "noise_classes": noise_classes,
        "rows": schedule_rows,
        "redundancy_ordering_failure_count": (
            len(
                redundancy_ordering_failures
            )
        ),
        "redundancy_ordering_failures": (
            redundancy_ordering_failures
        ),
    },
    "session_semantics_probe": {
        "first_support_occurrence_is_contributive": (
            first_observation[
                "is_session_contributive"
            ]
        ),
        "first_support_occurrence_gained_resources": (
            first_observation[
                "gained_resource_ids"
            ]
        ),
        "repeated_support_occurrence_is_contributive": (
            second_observation[
                "is_session_contributive"
            ]
        ),
        "repeated_support_occurrence_gained_resources": (
            second_observation[
                "gained_resource_ids"
            ]
        ),
        "redundancy_requires_prior_contribution": True,
    },
    "operator_contract": {
        "candidate_operator_keys": sorted(
            candidate_operator_keys
        ),
        "artifact_operator_key_paths": (
            artifact_key_paths
        ),
        "authoritative_operator_definition_present": False,
        "repository_class_reference_hits": (
            implementation_hits
        ),
        "production_operator_hits": (
            production_operator_hits
        ),
        "production_operator_implementation_present": False,
    },
    "blockers": blockers,
    "blocker_count": len(blockers),
    "v2_source_scope_resolved": True,
    "v2_patch_authoring_authorized": False,
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 NOISE-OPERATOR FEASIBILITY AUDIT",
    "=" * 92,
    f"source_commit={source_commit}",
    f"status={status}",
    "",
    "=== SOURCE SCOPE ===",
    "source_scope_file_count=21",
    "source_ownership_complete=true",
    "semantic_materializability_proven=false",
    "",
    "=== REDUNDANCY ORDERING FAILURE ===",
    (
        "failure_count="
        f"{len(redundancy_ordering_failures)}"
    ),
    (
        "failure_replication_index="
        f"{failure['replication_index']}"
    ),
    f"failure_seed={failure['seed']}",
    (
        "redundant_contribution_position="
        f"{failure['redundant_contribution_position']}"
    ),
    (
        "prior_contributive_step_count="
        f"{len(failure['prior_contributive_positions'])}"
    ),
    (
        "has_prior_contributive_step="
        f"{str(failure['has_prior_contributive_step']).lower()}"
    ),
    "",
    "=== SESSION SEMANTICS PROBE ===",
    "first_support_occurrence_is_contributive=true",
    "repeated_support_occurrence_is_contributive=false",
    "redundancy_requires_prior_contribution=true",
    "",
    "=== OPERATOR CONTRACT ===",
    "authoritative_operator_definition_present=false",
    "production_operator_implementation_present=false",
    "",
    "=== COMPLETE SCHEDULE ===",
]

for row in schedule_rows:
    surface_lines.extend(
        [
            "",
            (
                "replication_index="
                f"{row['replication_index']}"
            ),
            f"seed={row['seed']}",
            (
                "noise_positions="
                + json.dumps(
                    row["noise_positions"]
                )
            ),
            (
                "class_order="
                + json.dumps(
                    row["class_order"]
                )
            ),
            (
                "class_by_position="
                + json.dumps(
                    row["class_by_position"],
                    sort_keys=True,
                )
            ),
            (
                "redundant_contribution_position="
                f"{row['redundant_contribution_position']}"
            ),
            (
                "prior_contributive_positions="
                + json.dumps(
                    row[
                        "prior_contributive_positions"
                    ]
                )
            ),
            (
                "has_prior_contributive_step="
                f"{str(row['has_prior_contributive_step']).lower()}"
            ),
        ]
    )

surface_lines.extend(
    [
        "",
        "=== BLOCKERS ===",
        *[
            f"blocker={blocker}"
            for blocker in blockers
        ],
        "",
        "v2_source_scope_resolved=true",
        "v2_patch_authoring_authorized=false",
        "canonical_campaign_materialization_authorized=false",
        "canonical_campaign_generated=false",
        "campaign_materialization_performed=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("noise_operator_feasibility_projection=PASS")
print(f"status={status}")
print(
    "source_scope_file_count="
    f"{report['scope_projection']['total_patch_file_count']}"
)
print("source_ownership_complete=true")
print("semantic_materializability_proven=false")
print(
    "redundancy_ordering_failure_count="
    f"{len(redundancy_ordering_failures)}"
)
print(
    "failure_replication_index="
    f"{failure['replication_index']}"
)
print(f"failure_seed={failure['seed']}")
print(
    "redundant_contribution_position="
    f"{failure['redundant_contribution_position']}"
)
print("prior_contributive_step_count=0")
print(
    "authoritative_operator_definition_present=false"
)
print(
    "production_operator_implementation_present=false"
)
print("v2_patch_authoring_authorized=false")
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 3. Validate feasibility report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-noise-operator-feasibility-audit-v1"
  and .status
    == "sa5_objective_count_v2_noise_operator_contract_incomplete"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .read_only == true

  and .scope_projection.total_patch_file_count == 21
  and .scope_projection.source_ownership_complete == true
  and .scope_projection.semantic_materializability_proven == false

  and .noise_schedule.workload_length == 32
  and .noise_schedule.noise_step_count == 8
  and .noise_schedule.contributive_step_count == 24
  and .noise_schedule.redundancy_ordering_failure_count == 1

  and (
    .noise_schedule.redundancy_ordering_failures
    | length
  ) == 1

  and .noise_schedule.redundancy_ordering_failures[0].replication_index
    == 2
  and .noise_schedule.redundancy_ordering_failures[0].seed
    == 1198202409
  and .noise_schedule.redundancy_ordering_failures[0].redundant_contribution_position
    == 1
  and .noise_schedule.redundancy_ordering_failures[0].prior_contributive_positions
    == []
  and .noise_schedule.redundancy_ordering_failures[0].has_prior_contributive_step
    == false

  and .session_semantics_probe.first_support_occurrence_is_contributive
    == true
  and .session_semantics_probe.repeated_support_occurrence_is_contributive
    == false
  and .session_semantics_probe.redundancy_requires_prior_contribution
    == true

  and .operator_contract.authoritative_operator_definition_present
    == false
  and .operator_contract.production_operator_implementation_present
    == false

  and .blocker_count == 3
  and .v2_source_scope_resolved == true
  and .v2_patch_authoring_authorized == false

  and .canonical_campaign_materialization_authorized
    == false
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false

  and .next_stage
    == "preregister_sa5_objective_count_noise_operator_and_redundancy_ordering_amendment"
' "$REPORT" >/dev/null

echo "noise_operator_feasibility_report_validation=PASS"

echo
echo "=== 4. Compact semantic decision ==="

jq '{
  status,
  source_commit,
  scope_projection,
  noise_schedule: {
    workload_length,
    noise_step_count,
    contributive_step_count,
    redundancy_ordering_failure_count,
    redundancy_ordering_failures
  },
  session_semantics_probe,
  operator_contract: {
    artifact_operator_key_paths,
    authoritative_operator_definition_present,
    production_operator_implementation_present
  },
  blockers,
  blocker_count,
  v2_source_scope_resolved,
  v2_patch_authoring_authorized,
  next_stage
}' "$REPORT"

echo
echo "=== 5. High-value semantic surface ==="

grep -nE \
  '^(status=|source_scope|source_ownership|semantic_materializability|failure_|redundant_contribution_position=|prior_contributive|has_prior|first_support|repeated_support|redundancy_requires|authoritative_operator|production_operator|blocker=|v2_patch|next_stage=)' \
  "$SURFACE" |
  head -n 300 || true

echo
echo "=== 6. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_objective_count_v2_noise_operator_feasibility_audit=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo "source_scope_file_count=21"
echo "source_ownership_complete=true"
echo "semantic_materializability_proven=false"

echo "redundancy_ordering_failure_count=1"
echo "failure_replication_index=2"
echo "failure_seed=1198202409"
echo "redundant_contribution_position=1"
echo "prior_contributive_step_count=0"

echo "authoritative_operator_definition_present=false"
echo "v2_patch_authoring_authorized=false"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo "next_stage=preregister_sa5_objective_count_noise_operator_and_redundancy_ordering_amendment"

git status --short --branch
