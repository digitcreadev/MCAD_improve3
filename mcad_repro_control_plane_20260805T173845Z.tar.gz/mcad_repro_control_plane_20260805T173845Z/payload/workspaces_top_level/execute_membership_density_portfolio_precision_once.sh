#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="c056ea76176f6a06d2a5012ddd37e043ca4324a4"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
PRECISION_ROOT="$REPORTS/audits/membership_density/timing_stage10/precision_analysis"

AUTH="$REPORTS/planning/sa4_membership_density_portfolio_precision_analysis_authorization.json"
OBSERVATIONS="$PRECISION_ROOT/stage10_portfolio_measurement_observations.csv"
TIMING_ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

RAW_LOG="$PRECISION_ROOT/analyzer.log"
RAW_INTERVALS="$PRECISION_ROOT/raw_analyzer_intervals.csv"
RAW_REPORT_JSON="$PRECISION_ROOT/raw_analyzer_report.json"
RAW_REPORT_MD="$PRECISION_ROOT/raw_analyzer_report.md"

DECISION_JSON="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.json"
DECISION_MD="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.md"

EXPECTED_AUTH_SHA="835a22c0f74f18c2da64ed91257fcd58839a85a7c4f6113579b9bba05cd068d1"
EXPECTED_OBSERVATIONS_SHA="757c8e7684396cf1b5d7a923a4b7935a95b746896fac357c7ef4ea93df36133a"
EXPECTED_TIMING_ADAPTER_SHA="0bd99f578b6aca3913536fd8b237f89a9607db369a1fa4ad2243b9ceb295f9c3"
EXPECTED_MANIFEST_SHA="449d0d54bb10df84327e3d757382e33c78abe9d2c9b3c5f55e3d8d5ee6ac2451"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

EXPECTED_OBSERVATIONS_SIZE=55447769

trap 'echo "[ERROR] Precision execution stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Single-execution gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"

for FILE in \
  "$AUTH" \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test "$(sha256sum "$AUTH" | awk '{print $1}')" \
  = "$EXPECTED_AUTH_SHA"

test "$(sha256sum "$OBSERVATIONS" | awk '{print $1}')" \
  = "$EXPECTED_OBSERVATIONS_SHA"

test "$(sha256sum "$TIMING_ADAPTER" | awk '{print $1}')" \
  = "$EXPECTED_TIMING_ADAPTER_SHA"

test "$(sha256sum "$INPUT_MANIFEST" | awk '{print $1}')" \
  = "$EXPECTED_MANIFEST_SHA"

test "$(sha256sum "$ANALYZER" | awk '{print $1}')" \
  = "$EXPECTED_ANALYZER_SHA"

test "$(stat -c '%s' "$OBSERVATIONS")" \
  -eq "$EXPECTED_OBSERVATIONS_SIZE"

for OUTPUT in \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"
do
  test ! -e "$OUTPUT"
done

jq -e '
  .status
    == "membership_density_portfolio_precision_analysis_authorized"
  and .factor == "membership_density"
  and .authorization_scope.execution_count_authorized == 1
  and .authorization_scope.successful_execution_count_observed == 0
  and .authorization_scope.analyzer_execution_authorized == true
  and .authorization_scope.adapter_rematerialization_authorized == false
  and .authorization_scope.timing_reexecution_authorized == false
  and .authorization_scope.stage20_execution_authorized == false
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.inferential_cell_count == 4
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.measurements_per_cluster == 2300
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .analysis_contract.confidence_level == 0.95
  and .analysis_contract.median_relative_half_width_target == 0.10
  and .analysis_contract.p95_relative_half_width_target == 0.15
  and .scientific_controls.precision_analysis_authorized == true
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.successful_bootstrap_execution_count == 0
' "$AUTH" >/dev/null

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_inputs_materialized"
  and .adapter_contract.derived_measurement_observation_count == 92000
  and .adapter_contract.inferential_cell_count == 4
  and .adapter_contract.structural_seed_count == 10
  and .adapter_contract.measurements_per_cluster == 2300
  and .materialization_decision.adapter_inputs_validated == true
  and .scientific_controls.precision_analysis_performed == false
' "$INPUT_MANIFEST" >/dev/null

echo "single_execution_gate=PASS"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=0"
echo "precision_analysis_authorized=true"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create precision-analysis branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/analyze-membership-density-portfolio-precision-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Execute authorized analyzer exactly once ==="
echo "The bootstrap may remain quiet until its calculations finish."
echo "Do not relaunch this script while the process is running."

mkdir -p "$PRECISION_ROOT"

set +e

PYTHONPATH="$ROOT" \
"$PYTHON" "$ANALYZER" \
  --stage-size 10 \
  --observations "$OBSERVATIONS" \
  --timing-report "$TIMING_ADAPTER" \
  --intervals-csv "$RAW_INTERVALS" \
  --report-json "$RAW_REPORT_JSON" \
  --report-md "$RAW_REPORT_MD" \
  --levels "25,50,75,100" \
  --steps "0" \
  --measurements-per-cluster 2300 \
  --bootstrap-repetitions 10000 \
  --bootstrap-seed 20260728 \
  --confidence-level 0.95 \
  --median-target 0.10 \
  --p95-target 0.15 \
  2>&1 | tee "$RAW_LOG"

ANALYZER_STATUS="${PIPESTATUS[0]}"

set -e

echo "analyzer_exit_status=$ANALYZER_STATUS"

if [ "$ANALYZER_STATUS" -ne 0 ]; then
  echo "successful_bootstrap_execution_count=0"
  echo "precision_analysis_performed=false"
  echo "[ERROR] The authorized analyzer execution did not complete."
  exit "$ANALYZER_STATUS"
fi

for OUTPUT in \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD"
do
  test -s "$OUTPUT"
done

echo "clustered_precision_analyzer_execution=PASS"
echo "successful_bootstrap_execution_count=1"
echo "precision_analysis_performed=true"

echo
echo "=== 4. Validate raw outputs and create canonical decision ==="

"$PYTHON" - \
  "$ROOT" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$AUTH" \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST" \
  "$ANALYZER" \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
source_commit = sys.argv[2]
created_utc = sys.argv[3]

auth_path = (root / sys.argv[4]).resolve()
observations_path = (root / sys.argv[5]).resolve()
timing_adapter_path = (root / sys.argv[6]).resolve()
manifest_path = (root / sys.argv[7]).resolve()
analyzer_path = (root / sys.argv[8]).resolve()

raw_log_path = (root / sys.argv[9]).resolve()
raw_intervals_path = (root / sys.argv[10]).resolve()
raw_report_path = (root / sys.argv[11]).resolve()
raw_report_md_path = (root / sys.argv[12]).resolve()

decision_path = (root / sys.argv[13]).resolve()
decision_md_path = (root / sys.argv[14]).resolve()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.resolve().relative_to(root).as_posix()


def finite_float(value: Any, *, label: str) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise SystemExit(f"Invalid {label}: {value!r}") from exc

    if not math.isfinite(parsed):
        raise SystemExit(f"Non-finite {label}: {value!r}")

    return parsed


def optional_number(
    row: dict[str, Any],
    names: tuple[str, ...],
) -> float | None:
    for name in names:
        if name in row and row[name] is not None:
            return finite_float(row[name], label=name)

    return None


authorization = load_object(auth_path)
manifest = load_object(manifest_path)
timing_adapter = load_object(timing_adapter_path)
raw_report = load_object(raw_report_path)

if authorization.get("status") != (
    "membership_density_portfolio_"
    "precision_analysis_authorized"
):
    raise SystemExit("Authorization status mismatch.")

if manifest.get("factor") != "membership_density":
    raise SystemExit("Input-manifest factor mismatch.")

if timing_adapter.get("factor") != "membership_density":
    raise SystemExit("Timing-adapter factor mismatch.")

cell_results = raw_report.get("cell_results")

if not isinstance(cell_results, list):
    raise SystemExit("Raw analyzer report lacks cell_results.")

if len(cell_results) != 4:
    raise SystemExit(
        f"Expected four inferential cells, got {len(cell_results)}."
    )

expected_levels = [25, 50, 75, 100]
seen_levels: list[int] = []
canonical_cells: list[dict[str, Any]] = []

raw_factor_values: set[str] = set()

median_target = 0.10
p95_target = 0.15

for position, raw_cell in enumerate(cell_results):
    if not isinstance(raw_cell, dict):
        raise SystemExit(
            f"Invalid raw cell at position {position}."
        )

    level = int(raw_cell["factor_level"])
    step = int(raw_cell["step_index"])

    if step != 0:
        raise SystemExit(
            f"Raw analyzer step differs from zero: {step}."
        )

    raw_factor = str(raw_cell.get("factor"))
    raw_factor_values.add(raw_factor)

    median_rhw = finite_float(
        raw_cell["median_relative_half_width"],
        label="median_relative_half_width",
    )

    p95_rhw = finite_float(
        raw_cell["p95_relative_half_width"],
        label="p95_relative_half_width",
    )

    median_pass = median_rhw <= median_target
    p95_pass = p95_rhw <= p95_target

    median_ms = optional_number(
        raw_cell,
        (
            "median_ms",
            "observed_median_ms",
            "median_latency_ms",
        ),
    )

    p95_ms = optional_number(
        raw_cell,
        (
            "p95_ms",
            "observed_p95_ms",
            "p95_latency_ms",
        ),
    )

    canonical_cells.append({
        "factor": "membership_density",
        "factor_level": level,
        "step_index": 0,
        "raw_analyzer_factor": raw_factor,
        "median_ms": median_ms,
        "p95_ms": p95_ms,
        "median_relative_half_width": median_rhw,
        "p95_relative_half_width": p95_rhw,
        "median_relative_half_width_target": median_target,
        "p95_relative_half_width_target": p95_target,
        "median_target_met": median_pass,
        "p95_target_met": p95_pass,
        "all_cell_targets_met": (
            median_pass and p95_pass
        ),
        "bootstrap_repetitions": raw_cell.get(
            "bootstrap_repetitions"
        ),
        "bootstrap_seed": raw_cell.get("bootstrap_seed"),
    })

    seen_levels.append(level)

if sorted(seen_levels) != expected_levels:
    raise SystemExit(
        f"Unexpected inferential levels: {sorted(seen_levels)}"
    )

if raw_factor_values != {"constraint_count"}:
    raise SystemExit(
        "Unexpected raw analyzer factor values: "
        f"{sorted(raw_factor_values)}"
    )

canonical_cells.sort(key=lambda item: item["factor_level"])

all_median_targets_met = all(
    cell["median_target_met"]
    for cell in canonical_cells
)

all_p95_targets_met = all(
    cell["p95_target_met"]
    for cell in canonical_cells
)

all_precision_targets_met = (
    all_median_targets_met
    and all_p95_targets_met
)

failing_cells = [
    cell
    for cell in canonical_cells
    if not cell["all_cell_targets_met"]
]

failing_cell_count = len(failing_cells)

if all_precision_targets_met:
    status = "pass"
    stage10_sufficient = True
    stage20_extension_required = False
    next_stage = (
        "prepare_membership_density_stage10_freeze"
    )
else:
    status = "precision_targets_not_met"
    stage10_sufficient = False
    stage20_extension_required = True
    next_stage = (
        "preregister_membership_density_stage20_extension"
    )

with raw_intervals_path.open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    interval_reader = csv.DictReader(handle)
    interval_rows = list(interval_reader)

if len(interval_rows) != 4:
    raise SystemExit(
        f"Expected four interval rows, got {len(interval_rows)}."
    )

interval_levels = sorted({
    int(row["factor_level"])
    for row in interval_rows
})

interval_steps = sorted({
    int(row["step_index"])
    for row in interval_rows
})

if interval_levels != expected_levels:
    raise SystemExit(
        f"Unexpected interval levels: {interval_levels}"
    )

if interval_steps != [0]:
    raise SystemExit(
        f"Unexpected interval steps: {interval_steps}"
    )

raw_report_status = raw_report.get("status")
raw_report_next_stage = raw_report.get("next_stage")

decision = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-portfolio-precision-decision-v1"
    ),
    "status": status,
    "factor": "membership_density",
    "stage": 10,
    "created_utc": created_utc,
    "source_commit": source_commit,
    "analysis_execution": {
        "authorized_execution_count": 1,
        "successful_bootstrap_execution_count": 1,
        "precision_analysis_authorized": True,
        "precision_analysis_performed": True,
        "adapter_rematerialization_performed": False,
        "timing_reexecution_performed": False,
    },
    "analysis_contract": {
        "factor_levels": expected_levels,
        "synthetic_step_indexes": [0],
        "inferential_cell_count": 4,
        "structural_seed_count": 10,
        "measurements_per_cluster": 2300,
        "measurements_per_inferential_cell": 23000,
        "measurement_observation_count": 92000,
        "bootstrap_repetitions": 10000,
        "bootstrap_seed": 20260728,
        "confidence_level": 0.95,
        "median_relative_half_width_target": median_target,
        "p95_relative_half_width_target": p95_target,
    },
    "raw_analyzer_interpretation": {
        "raw_report_status": raw_report_status,
        "raw_report_next_stage": raw_report_next_stage,
        "raw_factor_values": sorted(raw_factor_values),
        "raw_factor_label_authoritative": False,
        "raw_next_stage_authoritative": False,
        "canonical_factor": "membership_density",
    },
    "cell_results": canonical_cells,
    "precision_decision": {
        "all_median_targets_met": (
            all_median_targets_met
        ),
        "all_p95_targets_met": (
            all_p95_targets_met
        ),
        "all_precision_targets_met": (
            all_precision_targets_met
        ),
        "failing_cell_count": failing_cell_count,
        "stage10_sufficient": stage10_sufficient,
        "stage20_extension_required": (
            stage20_extension_required
        ),
        "stage20_execution_authorized": False,
    },
    "source_artifacts": {
        "authorization": {
            "path": relative(auth_path),
            "sha256": sha256(auth_path),
        },
        "observations": {
            "path": relative(observations_path),
            "sha256": sha256(observations_path),
            "size_bytes": observations_path.stat().st_size,
            "row_count": 92000,
        },
        "timing_report_adapter": {
            "path": relative(timing_adapter_path),
            "sha256": sha256(timing_adapter_path),
        },
        "precision_input_manifest": {
            "path": relative(manifest_path),
            "sha256": sha256(manifest_path),
        },
        "precision_analyzer": {
            "path": relative(analyzer_path),
            "sha256": sha256(analyzer_path),
        },
        "raw_analyzer_log": {
            "path": relative(raw_log_path),
            "sha256": sha256(raw_log_path),
        },
        "raw_intervals": {
            "path": relative(raw_intervals_path),
            "sha256": sha256(raw_intervals_path),
            "row_count": 4,
        },
        "raw_report_json": {
            "path": relative(raw_report_path),
            "sha256": sha256(raw_report_path),
        },
        "raw_report_markdown": {
            "path": relative(raw_report_md_path),
            "sha256": sha256(raw_report_md_path),
        },
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_reexecution_performed": False,
        "adapter_rematerialization_performed": False,
        "precision_analysis_authorized": True,
        "precision_analysis_performed": True,
        "successful_bootstrap_execution_count": 1,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": next_stage,
}

decision_path.write_text(
    json.dumps(decision, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

lines = [
    (
        "# SA4 membership-density Stage-10 portfolio "
        "precision decision"
    ),
    "",
    f"- Status: `{status}`",
    "- Factor: `membership_density`",
    "- Successful bootstrap executions: `1`",
    "- Measurements: `92,000`",
    "- Structural clusters: `10`",
    "- Inferential cells: `4`",
    "- Bootstrap repetitions: `10,000`",
    (
        "- All median RHW targets met: "
        f"`{str(all_median_targets_met).lower()}`"
    ),
    (
        "- All p95 RHW targets met: "
        f"`{str(all_p95_targets_met).lower()}`"
    ),
    (
        "- All precision targets met: "
        f"`{str(all_precision_targets_met).lower()}`"
    ),
    f"- Failing cells: `{failing_cell_count}`",
    (
        "- Stage-10 sufficient: "
        f"`{str(stage10_sufficient).lower()}`"
    ),
    (
        "- Stage-20 extension required: "
        f"`{str(stage20_extension_required).lower()}`"
    ),
    "",
    "## Canonical cell results",
    "",
    (
        "| Density | Median ms | Median RHW | Median pass "
        "| p95 ms | p95 RHW | p95 pass |"
    ),
    "|---:|---:|---:|:---:|---:|---:|:---:|",
]

for cell in canonical_cells:
    median_ms = cell["median_ms"]
    p95_ms = cell["p95_ms"]

    rendered_median = (
        "n/a"
        if median_ms is None
        else f"{median_ms:.6f}"
    )

    rendered_p95 = (
        "n/a"
        if p95_ms is None
        else f"{p95_ms:.6f}"
    )

    lines.append(
        "| "
        f"{cell['factor_level']} | "
        f"{rendered_median} | "
        f"{cell['median_relative_half_width']:.6f} | "
        f"{str(cell['median_target_met']).lower()} | "
        f"{rendered_p95} | "
        f"{cell['p95_relative_half_width']:.6f} | "
        f"{str(cell['p95_target_met']).lower()} |"
    )

lines.extend([
    "",
    "## Raw analyzer interpretation",
    "",
    (
        "The raw analyzer label `constraint_count` and its "
        "raw next-stage value are retained for provenance but "
        "are non-authoritative."
    ),
    "",
    "## Next stage",
    "",
    f"`{next_stage}`",
    "",
])

decision_md_path.write_text(
    "\n".join(lines),
    encoding="utf-8",
)

print("canonical_precision_decision=PASS")
print("raw_analyzer_factor_values=constraint_count")
print("canonical_factor=membership_density")
print(
    "all_median_targets_met="
    f"{str(all_median_targets_met).lower()}"
)
print(
    "all_p95_targets_met="
    f"{str(all_p95_targets_met).lower()}"
)
print(
    "all_precision_targets_met="
    f"{str(all_precision_targets_met).lower()}"
)
print(f"failing_cell_count={failing_cell_count}")
print(
    "stage10_sufficient="
    f"{str(stage10_sufficient).lower()}"
)
print(
    "stage20_extension_required="
    f"{str(stage20_extension_required).lower()}"
)
print("stage20_execution_authorized=false")
print("successful_bootstrap_execution_count=1")
print("precision_analysis_performed=true")
print(f"next_stage={next_stage}")
PY

echo
echo "=== 5. Validate canonical decision ==="

test -s "$DECISION_JSON"
test -s "$DECISION_MD"

jq -e '
  .factor == "membership_density"
  and .stage == 10
  and .analysis_execution.authorized_execution_count == 1
  and .analysis_execution.successful_bootstrap_execution_count == 1
  and .analysis_execution.precision_analysis_authorized == true
  and .analysis_execution.precision_analysis_performed == true
  and .analysis_execution.adapter_rematerialization_performed == false
  and .analysis_execution.timing_reexecution_performed == false
  and .analysis_contract.inferential_cell_count == 4
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.measurements_per_cluster == 2300
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .raw_analyzer_interpretation.raw_factor_values
      == ["constraint_count"]
  and .raw_analyzer_interpretation.raw_factor_label_authoritative
      == false
  and .raw_analyzer_interpretation.raw_next_stage_authoritative
      == false
  and .raw_analyzer_interpretation.canonical_factor
      == "membership_density"
  and (.cell_results | length) == 4
  and ([.cell_results[].factor_level] | sort)
      == [25, 50, 75, 100]
  and ([.cell_results[].step_index] | unique) == [0]
  and .scientific_controls.precision_analysis_performed == true
  and .scientific_controls.successful_bootstrap_execution_count == 1
  and .scientific_controls.stage20_execution_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and (
    (
      .precision_decision.all_precision_targets_met == true
      and .precision_decision.failing_cell_count == 0
      and .precision_decision.stage10_sufficient == true
      and .precision_decision.stage20_extension_required == false
      and .next_stage
          == "prepare_membership_density_stage10_freeze"
    )
    or
    (
      .precision_decision.all_precision_targets_met == false
      and .precision_decision.failing_cell_count > 0
      and .precision_decision.stage10_sufficient == false
      and .precision_decision.stage20_extension_required == true
      and .next_stage
          == "preregister_membership_density_stage20_extension"
    )
  )
' "$DECISION_JSON" >/dev/null

RAW_LOG_SHA="$(sha256sum "$RAW_LOG" | awk '{print $1}')"
RAW_INTERVALS_SHA="$(sha256sum "$RAW_INTERVALS" | awk '{print $1}')"
RAW_REPORT_SHA="$(sha256sum "$RAW_REPORT_JSON" | awk '{print $1}')"
RAW_REPORT_MD_SHA="$(sha256sum "$RAW_REPORT_MD" | awk '{print $1}')"
DECISION_SHA="$(sha256sum "$DECISION_JSON" | awk '{print $1}')"

ALL_TARGETS="$(
  jq -r \
    '.precision_decision.all_precision_targets_met' \
    "$DECISION_JSON"
)"

FAILING_COUNT="$(
  jq -r \
    '.precision_decision.failing_cell_count' \
    "$DECISION_JSON"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$DECISION_JSON"
)"

echo "precision_result_validation=PASS"
echo "raw_analyzer_log_sha256=$RAW_LOG_SHA"
echo "raw_intervals_sha256=$RAW_INTERVALS_SHA"
echo "raw_report_sha256=$RAW_REPORT_SHA"
echo "raw_report_md_sha256=$RAW_REPORT_MD_SHA"
echo "canonical_decision_sha256=$DECISION_SHA"
echo "all_precision_targets_met=$ALL_TARGETS"
echo "failing_cell_count=$FAILING_COUNT"
echo "successful_bootstrap_execution_count=1"
echo "precision_analysis_performed=true"
echo "next_stage=$NEXT_STAGE"

echo
echo "=== 6. Commit precision evidence ==="

git add -f \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"

STAGED_FILE_COUNT="$(
  git diff --cached --name-only | wc -l
)"

test "$STAGED_FILE_COUNT" -eq 6

git diff --cached --check -- \
  "$RAW_LOG" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"

echo "precision_evidence_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"

git commit \
  -m "evidence(experiments): analyze membership-density Stage-10 precision"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 7. Push precision branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Analyze membership-density Stage-10 portfolio precision" \
    --body "$(cat <<EOF
## Authorized execution

- authorized analyzer executions: \`1\`;
- successful bootstrap executions: \`1\`;
- measurements: \`92,000\`;
- inferential cells: \`4\`;
- structural clusters: \`10\`;
- measurements per cluster: \`2,300\`;
- bootstrap repetitions: \`10,000\`;
- bootstrap seed: \`20260728\`.

## Precision decision

- all precision targets met: \`$ALL_TARGETS\`;
- failing cells: \`$FAILING_COUNT\`;
- next stage: \`$NEXT_STAGE\`;
- Stage-20 execution authorized: \`false\`;
- latency claims authorized: \`false\`.

## Non-mutating controls

- timing re-execution: \`false\`;
- adapter rematerialization: \`false\`;
- analyzer source modification: \`false\`;
- canonical factor: \`membership_density\`;
- raw analyzer factor label authoritative: \`false\`.

## Integrity

- raw analyzer log SHA-256:
  \`$RAW_LOG_SHA\`;
- raw intervals SHA-256:
  \`$RAW_INTERVALS_SHA\`;
- raw report SHA-256:
  \`$RAW_REPORT_SHA\`;
- canonical decision SHA-256:
  \`$DECISION_SHA\`.
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_portfolio_precision_analysis=PASS"
echo "commit=$COMMIT"
echo "canonical_decision_sha256=$DECISION_SHA"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=$ALL_TARGETS"
echo "failing_cell_count=$FAILING_COUNT"
echo "precision_analysis_authorized=true"
echo "precision_analysis_performed=true"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_precision_analysis"

git status --short --branch
git log --oneline --decorate -4
