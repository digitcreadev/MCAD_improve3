#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="13be44a20db08589b8c452ea8299bbfc61adf164"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"
RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$RUNNER"

echo "repository_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Implementation identities ==="

sha256sum "$ANALYZER" "$RUNNER"

echo
echo "=== 3. Analyzer CLI contract ==="

"$PYTHON" "$ANALYZER" --help | sed -n '1,240p'

echo
echo "=== 4. Static grouping and schema audit ==="

"$PYTHON" - "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")
tree = ast.parse(text)

required_tokens = (
    "factor_level",
    "step_index",
    "wall_latency_ms",
    "formal_replication_index",
    "formal_structural_seed",
)

for token in required_tokens:
    count = text.count(token)
    print(f"token_{token}_occurrence_count={count}")

    if count == 0:
        raise SystemExit(
            f"Required analyzer token absent: {token}"
        )

string_sequences: list[tuple[int, list[str]]] = []

for node in ast.walk(tree):
    if not isinstance(node, (ast.List, ast.Tuple)):
        continue

    values: list[str] = []

    for item in node.elts:
        if (
            isinstance(item, ast.Constant)
            and isinstance(item.value, str)
        ):
            values.append(item.value)
        else:
            values = []
            break

    if values:
        string_sequences.append(
            (getattr(node, "lineno", -1), values)
        )

print()
print("candidate_column_sequences:")

for lineno, values in sorted(string_sequences):
    selected = [
        value
        for value in values
        if value in required_tokens
    ]

    if selected:
        print(
            f"line={lineno} "
            f"values={','.join(values)}"
        )

grouping_patterns = (
    r"groupby\s*\(",
    r"factor_level",
    r"step_index",
    r"formal_structural_seed",
    r"bootstrap",
    r"relative_half_width",
)

print()
print("relevant_source_lines:")

for lineno, line in enumerate(
    text.splitlines(),
    start=1,
):
    if any(
        re.search(pattern, line)
        for pattern in grouping_patterns
    ):
        print(f"{lineno}:{line[:240]}")

factor_step_sequence = any(
    "factor_level" in values
    and "step_index" in values
    for _, values in string_sequences
)

cluster_sequence = any(
    "formal_structural_seed" in values
    for _, values in string_sequences
)

print()
print(
    "factor_level_step_index_grouping_detected="
    f"{str(factor_step_sequence).lower()}"
)
print(
    "structural_seed_column_detected="
    f"{str(cluster_sequence).lower()}"
)

print(
    "portfolio_adapter_candidate="
    f"{str(factor_step_sequence and cluster_sequence).lower()}"
)

print(
    "proposed_adapter_rule="
    "preserve_raw_step_index_and_query_digest;"
    "set_analysis_step_index=0_only_in_derived_analysis_csv"
)

print(
    "raw_timing_csv_modification_allowed=false"
)
PY

echo
echo "=== 5. Runner output-schema references ==="

grep -nE \
  'factor_level|step_index|wall_latency_ms|formal_replication_index|formal_structural_seed|formal_order_seed' \
  "$RUNNER" \
  | head -n 180

echo
echo "=== 6. Final state ==="

echo "portfolio_analyzer_compatibility_inspection=PASS"
echo "raw_timing_cluster_cell_count=920"
echo "proposed_precision_cell_count=4"
echo "raw_timing_csv_modification_allowed=false"
echo "derived_analysis_adapter_required=true"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=formalize_portfolio_level_membership_density_timing_preregistration"

git status --short --branch
