#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_BASE_HEAD="729b73b7716a4c32c610241256b7e42dd9ba6bfc"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
OBJECTIVE_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"

EXPECTED_EXECUTOR_SHA="8abbd54bfcaee529693add606ae351228355de2929373d3026a27b023d79e22a"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/fix-sa5-objective-count-bootstrap-${STAMP}"

trap 'echo "[ERROR] SA5 multi-objective bootstrap correction stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Correction preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT" \
  "$PREREG"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$EXECUTOR" |
    awk '{print $1}'
)" = "$EXPECTED_EXECUTOR_SHA"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

grep -F \
  'if objective_ids != {instance.objective_id}:' \
  "$EXECUTOR" >/dev/null

grep -F \
  'def _generate_campaign(' \
  "$OBJECTIVE_TEST" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "correction_preflight_gate=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "canonical_campaign_generated=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Create corrective branch ==="

git switch -c "$BRANCH" "$EXPECTED_BASE_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Patch objective-count bootstrap contract ==="

"$PYTHON" - \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

executor_path = Path(sys.argv[1])
test_path = Path(sys.argv[2])


def replace_once(
    path: Path,
    old: str,
    new: str,
) -> None:
    source = path.read_text(encoding="utf-8")

    count = source.count(old)

    if count != 1:
        raise SystemExit(
            f"Expected exactly one patch anchor in "
            f"{path}; found {count}."
        )

    path.write_text(
        source.replace(old, new, 1),
        encoding="utf-8",
    )


helper_anchor = '''def _build_instance_ckg(
    *,
    instance: DiscoveredInstance,
    runtime_output_dir: Path,
) -> CKGGraph:
'''

helper_source = '''def _expected_bootstrap_objective_ids(
    instance: DiscoveredInstance,
) -> set[str]:
    """
    Resolve the exact objective catalogue expected after bootstrap.

    Historical controlled families remain strictly single-objective.
    The objective-count family carries a factor-specific manifest with
    the complete generated objective set and one selected objective.
    """
    if instance.factor != "objective_count":
        return {instance.objective_id}

    manifest = _read_json(
        instance.manifest_path,
        "objective-count E2.1 instance manifest",
    )

    raw_objective_ids = manifest.get(
        "objective_ids"
    )

    if (
        not isinstance(raw_objective_ids, list)
        or not raw_objective_ids
        or any(
            not isinstance(value, str)
            or not value.strip()
            for value in raw_objective_ids
        )
    ):
        raise E3ExecutionError(
            "Objective-count instance manifest must "
            "contain a non-empty objective_ids list."
        )

    objective_ids = {
        value.strip()
        for value in raw_objective_ids
    }

    if len(objective_ids) != len(
        raw_objective_ids
    ):
        raise E3ExecutionError(
            "Objective-count instance manifest contains "
            "duplicate objective identifiers."
        )

    requested_count = _required_integer(
        manifest,
        "requested_objective_count",
        "objective-count instance manifest",
    )

    realised_count = _required_integer(
        manifest,
        "realised_objective_count",
        "objective-count instance manifest",
    )

    selected_objective_id = (
        _required_non_empty_string(
            manifest,
            "selected_objective_id",
            "objective-count instance manifest",
        )
    )

    manifest_objective_id = (
        _required_non_empty_string(
            manifest,
            "objective_id",
            "objective-count instance manifest",
        )
    )

    if requested_count != instance.factor_level:
        raise E3ExecutionError(
            "Objective-count requested_objective_count "
            "differs from the factor level: "
            f"expected={instance.factor_level}, "
            f"actual={requested_count}."
        )

    if realised_count != instance.factor_level:
        raise E3ExecutionError(
            "Objective-count realised_objective_count "
            "differs from the factor level: "
            f"expected={instance.factor_level}, "
            f"actual={realised_count}."
        )

    if len(objective_ids) != realised_count:
        raise E3ExecutionError(
            "Objective-count objective_ids cardinality "
            "differs from realised_objective_count: "
            f"expected={realised_count}, "
            f"actual={len(objective_ids)}."
        )

    if selected_objective_id != instance.objective_id:
        raise E3ExecutionError(
            "Objective-count selected_objective_id "
            "differs from instances.csv."
        )

    if manifest_objective_id != instance.objective_id:
        raise E3ExecutionError(
            "Objective-count manifest objective_id "
            "differs from instances.csv."
        )

    if instance.objective_id not in objective_ids:
        raise E3ExecutionError(
            "Selected objective is absent from the "
            "objective-count objective catalogue."
        )

    return objective_ids


def _build_instance_ckg(
    *,
    instance: DiscoveredInstance,
    runtime_output_dir: Path,
) -> CKGGraph:
'''

replace_once(
    executor_path,
    helper_anchor,
    helper_source,
)

old_validation = '''    objective_ids = set(ckg.objectives)

    if objective_ids != {instance.objective_id}:
        raise E3ExecutionError(
            "Bootstrapped objective set differs from the "
            f"instance manifest for "
            f"{instance.canonical_instance_id!r}: "
            f"expected={[instance.objective_id]!r}, "
            f"actual={sorted(objective_ids)!r}."
        )
'''

new_validation = '''    objective_ids = set(ckg.objectives)

    expected_objective_ids = (
        _expected_bootstrap_objective_ids(
            instance
        )
    )

    if objective_ids != expected_objective_ids:
        raise E3ExecutionError(
            "Bootstrapped objective set differs from the "
            f"instance manifest for "
            f"{instance.canonical_instance_id!r}: "
            f"expected={sorted(expected_objective_ids)!r}, "
            f"actual={sorted(objective_ids)!r}."
        )
'''

replace_once(
    executor_path,
    old_validation,
    new_validation,
)

test_source = test_path.read_text(
    encoding="utf-8"
)

test_marker = (
    "def test_objective_count_bootstrap_loads_"
    "complete_catalogue("
)

if test_marker in test_source:
    raise SystemExit(
        "Objective-count bootstrap tests already exist."
    )

addition = r'''

def test_objective_count_bootstrap_loads_complete_catalogue(
    tmp_path: Path,
) -> None:
    campaign_dir = (
        tmp_path / "objective_count_bootstrap"
    )

    manifest = _generate_campaign(
        campaign_dir
    )

    instances = executor._discover_all_instances(
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
    )

    assert len(instances) == 1

    instance = instances[0]

    ckg = executor._build_instance_ckg(
        instance=instance,
        runtime_output_dir=(
            tmp_path / "runtime"
        ),
    )

    instance_manifest = _read_json(
        instance.manifest_path
    )

    expected_objective_ids = set(
        instance_manifest["objective_ids"]
    )

    assert len(expected_objective_ids) == 2
    assert set(ckg.objectives) == (
        expected_objective_ids
    )

    assert instance.objective_id == (
        instance_manifest[
            "selected_objective_id"
        ]
    )

    assert instance.objective_id in (
        ckg.objectives
    )

    assert ckg.history == {}
    assert ckg.session_coverage == {}
    assert ckg.session_weighted_coverage == {}
    assert ckg.session_resource_coverage == {}


def test_objective_count_bootstrap_rejects_catalogue_cardinality_mismatch(
    tmp_path: Path,
) -> None:
    campaign_dir = (
        tmp_path / "objective_count_bad_cardinality"
    )

    manifest = _generate_campaign(
        campaign_dir
    )

    instances = executor._discover_all_instances(
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
    )

    instance = instances[0]

    instance_manifest = _read_json(
        instance.manifest_path
    )

    instance_manifest["objective_ids"] = (
        instance_manifest["objective_ids"][:1]
    )

    instance.manifest_path.write_text(
        json.dumps(
            instance_manifest,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )

    with pytest.raises(
        executor.E3ExecutionError,
        match=(
            "objective_ids cardinality differs "
            "from realised_objective_count"
        ),
    ):
        executor._build_instance_ckg(
            instance=instance,
            runtime_output_dir=(
                tmp_path / "runtime_bad_cardinality"
            ),
        )


def test_objective_count_bootstrap_rejects_selected_objective_mismatch(
    tmp_path: Path,
) -> None:
    campaign_dir = (
        tmp_path / "objective_count_bad_selected"
    )

    manifest = _generate_campaign(
        campaign_dir
    )

    instances = executor._discover_all_instances(
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
    )

    instance = instances[0]

    instance_manifest = _read_json(
        instance.manifest_path
    )

    alternate_objective_id = next(
        objective_id
        for objective_id
        in instance_manifest["objective_ids"]
        if objective_id != instance.objective_id
    )

    instance_manifest[
        "selected_objective_id"
    ] = alternate_objective_id

    instance.manifest_path.write_text(
        json.dumps(
            instance_manifest,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )

    with pytest.raises(
        executor.E3ExecutionError,
        match=(
            "selected_objective_id differs "
            "from instances.csv"
        ),
    ):
        executor._build_instance_ckg(
            instance=instance,
            runtime_output_dir=(
                tmp_path / "runtime_bad_selected"
            ),
        )
'''

test_path.write_text(
    test_source.rstrip()
    + "\n"
    + addition.rstrip()
    + "\n",
    encoding="utf-8",
)

print("objective_count_bootstrap_patch=PASS")
print("modified_file_count=2")
PY

echo
echo "=== 4. Compile corrective implementation ==="

"$PYTHON" -m py_compile \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

echo "bootstrap_patch_compile=PASS"

echo
echo "=== 5. Run targeted objective-count compatibility tests ==="

"$PYTHON" -m pytest \
  "$OBJECTIVE_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  -q \
  -p no:cacheprovider

echo "targeted_objective_count_bootstrap_tests=PASS"

echo
echo "=== 6. Run complete sensitivity regression ==="

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

echo "complete_sensitivity_regression=PASS"

echo
echo "=== 7. Explicit runtime-contract smoke ==="

SMOKE_ROOT="/workspaces/sa5_objective_count_bootstrap_contract_smoke_${STAMP}"

rm -rf "$SMOKE_ROOT"

"$PYTHON" - \
  "$SMOKE_ROOT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

import backend.harness.sensitivity_execution.execute_controlled_family as executor
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)

root = Path(sys.argv[1]).resolve()
campaign_dir = root / "campaign"

generate_controlled_family(
    ControlledFamilySpec(
        campaign_id=(
            "sa5_objective_count_bootstrap_contract_smoke"
        ),
        factor="objective_count",
        levels=(1, 2, 5),
        seeds=(101,),
        baseline_constraint_count=2,
        baseline_virtual_node_count=6,
        output_dir=str(campaign_dir),
    )
)

campaign_manifest = json.loads(
    (
        campaign_dir
        / "campaign_manifest.json"
    ).read_text(encoding="utf-8")
)

instances = executor._discover_all_instances(
    campaign_dir=campaign_dir,
    campaign_manifest=campaign_manifest,
)

assert [
    instance.factor_level
    for instance in instances
] == [1, 2, 5]

for instance in instances:
    ckg = executor._build_instance_ckg(
        instance=instance,
        runtime_output_dir=(
            root
            / "runtime"
            / instance.canonical_instance_id
        ),
    )

    instance_manifest = json.loads(
        instance.manifest_path.read_text(
            encoding="utf-8"
        )
    )

    assert len(ckg.objectives) == (
        instance.factor_level
    )

    assert set(ckg.objectives) == set(
        instance_manifest["objective_ids"]
    )

    assert instance.objective_id in (
        ckg.objectives
    )

print("objective_count_bootstrap_contract_smoke=PASS")
print("tested_levels=1,2,5")
print("tested_instance_count=3")
print("selected_objective_present=true")
print("complete_objective_catalogue_loaded=true")
print("workload_execution_performed=false")
print("canonical_campaign_generated=false")
print("scientific_execution_performed=false")
PY

echo
echo "=== 8. Repository scope gate ==="

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

CHANGED_FILES="$(
  git status --short |
    sed -E 's/^.. //'
)"

printf '%s\n' "$CHANGED_FILES" |
  sort \
  > "/workspaces/sa5_bootstrap_changed_files_${STAMP}.txt"

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)" -eq 2

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    grep -Fx "$EXECUTOR" |
    wc -l
)" -eq 1

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    grep -Fx "$OBJECTIVE_TEST" |
    wc -l
)" -eq 1

git diff --check

echo "repository_scope_gate=PASS"
echo "changed_file_count=2"
echo "canonical_campaign_generated=false"
echo "workload_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 9. Stage correction ==="

git add \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

test "$(
  git diff --cached --name-only |
    wc -l
)" -eq 2

git diff --cached --check

echo "correction_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 10. Commit correction ==="

git commit \
  -m "fix(sensitivity): support multi-objective SA5 bootstrap"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 11. Push corrective branch ==="

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 12. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Fix SA5 objective-count multi-objective bootstrap" \
    --body "$(cat <<'EOF'
## SA5 runtime correction

The objective-count generator correctly stores a complete multi-objective
catalogue while selecting one objective for evaluation. The E3 bootstrap
path still enforced the historical single-objective invariant and would
therefore reject every objective-count instance above level 1.

### Correction

For `objective_count` only, E3 now validates:

- the complete `objective_ids` catalogue;
- exact requested and realised objective counts;
- equality with the registered factor level;
- uniqueness and cardinality of objective identifiers;
- exact selected-objective binding;
- presence of the selected objective in the loaded CKG.

Historical factors retain the strict singleton-objective rule.

### Validation

- targeted objective-count compatibility tests;
- complete generator and E3 regression suites;
- test-only bootstrap smoke at levels `1`, `2`, and `5`;
- no workload steps executed.

### Scientific controls

- canonical SA5 campaign generated: `false`;
- canonical Stage-10 bootstrap performed: `false`;
- functional execution performed: `false`;
- timing execution performed: `false`;
- manuscript modified: `false`.

## Next stage

`author_sa5_objective_count_stage10_materializer_and_auditor`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 13. Verify PR scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

EXPECTED_FILES="$(
  printf '%s\n' \
    "$EXECUTOR" \
    "$OBJECTIVE_TEST" |
    sort
)"

ACTUAL_FILES="$(
  jq -r \
    '.files[].path' \
    <<<"$PR_DATA" |
    sort
)"

test "$ACTUAL_FILES" = "$EXPECTED_FILES"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 14. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_multi_objective_bootstrap_fix=PASS"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"
echo "changed_file_count=2"
echo "historical_single_objective_contract_preserved=true"
echo "objective_count_multi_objective_contract_supported=true"
echo "tested_levels=1,2,5"
echo "canonical_campaign_generated=false"
echo "canonical_stage10_bootstrap_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_bootstrap_fix"

git status --short --branch
git log --oneline --decorate -4
