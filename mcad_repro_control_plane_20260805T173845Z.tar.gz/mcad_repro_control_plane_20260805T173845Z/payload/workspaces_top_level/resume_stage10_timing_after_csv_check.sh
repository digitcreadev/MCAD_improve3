#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
BRANCH="paper/execute-virtual-node-count-stage10-timing-20260802T162601Z"
EXPECTED_HEAD="aea4d6f284b2aadcfd470b80fd3a951a0ad46f00"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

OUTPUT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/virtual_node_count_stage10_c4"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution"

REPORT="$AUDIT_ROOT/formal_timing_execution_report.json"
SUMMARY="$AUDIT_ROOT/formal_timing_execution_report.md"
LOG_DIR="$AUDIT_ROOT/logs"

trap 'echo "[ERROR] Recovery stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

CURRENT_BRANCH="$(git branch --show-current)"
CURRENT_HEAD="$(git rev-parse HEAD)"
STAGED_COUNT="$(git diff --cached --name-only | wc -l | tr -d ' ')"
UNSTAGED_COUNT="$(git diff --name-only | wc -l | tr -d ' ')"
UNTRACKED_COUNT="$(
  git ls-files --others --exclude-standard |
    wc -l |
    tr -d ' '
)"

echo "branch=$CURRENT_BRANCH"
echo "head=$CURRENT_HEAD"
echo "staged_file_count=$STAGED_COUNT"
echo "unstaged_file_count=$UNSTAGED_COUNT"
echo "untracked_file_count=$UNTRACKED_COUNT"

test "$CURRENT_BRANCH" = "$BRANCH"
test "$CURRENT_HEAD" = "$EXPECTED_HEAD"
test "$STAGED_COUNT" -eq 52
test "$UNSTAGED_COUNT" -eq 0
test "$UNTRACKED_COUNT" -eq 0
test -x "$PYTHON"
test -f "$REPORT"
test -f "$SUMMARY"

echo "recovery_gate=PASS"
echo "timing_execution_rerun_performed=false"

echo
echo "=== 2. Validate preserved timing evidence ==="

"$PYTHON" - \
  "$ROOT" \
  "$REPORT" \
  "$OUTPUT_ROOT" \
  "$LOG_DIR" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
report_path = root / sys.argv[2]
output_root = root / sys.argv[3]
log_root = root / sys.argv[4]


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SystemExit(f"Missing JSON file: {path}")

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output_tree_digest(directory: Path) -> tuple[str, int]:
    entries: list[str] = []

    for path in sorted(
        item
        for item in directory.rglob("*")
        if item.is_file()
    ):
        relative = path.relative_to(directory).as_posix()
        entries.append(
            f"{relative}\t{sha256_file(path)}"
        )

    payload = "\n".join(entries) + "\n"

    return (
        hashlib.sha256(
            payload.encode("utf-8")
        ).hexdigest(),
        len(entries),
    )


report = load_json(report_path)

expected_report = {
    "status": "pass",
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
}

for key, expected_value in expected_report.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

replications = report.get("replications")

if not isinstance(replications, list):
    raise SystemExit("Missing replication report list.")

if len(replications) != 10:
    raise SystemExit(
        f"Expected 10 replications, got {len(replications)}."
    )

expected_indexes = list(range(10))
observed_indexes = [
    int(item["replication_index"])
    for item in replications
]

if observed_indexes != expected_indexes:
    raise SystemExit(
        f"Invalid replication sequence: {observed_indexes}"
    )

total_rows = 0
total_warmups = 0
total_measurements = 0
crlf_files = 0

for item in replications:
    index = int(item["replication_index"])
    token = f"rep_{index:03d}"

    directory = output_root / token
    csv_path = directory / "timing_observations.csv"
    manifest_path = directory / "timing_manifest.json"
    summary_path = directory / "timing_summary.json"
    references_path = directory / "functional_references.json"
    log_path = log_root / f"{token}.log"

    for path in (
        directory,
        csv_path,
        manifest_path,
        summary_path,
        references_path,
        log_path,
    ):
        if not path.exists():
            raise SystemExit(
                f"Replication {index}: missing {path}"
            )

    if item.get("status") != "pass":
        raise SystemExit(
            f"Replication {index}: status is not pass."
        )

    if item.get("runner_exit_status") != 0:
        raise SystemExit(
            f"Replication {index}: nonzero runner status."
        )

    if item.get("timing_cell_count") != 6:
        raise SystemExit(
            f"Replication {index}: expected 6 cells."
        )

    if item.get("warmup_observation_count") != 60:
        raise SystemExit(
            f"Replication {index}: expected 60 warmups."
        )

    if item.get("measurement_observation_count") != 600:
        raise SystemExit(
            f"Replication {index}: expected 600 measurements."
        )

    if sha256_file(csv_path) != item.get(
        "timing_observations_sha256"
    ):
        raise SystemExit(
            f"Replication {index}: CSV digest mismatch."
        )

    if sha256_file(log_path) != item.get(
        "timing_log_sha256"
    ):
        raise SystemExit(
            f"Replication {index}: log digest mismatch."
        )

    tree_digest, file_count = output_tree_digest(directory)

    if tree_digest != item.get("output_tree_sha256"):
        raise SystemExit(
            f"Replication {index}: output-tree digest mismatch."
        )

    if file_count != item.get("output_file_count"):
        raise SystemExit(
            f"Replication {index}: output-file count mismatch."
        )

    raw = csv_path.read_bytes()

    if b"\r\n" not in raw:
        raise SystemExit(
            f"Replication {index}: expected CRLF CSV."
        )

    if b"\r" in raw.replace(b"\r\n", b""):
        raise SystemExit(
            f"Replication {index}: unexpected lone CR byte."
        )

    crlf_files += 1

    with csv_path.open(
        newline="",
        encoding="utf-8",
    ) as stream:
        rows = list(csv.DictReader(stream))

    phases = Counter(
        str(row.get("phase", "")).lower()
        for row in rows
    )

    if len(rows) != 660:
        raise SystemExit(
            f"Replication {index}: "
            f"expected 660 CSV rows, got {len(rows)}."
        )

    if phases["warmup"] != 60:
        raise SystemExit(
            f"Replication {index}: "
            f"expected 60 warmup rows, "
            f"got {phases['warmup']}."
        )

    if phases["measurement"] != 600:
        raise SystemExit(
            f"Replication {index}: "
            f"expected 600 measurement rows, "
            f"got {phases['measurement']}."
        )

    total_rows += len(rows)
    total_warmups += phases["warmup"]
    total_measurements += phases["measurement"]

if total_rows != 6600:
    raise SystemExit(
        f"Expected 6600 total CSV rows, got {total_rows}."
    )

if total_warmups != 600:
    raise SystemExit(
        f"Expected 600 warmups, got {total_warmups}."
    )

if total_measurements != 6000:
    raise SystemExit(
        f"Expected 6000 measurements, "
        f"got {total_measurements}."
    )

if crlf_files != 10:
    raise SystemExit(
        f"Expected 10 CRLF CSV files, got {crlf_files}."
    )

print("preserved_timing_evidence_validation=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("csv_observation_row_count=6600")
print("warmup_observation_count=600")
print("measurement_observation_count=6000")
print("crlf_csv_file_count=10")
print("all_recorded_hashes_match=true")
print("timing_execution_rerun_performed=false")
PY

echo
echo "=== 3. Classify full whitespace-check findings ==="

CHECK_LOG="$(mktemp)"

set +e
git diff --cached --check >"$CHECK_LOG" 2>&1
FULL_CHECK_STATUS=$?
set -e

echo "full_diff_check_exit_status=$FULL_CHECK_STATUS"

"$PYTHON" - \
  "$CHECK_LOG" \
  "$OUTPUT_ROOT" <<'PY'
from __future__ import annotations

import re
import sys
from pathlib import Path

log_path = Path(sys.argv[1])
expected_root = sys.argv[2].rstrip("/")

text = log_path.read_text(
    encoding="utf-8",
    errors="replace",
)

pattern = re.compile(
    r"^(.*?):(\d+): trailing whitespace\.$",
    re.MULTILINE,
)

matches = pattern.findall(text)

if not matches:
    raise SystemExit(
        "Expected CRLF whitespace findings were not detected."
    )

files = sorted(
    {
        path
        for path, _line in matches
    }
)

expected_files = [
    (
        f"{expected_root}/"
        f"rep_{index:03d}/timing_observations.csv"
    )
    for index in range(10)
]

if files != expected_files:
    unexpected = sorted(
        set(files) - set(expected_files)
    )
    missing = sorted(
        set(expected_files) - set(files)
    )

    raise SystemExit(
        "Whitespace findings are not limited to the "
        "ten generated CSV files.\n"
        f"Unexpected={unexpected}\n"
        f"Missing={missing}"
    )

other_error_lines = [
    line
    for line in text.splitlines()
    if (
        (
            "trailing whitespace." in line
            or "new blank line at EOF." in line
            or "space before tab in indent." in line
        )
        and not re.match(
            r"^.*:\d+: trailing whitespace\.$",
            line,
        )
    )
]

if other_error_lines:
    raise SystemExit(
        f"Unexpected whitespace diagnostics: "
        f"{other_error_lines[:20]}"
    )

print("whitespace_finding_classification=PASS")
print(f"generated_csv_finding_count={len(matches)}")
print("generated_csv_file_count=10")
print("non_csv_whitespace_finding_count=0")
print("csv_bytes_modified=false")
PY

rm -f "$CHECK_LOG"

echo
echo "=== 4. Check all non-CSV staged files ==="

git diff --cached --check -- \
  . \
  ":(exclude,glob)$OUTPUT_ROOT/rep_*/timing_observations.csv"

echo "non_csv_diff_check=PASS"
echo "generated_csv_bytes_preserved=true"
echo "recorded_hashes_preserved=true"

echo
echo "=== 5. Commit preserved timing evidence ==="

git diff --cached --stat

git commit \
  -m "evidence(experiments): execute virtual-node-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 6. Push execution branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

EXISTING_PR="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state open \
    --json url \
    --jq '.[0].url // ""'
)"

if [ -n "$EXISTING_PR" ]; then
  PR_URL="$EXISTING_PR"
  echo "pull_request_creation=ALREADY_EXISTS"
else
  PR_URL="$(
    gh pr create \
      --repo "$REPO" \
      --head "$BRANCH" \
      --base "$BASE" \
      --title "Execute virtual-node-count Stage-10 formal timing" \
      --body "$(cat <<'EOF'
## Scope

- preserves and commits the completed formal Stage-10 timing execution;
- validates all ten replication outputs against the formal report;
- validates all recorded CSV, log and output-tree SHA-256 values;
- records 60 timing cells;
- records 600 warmup observations;
- records 6000 measurement observations;
- performs no functional rerun and no timing rerun.

## CSV line-ending policy

`timing_observations.csv` is emitted by Python's CSV writer with
RFC-style CRLF record separators. These bytes are preserved because their
SHA-256 values are part of the timing evidence. The whitespace check was
therefore applied to every staged file except the ten generated timing CSV
files.

## Result

- replications: 10/10 PASS;
- timing cells: 60;
- warmups: 600;
- measurements: 6000;
- recorded hashes: all matched;
- timing rerun performed: false;
- precision analysis performed: false;
- latency claims: unauthorized;
- Stage-20: unauthorized.

## Next stage

Merge the timing evidence, then run the preregistered clustered precision
analyzer v2.
EOF
)"
  )"
fi

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

echo "virtual_node_count_stage10_timing_execution=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "warmup_observation_count=600"
echo "measurement_observation_count=6000"
echo "generated_csv_bytes_modified=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "timing_execution_performed=true"
echo "precision_analysis_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_execution_evidence"

git status --short --branch
git log --oneline --decorate -4
