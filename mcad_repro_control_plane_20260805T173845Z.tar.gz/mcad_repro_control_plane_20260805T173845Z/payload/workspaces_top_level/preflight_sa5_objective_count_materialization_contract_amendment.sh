#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="1685ee83afe14236f92e8ebbed09867fefee9d20"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"
DESIGN_DOC="backend/harness/sensitivity_design/SENSITIVITY_GENERATOR_DESIGN.md"

OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"

WORKLOAD_VALIDATOR="backend/harness/sensitivity_execution/validate_workload_spec.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

E22_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e2_2_controlled_families/campaigns/objective_count_stage10_c8_nv32"
E3_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_materialization_amendment_preflight_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_materialization_amendment_preflight.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_materialization_amendment_surface.txt"

trap 'echo "[ERROR] SA5 materialization-amendment preflight stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Exact read-only repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$PREREG" \
  "$DESIGN_MATRIX" \
  "$DESIGN_DOC" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$WORKLOAD_VALIDATOR" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

PREREG_SHA="$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)"

test "$PREREG_SHA" = "$EXPECTED_PREREG_SHA"

test ! -e "$E22_CAMPAIGN_ROOT"
test ! -e "$E3_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

"$PYTHON" -c 'import yaml'

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "preregistration_sha256=$PREREG_SHA"
echo "canonical_campaign_generated=false"
echo "repository_modified=false"

echo
echo "=== 2. Build detached scientific-contract preflight ==="

mkdir -p "$OUTPUT_ROOT"

"$PYTHON" - \
  "$ROOT" \
  "$OUTPUT_ROOT" \
  "$EXPECTED_HEAD" \
  "$PREREG" \
  "$DESIGN_MATRIX" \
  "$DESIGN_DOC" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import re
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterator

import yaml


root = Path(sys.argv[1]).resolve()
output_root = Path(sys.argv[2]).resolve()
expected_head = sys.argv[3]

prereg_path = root / sys.argv[4]
design_matrix_path = root / sys.argv[5]
design_doc_path = root / sys.argv[6]
generator_path = root / sys.argv[7]
family_path = root / sys.argv[8]

report_path = (
    output_root
    / "sa5_objective_count_materialization_amendment_preflight.json"
)

surface_path = (
    output_root
    / "sa5_objective_count_materialization_amendment_surface.txt"
)

expected_levels = [1, 2, 5, 10, 20, 50]

expected_noise_classes = [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

required_sa5_fields = [
    "objective_count",
    "selected_objective_id",
    "selected_objective_constraint_count",
    "total_constraint_count",
    "useful_virtual_node_count",
    "irrelevant_virtual_node_count",
    "total_virtual_node_count",
    "requirement_set_count",
    "requirement_membership_link_count",
    "realised_density",
    "workload_length",
    "non_contributive_query_count",
    "realised_noise_ratio",
    "realised_noise_class_counts",
    "graph_node_count",
    "graph_edge_count",
    "generator_version",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def walk(
    value: Any,
    path: str = "$",
) -> Iterator[tuple[str, Any]]:
    yield path, value

    if isinstance(value, dict):
        for key, child in value.items():
            yield from walk(
                child,
                f"{path}.{key}",
            )

    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from walk(
                child,
                f"{path}[{index}]",
            )


def key_entries(
    value: Any,
) -> list[tuple[str, str, Any]]:
    result: list[tuple[str, str, Any]] = []

    def visit(
        current: Any,
        path: str,
    ) -> None:
        if isinstance(current, dict):
            for key, child in current.items():
                child_path = f"{path}.{key}"
                result.append(
                    (
                        child_path,
                        str(key),
                        child,
                    )
                )
                visit(child, child_path)

        elif isinstance(current, list):
            for index, child in enumerate(current):
                visit(
                    child,
                    f"{path}[{index}]",
                )

    visit(value, "$")
    return result


def numeric_equal(
    value: Any,
    expected: float | int,
) -> bool:
    if isinstance(value, bool):
        return False

    try:
        return Fraction(str(value)) == Fraction(
            str(expected)
        )
    except Exception:
        return False


def exact_list_equal(
    value: Any,
    expected: list[int],
) -> bool:
    if not isinstance(value, list):
        return False

    try:
        return [int(item) for item in value] == expected
    except Exception:
        return False


def markdown_section(
    text: str,
    heading_prefix: str,
) -> str:
    lines = text.splitlines()

    start: int | None = None

    for index, line in enumerate(lines):
        if line.startswith(heading_prefix):
            start = index
            break

    if start is None:
        raise AssertionError(
            f"Missing Markdown section: {heading_prefix}"
        )

    end = len(lines)

    for index in range(start + 1, len(lines)):
        if lines[index].startswith("### "):
            end = index
            break

    return "\n".join(lines[start:end]).strip()


def class_fields(
    source_path: Path,
) -> dict[str, list[str]]:
    tree = ast.parse(
        source_path.read_text(encoding="utf-8"),
        filename=str(source_path),
    )

    result: dict[str, list[str]] = {}

    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue

        fields: list[str] = []

        for child in node.body:
            if (
                isinstance(child, ast.AnnAssign)
                and isinstance(child.target, ast.Name)
            ):
                fields.append(child.target.id)

        if fields:
            result[node.name] = fields

    return result


def relevant_strings(
    value: Any,
    terms: tuple[str, ...],
) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []

    for path, item in walk(value):
        if not isinstance(item, str):
            continue

        lowered = item.lower()

        if any(term in lowered for term in terms):
            result.append(
                {
                    "path": path,
                    "text": item,
                }
            )

    return result


prereg = json.loads(
    prereg_path.read_text(encoding="utf-8")
)

if not isinstance(prereg, dict):
    raise AssertionError(
        "SA5 preregistration must be a JSON object."
    )

design = yaml.safe_load(
    design_matrix_path.read_text(encoding="utf-8")
)

if not isinstance(design, dict):
    raise AssertionError(
        "Sensitivity design matrix must be a mapping."
    )

baseline = design.get("baseline")
axes = design.get("axes")

if not isinstance(baseline, dict):
    raise AssertionError(
        "Missing design baseline."
    )

if not isinstance(axes, dict):
    raise AssertionError(
        "Missing design axes."
    )

objective_axis = axes.get("objective_count")

if not isinstance(objective_axis, dict):
    raise AssertionError(
        "Missing objective_count design axis."
    )

objective_fixed = objective_axis.get("fixed")

if not isinstance(objective_fixed, dict):
    raise AssertionError(
        "Missing objective_count fixed controls."
    )

assert objective_axis.get("primary_factor") == (
    "objective_count"
)

assert objective_axis.get("levels") == expected_levels

assert int(
    objective_fixed.get(
        "constraints_per_objective"
    )
) == 8

assert int(
    objective_fixed.get(
        "virtual_nodes_per_objective"
    )
) == 32

assert numeric_equal(
    objective_fixed.get("contribution_density"),
    0.50,
)

assert int(
    objective_fixed.get("workload_length")
) == 40

assert numeric_equal(
    objective_fixed.get("noise_ratio"),
    0.25,
)

assert numeric_equal(
    baseline.get("useful_virtual_node_ratio"),
    0.75,
)

baseline_noise_distribution = baseline.get(
    "noise_distribution"
)

if not isinstance(
    baseline_noise_distribution,
    dict,
):
    raise AssertionError(
        "Missing baseline noise distribution."
    )

assert set(
    baseline_noise_distribution
) == set(expected_noise_classes)

for noise_class in expected_noise_classes:
    assert numeric_equal(
        baseline_noise_distribution[
            noise_class
        ],
        0.125,
    )

design_required_fields = design.get(
    "required_manifest_fields"
)

if not isinstance(
    design_required_fields,
    list,
):
    raise AssertionError(
        "Missing required_manifest_fields."
    )

missing_design_fields = sorted(
    set(required_sa5_fields)
    - {
        str(item)
        for item in design_required_fields
    }
)

if missing_design_fields:
    raise AssertionError(
        "Design matrix lacks required SA5 fields: "
        f"{missing_design_fields}"
    )

design_doc_text = design_doc_path.read_text(
    encoding="utf-8"
)

f4_section = markdown_section(
    design_doc_text,
    "### F4",
)

f5_section = markdown_section(
    design_doc_text,
    "### F5",
)

entries = key_entries(prereg)

factor_level_evidence = [
    {
        "path": path,
        "key": key,
        "value": value,
    }
    for path, key, value in entries
    if exact_list_equal(
        value,
        expected_levels,
    )
]

if not factor_level_evidence:
    raise AssertionError(
        "Preregistration does not freeze the exact "
        "SA5 factor levels."
    )

def numeric_evidence(
    key_fragments: tuple[str, ...],
    expected: float | int,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []

    for path, key, value in entries:
        lowered = key.lower()

        if not all(
            fragment in lowered
            for fragment in key_fragments
        ):
            continue

        if numeric_equal(value, expected):
            result.append(
                {
                    "path": path,
                    "key": key,
                    "value": value,
                }
            )

    return result


replication_evidence = numeric_evidence(
    ("replication", "count"),
    10,
)

expected_instance_evidence = numeric_evidence(
    ("expected", "instance", "count"),
    60,
)

workload_length_evidence = numeric_evidence(
    ("workload", "length"),
    40,
)

noise_ratio_evidence = numeric_evidence(
    ("noise", "ratio"),
    0.25,
)

contribution_density_evidence = (
    numeric_evidence(
        ("contribution", "density"),
        0.50,
    )
)

selected_objective_index_evidence = (
    numeric_evidence(
        ("selected", "objective", "index"),
        0,
    )
)

for label, evidence in (
    (
        "replication_count=10",
        replication_evidence,
    ),
    (
        "expected_instance_count=60",
        expected_instance_evidence,
    ),
    (
        "workload_length=40",
        workload_length_evidence,
    ),
    (
        "noise_ratio=0.25",
        noise_ratio_evidence,
    ),
    (
        "contribution_density=0.50",
        contribution_density_evidence,
    ),
    (
        "selected_objective_index=0",
        selected_objective_index_evidence,
    ),
):
    if not evidence:
        raise AssertionError(
            "Missing preregistration evidence: "
            f"{label}"
        )


noise_weight_candidates: list[
    dict[str, Any]
] = []

for path, value in walk(prereg):
    if not isinstance(value, dict):
        continue

    if not set(expected_noise_classes).issubset(
        value
    ):
        continue

    if all(
        numeric_equal(
            value[noise_class],
            0.125,
        )
        for noise_class
        in expected_noise_classes
    ):
        noise_weight_candidates.append(
            {
                "path": path,
                "weights": {
                    noise_class: value[
                        noise_class
                    ]
                    for noise_class
                    in expected_noise_classes
                },
            }
        )

if not noise_weight_candidates:
    raise AssertionError(
        "Preregistration does not expose the exact "
        "eight-class 0.125 noise weights."
    )


workload_length = Fraction(40, 1)
noise_ratio = Fraction(1, 4)
replication_count = 10
class_weight = Fraction(1, 8)

noise_queries_per_replication = (
    workload_length * noise_ratio
)

noise_queries_stage10 = (
    noise_queries_per_replication
    * replication_count
)

class_quota_per_replication = (
    noise_queries_per_replication
    * class_weight
)

class_quota_stage10 = (
    noise_queries_stage10
    * class_weight
)

noise_count_is_integer = (
    noise_queries_per_replication.denominator
    == 1
)

class_quota_per_replication_is_integer = (
    class_quota_per_replication.denominator
    == 1
)

class_quota_stage10_is_integer = (
    class_quota_stage10.denominator
    == 1
)

if not noise_count_is_integer:
    raise AssertionError(
        "The overall noise-query count is not integral."
    )


prereg_text = canonical(prereg).lower()

noise_algorithm_patterns = {
    "largest_remainder": (
        r"largest[-_ ]remainder"
    ),
    "hamilton_method": (
        r"hamilton[-_ ]method"
    ),
    "round_robin": (
        r"round[-_ ]robin"
    ),
    "cyclic_rotation": (
        r"cyclic[-_ ]rotation"
    ),
    "rotating_allocation": (
        r"rotat\w*[-_ ]allocat"
    ),
    "deterministic_allocation": (
        r"deterministic[-_ ]allocat"
    ),
    "integer_quota": (
        r"integer[-_ ]quota"
    ),
    "categorical_sampling": (
        r"categorical[-_ ]sampl"
    ),
    "weighted_sampling": (
        r"weighted[-_ ]sampl"
    ),
    "multinomial_sampling": (
        r"multinomial"
    ),
}

noise_algorithm_evidence = {
    name: bool(
        re.search(pattern, prereg_text)
    )
    for name, pattern
    in noise_algorithm_patterns.items()
}

noise_allocation_algorithm_found = any(
    noise_algorithm_evidence.values()
)

noise_policy_strings = relevant_strings(
    prereg,
    (
        "noise",
        "class",
        "allocation",
        "sampling",
        "round",
        "quota",
        "rotation",
    ),
)


contribution_terms = (
    "useful_virtual_node_count",
    "irrelevant_virtual_node_count",
    "useful_virtual_node_ratio",
    "contribution_support",
    "support_density",
    "realised_density",
)

contribution_policy_strings = (
    relevant_strings(
        prereg,
        contribution_terms,
    )
)

prereg_key_names = {
    key.lower()
    for _, key, _ in entries
}

useful_ratio_key_evidence = [
    {
        "path": path,
        "key": key,
        "value": value,
    }
    for path, key, value in entries
    if (
        "useful" in key.lower()
        and "ratio" in key.lower()
        and numeric_equal(value, 0.75)
    )
]

useful_count_key_evidence = [
    {
        "path": path,
        "key": key,
        "value": value,
    }
    for path, key, value in entries
    if "useful_virtual_node_count"
    in key.lower()
]

irrelevant_count_key_evidence = [
    {
        "path": path,
        "key": key,
        "value": value,
    }
    for path, key, value in entries
    if "irrelevant_virtual_node_count"
    in key.lower()
]

realised_density_key_evidence = [
    {
        "path": path,
        "key": key,
        "value": value,
    }
    for path, key, value in entries
    if "realised_density" in key.lower()
]

design_doc_reference_found = (
    design_doc_path.name.lower()
    in prereg_text
    or str(
        design_doc_path.relative_to(root)
    ).lower()
    in prereg_text
)

design_matrix_reference_found = (
    design_matrix_path.name.lower()
    in prereg_text
    or str(
        design_matrix_path.relative_to(root)
    ).lower()
    in prereg_text
)


source_paths = [
    generator_path,
    family_path,
]

source_texts = {
    str(path.relative_to(root)): (
        path.read_text(encoding="utf-8")
    )
    for path in source_paths
}

source_hashes = {
    relative_path: hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()
    for relative_path, text
    in source_texts.items()
}

source_class_fields = {
    str(path.relative_to(root)): (
        class_fields(path)
    )
    for path in source_paths
}

implementation_token_presence: dict[
    str,
    dict[str, int],
] = {}

for relative_path, text in source_texts.items():
    implementation_token_presence[
        relative_path
    ] = {
        field: text.count(field)
        for field in required_sa5_fields
    }

combined_source = "\n".join(
    source_texts.values()
)

materializer_required_fields_missing_from_current_generator = [
    field
    for field in (
        "useful_virtual_node_count",
        "irrelevant_virtual_node_count",
        "realised_density",
        "workload_length",
        "non_contributive_query_count",
        "realised_noise_ratio",
        "realised_noise_class_counts",
    )
    if field not in combined_source
]

objective_axis_has_explicit_useful_ratio = (
    "useful_virtual_node_ratio"
    in objective_fixed
)

prereg_has_explicit_useful_ratio = bool(
    useful_ratio_key_evidence
)

prereg_has_explicit_useful_irrelevant_counts = bool(
    useful_count_key_evidence
    and irrelevant_count_key_evidence
)

prereg_has_realised_density_contract = bool(
    realised_density_key_evidence
    or contribution_policy_strings
)


blockers: list[str] = []

if (
    not class_quota_per_replication_is_integer
    and not noise_allocation_algorithm_found
):
    blockers.append(
        "noise_class_integer_allocation_rule_missing"
    )

if (
    not objective_axis_has_explicit_useful_ratio
    and not prereg_has_explicit_useful_ratio
    and not prereg_has_explicit_useful_irrelevant_counts
):
    blockers.append(
        "useful_virtual_node_ratio_scope_unresolved_for_sa5"
    )

if (
    not prereg_has_realised_density_contract
    and not design_doc_reference_found
    and not design_matrix_reference_found
):
    blockers.append(
        "contribution_support_density_binding_unresolved"
    )


amendment_required = bool(blockers)

if amendment_required:
    status = (
        "sa5_objective_count_materialization_"
        "contract_amendment_required"
    )
    classification = (
        "preregistration_amendment_required_"
        "before_materialization"
    )
    next_stage = (
        "preregister_sa5_objective_count_"
        "materialization_contract_amendment"
    )
else:
    status = (
        "sa5_objective_count_materialization_"
        "contract_resolved"
    )
    classification = (
        "materializer_authoring_may_proceed"
    )
    next_stage = (
        "author_sa5_objective_count_stage10_"
        "materializer_and_auditor"
    )


report = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "materialization-amendment-preflight-v1"
    ),
    "status": status,
    "classification": classification,
    "source_commit": expected_head,
    "read_only": True,
    "source_artifacts": {
        "preregistration": {
            "path": str(
                prereg_path.relative_to(root)
            ),
            "sha256": sha256(prereg_path),
        },
        "design_matrix": {
            "path": str(
                design_matrix_path.relative_to(root)
            ),
            "sha256": sha256(
                design_matrix_path
            ),
        },
        "design_document": {
            "path": str(
                design_doc_path.relative_to(root)
            ),
            "sha256": sha256(
                design_doc_path
            ),
        },
        "implementation_hashes": (
            source_hashes
        ),
    },
    "resolved_controls": {
        "factor_levels": expected_levels,
        "replication_count": 10,
        "expected_instance_count": 60,
        "constraints_per_objective": 8,
        "virtual_nodes_per_objective": 32,
        "baseline_useful_virtual_node_ratio": 0.75,
        "requested_contribution_density": 0.50,
        "workload_length": 40,
        "noise_ratio": 0.25,
        "noise_class_count": len(
            expected_noise_classes
        ),
        "noise_classes": expected_noise_classes,
        "requested_noise_class_weight": 0.125,
    },
    "preregistration_evidence": {
        "factor_levels": factor_level_evidence,
        "replication_count": replication_evidence,
        "expected_instance_count": (
            expected_instance_evidence
        ),
        "workload_length": (
            workload_length_evidence
        ),
        "noise_ratio": noise_ratio_evidence,
        "contribution_density": (
            contribution_density_evidence
        ),
        "selected_objective_index": (
            selected_objective_index_evidence
        ),
        "noise_weight_candidates": (
            noise_weight_candidates
        ),
        "design_document_reference_found": (
            design_doc_reference_found
        ),
        "design_matrix_reference_found": (
            design_matrix_reference_found
        ),
        "useful_ratio_key_evidence": (
            useful_ratio_key_evidence
        ),
        "useful_count_key_evidence": (
            useful_count_key_evidence
        ),
        "irrelevant_count_key_evidence": (
            irrelevant_count_key_evidence
        ),
        "realised_density_key_evidence": (
            realised_density_key_evidence
        ),
    },
    "noise_arithmetic": {
        "noise_queries_per_replication": {
            "fraction": str(
                noise_queries_per_replication
            ),
            "decimal": float(
                noise_queries_per_replication
            ),
            "is_integer": (
                noise_count_is_integer
            ),
        },
        "noise_queries_stage10": {
            "fraction": str(
                noise_queries_stage10
            ),
            "decimal": float(
                noise_queries_stage10
            ),
            "is_integer": (
                noise_queries_stage10.denominator
                == 1
            ),
        },
        "per_class_quota_per_replication": {
            "fraction": str(
                class_quota_per_replication
            ),
            "decimal": float(
                class_quota_per_replication
            ),
            "is_integer": (
                class_quota_per_replication_is_integer
            ),
        },
        "per_class_quota_stage10": {
            "fraction": str(
                class_quota_stage10
            ),
            "decimal": float(
                class_quota_stage10
            ),
            "is_integer": (
                class_quota_stage10_is_integer
            ),
        },
        "exact_uniform_integer_allocation_"
        "possible_per_replication": (
            class_quota_per_replication_is_integer
        ),
        "exact_uniform_integer_allocation_"
        "possible_stage10": (
            class_quota_stage10_is_integer
        ),
    },
    "noise_allocation_policy": {
        "algorithm_evidence": (
            noise_algorithm_evidence
        ),
        "algorithm_found": (
            noise_allocation_algorithm_found
        ),
        "candidate_strings": (
            noise_policy_strings[:100]
        ),
    },
    "contribution_support_contract": {
        "objective_axis_has_explicit_"
        "useful_virtual_node_ratio": (
            objective_axis_has_explicit_useful_ratio
        ),
        "preregistration_has_explicit_"
        "useful_virtual_node_ratio": (
            prereg_has_explicit_useful_ratio
        ),
        "preregistration_has_explicit_"
        "useful_irrelevant_counts": (
            prereg_has_explicit_useful_irrelevant_counts
        ),
        "preregistration_has_realised_"
        "density_contract": (
            prereg_has_realised_density_contract
        ),
        "candidate_strings": (
            contribution_policy_strings[:100]
        ),
    },
    "implementation_surface": {
        "class_fields": source_class_fields,
        "required_field_token_presence": (
            implementation_token_presence
        ),
        "materializer_required_fields_"
        "missing_from_current_generator": (
            materializer_required_fields_missing_from_current_generator
        ),
    },
    "design_sections": {
        "f4_heading": (
            f4_section.splitlines()[0]
        ),
        "f5_heading": (
            f5_section.splitlines()[0]
        ),
    },
    "blockers": blockers,
    "amendment_required": amendment_required,
    "canonical_campaign_generated": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT MATERIALIZATION CONTRACT PREFLIGHT",
    "=" * 78,
    "",
    f"source_commit={expected_head}",
    f"status={status}",
    f"classification={classification}",
    "",
    "=== EXACT DESIGN SECTION F4 ===",
    "",
    f4_section,
    "",
    "=== EXACT DESIGN SECTION F5 ===",
    "",
    f5_section,
    "",
    "=== NOISE ARITHMETIC ===",
    "",
    (
        "noise_queries_per_replication="
        f"{noise_queries_per_replication}"
    ),
    (
        "per_class_quota_per_replication="
        f"{class_quota_per_replication}"
    ),
    (
        "noise_queries_stage10="
        f"{noise_queries_stage10}"
    ),
    (
        "per_class_quota_stage10="
        f"{class_quota_stage10}"
    ),
    (
        "exact_uniform_integer_allocation_"
        "possible_per_replication="
        f"{str(class_quota_per_replication_is_integer).lower()}"
    ),
    (
        "exact_uniform_integer_allocation_"
        "possible_stage10="
        f"{str(class_quota_stage10_is_integer).lower()}"
    ),
    (
        "noise_allocation_algorithm_found="
        f"{str(noise_allocation_algorithm_found).lower()}"
    ),
    "",
    "=== CONTRIBUTION-SUPPORT CONTRACT ===",
    "",
    (
        "objective_axis_has_explicit_"
        "useful_virtual_node_ratio="
        f"{str(objective_axis_has_explicit_useful_ratio).lower()}"
    ),
    (
        "preregistration_has_explicit_"
        "useful_virtual_node_ratio="
        f"{str(prereg_has_explicit_useful_ratio).lower()}"
    ),
    (
        "preregistration_has_explicit_"
        "useful_irrelevant_counts="
        f"{str(prereg_has_explicit_useful_irrelevant_counts).lower()}"
    ),
    (
        "preregistration_has_realised_"
        "density_contract="
        f"{str(prereg_has_realised_density_contract).lower()}"
    ),
    "",
    "=== IMPLEMENTATION FIELD GAP ===",
    "",
]

surface_lines.extend(
    (
        "missing_current_generator_field="
        f"{field}"
    )
    for field
    in materializer_required_fields_missing_from_current_generator
)

surface_lines.extend(
    [
        "",
        "=== BLOCKERS ===",
        "",
    ]
)

if blockers:
    surface_lines.extend(
        f"blocker={blocker}"
        for blocker in blockers
    )
else:
    surface_lines.append("blocker_count=0")

surface_lines.extend(
    [
        "",
        f"amendment_required={str(amendment_required).lower()}",
        "canonical_campaign_generated=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)
PY

test -s "$REPORT"
test -s "$SURFACE"

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "detached_preflight_generation=PASS"
echo "output_root=$OUTPUT_ROOT"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo
echo "=== 3. Show compact decision report ==="

jq '{
  status,
  classification,
  resolved_controls,
  noise_arithmetic,
  noise_allocation_policy: {
    algorithm_evidence:
      .noise_allocation_policy.algorithm_evidence,
    algorithm_found:
      .noise_allocation_policy.algorithm_found
  },
  contribution_support_contract,
  implementation_surface: {
    materializer_required_fields_missing_from_current_generator:
      .implementation_surface.materializer_required_fields_missing_from_current_generator
  },
  blockers,
  amendment_required,
  next_stage
}' "$REPORT"

echo
echo "=== 4. Show exact F4/F5 and blocker surface ==="

cat "$SURFACE"

echo
echo "=== 5. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$E22_CAMPAIGN_ROOT"
test ! -e "$E3_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "preregistration_modified=false"
echo "canonical_campaign_generated=false"
echo "canonical_stage10_bootstrap_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 6. Final state ==="

CLASSIFICATION="$(
  jq -r '.classification' "$REPORT"
)"

AMENDMENT_REQUIRED="$(
  jq -r '.amendment_required' "$REPORT"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$REPORT"
)"

BLOCKER_COUNT="$(
  jq '.blockers | length' "$REPORT"
)"

echo "sa5_objective_count_materialization_amendment_preflight=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "classification=$CLASSIFICATION"
echo "blocker_count=$BLOCKER_COUNT"
echo "amendment_required=$AMENDMENT_REQUIRED"
echo "campaign_materialization_performed=false"
echo "canonical_campaign_generated=false"
echo "functional_execution_authorized=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=$NEXT_STAGE"

git status --short --branch
