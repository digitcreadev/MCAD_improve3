#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=36

BASE="paper/phase3-controlled-execution"
FEATURE_BRANCH="paper/materialize-sa5-objective-count-stage10-functional-evidence-20260805T140248Z"

EXPECTED_PREVIOUS_HEAD="809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
EXPECTED_FEATURE_HEAD="539c928a118ffcf45bfedc7a98a5cac9aee5e1de"
EXPECTED_MERGE_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

RUN_ROOT="$E3/runs"
EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/functional_execution"
CANONICAL_RUN_MANIFEST="$EVIDENCE_ROOT/source_post_execution/canonical_functional_run_file_manifest.sha256"

EVIDENCE_MANIFEST="$EVIDENCE_ROOT/functional_execution_evidence_manifest.json"
EXPECTED_EVIDENCE_MANIFEST_SHA="d2b66ccf52bde34aee15596a898ddf7fa95cb51aad6ce6bd4b0fa14f59e37dbc"

MATERIALIZATION_REPORT="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="69fd9c4d291adefefef50fb595c779b222cfc1e4299796f9e9fa525a1c150e07"

MATERIALIZATION_SUMMARY="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="24faa78e4e2a2f01efd8842fa2ece035c4f04d4038af73c67f8aaccbe93b4869"

EXPECTED_CANONICAL_RUN_MANIFEST_SHA="10f2795a20c27c7ba2222636eee8d0800709e12f3fe290138bf4e31c29db6bf1"

SPEC_MANIFEST="$E3/execution_specs/objective_count_stage10_execution_spec_manifest.json"
EXPECTED_SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

CAMPAIGN_HASHES="$E3/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_HASHES_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

AUTH_REPORT="$EVIDENCE_ROOT/source_authorization/sa5_objective_count_stage10_functional_execution_authorization.json"
EXPECTED_AUTH_REPORT_SHA="e21998b445f199253894aa40dbfeb4508c1cd6e64b7002ce1c438bbe05e7cb04"

AUTH_SURFACE="$EVIDENCE_ROOT/source_authorization/sa5_objective_count_stage10_functional_execution_authorization.txt"
EXPECTED_AUTH_SURFACE_SHA="5defd8ff1c5107d6b257343f8e05336644cfb58f943190d85eff34bcc78ea0a7"

EXEC_LEDGER="$EVIDENCE_ROOT/source_execution/sa5_objective_count_stage10_functional_execution_ledger.json"
EXPECTED_EXEC_LEDGER_SHA="6432e399be10798362a27d00ca55208909c85d9a538de0c53c89b8f7c90d85e0"

EXEC_SURFACE="$EVIDENCE_ROOT/source_execution/sa5_objective_count_stage10_functional_execution_ledger.txt"
EXPECTED_EXEC_SURFACE_SHA="3db78e3df9c4bff3c33e88a9845d1ae7c4e2a4d08b243a7bf37c2d1a8739199b"

POST_REPORT="$EVIDENCE_ROOT/source_post_execution/sa5_objective_count_stage10_post_functional_execution_audit.json"
EXPECTED_POST_REPORT_SHA="f53ed50765ed41fc253de969a7a5f8858b6627bab774bd3add013d5177872647"

POST_SURFACE="$EVIDENCE_ROOT/source_post_execution/sa5_objective_count_stage10_post_functional_execution_audit.txt"
EXPECTED_POST_SURFACE_SHA="5c4e2493d673efadc523552976a887cf55864b0d807fad8ad1b499e5904606cb"

CI_AUDIT_ROOT="/workspaces/sa5_objective_count_pr36_ci_eligibility_audit_20260805T141114Z"
CI_AUDIT_REPORT="$CI_AUDIT_ROOT/sa5_objective_count_pr36_ci_eligibility_audit.json"
EXPECTED_CI_AUDIT_REPORT_SHA="b1ec1438bb0c31943dea0ff3300d07970a6088c6ecb7dfe1ee882fcbf5b20964"

CI_AUDIT_SURFACE="$CI_AUDIT_ROOT/sa5_objective_count_pr36_ci_eligibility_audit.txt"
EXPECTED_CI_AUDIT_SURFACE_SHA="475c13993dd2f89fdbb3c4d06bbb62eb9340866b5606538cc1cbf2a0a3819a5d"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_pr36_postmerge_resume_audit_${STAMP}"
AUDIT_REPORT="$AUDIT_ROOT/sa5_objective_count_pr36_postmerge_resume_audit.json"
AUDIT_SURFACE="$AUDIT_ROOT/sa5_objective_count_pr36_postmerge_resume_audit.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_pr36_postmerge_resume.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #36 post-merge resume stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Resume gate: merge already completed ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_MERGE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_MERGE_HEAD"
test -z "$(git ls-remote --heads origin "$FEATURE_BRANCH")"

read -r MERGE_COMMIT FIRST_PARENT SECOND_PARENT EXTRA_PARENT \
  <<<"$(git rev-list --parents -n 1 "$EXPECTED_MERGE_HEAD")"

test "$MERGE_COMMIT" = "$EXPECTED_MERGE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_PREVIOUS_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit,headRefOid,baseRefName,title
)"

jq -e \
  --arg merge "$EXPECTED_MERGE_HEAD" \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg base "$BASE" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge
    and .headRefOid == $feature
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 functional evidence"
  ' <<<"$FINAL_PR" >/dev/null

echo "resume_gate=PASS"
echo "merge_already_completed=true"
echo "merge_commit=$EXPECTED_MERGE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"
echo "remote_feature_branch_deleted=true"
echo "merge_reexecution_required=false"

echo
echo "=== 2. Diagnose the prior line-818 failure ==="

ALL_RUN_ROOT_FILE_COUNT="$(find "$RUN_ROOT" -type f | wc -l)"

test "$ALL_RUN_ROOT_FILE_COUNT" -ne 280

echo "prior_failure_diagnosis=PASS"
echo "prior_failed_assertion=line_818_all_run_root_file_count_equals_280"
echo "all_run_root_file_count=$ALL_RUN_ROOT_FILE_COUNT"
echo "expected_canonical_stage10_run_file_count=280"
echo "cause=overbroad_run_root_scope"
echo "merge_state_affected=false"

echo
echo "=== 3. Reconstruct the exact canonical 300-file scope ==="

verify_sha "$EVIDENCE_MANIFEST" "$EXPECTED_EVIDENCE_MANIFEST_SHA"
verify_sha "$MATERIALIZATION_REPORT" "$EXPECTED_MATERIALIZATION_REPORT_SHA"
verify_sha "$MATERIALIZATION_SUMMARY" "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
verify_sha "$CANONICAL_RUN_MANIFEST" "$EXPECTED_CANONICAL_RUN_MANIFEST_SHA"
verify_sha "$SPEC_MANIFEST" "$EXPECTED_SPEC_MANIFEST_SHA"
verify_sha "$CAMPAIGN_HASHES" "$EXPECTED_CAMPAIGN_HASHES_SHA"
verify_sha "$AUTH_REPORT" "$EXPECTED_AUTH_REPORT_SHA"
verify_sha "$AUTH_SURFACE" "$EXPECTED_AUTH_SURFACE_SHA"
verify_sha "$EXEC_LEDGER" "$EXPECTED_EXEC_LEDGER_SHA"
verify_sha "$EXEC_SURFACE" "$EXPECTED_EXEC_SURFACE_SHA"
verify_sha "$POST_REPORT" "$EXPECTED_POST_REPORT_SHA"
verify_sha "$POST_SURFACE" "$EXPECTED_POST_SURFACE_SHA"
verify_sha "$CI_AUDIT_REPORT" "$EXPECTED_CI_AUDIT_REPORT_SHA"
verify_sha "$CI_AUDIT_SURFACE" "$EXPECTED_CI_AUDIT_SURFACE_SHA"

sha256sum -c "$CAMPAIGN_HASHES" >/dev/null
sha256sum -c "$CANONICAL_RUN_MANIFEST" >/dev/null

awk '{print $2}' "$CANONICAL_RUN_MANIFEST" |
  sort > "$TMP_ROOT/manifest_run_files.txt"

test "$(wc -l < "$TMP_ROOT/manifest_run_files.txt")" -eq 280
test "$(sort -u "$TMP_ROOT/manifest_run_files.txt" | wc -l)" -eq 280

: > "$TMP_ROOT/actual_canonical_run_files.txt"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  RUN_DIR="$RUN_ROOT/objective_count_stage10_rep_${TOKEN}_canonical"

  test -d "$RUN_DIR"

  find "$RUN_DIR" -type f |
    sort >> "$TMP_ROOT/actual_canonical_run_files.txt"

  test "$(find "$RUN_DIR" -type f | wc -l)" -eq 28
done

sort -o \
  "$TMP_ROOT/actual_canonical_run_files.txt" \
  "$TMP_ROOT/actual_canonical_run_files.txt"

diff -u \
  "$TMP_ROOT/manifest_run_files.txt" \
  "$TMP_ROOT/actual_canonical_run_files.txt"

find "$EVIDENCE_ROOT" -type f |
  sort > "$TMP_ROOT/evidence_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/manifest_run_files.txt" \
  "$TMP_ROOT/evidence_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/evidence_files.txt")" -eq 18
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 300

git diff --name-only \
  "$EXPECTED_PREVIOUS_HEAD..$EXPECTED_MERGE_HEAD" |
  sort > "$TMP_ROOT/merged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/merged_files.txt"

while IFS= read -r FILE; do
  test -f "$FILE"
  git ls-files --error-unmatch "$FILE" >/dev/null
done < "$TMP_ROOT/expected_files.txt"

echo "corrected_canonical_scope_gate=PASS"
echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_merged_file_count=300"

echo
echo "=== 4. Canonical evidence and scientific-control gate ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .completion.successful_execution_spec_count == 10
  and .completion.failed_execution_spec_count == 0
  and .completion.canonical_run_count == 10
  and .completion.total_instance_count == 60
  and .completion.total_step_evaluations == 1920
  and .completion.canonical_run_file_count == 280
  and .completion.canonical_run_total_bytes == 25018782
  and .repository_scope.total_materialized_file_count == 300
  and .scientific_controls.canonical_stage10_functional_execution_performed == true
  and .scientific_controls.functional_execution_completion_audited == true
  and .scientific_controls.functional_execution_evidence_materialized == true
  and .scientific_controls.functional_execution_evidence_committed == false
  and .scientific_controls.timing_analysis_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.scientific_result_interpretation_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization.functional_execution_evidence_commit_authorized == true
  and .authorization.timing_analysis_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$EVIDENCE_MANIFEST" >/dev/null

jq -e '
  .pull_request == 36
  and .changed_file_count == 300
  and .eligible_pull_request_workflow_count == 0
  and .registered_ci.object_count == 0
  and .registered_ci.failure_count == 0
  and .decision.ci_absence_is_expected == true
  and .blocker_count == 0
  and .audit_complete == true
' "$CI_AUDIT_REPORT" >/dev/null

echo "canonical_evidence_decision_gate=PASS"
echo "ci_mode=workflow_ineligible"
echo "timing_analysis_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 5. Post-merge full regression ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

MANUSCRIPT_SHA_BEFORE="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA_BEFORE="$(sha256sum "$DEFERRED" | awk '{print $1}')"

"$PYTHON" backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA_BEFORE"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA_BEFORE"
test -z "$(git status --porcelain)"

echo "post_merge_full_regression_gate=PASS"

echo
echo "=== 6. Write detached corrected resume audit ==="

mkdir -p "$AUDIT_ROOT"

export AUDIT_REPORT AUDIT_SURFACE
export EXPECTED_MERGE_HEAD EXPECTED_PREVIOUS_HEAD EXPECTED_FEATURE_HEAD
export ALL_RUN_ROOT_FILE_COUNT

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


report_path = Path(os.environ["AUDIT_REPORT"])
surface_path = Path(os.environ["AUDIT_SURFACE"])

report = {
    "schema_version": (
        "mcad-sa5-objective-count-pr36-"
        "postmerge-resume-audit-v1"
    ),
    "status": "pr36_postmerge_validation_resumed_and_completed",
    "merge_commit": os.environ["EXPECTED_MERGE_HEAD"],
    "first_parent": os.environ["EXPECTED_PREVIOUS_HEAD"],
    "second_parent": os.environ["EXPECTED_FEATURE_HEAD"],
    "prior_failure": {
        "line": 818,
        "assertion": "all_run_root_file_count_equals_280",
        "actual_all_run_root_file_count": int(
            os.environ["ALL_RUN_ROOT_FILE_COUNT"]
        ),
        "expected_canonical_stage10_run_file_count": 280,
        "cause": "overbroad_run_root_scope",
        "merge_state_affected": False,
        "scientific_evidence_affected": False,
    },
    "corrected_scope": {
        "canonical_run_count": 10,
        "canonical_run_file_count": 280,
        "canonical_evidence_file_count": 18,
        "planning_file_count": 2,
        "total_merged_file_count": 300,
        "canonical_run_manifest_verified": True,
        "merged_diff_matches_exact_scope": True,
    },
    "validation": {
        "merge_lineage": "PASS",
        "pull_request_final_state": "PASS",
        "canonical_evidence_integrity": "PASS",
        "post_merge_full_regression": "PASS",
        "repository_clean": True,
        "manuscript_modified": False,
    },
    "scientific_controls": {
        "canonical_stage10_functional_execution_performed": True,
        "functional_execution_completion_audited": True,
        "functional_execution_evidence_committed": True,
        "timing_analysis_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "resume_complete": True,
    "next_stage": (
        "audit_sa5_objective_count_stage10_"
        "post_merge_analysis_readiness"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT PR #36 POST-MERGE RESUME AUDIT",
        "=" * 78,
        f"merge_commit={report['merge_commit']}",
        "prior_failed_line=818",
        "prior_failure_cause=overbroad_run_root_scope",
        (
            "actual_all_run_root_file_count="
            f"{report['prior_failure']['actual_all_run_root_file_count']}"
        ),
        "expected_canonical_stage10_run_file_count=280",
        "merge_state_affected=false",
        "corrected_canonical_scope=PASS",
        "canonical_run_count=10",
        "canonical_run_file_count=280",
        "canonical_evidence_file_count=18",
        "planning_file_count=2",
        "total_merged_file_count=300",
        "post_merge_full_regression=PASS",
        "repository_clean=true",
        "manuscript_modified=false",
        "blocker_count=0",
        "resume_complete=true",
        f"next_stage={report['next_stage']}",
        "",
    ]),
    encoding="utf-8",
)

print("corrected_resume_audit_generation=PASS")
print(f"resume_audit_report={report_path}")
print(
    "resume_audit_report_sha256="
    + hashlib.sha256(report_path.read_bytes()).hexdigest()
)
print(f"resume_audit_surface={surface_path}")
print(
    "resume_audit_surface_sha256="
    + hashlib.sha256(surface_path.read_bytes()).hexdigest()
)
PY

echo
echo "=== 7. Cleanup preserved local feature branch ==="

if git show-ref --verify --quiet "refs/heads/$FEATURE_BRANCH"; then
  git branch -d "$FEATURE_BRANCH"
fi

test -z "$(git ls-remote --heads origin "$FEATURE_BRANCH")"
test -z "$(git status --porcelain)"

echo "local_feature_branch_cleanup=PASS"

echo
echo "=== 8. Final state ==="

echo "sa5_objective_count_stage10_functional_evidence_merge_resume=PASS"
echo "base_head=$EXPECTED_MERGE_HEAD"
echo "pull_request=36"
echo "merge_already_completed=true"
echo "merge_reexecution_performed=false"
echo "prior_failure_cause=overbroad_run_root_scope"
echo "all_run_root_file_count=$ALL_RUN_ROOT_FILE_COUNT"

echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_merged_file_count=300"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"
echo "total_output_bytes=25018782"

echo "post_merge_full_regression=PASS"
echo "repository_clean=true"

echo "canonical_stage10_functional_execution_performed=true"
echo "functional_execution_completion_audited=true"
echo "functional_execution_evidence_committed=true"

echo "timing_analysis_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"

echo "blocker_count=0"
echo "resume_complete=true"
echo "next_stage=audit_sa5_objective_count_stage10_post_merge_analysis_readiness"

git status --short --branch
git log --oneline --decorate -6
