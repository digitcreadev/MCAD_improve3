#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"
DESIGN_DOC="backend/harness/sensitivity_design/SENSITIVITY_GENERATOR_DESIGN.md"
DESIGN_VALIDATOR="backend/harness/sensitivity_design/validate_design.py"
DESIGN_TEST="backend/harness/sensitivity_design/tests/test_design_contract.py"

SEMANTIC_BINDING="backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml"
SEMANTIC_DOC="backend/harness/sensitivity_design/semantic_binding/SEMANTIC_BINDING_E1_1.md"

CONTROLLED_GENERATOR="backend/harness/sensitivity_generator/families/controlled_families.py"
CONTROLLED_TEST="backend/harness/sensitivity_generator/tests/test_controlled_families.py"
CONTROLLED_DOC="backend/harness/sensitivity_generator/families/CONTROLLED_FAMILIES_E2_2.md"

STRUCTURAL_GENERATOR="backend/harness/sensitivity_generator/structural_generator.py"
EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
E3_VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"
SCALABILITY_RUNNER="backend/harness/run_scalability_benchmark.py"

FROZEN_REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"
MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_capability_audit_${STAMP}"

REPORT_JSON="$AUDIT_ROOT/sa5_objective_count_capability_audit.json"
REPORT_MD="$AUDIT_ROOT/sa5_objective_count_capability_audit.md"

trap 'echo "[ERROR] SA5 objective-count audit stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only SA5 gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$DESIGN_MATRIX" \
  "$DESIGN_DOC" \
  "$DESIGN_VALIDATOR" \
  "$DESIGN_TEST" \
  "$CONTROLLED_GENERATOR" \
  "$CONTROLLED_TEST" \
  "$CONTROLLED_DOC" \
  "$EXECUTOR" \
  "$FROZEN_REGISTRY" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

REGISTRY_SHA_BEFORE="$(
  sha256sum "$FROZEN_REGISTRY" |
    awk '{print $1}'
)"

echo "sa5_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "repository_modified=false"
echo "manuscript_modified=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Initialize detached audit output ==="

rm -rf "$AUDIT_ROOT"

mkdir -p \
  "$AUDIT_ROOT/evidence" \
  "$AUDIT_ROOT/tests" \
  "$AUDIT_ROOT/snippets"

echo "audit_root=$AUDIT_ROOT"

echo
echo "=== 3. Collect objective-count implementation evidence ==="

git grep \
  -n \
  -I \
  -E \
  'objective_count|n_objectives|objective count|number of objectives' \
  -- \
  'backend/harness/**/*.py' \
  'backend/harness/**/*.yaml' \
  'backend/harness/**/*.yml' \
  'backend/harness/**/*.md' \
  > "$AUDIT_ROOT/evidence/objective_count_git_grep.txt" \
  || true

git ls-files |
  grep -Ei \
    'objective.?count|objectives?.*(generator|family|oracle|audit)' \
  > "$AUDIT_ROOT/evidence/objective_count_candidate_files.txt" \
  || true

find \
  reports/article_experiments/sensitivity \
  -type f \
  -o -type d \
  2>/dev/null |
  grep -Ei \
    'objective.?count' \
  > "$AUDIT_ROOT/evidence/existing_objective_count_artifacts.txt" \
  || true

grep -n \
  -A25 \
  -B10 \
  -E \
  'primary_factor:[[:space:]]*objective_count|objective_count:' \
  "$DESIGN_MATRIX" \
  > "$AUDIT_ROOT/snippets/design_matrix_objective_count.txt" \
  || true

grep -n \
  -A25 \
  -B10 \
  -Ei \
  'objective count|n_objectives' \
  "$DESIGN_DOC" \
  > "$AUDIT_ROOT/snippets/design_document_objective_count.txt" \
  || true

grep -n \
  -A20 \
  -B10 \
  -E \
  'objective_count|n_objectives' \
  "$CONTROLLED_GENERATOR" \
  > "$AUDIT_ROOT/snippets/controlled_generator_objective_count.txt" \
  || true

grep -n \
  -A20 \
  -B10 \
  -E \
  'objective_count|n_objectives' \
  "$EXECUTOR" \
  > "$AUDIT_ROOT/snippets/executor_objective_count.txt" \
  || true

echo "implementation_evidence_collection=PASS"
echo "objective_count_hit_count=$(
  wc -l < "$AUDIT_ROOT/evidence/objective_count_git_grep.txt"
)"

echo
echo "=== 4. Compile relevant Python modules ==="

COMPILE_PATHS=(
  "$DESIGN_VALIDATOR"
  "$CONTROLLED_GENERATOR"
  "$EXECUTOR"
)

for OPTIONAL in \
  "$STRUCTURAL_GENERATOR" \
  "$E3_VALIDATOR" \
  "$SCALABILITY_RUNNER"
do
  if [ -f "$OPTIONAL" ]; then
    COMPILE_PATHS+=("$OPTIONAL")
  fi
done

set +e

"$PYTHON" -m py_compile \
  "${COMPILE_PATHS[@]}" \
  > "$AUDIT_ROOT/tests/python_compile.log" \
  2>&1

COMPILE_STATUS=$?

set -e

echo "python_compile_exit_status=$COMPILE_STATUS"

echo
echo "=== 5. Run current design validation ==="

set +e

"$PYTHON" "$DESIGN_VALIDATOR" \
  > "$AUDIT_ROOT/tests/design_validation.log" \
  2>&1

DESIGN_VALIDATION_STATUS=$?

set -e

echo "design_validation_exit_status=$DESIGN_VALIDATION_STATUS"

echo
echo "=== 6. Run current design-contract tests ==="

set +e

"$PYTHON" -m pytest \
  "$DESIGN_TEST" \
  -q \
  -p no:cacheprovider \
  > "$AUDIT_ROOT/tests/design_contract_tests.log" \
  2>&1

DESIGN_TEST_STATUS=$?

set -e

echo "design_contract_test_exit_status=$DESIGN_TEST_STATUS"

echo
echo "=== 7. Run controlled-family regression tests ==="

set +e

"$PYTHON" -m pytest \
  "$CONTROLLED_TEST" \
  -q \
  -p no:cacheprovider \
  > "$AUDIT_ROOT/tests/controlled_family_tests.log" \
  2>&1

CONTROLLED_TEST_STATUS=$?

set -e

echo "controlled_family_test_exit_status=$CONTROLLED_TEST_STATUS"

echo
echo "=== 8. Classify current SA5 capability ==="

"$PYTHON" - \
  "$ROOT" \
  "$AUDIT_ROOT" \
  "$EXPECTED_HEAD" \
  "$COMPILE_STATUS" \
  "$DESIGN_VALIDATION_STATUS" \
  "$DESIGN_TEST_STATUS" \
  "$CONTROLLED_TEST_STATUS" \
  "$DESIGN_MATRIX" \
  "$DESIGN_DOC" \
  "$DESIGN_VALIDATOR" \
  "$DESIGN_TEST" \
  "$SEMANTIC_BINDING" \
  "$SEMANTIC_DOC" \
  "$CONTROLLED_GENERATOR" \
  "$CONTROLLED_TEST" \
  "$CONTROLLED_DOC" \
  "$STRUCTURAL_GENERATOR" \
  "$EXECUTOR" \
  "$E3_VALIDATOR" \
  "$REPORT_JSON" \
  "$REPORT_MD" <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
audit_root = Path(sys.argv[2]).resolve()
source_commit = sys.argv[3]

compile_status = int(sys.argv[4])
design_validation_status = int(sys.argv[5])
design_test_status = int(sys.argv[6])
controlled_test_status = int(sys.argv[7])

paths = {
    "design_matrix": sys.argv[8],
    "design_document": sys.argv[9],
    "design_validator": sys.argv[10],
    "design_test": sys.argv[11],
    "semantic_binding": sys.argv[12],
    "semantic_document": sys.argv[13],
    "controlled_generator": sys.argv[14],
    "controlled_test": sys.argv[15],
    "controlled_document": sys.argv[16],
    "structural_generator": sys.argv[17],
    "executor": sys.argv[18],
    "e3_validator": sys.argv[19],
}

report_json = Path(sys.argv[20]).resolve()
report_md = Path(sys.argv[21]).resolve()


def read(relative: str) -> str:
    path = root / relative

    if not path.is_file():
        return ""

    return path.read_text(
        encoding="utf-8",
        errors="replace",
    )


def sha256(relative: str) -> str | None:
    path = root / relative

    if not path.is_file():
        return None

    return hashlib.sha256(path.read_bytes()).hexdigest()


def line_hits(
    relative: str,
    pattern: str,
) -> list[dict[str, Any]]:
    text = read(relative)
    regex = re.compile(pattern, re.IGNORECASE)

    results: list[dict[str, Any]] = []

    for number, line in enumerate(
        text.splitlines(),
        start=1,
    ):
        if regex.search(line):
            results.append({
                "line": number,
                "text": line[:500],
            })

    return results


def parse_python(relative: str) -> dict[str, Any]:
    text = read(relative)

    if not text:
        return {
            "exists": False,
            "parseable": False,
            "functions": [],
            "classes": [],
        }

    try:
        tree = ast.parse(text)
    except SyntaxError:
        return {
            "exists": True,
            "parseable": False,
            "functions": [],
            "classes": [],
        }

    functions = sorted({
        node.name
        for node in ast.walk(tree)
        if isinstance(
            node,
            (ast.FunctionDef, ast.AsyncFunctionDef),
        )
    })

    classes = sorted({
        node.name
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef)
    })

    return {
        "exists": True,
        "parseable": True,
        "functions": functions,
        "classes": classes,
    }


design_matrix_text = read(paths["design_matrix"])
design_document_text = read(paths["design_document"])
design_validator_text = read(paths["design_validator"])
design_test_text = read(paths["design_test"])

controlled_generator_text = read(
    paths["controlled_generator"]
)
controlled_test_text = read(paths["controlled_test"])
controlled_document_text = read(
    paths["controlled_document"]
)

structural_generator_text = read(
    paths["structural_generator"]
)
executor_text = read(paths["executor"])
e3_validator_text = read(paths["e3_validator"])

design_axis_defined = bool(
    re.search(
        r"primary_factor\s*:\s*objective_count",
        design_matrix_text,
    )
    or re.search(
        r"(?m)^[ \t]*objective_count\s*:",
        design_matrix_text,
    )
)

design_validator_mentions_axis = (
    "objective_count" in design_validator_text
)

design_tests_cover_axis = (
    "objective_count" in design_test_text
)

design_document_defines_factor = bool(
    re.search(
        r"objective count|n_objectives",
        design_document_text,
        flags=re.IGNORECASE,
    )
)

explicit_generator_branch_patterns = (
    r'factor\s*==\s*["\']objective_count["\']',
    r'factor\s+in\s+[^#\n]*["\']objective_count["\']',
    r'["\']objective_count["\']\s*:',
)

controlled_generator_explicit_support = any(
    re.search(
        pattern,
        controlled_generator_text,
    )
    for pattern in explicit_generator_branch_patterns
)

structural_generator_explicit_support = any(
    re.search(
        pattern,
        structural_generator_text,
    )
    for pattern in (
        r'n_objectives\s*[:=]',
        r'objective_count\s*[:=]',
        r'def\s+\w*objective\w*',
    )
)

dedicated_generator_test_support = bool(
    re.search(
        r'factor\s*=\s*["\']objective_count["\']',
        controlled_test_text,
    )
    or re.search(
        r'objective_count',
        controlled_test_text,
    )
)

controlled_document_declares_support = bool(
    re.search(
        r'objective_count|objective count',
        controlled_document_text,
        flags=re.IGNORECASE,
    )
)

executor_observes_objective_count = bool(
    re.search(
        r'objective_count|n_objectives',
        executor_text,
    )
)

executor_explicit_factor_acceptance = any(
    re.search(
        pattern,
        executor_text,
    )
    for pattern in explicit_generator_branch_patterns
)

e3_contract_explicit_support = bool(
    re.search(
        r'objective_count',
        e3_validator_text,
    )
)

dedicated_files = sorted(
    path.relative_to(root).as_posix()
    for path in root.rglob("*")
    if path.is_file()
    and re.search(
        r"objective.?count",
        path.name,
        flags=re.IGNORECASE,
    )
)

existing_campaign_paths = sorted({
    path.relative_to(root).as_posix()
    for base in (
        root
        / "reports"
        / "article_experiments"
        / "sensitivity",
        root
        / "experiments"
        / "article",
    )
    if base.exists()
    for path in base.rglob("*")
    if re.search(
        r"objective.?count",
        path.as_posix(),
        flags=re.IGNORECASE,
    )
})

campaign_exists = bool(existing_campaign_paths)

test_status = {
    "python_compile_passed": compile_status == 0,
    "design_validation_passed": (
        design_validation_status == 0
    ),
    "design_contract_tests_passed": (
        design_test_status == 0
    ),
    "controlled_family_tests_passed": (
        controlled_test_status == 0
    ),
}

design_contract_ready = all([
    design_axis_defined,
    design_validator_mentions_axis,
    design_tests_cover_axis,
    design_document_defines_factor,
    test_status["design_validation_passed"],
    test_status["design_contract_tests_passed"],
])

generator_ready = all([
    controlled_generator_explicit_support,
    structural_generator_explicit_support,
    dedicated_generator_test_support,
    test_status["controlled_family_tests_passed"],
])

executor_ready = all([
    executor_observes_objective_count,
    executor_explicit_factor_acceptance,
    e3_contract_explicit_support,
])

direct_preregistration_ready = all([
    test_status["python_compile_passed"],
    design_contract_ready,
    generator_ready,
    executor_ready,
])

if direct_preregistration_ready:
    capability_status = (
        "ready_for_direct_preregistration"
    )
    next_stage = (
        "preregister_sa5_objective_count_campaign"
    )
    implementation_required = False
elif design_contract_ready:
    capability_status = (
        "implementation_required_before_preregistration"
    )
    next_stage = (
        "design_and_implement_sa5_objective_count_"
        "controlled_family"
    )
    implementation_required = True
else:
    capability_status = (
        "design_contract_amendment_required"
    )
    next_stage = (
        "formalize_sa5_objective_count_design_contract"
    )
    implementation_required = True

missing_capabilities: list[str] = []

checks = {
    "design_axis_defined": design_axis_defined,
    "design_validator_mentions_axis": (
        design_validator_mentions_axis
    ),
    "design_tests_cover_axis": design_tests_cover_axis,
    "design_document_defines_factor": (
        design_document_defines_factor
    ),
    "controlled_generator_explicit_support": (
        controlled_generator_explicit_support
    ),
    "structural_generator_explicit_support": (
        structural_generator_explicit_support
    ),
    "dedicated_generator_test_support": (
        dedicated_generator_test_support
    ),
    "controlled_document_declares_support": (
        controlled_document_declares_support
    ),
    "executor_observes_objective_count": (
        executor_observes_objective_count
    ),
    "executor_explicit_factor_acceptance": (
        executor_explicit_factor_acceptance
    ),
    "e3_contract_explicit_support": (
        e3_contract_explicit_support
    ),
}

for name, value in checks.items():
    if not value:
        missing_capabilities.append(name)

for name, value in test_status.items():
    if not value:
        missing_capabilities.append(name)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-capability-audit-v1"
    ),
    "status": capability_status,
    "factor": "objective_count",
    "campaign_stage": "SA5",
    "source_branch": (
        "paper/phase3-controlled-execution"
    ),
    "source_commit": source_commit,
    "read_only_audit": True,
    "scientific_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "manuscript_modified": False,
    "design_contract": {
        "ready": design_contract_ready,
        "checks": {
            key: checks[key]
            for key in (
                "design_axis_defined",
                "design_validator_mentions_axis",
                "design_tests_cover_axis",
                "design_document_defines_factor",
            )
        },
    },
    "controlled_generation": {
        "ready": generator_ready,
        "checks": {
            key: checks[key]
            for key in (
                "controlled_generator_explicit_support",
                "structural_generator_explicit_support",
                "dedicated_generator_test_support",
                "controlled_document_declares_support",
            )
        },
    },
    "execution_compatibility": {
        "ready": executor_ready,
        "checks": {
            key: checks[key]
            for key in (
                "executor_observes_objective_count",
                "executor_explicit_factor_acceptance",
                "e3_contract_explicit_support",
            )
        },
    },
    "test_status": test_status,
    "repository_evidence": {
        "dedicated_objective_count_files": dedicated_files,
        "existing_campaign_paths": (
            existing_campaign_paths
        ),
        "existing_campaign_detected": campaign_exists,
    },
    "source_files": {
        name: {
            "path": path,
            "sha256": sha256(path),
            "objective_count_hits": line_hits(
                path,
                r"objective_count|n_objectives|"
                r"objective count",
            )[:50],
            "python_structure": (
                parse_python(path)
                if path.endswith(".py")
                else None
            ),
        }
        for name, path in paths.items()
    },
    "scientific_decision": {
        "direct_preregistration_ready": (
            direct_preregistration_ready
        ),
        "implementation_required": (
            implementation_required
        ),
        "missing_capabilities": sorted(
            set(missing_capabilities)
        ),
        "campaign_exists": campaign_exists,
        "campaign_execution_authorized": False,
        "timing_execution_authorized": False,
        "latency_claim_authorized": False,
    },
    "accelerated_completion_policy": {
        "manuscript_integration_before_global_freeze": False,
        "deferred_result_fragment_after_campaign_freeze": True,
        "reuse_stage10_replication_and_precision_pipeline": True,
        "reuse_existing_seed_schedule_subject_to_preregistration": True,
        "skip_redundant_exploratory_runs": True,
        "require_functional_equivalence_before_timing": True,
    },
    "next_stage": next_stage,
}

report_json.write_text(
    json.dumps(report, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

lines = [
    "# SA5 objective-count capability audit",
    "",
    f"- Status: `{capability_status}`",
    f"- Design contract ready: `{str(design_contract_ready).lower()}`",
    f"- Controlled generator ready: `{str(generator_ready).lower()}`",
    f"- E3 executor ready: `{str(executor_ready).lower()}`",
    (
        "- Direct preregistration ready: "
        f"`{str(direct_preregistration_ready).lower()}`"
    ),
    (
        "- Implementation required: "
        f"`{str(implementation_required).lower()}`"
    ),
    (
        "- Existing objective-count campaign detected: "
        f"`{str(campaign_exists).lower()}`"
    ),
    "",
    "## Missing capabilities",
    "",
]

if missing_capabilities:
    lines.extend(
        f"- `{name}`"
        for name in sorted(set(missing_capabilities))
    )
else:
    lines.append("- None")

lines.extend([
    "",
    "## Scientific controls",
    "",
    "- Campaign execution authorized: `false`",
    "- Timing execution authorized: `false`",
    "- Bootstrap execution performed: `false`",
    "- Manuscript modified: `false`",
    "",
    "## Next stage",
    "",
    f"`{next_stage}`",
    "",
])

report_md.write_text(
    "\n".join(lines),
    encoding="utf-8",
)

print("sa5_capability_classification=PASS")
print(f"capability_status={capability_status}")
print(
    "design_contract_ready="
    f"{str(design_contract_ready).lower()}"
)
print(
    "controlled_generator_ready="
    f"{str(generator_ready).lower()}"
)
print(
    "executor_ready="
    f"{str(executor_ready).lower()}"
)
print(
    "direct_preregistration_ready="
    f"{str(direct_preregistration_ready).lower()}"
)
print(
    "implementation_required="
    f"{str(implementation_required).lower()}"
)
print(
    "existing_campaign_detected="
    f"{str(campaign_exists).lower()}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 9. Validate audit classification ==="

test -s "$REPORT_JSON"
test -s "$REPORT_MD"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-capability-audit-v1"
  and .factor == "objective_count"
  and .campaign_stage == "SA5"
  and .read_only_audit == true
  and .scientific_execution_performed == false
  and .timing_execution_performed == false
  and .bootstrap_execution_performed == false
  and .manuscript_modified == false
  and .scientific_decision.campaign_execution_authorized == false
  and .scientific_decision.timing_execution_authorized == false
  and .scientific_decision.latency_claim_authorized == false
  and (
    (
      .status == "ready_for_direct_preregistration"
      and .scientific_decision.direct_preregistration_ready
          == true
      and .scientific_decision.implementation_required
          == false
      and .next_stage
          == "preregister_sa5_objective_count_campaign"
    )
    or
    (
      .status
          == "implementation_required_before_preregistration"
      and .scientific_decision.direct_preregistration_ready
          == false
      and .scientific_decision.implementation_required
          == true
      and .next_stage
          == "design_and_implement_sa5_objective_count_controlled_family"
    )
    or
    (
      .status == "design_contract_amendment_required"
      and .scientific_decision.direct_preregistration_ready
          == false
      and .scientific_decision.implementation_required
          == true
      and .next_stage
          == "formalize_sa5_objective_count_design_contract"
    )
  )
' "$REPORT_JSON" >/dev/null

CAPABILITY_STATUS="$(
  jq -r '.status' "$REPORT_JSON"
)"

DIRECT_READY="$(
  jq -r \
    '.scientific_decision.direct_preregistration_ready' \
    "$REPORT_JSON"
)"

IMPLEMENTATION_REQUIRED="$(
  jq -r \
    '.scientific_decision.implementation_required' \
    "$REPORT_JSON"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$REPORT_JSON"
)"

echo "sa5_capability_audit_validation=PASS"
echo "capability_status=$CAPABILITY_STATUS"
echo "direct_preregistration_ready=$DIRECT_READY"
echo "implementation_required=$IMPLEMENTATION_REQUIRED"
echo "next_stage=$NEXT_STAGE"

echo
echo "=== 10. Audit summary ==="

jq '{
  status,
  design_contract,
  controlled_generation,
  execution_compatibility,
  test_status,
  scientific_decision,
  next_stage
}' "$REPORT_JSON"

echo
echo "--- Missing capabilities ---"

jq -r \
  '.scientific_decision.missing_capabilities[]?' \
  "$REPORT_JSON"

echo
echo "--- Design validation log ---"

tail -n 80 \
  "$AUDIT_ROOT/tests/design_validation.log"

echo
echo "--- Design-contract tests ---"

tail -n 80 \
  "$AUDIT_ROOT/tests/design_contract_tests.log"

echo
echo "--- Controlled-family tests ---"

tail -n 80 \
  "$AUDIT_ROOT/tests/controlled_family_tests.log"

echo
echo "=== 11. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test "$(
  sha256sum "$FROZEN_REGISTRY" |
    awk '{print $1}'
)" = "$REGISTRY_SHA_BEFORE"

echo "sa5_objective_count_capability_audit=PASS"
echo "repository_modified=false"
echo "manuscript_modified=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "audit_report=$REPORT_JSON"
echo "capability_status=$CAPABILITY_STATUS"
echo "direct_preregistration_ready=$DIRECT_READY"
echo "implementation_required=$IMPLEMENTATION_REQUIRED"
echo "next_stage=$NEXT_STAGE"

git status --short --branch
