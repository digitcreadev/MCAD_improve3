#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BRANCH="paper/audit-virtual-node-count-stage10-functional-20260802T145136Z"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="46b95f74df41cb9ae255839dd999cefe94cf0ae4"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TOOL="backend/harness/sensitivity_execution/tools/audit_virtual_node_count_stage10_functional_completion.py"
TEST="backend/harness/sensitivity_execution/tests/test_virtual_node_count_stage10_functional_completion.py"

AUDIT_DIR="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion"
REPORT="$AUDIT_DIR/combined_60_functional_steps_audit.json"
SUMMARY="$AUDIT_DIR/combined_60_functional_steps_audit.md"

trap 'echo "[ERROR] recovery script stopped at line $LINENO"' ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -f "$TOOL"
test -f "$TEST"
test -x "$PYTHON"

echo "branch=$BRANCH"
echo "head=$EXPECTED_HEAD"
echo "recovery_gate=PASS"

echo
echo "=== 2. Patch obsolete historical-report dependency ==="

"$PYTHON" - "$TOOL" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

path = Path(sys.argv[1])
text = path.read_text(encoding="utf-8")


def replace_once(
    source: str,
    old: str,
    new: str,
    label: str,
) -> str:
    if new and new in source:
        print(f"{label}=ALREADY_APPLIED")
        return source

    count = source.count(old)

    if count != 1:
        raise SystemExit(
            f"{label}: expected one occurrence, got {count}"
        )

    print(f"{label}=PASS")
    return source.replace(old, new, 1)


old_constant = '''HISTORICAL_COMPLETION_REPORT = (
    E3
    / "aggregates"
    / "e3_execution_completion_report.json"
)

'''

text = replace_once(
    text,
    old_constant,
    "",
    "remove_historical_report_constant",
)

old_load = '''    historical_report = load_json(
        root / HISTORICAL_COMPLETION_REPORT
    )
'''

text = replace_once(
    text,
    old_load,
    "",
    "remove_historical_report_load",
)

old_validation = '''    historical_runs = (
        historical_report
        .get("canonical_execution_wave", {})
        .get("runs", {})
    )

    for replication in (0, 1):
        stem = run_stem(replication)
        entry = historical_runs.get(stem)

        require(
            isinstance(entry, dict),
            f"Missing historical completion entry: {stem}",
        )

        require(
            str(entry.get("status", "")).lower()
            == "success",
            f"Historical run is not successful: {stem}",
        )

        require(
            int(entry.get("instance_result_count", -1))
            == 3,
            f"Historical run must contain 3 results: {stem}",
        )

        forbidden_stage10_dir = (
            root
            / RUNS
            / (
                "virtual_node_count_stage10_"
                f"rep_{replication:03d}_strict_common"
            )
        )

        require(
            not forbidden_stage10_dir.exists(),
            "Historical prefix appears to have been "
            f"rerun: {forbidden_stage10_dir}",
        )
'''

new_validation = '''    # rep_000 and rep_001 are validated directly from their
    # authoritative historical run directories by validate_run().
    # Only a Stage-10-named duplicate directory would indicate a rerun.
    for replication in (0, 1):
        forbidden_stage10_dir = (
            root
            / RUNS
            / (
                "virtual_node_count_stage10_"
                f"rep_{replication:03d}_strict_common"
            )
        )

        require(
            not forbidden_stage10_dir.exists(),
            "Historical prefix appears to have been "
            f"rerun: {forbidden_stage10_dir}",
        )
'''

text = replace_once(
    text,
    old_validation,
    new_validation,
    "replace_historical_validation",
)

old_metadata = '''            "historical_completion_report": {
                "path": (
                    HISTORICAL_COMPLETION_REPORT
                    .as_posix()
                ),
                "sha256": sha256_file(
                    root / HISTORICAL_COMPLETION_REPORT
                ),
            },
'''

text = replace_once(
    text,
    old_metadata,
    "",
    "remove_historical_report_metadata",
)

for obsolete in (
    "HISTORICAL_COMPLETION_REPORT",
    "historical_report",
    "historical_runs",
):
    if obsolete in text:
        raise SystemExit(
            f"Obsolete reference remains: {obsolete}"
        )

path.write_text(text, encoding="utf-8")

print("historical_dependency_removal=PASS")
PY

echo
echo "=== 3. Compile and generate combined audit ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" -m py_compile \
    "$TOOL" \
    "$TEST"

PYTHONPATH="$ROOT" \
  "$PYTHON" "$TOOL" \
    --repo-root "$ROOT"

echo
echo "=== 4. Focused tests ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" -m pytest -q "$TEST"

echo
echo "=== 5. Validate final report ==="

"$PYTHON" - "$REPORT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

if not path.is_file():
    raise SystemExit(f"Missing report: {path}")

report = json.loads(
    path.read_text(encoding="utf-8")
)

expected = {
    "status": "pass",
    "replication_count": 10,
    "instance_count": 30,
    "functional_step_count": 60,
    "timing_execution_performed": False,
    "timing_artifact_count": 0,
    "latency_claim_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

runs = report.get("runs", [])

if len(runs) != 10:
    raise SystemExit(
        f"Expected 10 runs, got {len(runs)}"
    )

if [
    item["replication_index"]
    for item in runs
] != list(range(10)):
    raise SystemExit(
        "Replication sequence must be 0 through 9."
    )

for run in runs:
    if (
        run.get("status") != "pass"
        or run.get("selected_instance_count") != 3
        or run.get("functional_step_count") != 6
        or run.get("timing_artifact_count") != 0
    ):
        raise SystemExit(
            "Invalid run audit: "
            f"replication={run.get('replication_index')}"
        )

prefix = report.get("historical_prefix", {})

if prefix.get("reused") is not True:
    raise SystemExit(
        "Historical prefix must be marked reused."
    )

if prefix.get("rerun_performed") is not False:
    raise SystemExit(
        "Historical prefix must not be marked rerun."
    )

print("combined_report_validation=PASS")
print("replication_count=10")
print("instance_count=30")
print("functional_step_count=60")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 6. Commit and push ==="

git add \
  "$TOOL" \
  "$TEST"

git add -f \
  "$REPORT" \
  "$SUMMARY"

git diff --cached --check

git commit \
  -m "evidence(experiments): audit virtual-node-count Stage-10 functional completion"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

EXISTING_PR="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state open \
    --json url \
    --jq '.[0].url // ""'
)"

if [ -n "$EXISTING_PR" ]; then
  PR_URL="$EXISTING_PR"
  echo "pull_request_creation=ALREADY_EXISTS"
else
  PR_URL="$(
    gh pr create \
      --repo "$REPO" \
      --head "$BRANCH" \
      --base "$BASE" \
      --title "Audit virtual-node-count Stage-10 functional completion" \
      --body "$(cat <<'EOF'
## Scope

- reuses the valid historical functional evidence for rep_000 and rep_001;
- audits rep_002 through rep_009 without rerunning them;
- validates 10 replications, 30 instances and 60 functional steps;
- verifies levels 6, 12 and 24 for every replication;
- verifies the expected structural seed for every replication;
- verifies that no timing artifacts were produced;
- performs no functional execution and no timing execution.

## Result

- historical evidence: 6 instances / 12 steps;
- new evidence: 24 instances / 48 steps;
- combined evidence: 30 instances / 60 steps;
- historical rerun performed: false;
- timing execution performed: false.

## Next stage

Prepare the formal Stage-10 timing authorization.
EOF
)"
  )"
fi

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

echo "virtual_node_count_stage10_functional_completion=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "instance_count=30"
echo "functional_step_count=60"
echo "historical_prefix_rerun_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_functional_completion_audit"

git status --short --branch
