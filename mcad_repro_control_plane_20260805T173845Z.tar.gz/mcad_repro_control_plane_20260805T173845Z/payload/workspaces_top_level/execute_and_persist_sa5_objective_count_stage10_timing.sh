#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="20dfec11a502cc0fccbcc07f6e2df0734debe29c"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_SPECS="$SETUP_ROOT/specs"
SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
EXPECTED_SETUP_MANIFEST_SHA="5e5baad8a32d5c9c8e647d8d2365d68a9e3a286e620fc783373ec577a26cf155"

SETUP_FILES="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"
EXPECTED_SETUP_FILES_SHA="c785ab0fafc1c424e7a737d0dfd4282cb01b7ef071cf54c2adeb4304fb9ad9af"

AUTHORIZATION="$E3/planning/sa5_objective_count_stage10_timing_execution_authorization.json"
EXPECTED_AUTHORIZATION_SHA="bb8805eaaedb3277e25197a1eab2d5b4e484aa66006fc4a4dcf0bff424b47c20"

RUNNER_MODULE="backend.harness.sensitivity_execution.run_timing_repetitions"
RUNNER_FILE="backend/harness/sensitivity_execution/run_timing_repetitions.py"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"
EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/timing_execution"
EVIDENCE_LOG_ROOT="$EVIDENCE_ROOT/logs"
RUN_FILE_MANIFEST="$EVIDENCE_ROOT/objective_count_stage10_timing_run_files.sha256"
EVIDENCE_MANIFEST="$EVIDENCE_ROOT/objective_count_stage10_timing_execution_evidence.json"

PLANNING_REPORT="$E3/planning/sa5_objective_count_stage10_timing_execution_report.json"
PLANNING_SUMMARY="$E3/planning/sa5_objective_count_stage10_timing_execution_report.md"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/persist-sa5-objective-count-stage10-timing-${STAMP}"

DETACHED_ROOT="/workspaces/sa5_objective_count_stage10_timing_execution_${STAMP}"
DETACHED_LOG_ROOT="$DETACHED_ROOT/logs"
DETACHED_PLAN="$DETACHED_ROOT/timing_execution_plan.json"

TMP_ROOT="$(mktemp -d /workspaces/sa5_timing_execution.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 Timing Execution stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact merged Timing Setup authorization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_FILES" "$EXPECTED_SETUP_FILES_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
verify_sha "$RUNNER_FILE" "$EXPECTED_RUNNER_SHA"

test "$(wc -l < "$SETUP_FILES")" -eq 19
sha256sum -c "$SETUP_FILES" >/dev/null

jq -e '
  .status == "timing_execution_authorized"
  and .source_commit
    == "0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .factor_levels == [1,2,5,10,20,50]
  and .replication_count == 10
  and .instance_count == 60
  and .timing_spec_count == 10
  and .workload_step_count_per_instance == 32
  and .measured_repetitions_per_factor_level == 2530
  and .expected_observation_rows_per_replication == 15180
  and .expected_total_observation_rows == 151800
  and .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .precision_analysis_authorized == false
  and .bootstrap_analysis_authorized == false
  and .scientific_result_interpretation_authorized == false
  and .scientific_freeze_authorized == false
  and .manuscript_integration_authorized == false
  and .blocker_count == 0
  and .authorization_complete == true
  and .next_stage
    == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION" >/dev/null

test "$(find "$SETUP_SPECS" -maxdepth 1 -type f -name '*.json' | wc -l)" -eq 10
test ! -e "$EVIDENCE_ROOT"
test ! -e "$PLANNING_REPORT"
test ! -e "$PLANNING_SUMMARY"

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "timing_authorization_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "timing_spec_count=10"
echo "expected_total_observation_rows=151800"
echo "timing_execution_authorized=true"

echo
echo "=== 2. Freeze exact CLI plan from committed specs ==="

mkdir -p "$DETACHED_LOG_ROOT"

export ROOT SETUP_SPECS SETUP_MANIFEST DETACHED_PLAN
export EXPECTED_HEAD EXPECTED_RUNNER_SHA

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


root = Path(os.environ["ROOT"]).resolve()
spec_root = root / os.environ["SETUP_SPECS"]
setup_manifest_path = root / os.environ["SETUP_MANIFEST"]
plan_path = Path(os.environ["DETACHED_PLAN"])


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def option_default(
    runner: dict[str, Any],
    name: str,
) -> Any:
    matches = [
        argument
        for argument in runner["arguments"]
        if name in argument["names"]
    ]
    assert len(matches) == 1, (name, matches)
    return matches[0]["keywords"]["default"]


setup = read_json(setup_manifest_path)
assert setup["objective_count_timing_plan"]["timing_spec_count"] == 10

rows = []
parameter_tuples = set()
output_dirs = set()
functional_specs = set()

for index in range(10):
    token = f"{index:03d}"
    spec_path = (
        spec_root
        / f"objective_count_rep_{token}_portfolio_timing_stage10.json"
    )
    spec = read_json(spec_path)

    runner = spec["timing_runner"]
    assert runner["sha256"] == os.environ["EXPECTED_RUNNER_SHA"]
    assert runner["ast_parse"] == "PASS"

    warmups = int(option_default(runner, "--warmups"))
    measurements = int(option_default(runner, "--measurements"))
    order_seed = int(option_default(runner, "--order-seed"))

    # These values are frozen by the committed runner contract embedded in
    # every timing specification.
    assert warmups == 10
    assert measurements == 100
    assert order_seed == 20260728

    assert spec["replication_index"] == index
    assert spec["factor_levels"] == [1, 2, 5, 10, 20, 50]
    assert spec["selected_instance_count"] == 6
    assert spec["measured_repetitions_per_factor_level"] == 2530
    assert spec["expected_observation_rows"] == 15180
    assert spec["timing_execution_authorized"] is True
    assert spec["timing_execution_performed"] is False

    functional_spec = root / spec["functional_execution_spec"]
    output_dir = root / spec["timing_output_dir"]

    assert functional_spec.is_file()
    assert sha(functional_spec) == spec["functional_execution_spec_sha256"]

    parameter_tuples.add((warmups, measurements, order_seed))
    output_dirs.add(str(output_dir))
    functional_specs.add(str(functional_spec))

    rows.append({
        "replication_index": index,
        "timing_spec": spec_path.relative_to(root).as_posix(),
        "timing_spec_sha256": sha(spec_path),
        "functional_execution_spec": (
            functional_spec.relative_to(root).as_posix()
        ),
        "functional_execution_spec_sha256": sha(functional_spec),
        "timing_output_dir": output_dir.relative_to(root).as_posix(),
        "warmups": warmups,
        "measurements": measurements,
        "order_seed": order_seed,
        "reuse_successful": True,
        "expected_observation_rows": 15180,
    })

assert len(parameter_tuples) == 1
assert len(output_dirs) == 10
assert len(functional_specs) == 10

plan = {
    "schema_version": "mcad-sa5-objective-count-timing-execution-plan-v1",
    "status": "exact_timing_execution_plan_frozen",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "runner_module": (
        "backend.harness.sensitivity_execution.run_timing_repetitions"
    ),
    "runner_sha256": os.environ["EXPECTED_RUNNER_SHA"],
    "warmups": 10,
    "measurements": 100,
    "order_seed": 20260728,
    "reuse_successful": True,
    "replication_count": 10,
    "factor_levels": [1, 2, 5, 10, 20, 50],
    "expected_observation_rows_per_replication": 15180,
    "expected_total_observation_rows": 151800,
    "rows": rows,
    "timing_execution_performed": False,
}

plan_path.write_text(
    json.dumps(
        plan,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

print("exact_cli_plan_freeze=PASS")
print("warmups=10")
print("measurements=100")
print("order_seed=20260728")
print("reuse_successful=true")
print("replication_count=10")
print("expected_observation_rows_per_replication=15180")
print("expected_total_observation_rows=151800")
print(f"detached_plan={plan_path}")
print(f"detached_plan_sha256={sha(plan_path)}")
PY

echo
echo "=== 3. Execute or resume ten timing replications sequentially ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

SUCCESSFUL_REPLICATIONS=0
TOTAL_STARTED_AT="$(date +%s)"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"

  SPEC="$SETUP_SPECS/objective_count_rep_${TOKEN}_portfolio_timing_stage10.json"
  FUNCTIONAL_SPEC="$(jq -r '.functional_execution_spec' "$SPEC")"
  OUTPUT_DIR="$(jq -r '.timing_output_dir' "$SPEC")"
  EXPECTED_ROWS="$(jq -r '.expected_observation_rows' "$SPEC")"
  LOG="$DETACHED_LOG_ROOT/rep_${TOKEN}.log"

  test "$EXPECTED_ROWS" -eq 15180
  test -f "$FUNCTIONAL_SPEC"

  echo
  echo "--- timing replication $TOKEN ---"
  echo "functional_spec=$FUNCTIONAL_SPEC"
  echo "output_dir=$OUTPUT_DIR"
  echo "expected_observation_rows=$EXPECTED_ROWS"

  STARTED_AT="$(date +%s)"

  "$PYTHON" \
    -m "$RUNNER_MODULE" \
    "$FUNCTIONAL_SPEC" \
    --output-dir "$OUTPUT_DIR" \
    --warmups 10 \
    --measurements 100 \
    --order-seed 20260728 \
    --reuse-successful \
    2>&1 |
    tee "$LOG"

  ELAPSED="$(( $(date +%s) - STARTED_AT ))"

  test -d "$OUTPUT_DIR"

  for NAME in \
    timing_manifest.json \
    timing_observations.csv \
    timing_summary.json \
    functional_references.json
  do
    test -s "$OUTPUT_DIR/$NAME"
  done

  test "$(find "$OUTPUT_DIR" -maxdepth 1 -type f | wc -l)" -eq 4

  ACTUAL_ROWS="$(
    awk 'END {print NR > 0 ? NR - 1 : 0}' \
      "$OUTPUT_DIR/timing_observations.csv"
  )"

  test "$ACTUAL_ROWS" -eq "$EXPECTED_ROWS"

  "$PYTHON" - <<PY
import json
from pathlib import Path

for name in (
    "timing_manifest.json",
    "timing_summary.json",
    "functional_references.json",
):
    path = Path("$OUTPUT_DIR") / name
    json.loads(path.read_text(encoding="utf-8"))
PY

  SUCCESSFUL_REPLICATIONS="$((SUCCESSFUL_REPLICATIONS + 1))"

  echo "replication_${TOKEN}=PASS"
  echo "replication_${TOKEN}_observation_rows=$ACTUAL_ROWS"
  echo "replication_${TOKEN}_elapsed_seconds=$ELAPSED"
done

test "$SUCCESSFUL_REPLICATIONS" -eq 10

TOTAL_ELAPSED="$(( $(date +%s) - TOTAL_STARTED_AT ))"

echo
echo "timing_process_execution=PASS"
echo "successful_replication_count=10"
echo "total_execution_elapsed_seconds=$TOTAL_ELAPSED"

echo
echo "=== 4. Audit all timing outputs and materialize evidence ==="

mkdir -p "$EVIDENCE_LOG_ROOT"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  cp "$DETACHED_LOG_ROOT/rep_${TOKEN}.log" \
    "$EVIDENCE_LOG_ROOT/rep_${TOKEN}.log"
done

export EVIDENCE_ROOT EVIDENCE_LOG_ROOT
export RUN_FILE_MANIFEST EVIDENCE_MANIFEST
export PLANNING_REPORT PLANNING_SUMMARY
export DETACHED_PLAN AUTHORIZATION
export TIMING_RUN_ROOT
export TOTAL_ELAPSED

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any, Iterable


root = Path(os.environ["ROOT"]).resolve()
spec_root = root / os.environ["SETUP_SPECS"]
timing_root = root / os.environ["TIMING_RUN_ROOT"]
evidence_root = root / os.environ["EVIDENCE_ROOT"]
log_root = root / os.environ["EVIDENCE_LOG_ROOT"]

run_manifest_path = root / os.environ["RUN_FILE_MANIFEST"]
evidence_path = root / os.environ["EVIDENCE_MANIFEST"]
planning_report_path = root / os.environ["PLANNING_REPORT"]
planning_summary_path = root / os.environ["PLANNING_SUMMARY"]

detached_plan = Path(os.environ["DETACHED_PLAN"])
authorization_path = root / os.environ["AUTHORIZATION"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def explicit_failures(value: Any) -> list[dict[str, str]]:
    failure_values = {
        "FAIL",
        "FAILED",
        "ERROR",
        "ABORTED",
        "CANCELLED",
    }
    rows: list[dict[str, str]] = []

    for node in walk(value):
        if not isinstance(node, dict):
            continue
        for key, child in node.items():
            normalized = str(key).lower().replace("-", "_")
            if (
                normalized
                in {
                    "status",
                    "execution_status",
                    "result_status",
                    "timing_status",
                }
                and isinstance(child, str)
                and child.upper() in failure_values
            ):
                rows.append({"key": normalized, "value": child})

    return rows


run_rows = []
all_run_files: list[Path] = []
all_headers: list[list[str]] = []
total_rows = 0
total_bytes = 0
explicit_failure_count = 0

for index in range(10):
    token = f"{index:03d}"
    spec_path = (
        spec_root
        / f"objective_count_rep_{token}_portfolio_timing_stage10.json"
    )
    spec = read_json(spec_path)
    output_dir = root / spec["timing_output_dir"]
    log_path = log_root / f"rep_{token}.log"

    expected_names = {
        "timing_manifest.json",
        "timing_observations.csv",
        "timing_summary.json",
        "functional_references.json",
    }
    files = sorted(path for path in output_dir.iterdir() if path.is_file())

    assert {path.name for path in files} == expected_names
    assert log_path.is_file() and log_path.stat().st_size > 0

    manifest = read_json(output_dir / "timing_manifest.json")
    summary = read_json(output_dir / "timing_summary.json")
    references = read_json(output_dir / "functional_references.json")

    failures = (
        explicit_failures(manifest)
        + explicit_failures(summary)
        + explicit_failures(references)
    )
    explicit_failure_count += len(failures)
    assert not failures

    csv_path = output_dir / "timing_observations.csv"
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        header = list(reader.fieldnames or [])

    assert header
    assert len(rows) == 15180
    all_headers.append(header)

    for row in rows:
        for raw in row.values():
            if raw is None or raw == "":
                continue
            try:
                number = float(raw)
            except ValueError:
                continue
            assert math.isfinite(number)

    selected_ids = set(spec["selected_instance_ids"])
    reference_strings = {
        node
        for node in walk(references)
        if isinstance(node, str)
    }
    assert selected_ids.issubset(reference_strings)

    log_text = log_path.read_text(encoding="utf-8")
    assert "Traceback" not in log_text
    assert "[ERROR]" not in log_text

    file_rows = []
    for path in files:
        file_rows.append({
            "path": path.relative_to(root).as_posix(),
            "sha256": sha(path),
            "byte_count": path.stat().st_size,
        })

    output_bytes = sum(path.stat().st_size for path in files)
    total_bytes += output_bytes
    total_rows += len(rows)
    all_run_files.extend(files)

    run_rows.append({
        "replication_index": index,
        "seed": spec["seed"],
        "timing_spec": spec_path.relative_to(root).as_posix(),
        "timing_spec_sha256": sha(spec_path),
        "functional_execution_spec": spec["functional_execution_spec"],
        "timing_output_dir": output_dir.relative_to(root).as_posix(),
        "warmups": 10,
        "measurements": 100,
        "order_seed": 20260728,
        "observation_row_count": len(rows),
        "csv_header": header,
        "output_file_count": len(files),
        "output_total_bytes": output_bytes,
        "files": file_rows,
        "log_path": log_path.relative_to(root).as_posix(),
        "log_sha256": sha(log_path),
        "explicit_failure_count": 0,
        "status": "PASS",
    })

assert len(run_rows) == 10
assert total_rows == 151800
assert len(all_run_files) == 40
assert len({path.resolve() for path in all_run_files}) == 40
assert all(header == all_headers[0] for header in all_headers)
assert explicit_failure_count == 0

run_manifest_path.write_text(
    "".join(
        f"{sha(path)}  {path.relative_to(root).as_posix()}\n"
        for path in sorted(all_run_files)
    ),
    encoding="utf-8",
)

evidence = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-timing-execution-evidence-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_timing_execution_complete_and_audited"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "authorization": {
        "path": authorization_path.relative_to(root).as_posix(),
        "sha256": sha(authorization_path),
    },
    "execution_plan": {
        "detached_path": str(detached_plan),
        "sha256": sha(detached_plan),
        "runner_module": (
            "backend.harness.sensitivity_execution.run_timing_repetitions"
        ),
        "runner_sha256": os.environ["EXPECTED_RUNNER_SHA"],
        "warmups": 10,
        "measurements": 100,
        "order_seed": 20260728,
        "reuse_successful": True,
    },
    "completion": {
        "replication_count": 10,
        "successful_replication_count": 10,
        "failed_replication_count": 0,
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "instance_count": 60,
        "observation_rows_per_replication": 15180,
        "total_observation_rows": total_rows,
        "timing_output_file_count": 40,
        "timing_output_total_bytes": total_bytes,
        "execution_log_count": 10,
        "explicit_failure_count": explicit_failure_count,
        "consistent_csv_schema": True,
        "finite_numeric_values": True,
        "runs": run_rows,
    },
    "canonical_run_file_manifest": {
        "path": run_manifest_path.relative_to(root).as_posix(),
        "sha256": sha(run_manifest_path),
        "line_count": 40,
    },
    "scientific_controls": {
        "timing_execution_performed": True,
        "timing_execution_completion_audited": True,
        "timing_values_interpreted": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "scientific_freeze_performed": False,
        "manuscript_modified": False,
    },
    "authorization_decision": {
        "timing_evidence_commit_authorized": True,
        "precision_setup_authorized_after_merge": True,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "scientific_freeze_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
    "next_stage": (
        "commit_and_merge_sa5_objective_count_stage10_timing_evidence"
    ),
}

evidence_path.write_text(
    json.dumps(
        evidence,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

planning = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-timing-execution-report-v1"
    ),
    "status": "timing_execution_evidence_materialized",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "timing_execution_evidence": {
        "path": evidence_path.relative_to(root).as_posix(),
        "sha256": sha(evidence_path),
    },
    "canonical_run_file_manifest": {
        "path": run_manifest_path.relative_to(root).as_posix(),
        "sha256": sha(run_manifest_path),
    },
    "replication_count": 10,
    "successful_replication_count": 10,
    "failed_replication_count": 0,
    "total_observation_rows": total_rows,
    "timing_output_file_count": 40,
    "timing_output_total_bytes": total_bytes,
    "execution_log_count": 10,
    "total_execution_elapsed_seconds": int(
        os.environ["TOTAL_ELAPSED"]
    ),
    "timing_execution_performed": True,
    "timing_execution_completion_audited": True,
    "timing_values_interpreted": False,
    "precision_analysis_performed": False,
    "bootstrap_analysis_performed": False,
    "scientific_result_interpretation_performed": False,
    "manuscript_modified": False,
    "blockers": [],
    "blocker_count": 0,
    "report_complete": True,
    "next_stage": (
        "wait_for_ci_then_merge_sa5_objective_count_stage10_timing_evidence"
    ),
}

planning_report_path.write_text(
    json.dumps(
        planning,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

planning_summary_path.write_text(
    "\n".join([
        "# SA5 objective-count Stage-10 timing execution",
        "",
        "- Replications: `10/10 PASS`",
        "- Factor levels: `1, 2, 5, 10, 20, 50`",
        "- Warmups: `10`",
        "- Measurements: `100`",
        "- Order seed: `20260728`",
        "- Total timing observations: `151800`",
        "- Timing output files: `40`",
        f"- Timing output bytes: `{total_bytes}`",
        "- Execution logs: `10`",
        "- Explicit failures: `0`",
        "- Timing execution: `performed and completion-audited`",
        "- Timing-value interpretation: `not performed`",
        "- Precision analysis: `not performed`",
        "- Bootstrap analysis: `not performed`",
        "- Manuscript modification: `not performed`",
        "",
        "Next stage: review and merge this timing-evidence-only change.",
        "",
    ]),
    encoding="utf-8",
)

print("timing_output_audit=PASS")
print("successful_replication_count=10")
print("failed_replication_count=0")
print("total_observation_rows=151800")
print("timing_output_file_count=40")
print(f"timing_output_total_bytes={total_bytes}")
print("execution_log_count=10")
print("explicit_failure_count=0")
print("consistent_csv_schema=true")
print("finite_numeric_values=true")
print(f"run_file_manifest={run_manifest_path}")
print(f"run_file_manifest_sha256={sha(run_manifest_path)}")
print(f"evidence_manifest={evidence_path}")
print(f"evidence_manifest_sha256={sha(evidence_path)}")
print(f"planning_report={planning_report_path}")
print(f"planning_report_sha256={sha(planning_report_path)}")
print(f"planning_summary={planning_summary_path}")
print(f"planning_summary_sha256={sha(planning_summary_path)}")
PY

test "$(wc -l < "$RUN_FILE_MANIFEST")" -eq 40
sha256sum -c "$RUN_FILE_MANIFEST" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_stage10_timing_execution_complete_and_audited"
  and .source_commit
    == "20dfec11a502cc0fccbcc07f6e2df0734debe29c"
  and .completion.replication_count == 10
  and .completion.successful_replication_count == 10
  and .completion.failed_replication_count == 0
  and .completion.total_observation_rows == 151800
  and .completion.timing_output_file_count == 40
  and .completion.execution_log_count == 10
  and .completion.explicit_failure_count == 0
  and .completion.consistent_csv_schema == true
  and .completion.finite_numeric_values == true
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.timing_execution_completion_audited == true
  and .scientific_controls.timing_values_interpreted == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.scientific_result_interpretation_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization_decision.timing_evidence_commit_authorized == true
  and .authorization_decision.precision_setup_authorized_after_merge == true
  and .authorization_decision.precision_analysis_authorized == false
  and .blocker_count == 0
  and .audit_complete == true
' "$EVIDENCE_MANIFEST" >/dev/null

echo "timing_evidence_validation=PASS"

echo
echo "=== 5. Repository and manuscript control before persistence ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
verify_sha "$RUNNER_FILE" "$EXPECTED_RUNNER_SHA"

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "pre_persistence_immutability_gate=PASS"
echo "manuscript_modified=false"

echo
echo "=== 6. Create one Timing Evidence branch and exact commit ==="

git switch -c "$BRANCH"

{
  awk '{print $2}' "$RUN_FILE_MANIFEST"
  find "$EVIDENCE_ROOT" -type f
  printf '%s\n' "$PLANNING_REPORT" "$PLANNING_SUMMARY"
} |
  sort -u > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 54

mapfile -t GENERATED_FILES < "$TMP_ROOT/expected_files.txt"
git add -f -- "${GENERATED_FILES[@]}"

git diff --cached --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 54
test -z "$(git diff --name-only)"

git commit \
  -m "evidence(experiments): persist SA5 objective-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git diff-tree --no-commit-id --name-only -r "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/committed_files.txt"

echo "timing_evidence_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=54"

echo
echo "=== 7. Push and create one Timing Evidence PR ==="

git push -u origin "$BRANCH"

EVIDENCE_SHA="$(sha256sum "$EVIDENCE_MANIFEST" | awk '{print $1}')"
RUN_FILES_SHA="$(sha256sum "$RUN_FILE_MANIFEST" | awk '{print $1}')"
REPORT_SHA="$(sha256sum "$PLANNING_REPORT" | awk '{print $1}')"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Persist SA5 objective-count Stage-10 timing evidence" \
    --body-file - <<EOF
## Timing Execution

- 10/10 successful timing replications
- 6 objective-count levels per replication
- warmups: 10
- measurements: 100
- order seed: 20260728
- 151,800 total timing observations
- 40 timing-output files
- 10 execution logs
- 0 explicit failures
- consistent CSV schema
- finite numeric values

## Provenance

- source commit: \`$EXPECTED_HEAD\`
- timing evidence SHA-256: \`$EVIDENCE_SHA\`
- timing run-file manifest SHA-256: \`$RUN_FILES_SHA\`
- timing execution report SHA-256: \`$REPORT_SHA\`

## Scientific control

Timing execution and completion audit are complete. Timing values have not been interpreted. Precision analysis, bootstrap analysis, scientific interpretation, scientific freeze, and manuscript integration have not been performed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

gh pr view "$PR_NUMBER" \
  --repo "$REPO" \
  --json state,isDraft,headRefOid,headRefName,baseRefName,title |
jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Persist SA5 objective-count Stage-10 timing evidence"
  ' >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 54

echo "timing_evidence_push=PASS"
echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"
echo "pr_file_count=54"

echo
echo "=== 8. Final state ==="

echo "sa5_objective_count_stage10_timing_execution=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "warmups=10"
echo "measurements=100"
echo "order_seed=20260728"
echo "successful_replication_count=10"
echo "failed_replication_count=0"
echo "total_observation_rows=151800"
echo "timing_output_file_count=40"
echo "execution_log_count=10"
echo "committed_file_count=54"

echo "evidence_manifest=$EVIDENCE_MANIFEST"
echo "evidence_manifest_sha256=$EVIDENCE_SHA"
echo "run_file_manifest=$RUN_FILE_MANIFEST"
echo "run_file_manifest_sha256=$RUN_FILES_SHA"
echo "planning_report=$PLANNING_REPORT"
echo "planning_report_sha256=$REPORT_SHA"

echo "timing_execution_performed=true"
echo "timing_execution_completion_audited=true"
echo "timing_values_interpreted=false"

echo "precision_setup_authorized_after_merge=true"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_timing_evidence"

git status --short --branch
git log --oneline --decorate -5
