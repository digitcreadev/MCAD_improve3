#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=9

BASE="paper/phase3-controlled-execution"
BRANCH="paper/audit-virtual-node-count-stage10-functional-20260802T145136Z"
EXPECTED_HEAD="3d1c6ad370f6b8612a46b362e54d2683e59187f4"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TEST_REL="backend/harness/sensitivity_execution/tests/test_virtual_node_count_stage10_common_workloads.py"

REPORT_REL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"

trap \
  'echo "[ERROR] Script stopped at line $LINENO."' \
  ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

CURRENT_BRANCH="$(git branch --show-current)"
CURRENT_HEAD="$(git rev-parse HEAD)"

echo "branch=$CURRENT_BRANCH"
echo "head=$CURRENT_HEAD"

test "$CURRENT_BRANCH" = "$BRANCH"
test "$CURRENT_HEAD" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$TEST_REL"
test -x "$PYTHON"

echo "recovery_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"

echo
echo "=== 2. Make preparation test stage-scoped ==="

"$PYTHON" - "$TEST_REL" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

old_name = "test_no_execution_or_timing_was_performed"
new_name = (
    "test_preparation_recorded_no_execution_or_timing"
)

old_node = next(
    (
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == old_name
    ),
    None,
)

new_node = next(
    (
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == new_name
    ),
    None,
)

if old_node is None:
    if new_node is not None:
        print("stage_scoped_test_patch=ALREADY_APPLIED")
        raise SystemExit(0)

    raise SystemExit(
        f"Target test function not found: {old_name}"
    )

replacement = '''def test_preparation_recorded_no_execution_or_timing() -> None:
    """Validate the preparation-stage audit, not later repository state."""
    report = load_json(
        AUDIT_ROOT
        / "stage10_common_workload_audit.json"
    )

    # These fields describe what the workload-preparation stage did.
    # Later, separately authorized functional executions may legitimately
    # create run directories without invalidating this historical audit.
    assert (
        report["functional_execution_performed"]
        is False
    )
    assert report["timing_execution_performed"] is False
    assert (
        report["new_functional_execution_authorized"]
        is False
    )
    assert (
        report["formal_timing_execution_authorized"]
        is False
    )
'''

lines = source.splitlines(keepends=True)

start = old_node.lineno - 1
end = old_node.end_lineno

lines[start:end] = [replacement]

updated = "".join(lines)
ast.parse(updated)

path.write_text(
    updated,
    encoding="utf-8",
)

print("stage_scoped_test_patch=PASS")
print(
    "removed_invalid_global_run_directory_assertion=true"
)
PY

echo
echo "=== 3. Focused regression ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" -m pytest \
    "$TEST_REL" \
    -q \
    -p no:cacheprovider

echo
echo "=== 4. Exact CI regression suite ==="

PYTHONPATH="$ROOT" \
PYTHONDONTWRITEBYTECODE=1 \
PYTHONHASHSEED=0 \
MPLBACKEND=Agg \
  "$PYTHON" -m pytest \
    backend/harness/sensitivity_execution/tests \
    -q \
    -p no:cacheprovider

echo "local_ci_equivalent_suite=PASS"

echo
echo "=== 5. Commit and push CI fix ==="

git add "$TEST_REL"
git diff --cached --check

git commit \
  -m "fix(tests): scope Stage-10 preparation assertions"

FIX_COMMIT="$(git rev-parse HEAD)"

git push origin "$BRANCH"

echo "fix_commit=$FIX_COMMIT"
echo "push=PASS"

echo
echo "=== 6. Verify PR head update ==="

PR_HEAD="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json headRefOid \
    --jq '.headRefOid'
)"

echo "pr_head=$PR_HEAD"

test "$PR_HEAD" = "$FIX_COMMIT"

echo "pr_head_update=PASS"

echo
echo "=== 7. Wait for the replacement CI check ==="

CHECK_COUNT=0

for ATTEMPT in $(seq 1 36); do
  CHECK_JSON="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if [ -n "$CHECK_JSON" ]; then
    CHECK_COUNT="$(
      jq 'length' <<<"$CHECK_JSON"
    )"
  else
    CHECK_COUNT=0
  fi

  echo \
    "check_discovery_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 5
done

test "$CHECK_COUNT" -gt 0

gh pr checks "$PR" \
  --repo "$REPO" \
  --watch \
  --interval 10

echo "replacement_ci=PASS"

echo
echo "=== 8. Final merge gate ==="

MERGE_READY=0

for ATTEMPT in $(seq 1 12); do
  PR_DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
  PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
  PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
  MERGE_STATE="$(
    jq -r '.mergeStateStatus' <<<"$PR_DATA"
  )"

  echo \
    "merge_gate_attempt=$ATTEMPT " \
    "state=$PR_STATE " \
    "head=$PR_HEAD " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$PR_STATE" = "OPEN" ] \
     && [ "$PR_HEAD" = "$FIX_COMMIT" ] \
     && [ "$PR_BASE" = "$BASE" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    MERGE_READY=1
    break
  fi

  sleep 5
done

test "$MERGE_READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 9. Merge PR #9 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 10. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

echo "base_head=$BASE_HEAD"

git merge-base --is-ancestor \
  "$FIX_COMMIT" \
  "$BASE_HEAD"

echo
echo "=== 11. Verify merged scientific result ==="

"$PYTHON" - "$REPORT_REL" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

if not path.is_file():
    raise SystemExit(
        f"Missing completion report: {path}"
    )

report = json.loads(
    path.read_text(encoding="utf-8")
)

expected = {
    "status": "pass",
    "replication_count": 10,
    "instance_count": 30,
    "functional_step_count": 60,
    "all_replications_passed": True,
    "timing_execution_performed": False,
    "timing_artifact_count": 0,
    "latency_claim_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

prefix = report.get("historical_prefix", {})

if prefix.get("reused") is not True:
    raise SystemExit(
        "Historical prefix must be marked reused."
    )

if prefix.get("rerun_performed") is not False:
    raise SystemExit(
        "Historical prefix must not be marked rerun."
    )

print("merged_functional_completion_report=PASS")
print("replication_count=10")
print("instance_count=30")
print("functional_step_count=60")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 12. Cleanup local feature branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 13. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "pr9_ci_fix_and_merge=PASS"
echo "fix_commit=$FIX_COMMIT"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "instance_count=30"
echo "functional_step_count=60"
echo "historical_prefix_rerun_performed=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=prepare_stage10_formal_timing_authorization"

git status --short --branch
git log --oneline --decorate -5
