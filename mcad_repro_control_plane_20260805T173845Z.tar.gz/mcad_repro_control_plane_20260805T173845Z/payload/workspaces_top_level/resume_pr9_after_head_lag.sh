#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=9

BASE="paper/phase3-controlled-execution"
BRANCH="paper/audit-virtual-node-count-stage10-functional-20260802T145136Z"
FIX_COMMIT="644eacd62c4dd7b9b4c43f727e5c881b4798093c"

REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"

trap 'echo "[ERROR] Continuation stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$FIX_COMMIT"
test -z "$(git status --porcelain)"

echo "branch=$BRANCH"
echo "head=$FIX_COMMIT"
echo "local_recovery_gate=PASS"
echo "tests_rerun=false"
echo "functional_execution_rerun=false"
echo "timing_execution=false"

echo
echo "=== 2. Wait for PR head propagation ==="

PR_HEAD=""

for ATTEMPT in $(seq 1 60); do
  PR_HEAD="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json headRefOid \
      --jq '.headRefOid'
  )"

  echo "head_poll_attempt=$ATTEMPT pr_head=$PR_HEAD"

  if [ "$PR_HEAD" = "$FIX_COMMIT" ]; then
    break
  fi

  sleep 5
done

test "$PR_HEAD" = "$FIX_COMMIT"

echo "pr_head_propagation=PASS"

echo
echo "=== 3. Wait for CI run attached to new commit ==="

RUN_ID=""

for ATTEMPT in $(seq 1 60); do
  RUNS="$(
    gh run list \
      --repo "$REPO" \
      --branch "$BRANCH" \
      --event pull_request \
      --limit 20 \
      --json databaseId,headSha,name,status,conclusion,url
  )"

  RUN_ID="$(
    jq -r \
      --arg sha "$FIX_COMMIT" \
      '
      [
        .[]
        | select(
            .headSha == $sha
            and .name == "Phase 3 regression"
          )
      ]
      | first
      | .databaseId // ""
      ' <<<"$RUNS"
  )"

  echo "ci_discovery_attempt=$ATTEMPT run_id=$RUN_ID"

  if [ -n "$RUN_ID" ]; then
    break
  fi

  sleep 5
done

test -n "$RUN_ID"

echo "replacement_ci_run_id=$RUN_ID"

echo
echo "=== 4. Wait for replacement CI result ==="

gh run watch "$RUN_ID" \
  --repo "$REPO" \
  --interval 10 \
  --exit-status

RUN_DATA="$(
  gh run view "$RUN_ID" \
    --repo "$REPO" \
    --json headSha,status,conclusion,name,url
)"

RUN_HEAD="$(jq -r '.headSha' <<<"$RUN_DATA")"
RUN_STATUS="$(jq -r '.status' <<<"$RUN_DATA")"
RUN_CONCLUSION="$(jq -r '.conclusion' <<<"$RUN_DATA")"

echo "ci_head=$RUN_HEAD"
echo "ci_status=$RUN_STATUS"
echo "ci_conclusion=$RUN_CONCLUSION"

test "$RUN_HEAD" = "$FIX_COMMIT"
test "$RUN_STATUS" = "completed"
test "$RUN_CONCLUSION" = "success"

echo "replacement_ci=PASS"

echo
echo "=== 5. Final PR merge gate ==="

MERGE_READY=0

for ATTEMPT in $(seq 1 30); do
  PR_DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  PR_STATE="$(jq -r '.state' <<<"$PR_DATA")"
  PR_HEAD="$(jq -r '.headRefOid' <<<"$PR_DATA")"
  PR_BASE="$(jq -r '.baseRefName' <<<"$PR_DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$PR_DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$PR_DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$PR_DATA")"

  echo \
    "merge_poll_attempt=$ATTEMPT " \
    "state=$PR_STATE " \
    "head=$PR_HEAD " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$PR_STATE" = "OPEN" ] \
     && [ "$PR_HEAD" = "$FIX_COMMIT" ] \
     && [ "$PR_BASE" = "$BASE" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    MERGE_READY=1
    break
  fi

  sleep 5
done

test "$MERGE_READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 6. Merge PR #9 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 7. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$FIX_COMMIT" \
  "$BASE_HEAD"

echo "base_head=$BASE_HEAD"
echo "fix_commit_is_ancestor=PASS"

echo
echo "=== 8. Verify merged scientific report ==="

python - "$REPORT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])

if not path.is_file():
    raise SystemExit(f"Missing report: {path}")

report = json.loads(
    path.read_text(encoding="utf-8")
)

expected = {
    "status": "pass",
    "replication_count": 10,
    "instance_count": 30,
    "functional_step_count": 60,
    "all_replications_passed": True,
    "timing_execution_performed": False,
    "timing_artifact_count": 0,
    "latency_claim_authorized": False,
}

for key, expected_value in expected.items():
    actual = report.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"{key}: expected {expected_value!r}, "
            f"got {actual!r}"
        )

prefix = report["historical_prefix"]

if prefix["reused"] is not True:
    raise SystemExit("Historical prefix is not marked reused.")

if prefix["rerun_performed"] is not False:
    raise SystemExit("Historical prefix is marked rerun.")

print("merged_functional_completion_report=PASS")
print("replication_count=10")
print("instance_count=30")
print("functional_step_count=60")
print("historical_prefix_rerun_performed=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 9. Cleanup local feature branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 10. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "pr9_ci_fix_and_merge=PASS"
echo "fix_commit=$FIX_COMMIT"
echo "base_head=$BASE_HEAD"
echo "replication_count=10"
echo "instance_count=30"
echo "functional_step_count=60"
echo "historical_prefix_rerun_performed=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=prepare_stage10_formal_timing_authorization"

git status --short --branch
git log --oneline --decorate -5
