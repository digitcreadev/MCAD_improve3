#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="791dade992f0de8ed80f5f675ebda0cef7654b1d"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"

PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_stage10"
STATUS_JSON="$PACKAGE/STATUS.json"
FREEZE_JSON="$PACKAGE/freeze/FREEZE.json"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/membership_density/timing_stage10/precision_analysis"

DECISION="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.json"
ANALYZER_LOG="$PRECISION_ROOT/analyzer.log"

ARCHIVE="$PACKAGE/archive/membership_density_stage10_canonical_20260804T161119Z.tar.gz"

EXPECTED_ARCHIVE_SHA="1729d7913e68407f754804c9d23468559e0eeefbf616e8f7ecc6be5fab940ffc"
EXPECTED_DECISION_SHA="92a9307a89e92c5e849b0e058f5e0a3c89633f6f8cd39f98ec9a2b9392cc88a4"
EXPECTED_ANALYZER_LOG_SHA="019472284afb9cdca6bd24b0f0b77df85e50a2806a2169d50dc4e2392e8b0f88"

SECTION_LABEL="subsec:sa4-membership-density"
TABLE_LABEL="tab:membership-density-stage10"
INSERTION_ANCHOR='\section{Discussion, limites et perspectives}'

trap 'echo "[ERROR] Manuscript integration stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Manuscript integration gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$MANUSCRIPT" \
  "$STATUS_JSON" \
  "$FREEZE_JSON" \
  "$REGISTRY" \
  "$DECISION" \
  "$ANALYZER_LOG" \
  "$ARCHIVE"
do
  test -f "$FILE"
done

test "$(sha256sum "$ARCHIVE" | awk '{print $1}')" \
  = "$EXPECTED_ARCHIVE_SHA"

test "$(sha256sum "$DECISION" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

test "$(sha256sum "$ANALYZER_LOG" | awk '{print $1}')" \
  = "$EXPECTED_ANALYZER_LOG_SHA"

jq -e '
  .campaign_id == "sa4_membership_density_stage10"
  and .status == "completed_precision_targets_met"
  and .factor == "membership_density"
  and .stage == 10
  and .run_count == 10
  and .measurement_observation_count == 92000
  and .successful_bootstrap_execution_count == 1
  and .all_precision_targets_met == true
  and .failing_cell_count == 0
  and .stage10_sufficient == true
  and .stage20_extension_required == false
  and .scientific_freeze == true
  and .latency_claim_authorized == true
  and .manuscript_resume_authorized == true
  and .global_scientific_freeze == false
' "$STATUS_JSON" >/dev/null

jq -e '
  .freeze_status == "frozen"
  and .factor == "membership_density"
  and .immutability.canonical_timing_rerun_allowed == false
  and .immutability.canonical_adapter_rematerialization_allowed == false
  and .immutability.canonical_bootstrap_rerun_allowed == false
  and .immutability.canonical_evidence_modification_allowed == false
  and .publication_controls.scientific_freeze == true
  and .publication_controls.latency_claim_authorized == true
  and .publication_controls.manuscript_resume_authorized == true
  and .publication_controls.global_scientific_freeze == false
' "$FREEZE_JSON" >/dev/null

jq -e '
  .status == "pass"
  and .factor == "membership_density"
  and .analysis_contract.factor_levels == [25, 50, 75, 100]
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .analysis_contract.confidence_level == 0.95
  and .analysis_contract.median_relative_half_width_target == 0.10
  and .analysis_contract.p95_relative_half_width_target == 0.15
  and .precision_decision.all_median_targets_met == true
  and .precision_decision.all_p95_targets_met == true
  and .precision_decision.all_precision_targets_met == true
  and .precision_decision.failing_cell_count == 0
  and .precision_decision.stage10_sufficient == true
  and .precision_decision.stage20_extension_required == false
' "$DECISION" >/dev/null

test "$(
  grep -Fc "$INSERTION_ANCHOR" "$MANUSCRIPT"
)" -eq 1

test "$(
  grep -Fc "\\label{$SECTION_LABEL}" "$MANUSCRIPT" || true
)" -eq 0

test "$(
  grep -Fc "\\label{$TABLE_LABEL}" "$MANUSCRIPT" || true
)" -eq 0

grep -A4 '^global_state:' "$REGISTRY" |
  grep -F '  global_scientific_freeze: false' >/dev/null

grep -A4 '^global_state:' "$REGISTRY" |
  grep -F '  latency_claim_authorized: false' >/dev/null

grep -A4 '^global_state:' "$REGISTRY" |
  grep -F '  manuscript_resume_authorized: false' >/dev/null

echo "manuscript_integration_gate=PASS"
echo "manuscript=$MANUSCRIPT"
echo "campaign_scientific_freeze=true"
echo "campaign_latency_claim_authorized=true"
echo "campaign_manuscript_resume_authorized=true"
echo "global_scientific_freeze=false"
echo "scientific_execution_performed=false"
echo "bootstrap_rerun_performed=false"

echo
echo "=== 2. Create manuscript-integration branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/integrate-membership-density-stage10-manuscript-${STAMP}"
BUILD_ROOT="/workspaces/membership_density_manuscript_build_${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

rm -rf "$BUILD_ROOT"
mkdir -p "$BUILD_ROOT"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"
echo "build_root=$BUILD_ROOT"

echo
echo "=== 3. Generate and apply exact manuscript patch ==="

python3 - \
  "$ROOT" \
  "$MANUSCRIPT" \
  "$DECISION" \
  "$ANALYZER_LOG" \
  "$BUILD_ROOT" \
  "$INSERTION_ANCHOR" \
  "$SECTION_LABEL" \
  "$TABLE_LABEL" <<'PY'
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
manuscript_path = (root / sys.argv[2]).resolve()
decision_path = (root / sys.argv[3]).resolve()
log_path = (root / sys.argv[4]).resolve()
build_root = Path(sys.argv[5]).resolve()

anchor = sys.argv[6]
section_label = sys.argv[7]
table_label = sys.argv[8]


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


decision = load_object(decision_path)

if decision.get("factor") != "membership_density":
    raise SystemExit("Canonical factor mismatch.")

if decision.get("status") != "pass":
    raise SystemExit("Canonical decision is not PASS.")

precision = decision.get("precision_decision", {})

if precision.get("all_precision_targets_met") is not True:
    raise SystemExit("Not all precision targets were met.")

if precision.get("failing_cell_count") != 0:
    raise SystemExit("Canonical decision contains failing cells.")

log_pattern = re.compile(
    r"^level=(?P<level>\d+)"
    r"\s+step=0"
    r"\s+median_ms=(?P<median>[0-9.]+)"
    r"\s+median_rhw=(?P<median_rhw>[0-9.]+)"
    r"\s+median_pass=true"
    r"\s+p95_ms=(?P<p95>[0-9.]+)"
    r"\s+p95_rhw=(?P<p95_rhw>[0-9.]+)"
    r"\s+p95_pass=true$"
)

rows: list[dict[str, Any]] = []

for line in log_path.read_text(
    encoding="utf-8"
).splitlines():
    match = log_pattern.fullmatch(line.strip())

    if match is None:
        continue

    rows.append({
        "level": int(match.group("level")),
        "median_ms": float(match.group("median")),
        "p95_ms": float(match.group("p95")),
        "median_rhw": float(match.group("median_rhw")),
        "p95_rhw": float(match.group("p95_rhw")),
    })

rows.sort(key=lambda item: item["level"])

if [row["level"] for row in rows] != [25, 50, 75, 100]:
    raise SystemExit(
        f"Unexpected analyzer-log levels: "
        f"{[row['level'] for row in rows]}"
    )

canonical_cells = {
    int(cell["factor_level"]): cell
    for cell in decision["cell_results"]
}

for row in rows:
    cell = canonical_cells.get(row["level"])

    if cell is None:
        raise SystemExit(
            f"Missing canonical cell for level {row['level']}."
        )

    for source_key, decision_key in (
        ("median_rhw", "median_relative_half_width"),
        ("p95_rhw", "p95_relative_half_width"),
    ):
        if not math.isclose(
            row[source_key],
            float(cell[decision_key]),
            rel_tol=0,
            abs_tol=1.0e-6,
        ):
            raise SystemExit(
                f"Log/decision mismatch for level "
                f"{row['level']} and {source_key}."
            )

    if cell.get("median_target_met") is not True:
        raise SystemExit("Median precision target failed.")

    if cell.get("p95_target_met") is not True:
        raise SystemExit("p95 precision target failed.")

median_change_percent = (
    rows[-1]["median_ms"] / rows[0]["median_ms"] - 1.0
) * 100.0

p95_change_percent = (
    rows[-1]["p95_ms"] / rows[0]["p95_ms"] - 1.0
) * 100.0

table_lines = []

for row in rows:
    table_lines.append(
        f"{row['level']}\\% & "
        f"{row['median_ms']:.6f} & "
        f"{row['p95_ms']:.6f} & "
        f"{row['median_rhw']:.6f} & "
        f"{row['p95_rhw']:.6f} \\\\"
    )

section = "\n".join([
    (
        "\\subsection{Sensibilité à la densité "
        "d'appartenance des ensembles d'exigences}"
    ),
    f"\\label{{{section_label}}}",
    "",
    (
        "Nous avons complété l'analyse de sensibilité structurelle "
        "par une campagne contrôlée faisant varier la densité "
        "d'appartenance des ensembles d'exigences. Cette densité "
        "correspond au rapport entre les liens d'appartenance "
        "effectivement présents et le maximum admissible, calculé "
        "localement pour chaque contrainte. Le protocole OFAT "
        "maintient quatre contraintes et 24 nœuds virtuels, puis "
        "évalue les niveaux 25\\%, 50\\%, 75\\% et 100\\% sur dix "
        "graines structurelles. Les charges canoniques sont "
        "partagées entre les niveaux d'une même réplication afin "
        "d'isoler l'effet de la densité."
    ),
    "",
    (
        "L'analyse repose sur 92\\,000 observations temporelles. "
        "La précision a été évaluée par un bootstrap groupé de "
        "10\\,000 réplications, avec la graine 20260728 et un "
        "niveau de confiance de 95\\%. Les seuils préenregistrés "
        "imposaient une demi-largeur relative (RHW) inférieure ou "
        "égale à 0,10 pour la médiane et à 0,15 pour le "
        "95\\ieme{} percentile. Les huit contrôles correspondants "
        "sont satisfaits et aucune cellule inférentielle n'échoue."
    ),
    "",
    "\\begin{table}[t]",
    "\\caption{Sensibilité temporelle à la densité d'appartenance.}",
    f"\\label{{{table_label}}}",
    "\\centering",
    "\\scriptsize",
    "\\setlength{\\tabcolsep}{3pt}",
    "\\begin{tabular}{r r r r r}",
    "\\hline",
    (
        "Densité & Médiane & p95 & RHW méd. & RHW p95 \\\\"
    ),
    " & (ms) & (ms) & & \\\\",
    "\\hline",
    *table_lines,
    "\\hline",
    "\\end{tabular}",
    "\\end{table}",
    "",
    (
        "La médiane passe de "
        f"{rows[0]['median_ms']:.6f}\\,ms à "
        f"{rows[-1]['median_ms']:.6f}\\,ms entre 25\\% et 100\\% "
        "de densité, soit une variation relative de "
        f"{median_change_percent:.2f}\\%. Le 95\\ieme{{}} "
        "percentile passe de "
        f"{rows[0]['p95_ms']:.6f}\\,ms à "
        f"{rows[-1]['p95_ms']:.6f}\\,ms, soit "
        f"{p95_change_percent:.2f}\\%. Dans le périmètre contrôlé "
        "de cette campagne, ces résultats indiquent donc une "
        "stabilité temporelle empirique lorsque la densité "
        "d'appartenance augmente."
    ),
    "",
    (
        "Cette conclusion reste limitée aux instances, charges et "
        "environnement du prototype étudié. Elle ne démontre ni "
        "une invariance universelle de la latence ni un gel "
        "scientifique global de l'article. Le gel scientifique et "
        "l'autorisation des revendications temporelles portent "
        "uniquement sur cette campagne SA4."
    ),
    "",
])

text = manuscript_path.read_text(encoding="utf-8")

if text.count(anchor) != 1:
    raise SystemExit(
        f"Expected one insertion anchor, got {text.count(anchor)}."
    )

if f"\\label{{{section_label}}}" in text:
    raise SystemExit("Membership-density section already exists.")

updated = text.replace(
    anchor,
    section + "\n" + anchor,
    1,
)

manuscript_path.write_text(
    updated,
    encoding="utf-8",
)

integration_report = {
    "schema_version": (
        "mcad-membership-density-manuscript-integration-v1"
    ),
    "manuscript": manuscript_path.relative_to(root).as_posix(),
    "section_label": section_label,
    "table_label": table_label,
    "factor": "membership_density",
    "factor_levels": [row["level"] for row in rows],
    "measurement_observation_count": 92000,
    "structural_seed_count": 10,
    "bootstrap_repetitions": 10000,
    "bootstrap_seed": 20260728,
    "confidence_level": 0.95,
    "median_relative_half_width_target": 0.10,
    "p95_relative_half_width_target": 0.15,
    "all_precision_targets_met": True,
    "failing_cell_count": 0,
    "stage10_sufficient": True,
    "stage20_extension_required": False,
    "median_change_percent_25_to_100": (
        median_change_percent
    ),
    "p95_change_percent_25_to_100": (
        p95_change_percent
    ),
    "campaign_scientific_freeze": True,
    "campaign_latency_claim_authorized": True,
    "global_scientific_freeze": False,
    "global_latency_claim_authorized": False,
    "global_manuscript_resume_authorized": False,
    "scientific_execution_performed": False,
    "bootstrap_rerun_performed": False,
    "rows": rows,
}

(build_root / "integration_report.json").write_text(
    json.dumps(
        integration_report,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

(build_root / "inserted_section.tex").write_text(
    section,
    encoding="utf-8",
)

print("exact_manuscript_patch=PASS")
print("manuscript=MCAD_audited_real_main_fr.tex")
print("inserted_section_count=1")
print("inserted_table_count=1")
print("factor_level_count=4")
print("measurement_observation_count=92000")
print("all_precision_targets_met=true")
print("failing_cell_count=0")
print(
    f"median_change_percent_25_to_100="
    f"{median_change_percent:.6f}"
)
print(
    f"p95_change_percent_25_to_100="
    f"{p95_change_percent:.6f}"
)
print("global_scientific_freeze=false")
PY

echo
echo "=== 4. Validate manuscript content ==="

test "$(
  grep -Fc "\\label{$SECTION_LABEL}" "$MANUSCRIPT"
)" -eq 1

test "$(
  grep -Fc "\\label{$TABLE_LABEL}" "$MANUSCRIPT"
)" -eq 1

for VALUE in \
  '0.456054' \
  '0.897460' \
  '0.459504' \
  '0.907403' \
  '0.462777' \
  '0.910817' \
  '0.465190' \
  '0.916927' \
  '92\,000' \
  '10\,000'
do
  grep -F "$VALUE" "$MANUSCRIPT" >/dev/null
done

grep -F \
  "Elle ne démontre ni une invariance universelle de la latence ni un gel scientifique global de l'article." \
  "$MANUSCRIPT" >/dev/null

grep -F \
  "uniquement sur cette campagne SA4" \
  "$MANUSCRIPT" >/dev/null

CHANGED_FILES="$(
  git diff --name-only
)"

CHANGED_FILE_COUNT="$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 1
test "$CHANGED_FILES" = "$MANUSCRIPT"

git diff --check -- "$MANUSCRIPT"

echo "manuscript_content_validation=PASS"
echo "changed_file_count=1"
echo "scientific_execution_performed=false"
echo "bootstrap_rerun_performed=false"

echo
echo "=== 5. Compile manuscript in detached output directory ==="

COMPILE_STATUS="NOT_AVAILABLE"
COMPILE_LOG="$BUILD_ROOT/latex_compile.log"

if command -v latexmk >/dev/null 2>&1; then
  set +e

  latexmk \
    -pdf \
    -interaction=nonstopmode \
    -halt-on-error \
    -file-line-error \
    -outdir="$BUILD_ROOT" \
    "$MANUSCRIPT" \
    >"$COMPILE_LOG" 2>&1

  LATEX_STATUS=$?
  set -e

  if [ "$LATEX_STATUS" -ne 0 ]; then
    tail -n 120 "$COMPILE_LOG"
    echo "[ERROR] latexmk compilation failed."
    exit "$LATEX_STATUS"
  fi

  COMPILE_STATUS="PASS_LATEXMK"

elif command -v pdflatex >/dev/null 2>&1; then
  set +e

  pdflatex \
    -interaction=nonstopmode \
    -halt-on-error \
    -file-line-error \
    -output-directory="$BUILD_ROOT" \
    "$MANUSCRIPT" \
    >"$COMPILE_LOG" 2>&1

  FIRST_STATUS=$?

  if [ "$FIRST_STATUS" -eq 0 ]; then
    pdflatex \
      -interaction=nonstopmode \
      -halt-on-error \
      -file-line-error \
      -output-directory="$BUILD_ROOT" \
      "$MANUSCRIPT" \
      >>"$COMPILE_LOG" 2>&1

    SECOND_STATUS=$?
  else
    SECOND_STATUS="$FIRST_STATUS"
  fi

  set -e

  if [ "$FIRST_STATUS" -ne 0 ] || [ "$SECOND_STATUS" -ne 0 ]; then
    tail -n 120 "$COMPILE_LOG"
    echo "[ERROR] pdflatex compilation failed."
    exit 1
  fi

  COMPILE_STATUS="PASS_PDFLATEX"
fi

if [ "$COMPILE_STATUS" != "NOT_AVAILABLE" ]; then
  PDF="$BUILD_ROOT/${MANUSCRIPT%.tex}.pdf"
  test -s "$PDF"

  echo "compiled_pdf=$PDF"
  echo "compiled_pdf_size_bytes=$(stat -c '%s' "$PDF")"
fi

echo "manuscript_compile_status=$COMPILE_STATUS"

echo
echo "=== 6. Review exact diff ==="

git diff --stat
git diff -- "$MANUSCRIPT"

echo
echo "=== 7. Stage and commit manuscript patch ==="

git add "$MANUSCRIPT"

test "$(
  git diff --cached --name-only | wc -l
)" -eq 1

test "$(
  git diff --cached --name-only
)" = "$MANUSCRIPT"

git diff --cached --check

git commit \
  -m "docs(article): integrate membership-density Stage-10 results"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 8. Push manuscript branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 9. Create pull request ==="

MEDIAN_CHANGE="$(
  jq -r \
    '.median_change_percent_25_to_100' \
    "$BUILD_ROOT/integration_report.json"
)"

P95_CHANGE="$(
  jq -r \
    '.p95_change_percent_25_to_100' \
    "$BUILD_ROOT/integration_report.json"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Integrate membership-density Stage-10 results into manuscript" \
    --body "$(cat <<EOF
## Manuscript integration

Updated:

- \`MCAD_audited_real_main_fr.tex\`.

Added a campaign-specific subsection before the discussion section,
including:

- density levels: \`25%, 50%, 75%, 100%\`;
- structural replications: \`10\`;
- timing observations: \`92,000\`;
- bootstrap repetitions: \`10,000\`;
- bootstrap seed: \`20260728\`;
- confidence level: \`95%\`;
- failing precision cells: \`0\`;
- Stage-10 sufficient: \`true\`;
- Stage-20 extension required: \`false\`.

## Frozen latency values

| Density | Median ms | p95 ms |
|---:|---:|---:|
| 25% | 0.456054 | 0.897460 |
| 50% | 0.459504 | 0.907403 |
| 75% | 0.462777 | 0.910817 |
| 100% | 0.465190 | 0.916927 |

Relative change from 25% to 100%:

- median: \`${MEDIAN_CHANGE}%\`;
- p95: \`${P95_CHANGE}%\`.

## Scope controls

- campaign scientific freeze: \`true\`;
- campaign latency claims authorized: \`true\`;
- global scientific freeze: \`false\`;
- global latency claims authorized: \`false\`;
- scientific re-execution: \`false\`;
- bootstrap rerun: \`false\`.

The manuscript explicitly states that the conclusion is local to the
controlled SA4 campaign and does not establish universal latency
invariance or a global scientific freeze.
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 10. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_stage10_manuscript_integration=PASS"
echo "commit=$COMMIT"
echo "manuscript=$MANUSCRIPT"
echo "changed_file_count=1"
echo "measurement_observation_count=92000"
echo "all_precision_targets_met=true"
echo "failing_cell_count=0"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"
echo "campaign_scientific_freeze=true"
echo "campaign_latency_claim_authorized=true"
echo "global_scientific_freeze=false"
echo "global_latency_claim_authorized=false"
echo "scientific_execution_performed=false"
echo "bootstrap_rerun_performed=false"
echo "manuscript_compile_status=$COMPILE_STATUS"
echo "pull_request=$PR_NUMBER"
echo "next_stage=review_then_merge_membership_density_manuscript_integration"

git status --short --branch
git log --oneline --decorate -4
