#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PR=28

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-sa5-objective-count-stage10-20260804T185827Z"

EXPECTED_BASE_HEAD="496addef55cc60a3303fa1e62a12392be2296ece"
EXPECTED_FEATURE_HEAD="717806cdb0fbc6869976bdbe3e055db443e68a4c"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"

EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_pr28.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 preregistration merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

printf '%s\n' \
  "$PREREG_TEST" \
  "$PREREG" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

echo "=== 1. Local preregistration gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test -z "$(git status --porcelain)"

test -f "$PREREG"
test -f "$PREREG_TEST"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort \
  > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(
  wc -l < "$TMP_ROOT/actual_files.txt"
)" -eq 2

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_preregistration_gate=PASS"
echo "changed_file_count=2"
echo "preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Exact preregistration-content gate ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-campaign-preregistration-v1"
  and .preregistration_id
    == "sa5_objective_count_stage10_c8_nv32"
  and .status
    == "preregistered_not_materialized"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "496addef55cc60a3303fa1e62a12392be2296ece"
  and .implementation_commit
    == "a4f7767b2100c997456b55efce2714da6e29254f"
  and .factor_contract.factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .factor_contract.selected_objective_index == 0
  and .factor_contract.constraints_per_objective == 8
  and .factor_contract.virtual_nodes_per_objective == 32
  and .factor_contract.workload_length == 40
  and .factor_contract.noise_ratio == 0.25
  and .replication_contract.stage == 10
  and .replication_contract.replication_count == 10
  and .replication_contract.level_count == 6
  and .replication_contract.expected_instance_count == 60
  and (
    .replication_contract.structural_seeds
    | length
  ) == 10
  and (
    .replication_contract.structural_seeds
    | unique
    | length
  ) == 10
  and .authorization.preregistration_persistence_authorized
    == true
  and .authorization.campaign_materialization_authorized_now
    == false
  and .authorization.campaign_materialization_authorized_after_preregistration_merge
    == true
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.stage20_execution_authorized
    == false
  and .authorization.latency_claim_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$PREREG" >/dev/null

echo "preregistration_content_gate=PASS"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "selected_objective_index=0"

echo
echo "=== 3. Pre-merge test gate ==="

"$PYTHON" -m py_compile \
  "$PREREG_TEST"

"$PYTHON" -m pytest \
  "$PREREG_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_e3_contract.py \
  -q \
  -p no:cacheprovider

echo "pre_merge_preregistration_tests=PASS"

echo
echo "=== 4. Remote lineage gate ==="

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_BASE_HEAD"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$EXPECTED_FEATURE_HEAD"

echo "remote_lineage_gate=PASS"
echo "remote_base_head=$EXPECTED_BASE_HEAD"
echo "remote_feature_head=$EXPECTED_FEATURE_HEAD"

echo
echo "=== 5. Pull-request identity and scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count Stage-10 campaign"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 6. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' \
  >/dev/null 2>&1 \
  <<<"$CHECKS"
then
  CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$CHECKS"
)"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '
      [
        .[]
        | select(.bucket != "pass")
      ]
      | length
    ' <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "sa5_preregistration_ci=PASS"
else
  echo "sa5_preregistration_ci=NOT_APPLICABLE"
fi

echo
echo "=== 7. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 8. Merge PR #28 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 9. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 10. Post-merge preregistration validation ==="

test -f "$PREREG"
test -f "$PREREG_TEST"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

git ls-files --error-unmatch \
  "$PREREG" >/dev/null

git ls-files --error-unmatch \
  "$PREREG_TEST" >/dev/null

"$PYTHON" -m pytest \
  "$PREREG_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_e3_contract.py \
  -q \
  -p no:cacheprovider

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "post_merge_preregistration_validation=PASS"
echo "preregistration_tracked=true"
echo "canonical_campaign_generated=false"
echo "functional_execution_authorized=false"
echo "timing_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 11. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 12. Cleanup local preregistration branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo
echo "=== 13. Final state ==="

echo "sa5_objective_count_stage10_preregistration_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "selected_objective_index=0"
echo "campaign_materialization_eligible=true"
echo "canonical_campaign_generated=false"
echo "functional_execution_authorized=false"
echo "timing_execution_authorized=false"
echo "precision_analysis_authorized=false"
echo "bootstrap_execution_authorized=false"
echo "stage20_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=materialize_sa5_objective_count_stage10_structure_and_common_workloads"

git status --short --branch
git log --oneline --decorate -5
