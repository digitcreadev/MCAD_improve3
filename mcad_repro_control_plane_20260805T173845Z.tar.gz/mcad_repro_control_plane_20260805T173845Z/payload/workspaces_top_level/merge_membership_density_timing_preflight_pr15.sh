#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=15

BASE="paper/phase3-controlled-execution"
BRANCH="paper/preregister-membership-density-timing-preflight-20260802T190407Z"
EXPECTED_HEAD="c2ac9e1fa41b4237e0bbb9b95011c07bf8d782f8"

PREFLIGHT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_timing_preregistration_preflight.json"

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$PREFLIGHT"

echo "local_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Preflight evidence gate ==="

jq -e '
  .status
    == "membership_density_timing_preregistration_preflight_complete"
  and .structural_contract.stage_size == 10
  and .structural_contract.levels == [25, 50, 75, 100]
  and .workload_balance_audit.available_step_count_histogram
      == {"23": 2, "24": 8}
  and .workload_balance_audit.balanced_local_step_indexes
      == [range(1; 24)]
  and .workload_balance_audit.balanced_step_count == 23
  and .workload_balance_audit.global_query_digest_intersection_count == 0
  and .workload_balance_audit.within_replication_cross_level_equivalence_required
      == true
  and .workload_balance_audit.cross_replication_query_digest_identity_required
      == false
  and .proposed_timing_protocol.timing_cluster_cell_count == 920
  and .proposed_timing_protocol.precision_cell_count == 92
  and .proposed_timing_protocol.warmup_observation_count == 9200
  and .proposed_timing_protocol.measurement_observation_count == 92000
  and .timing_input_materialization.required == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .preflight_decision.formal_timing_preregistration_ready == true
  and .preflight_decision.timing_input_materialization_ready == false
  and .preflight_decision.timing_execution_ready == false
  and .next_stage
      == "formalize_membership_density_timing_preregistration"
' "$PREFLIGHT" >/dev/null

echo "preflight_evidence_gate=PASS"
echo "global_query_digest_intersection_count=0"
echo "cross_replication_query_identity_assumed=false"

echo
echo "=== 3. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 4. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASSING="$(
    jq \
      '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASSING" -eq 0
  echo "timing_preflight_ci=PASS"
else
  echo "timing_preflight_ci=NOT_APPLICABLE"
fi

echo
echo "=== 5. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 6. Merge PR #15 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 7. Update base ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "preflight_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 8. Verify merged preflight ==="

test -f "$PREFLIGHT"

jq -e '
  .status
    == "membership_density_timing_preregistration_preflight_complete"
  and .workload_balance_audit.balanced_step_count == 23
  and .workload_balance_audit.global_query_digest_intersection_count == 0
  and .workload_balance_audit.cross_replication_query_digest_identity_required
      == false
  and .proposed_timing_protocol.timing_cluster_cell_count == 920
  and .proposed_timing_protocol.precision_cell_count == 92
  and .proposed_timing_protocol.measurement_observation_count == 92000
  and .timing_input_materialization.required == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "formalize_membership_density_timing_preregistration"
' "$PREFLIGHT" >/dev/null

echo "merged_timing_preflight=PASS"
echo "balanced_timing_step_count=23"
echo "global_query_digest_intersection_count=0"
echo "cross_replication_query_identity_assumed=false"
echo "timing_cluster_cell_count=920"
echo "precision_cell_count=92"
echo "measurement_observation_count=92000"
echo "timing_execution_authorized=false"

echo
echo "=== 9. Cleanup ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 10. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "membership_density_timing_preflight_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=formalize_membership_density_timing_preregistration"

git status --short --branch
git log --oneline --decorate -5
