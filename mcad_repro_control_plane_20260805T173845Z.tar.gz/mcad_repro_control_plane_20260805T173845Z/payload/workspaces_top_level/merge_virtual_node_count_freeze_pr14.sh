#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=14

BASE="paper/phase3-controlled-execution"
BRANCH="paper/freeze-virtual-node-count-stage10-20260802T182731Z"
EXPECTED_HEAD="8dacca96d9f58aac5237b6251699e8d877776a63"

PACKAGE="experiments/article/frozen_campaigns/sa3_virtual_node_count_stage10"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

EXPECTED_ARCHIVE="virtual_node_count_stage10_canonical_20260802T182731Z.tar.gz"
EXPECTED_ARCHIVE_SHA256="f192aa5a2204c43776f3d8a4cef176ef3233fc101a5e40230557934c0698d072"

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -d "$PACKAGE"
test -f "$REGISTRY"
test -f "$PACKAGE/archive/$EXPECTED_ARCHIVE"

echo "local_gate=PASS"
echo "campaign_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_rerun_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI discovery ==="

CHECK_COUNT=0

for ATTEMPT in $(seq 1 12); do
  CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || printf '[]'
  )"

  CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

  echo \
    "check_discovery_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 5
done

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASSING="$(
    jq \
      '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASSING" -eq 0

  echo "freeze_package_ci=PASS"
else
  echo "freeze_package_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Final merge gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"
  IS_DRAFT="$(jq -r '.isDraft' <<<"$DATA")"

  echo \
    "merge_poll_attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$IS_DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #14 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "freeze_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged canonical package ==="

test -d "$PACKAGE"
test -f "$PACKAGE/MANIFEST.json"
test -f "$PACKAGE/PROVENANCE.json"
test -f "$PACKAGE/STATUS.json"
test -f "$PACKAGE/freeze/FREEZE.json"
test -f "$PACKAGE/archive/$EXPECTED_ARCHIVE"

ACTUAL_ARCHIVE_SHA256="$(
  sha256sum \
    "$PACKAGE/archive/$EXPECTED_ARCHIVE" \
    | awk '{print $1}'
)"

test \
  "$ACTUAL_ARCHIVE_SHA256" \
  = "$EXPECTED_ARCHIVE_SHA256"

(
  cd "$PACKAGE"
  sha256sum -c SHA256SUMS
)

jq -e \
  --arg archive "$EXPECTED_ARCHIVE" \
  --arg sha "$EXPECTED_ARCHIVE_SHA256" \
  '
    .campaign_regenerated_during_freeze == false
    and .canonical_archive == $archive
    and .canonical_archive_sha256 == $sha
    and .packaging_mode
        == "existing_evidence_exact_snapshot"
    and .source_commit
        == "4ad3f6aa90fd47107bb767ffeb23e38d995e3120"
  ' \
  "$PACKAGE/PROVENANCE.json" >/dev/null

jq -e '
  .campaign_id == "sa3_virtual_node_count_stage10"
  and .run_count == 10
  and .successful_run_count == 10
  and .measurement_observation_count == 6000
  and .functional_mismatch_count == 0
  and .precision_targets_met == true
  and .scientific_freeze == true
  and .global_scientific_freeze == false
  and .latency_claim_authorized == false
  and .rerun_required == false
  and .repository_persistence_status == "complete"
' "$PACKAGE/STATUS.json" >/dev/null

jq -e '
  .freeze_scope == "virtual_node_count_stage10"
  and .precision_targets_met == true
  and .scientific_freeze == true
  and .global_scientific_freeze == false
  and .latency_claim_authorized == false
' "$PACKAGE/freeze/FREEZE.json" >/dev/null

grep -q \
  '^  sa3_virtual_node_count_stage10:$' \
  "$REGISTRY"

grep -q \
  "canonical_archive_sha256: $EXPECTED_ARCHIVE_SHA256" \
  "$REGISTRY"

grep -q \
  'next_action: continue_membership_density_temporal' \
  "$REGISTRY"

grep -q \
  '^  global_scientific_freeze: false$' \
  "$REGISTRY"

grep -q \
  '^  latency_claim_authorized: false$' \
  "$REGISTRY"

grep -q \
  '^  manuscript_resume_authorized: false$' \
  "$REGISTRY"

echo "merged_canonical_freeze_package=PASS"
echo "canonical_archive_sha256=$ACTUAL_ARCHIVE_SHA256"
echo "campaign_scientific_freeze=true"
echo "global_scientific_freeze=false"
echo "latency_claim_authorized=false"
echo "manuscript_resume_authorized=false"

echo
echo "=== 8. Cleanup local freeze branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "virtual_node_count_stage10_freeze_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "canonical_archive_sha256=$ACTUAL_ARCHIVE_SHA256"
echo "campaign_scientific_freeze=true"
echo "global_scientific_freeze=false"
echo "latency_claim_authorized=false"
echo "campaign_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_rerun_performed=false"
echo "next_stage=continue_membership_density_temporal"

git status --short --branch
git log --oneline --decorate -5
