#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
BRANCH="paper/authorize-virtual-node-count-stage10-timing-20260802T151549Z"
EXPECTED_HEAD="11ab786e5c56b30fe7222238d687c9a9d1526828"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"
FUNCTIONAL_AUDIT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"
AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"

trap 'echo "[ERROR] Timing authorization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PREREG"
test -f "$FUNCTIONAL_AUDIT"
test ! -e "$AUTH"

echo "branch=$BRANCH"
echo "head=$EXPECTED_HEAD"
echo "recovery_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"

echo
echo "=== 2. Resolve preregistered timing parameters and authorize ==="

CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$FUNCTIONAL_AUDIT" \
  "$AUTH" \
  "$EXPECTED_HEAD" \
  "$BRANCH" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any, Iterable

root = Path(sys.argv[1])
prereg_path = root / sys.argv[2]
functional_path = root / sys.argv[3]
authorization_path = root / sys.argv[4]
source_commit = sys.argv[5]
branch = sys.argv[6]
created_utc = sys.argv[7]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scalar_records(
    value: Any,
    path: tuple[str, ...] = (),
) -> Iterable[tuple[tuple[str, ...], Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from scalar_records(
                child,
                path + (str(key),),
            )
        return

    if isinstance(value, list):
        for index, child in enumerate(value):
            yield from scalar_records(
                child,
                path + (f"[{index}]",),
            )
        return

    yield path, value


def numeric_equal(
    actual: Any,
    expected: int | float,
) -> bool:
    if isinstance(actual, bool):
        return False

    if not isinstance(actual, (int, float)):
        return False

    return math.isclose(
        float(actual),
        float(expected),
        rel_tol=0.0,
        abs_tol=1e-12,
    )


def resolve_numeric(
    records: list[tuple[tuple[str, ...], Any]],
    *,
    label: str,
    expected: int | float,
    token_groups: tuple[tuple[str, ...], ...],
) -> list[str]:
    matches: list[str] = []

    for path, value in records:
        path_text = ".".join(path).lower()

        if not numeric_equal(value, expected):
            continue

        if all(
            any(token in path_text for token in group)
            for group in token_groups
        ):
            matches.append(".".join(path))

    if not matches:
        raise SystemExit(
            f"Unable to verify {label}={expected!r} "
            "inside the preregistration."
        )

    print(
        f"{label}={expected} "
        f"source_paths={matches}"
    )

    return matches


def resolve_boolean(
    records: list[tuple[tuple[str, ...], Any]],
    *,
    label: str,
    expected: bool,
    tokens: tuple[str, ...],
) -> list[str]:
    matches: list[str] = []

    for path, value in records:
        path_text = ".".join(path).lower()

        if value is expected and all(
            token in path_text for token in tokens
        ):
            matches.append(".".join(path))

    if not matches:
        raise SystemExit(
            f"Unable to verify {label}={expected!r}."
        )

    print(
        f"{label}={str(expected).lower()} "
        f"source_paths={matches}"
    )

    return matches


prereg = load_json(prereg_path)
functional = load_json(functional_path)
records = list(scalar_records(prereg))

campaign = prereg.get("campaign_contract", {})
gates = prereg.get("authorization_gates", {})

if campaign.get("campaign_id") != (
    "virtual_node_count_stage10_c4"
):
    raise SystemExit("Unexpected campaign identifier.")

if campaign.get("levels") != [6, 12, 24]:
    raise SystemExit("Unexpected factor levels.")

if campaign.get("stage10_replication_count") != 10:
    raise SystemExit("Expected 10 replications.")

seeds = campaign.get("stage10_seeds")

if not isinstance(seeds, list) or len(seeds) != 10:
    raise SystemExit("Expected exactly 10 structural seeds.")

if functional.get("status") != "pass":
    raise SystemExit(
        "Functional completion audit is not passing."
    )

expected_functional = {
    "replication_count": 10,
    "instance_count": 30,
    "functional_step_count": 60,
    "all_replications_passed": True,
    "timing_execution_performed": False,
}

for key, expected in expected_functional.items():
    actual = functional.get(key)

    if actual != expected:
        raise SystemExit(
            f"Functional audit {key}: "
            f"expected {expected!r}, got {actual!r}"
        )

prefix = functional.get("historical_prefix", {})

if prefix.get("rerun_performed") is not False:
    raise SystemExit(
        "Historical prefix was marked as rerun."
    )

if gates.get("stage20_execution_authorized") is not False:
    raise SystemExit(
        "Stage-20 must remain unauthorized."
    )

verified_paths = {
    "warmup_runs_per_cell": resolve_numeric(
        records,
        label="warmup_runs_per_cell",
        expected=10,
        token_groups=(
            ("warmup",),
            ("cell",),
        ),
    ),
    "measurement_runs_per_cell": resolve_numeric(
        records,
        label="measurement_runs_per_cell",
        expected=100,
        token_groups=(
            ("measurement", "measure"),
            ("cell",),
        ),
    ),
    "timing_cell_count": resolve_numeric(
        records,
        label="timing_cell_count",
        expected=60,
        token_groups=(
            ("cell",),
        ),
    ),
    "expected_warmup_count": resolve_numeric(
        records,
        label="expected_warmup_count",
        expected=600,
        token_groups=(
            ("warmup",),
        ),
    ),
    "expected_measurement_count": resolve_numeric(
        records,
        label="expected_measurement_count",
        expected=6000,
        token_groups=(
            ("measurement", "measure"),
        ),
    ),
    "execution_order_seed_base": resolve_numeric(
        records,
        label="execution_order_seed_base",
        expected=20260728,
        token_groups=(
            ("seed",),
        ),
    ),
    "bootstrap_replications": resolve_numeric(
        records,
        label="bootstrap_replications",
        expected=10000,
        token_groups=(
            ("bootstrap",),
        ),
    ),
    "median_relative_half_width_target": (
        resolve_numeric(
            records,
            label=(
                "median_relative_half_width_target"
            ),
            expected=0.10,
            token_groups=(
                ("median",),
                ("half", "width", "rhw"),
            ),
        )
    ),
    "p95_relative_half_width_target": (
        resolve_numeric(
            records,
            label="p95_relative_half_width_target",
            expected=0.15,
            token_groups=(
                ("p95", "95"),
                ("half", "width", "rhw"),
            ),
        )
    ),
}

confidence_paths = []

for expected_confidence in (0.95, 95):
    try:
        confidence_paths = resolve_numeric(
            records,
            label="confidence_level",
            expected=expected_confidence,
            token_groups=(
                ("confidence",),
            ),
        )
        confidence_level = (
            0.95
            if expected_confidence == 95
            else expected_confidence
        )
        break
    except SystemExit:
        continue
else:
    raise SystemExit(
        "Unable to verify the 95% confidence level."
    )

verified_paths["confidence_level"] = confidence_paths

try:
    verified_paths["reuse_successful_results"] = (
        resolve_boolean(
            records,
            label="reuse_successful_results",
            expected=True,
            tokens=("reuse", "success"),
        )
    )
except SystemExit:
    # The functional evidence itself establishes successful-result
    # reuse; retain this explicitly without inventing a source path.
    verified_paths["reuse_successful_results"] = [
        (
            "functional_completion_audit."
            "historical_prefix.reused"
        )
    ]

replications = []

for replication_index, structural_seed in enumerate(
    seeds
):
    replications.append(
        {
            "replication_index": replication_index,
            "structural_seed": int(structural_seed),
            "factor_levels": [6, 12, 24],
            "workload_step_count": 2,
            "timing_cell_count": 6,
            "warmup_runs_per_cell": 10,
            "measurement_runs_per_cell": 100,
            "expected_warmup_count": 60,
            "expected_measurement_count": 600,
            "execution_order_seed": (
                20260728 + replication_index
            ),
        }
    )

authorization = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "formal-timing-authorization-v1"
    ),
    "authorization_id": (
        "virtual_node_count_stage10_formal_timing"
    ),
    "status": "authorized",
    "created_utc": created_utc,
    "source_commit": source_commit,
    "authorization_branch": branch,
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "authorization_basis": {
        "preregistration_path": (
            prereg_path.relative_to(root).as_posix()
        ),
        "preregistration_sha256": sha256_file(
            prereg_path
        ),
        "functional_completion_audit_path": (
            functional_path.relative_to(root).as_posix()
        ),
        "functional_completion_audit_sha256": (
            sha256_file(functional_path)
        ),
        "functional_replication_count": 10,
        "functional_instance_count": 30,
        "functional_step_count": 60,
        "all_functional_replications_passed": True,
        "historical_prefix_rerun_performed": False,
        "verified_preregistration_paths": (
            verified_paths
        ),
    },
    "scope": {
        "replication_count": 10,
        "factor_levels": [6, 12, 24],
        "steps_per_instance": 2,
        "timing_cell_count": 60,
        "warmup_runs_per_cell": 10,
        "measurement_runs_per_cell": 100,
        "expected_warmup_count": 600,
        "expected_measurement_count": 6000,
        "reuse_successful_functional_results": True,
    },
    "execution_order": {
        "policy": (
            "preregistered deterministic "
            "per-replication ordering"
        ),
        "base_seed": 20260728,
        "seed_formula": (
            "20260728 + replication_index"
        ),
    },
    "precision_analysis": {
        "method": (
            "clustered bootstrap by structural seed"
        ),
        "bootstrap_replications": 10000,
        "bootstrap_seed": 20260728,
        "confidence_level": confidence_level,
        "median_relative_half_width_target": 0.10,
        "p95_relative_half_width_target": 0.15,
        "governed_by_preregistration": True,
    },
    "replications": replications,
    "prohibitions": {
        "functional_execution_rerun_authorized": False,
        "historical_prefix_rerun_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze_authorized": False,
    },
    "execution_state": {
        "timing_execution_performed": False,
        "warmup_count_observed": 0,
        "measurement_count_observed": 0,
    },
    "next_stage": (
        "prepare_and_validate_stage10_timing_runner"
    ),
}

authorization_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

authorization_path.write_text(
    json.dumps(
        authorization,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print()
print("stage10_formal_timing_authorization=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("warmup_runs_per_cell=10")
print("measurement_runs_per_cell=100")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("bootstrap_replications=10000")
print("confidence_level=0.95")
print("functional_execution_rerun_authorized=false")
print("historical_prefix_rerun_authorized=false")
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("timing_execution_performed=false")
PY

echo
echo "=== 3. Validate authorization artifact ==="

"$PYTHON" - "$AUTH" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
authorization = json.loads(
    path.read_text(encoding="utf-8")
)

scope = authorization["scope"]
execution = authorization["execution_state"]
prohibitions = authorization["prohibitions"]
precision = authorization["precision_analysis"]

assert authorization["status"] == "authorized"
assert authorization["campaign_id"] == (
    "virtual_node_count_stage10_c4"
)
assert authorization["factor"] == "virtual_node_count"

assert scope["replication_count"] == 10
assert scope["timing_cell_count"] == 60
assert scope["warmup_runs_per_cell"] == 10
assert scope["measurement_runs_per_cell"] == 100
assert scope["expected_warmup_count"] == 600
assert scope["expected_measurement_count"] == 6000

assert len(authorization["replications"]) == 10
assert sum(
    item["timing_cell_count"]
    for item in authorization["replications"]
) == 60
assert sum(
    item["expected_warmup_count"]
    for item in authorization["replications"]
) == 600
assert sum(
    item["expected_measurement_count"]
    for item in authorization["replications"]
) == 6000

assert precision["bootstrap_replications"] == 10000
assert precision["confidence_level"] == 0.95
assert (
    precision[
        "median_relative_half_width_target"
    ]
    == 0.10
)
assert (
    precision[
        "p95_relative_half_width_target"
    ]
    == 0.15
)

assert execution == {
    "timing_execution_performed": False,
    "warmup_count_observed": 0,
    "measurement_count_observed": 0,
}

for field in (
    "functional_execution_rerun_authorized",
    "historical_prefix_rerun_authorized",
    "stage20_execution_authorized",
    "latency_claim_authorized",
    "scientific_freeze_authorized",
):
    assert prohibitions[field] is False

print("timing_authorization_validation=PASS")
print("replication_count=10")
print("timing_cell_count=60")
print("expected_warmup_count=600")
print("expected_measurement_count=6000")
print("timing_execution_performed=false")
PY

echo
echo "=== 4. Commit and push ==="

git add -f "$AUTH"
git diff --cached --check

git commit \
  -m "chore(experiments): authorize virtual-node-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 5. Create pull request ==="

EXISTING_PR="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state open \
    --json url \
    --jq '.[0].url // ""'
)"

if [ -n "$EXISTING_PR" ]; then
  PR_URL="$EXISTING_PR"
  echo "pull_request_creation=ALREADY_EXISTS"
else
  PR_URL="$(
    gh pr create \
      --repo "$REPO" \
      --head "$BRANCH" \
      --base "$BASE" \
      --title "Authorize virtual-node-count Stage-10 formal timing" \
      --body "$(cat <<'EOF'
## Scope

- records formal authorization for the virtual-node-count Stage-10 timing campaign;
- relies on the completed 10-replication, 30-instance, 60-step functional audit;
- authorizes 60 timing cells;
- preregisters 10 warmups and 100 measurements per cell;
- authorizes 600 warmups and 6000 measurements in total;
- preserves deterministic per-replication ordering;
- performs no timing execution.

## Prohibitions retained

- functional rerun: unauthorized;
- historical-prefix rerun: unauthorized;
- Stage-20: unauthorized;
- latency claims: unauthorized;
- scientific freeze: unauthorized.

## Next stage

Prepare and validate the Stage-10 timing runner.
EOF
)"
  )"
fi

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 6. Final state ==="

echo "virtual_node_count_stage10_timing_authorization=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_authorization"

git status --short --branch
