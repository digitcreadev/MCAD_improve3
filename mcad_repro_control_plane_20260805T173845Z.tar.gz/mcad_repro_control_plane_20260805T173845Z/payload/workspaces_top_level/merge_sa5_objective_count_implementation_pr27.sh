#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PR=27

BASE="paper/phase3-controlled-execution"
BRANCH="paper/implement-sa5-objective-count-20260804T184809Z"

EXPECTED_BASE_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"
EXPECTED_HEAD="a4f7767b2100c997456b55efce2714da6e29254f"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

EXPECTED_FILES=(
  "backend/harness/sensitivity_execution/e3_contract.yaml"
  "backend/harness/sensitivity_execution/execute_controlled_family.py"
  "backend/harness/sensitivity_execution/tests/test_e3_contract.py"
  "backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py"
  "backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"
  "backend/harness/sensitivity_execution/validate_e3_contract.py"
  "backend/harness/sensitivity_generator/families/controlled_families.py"
  "backend/harness/sensitivity_generator/families/objective_count_family.py"
  "backend/harness/sensitivity_generator/objective_count_generator.py"
  "backend/harness/sensitivity_generator/tests/test_controlled_families.py"
  "backend/harness/sensitivity_generator/tests/test_objective_count_family.py"
)

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_objective_count_pr27.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #27 merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Local implementation gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

printf '%s\n' "${EXPECTED_FILES[@]}" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_HEAD" |
  sort \
  > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(
  wc -l < "$TMP_ROOT/actual_files.txt"
)" -eq 11

while IFS= read -r FILE; do
  test -f "$FILE"
done < "$TMP_ROOT/actual_files.txt"

! grep -Eq \
  '^(MCAD_audited_real_main_fr\.tex|reports/article_experiments/|experiments/article/frozen_campaigns/)' \
  "$TMP_ROOT/actual_files.txt"

echo "local_implementation_gate=PASS"
echo "changed_file_count=11"
echo "manuscript_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Exact implementation-content gate ==="

"$PYTHON" - <<'PY'
from backend.harness.sensitivity_execution.execute_controlled_family import (
    SUPPORTED_GENERATOR_VERSION_PAIRS,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    SUPPORTED_FACTORS,
)

expected = (
    "mcad-sensitivity-e2.2-objective-count-v1",
    "mcad-sensitivity-e2.1-objective-count-v1",
)

assert "objective_count" in SUPPORTED_FACTORS

assert (
    SUPPORTED_GENERATOR_VERSION_PAIRS[
        "objective_count"
    ]
    == expected
)

print("generator_profile_import_gate=PASS")
PY

grep -F \
  'selected_objective_index=0' \
  backend/harness/sensitivity_generator/families/controlled_families.py \
  >/dev/null

grep -F \
  'FACTOR = "objective_count"' \
  backend/harness/sensitivity_generator/families/objective_count_family.py \
  >/dev/null

grep -F \
  'GENERATOR_VERSION = "mcad-sensitivity-e2.1-objective-count-v1"' \
  backend/harness/sensitivity_generator/objective_count_generator.py \
  >/dev/null

grep -F \
  'objective_count:' \
  backend/harness/sensitivity_execution/e3_contract.yaml \
  >/dev/null

grep -F \
  '"objective_count": (' \
  backend/harness/sensitivity_execution/validate_e3_contract.py \
  >/dev/null

echo "implementation_content_gate=PASS"
echo "selected_objective_index=0"
echo "controlled_generator_ready=true"
echo "executor_ready=true"
echo "e3_contract_ready=true"

echo
echo "=== 3. Pre-merge regression gate ==="

"$PYTHON" -m py_compile \
  backend/harness/sensitivity_generator/objective_count_generator.py \
  backend/harness/sensitivity_generator/families/objective_count_family.py \
  backend/harness/sensitivity_generator/families/controlled_families.py \
  backend/harness/sensitivity_execution/execute_controlled_family.py \
  backend/harness/sensitivity_execution/validate_e3_contract.py

echo "python_compile=PASS"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

echo "e3_contract_validation=PASS"

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

echo "complete_sensitivity_regression=PASS"

echo
echo "=== 4. Remote base and branch gate ==="

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_BASE_HEAD"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$EXPECTED_HEAD"

echo "remote_lineage_gate=PASS"
echo "remote_base_head=$EXPECTED_BASE_HEAD"
echo "remote_feature_head=$EXPECTED_HEAD"

echo
echo "=== 5. Pull-request identity and scope ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,files
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and (.files | length) == 11
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 6. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' \
  >/dev/null 2>&1 \
  <<<"$CHECKS"
then
  CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$CHECKS"
)"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '
      [
        .[]
        | select(.bucket != "pass")
      ]
      | length
    ' <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "sa5_implementation_ci=PASS"
else
  echo "sa5_implementation_ci=NOT_APPLICABLE"
fi

echo
echo "=== 7. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 8. Merge PR #27 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 9. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 10. Post-merge implementation validation ==="

for FILE in "${EXPECTED_FILES[@]}"; do
  test -f "$FILE"
done

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_e3_contract.py \
  -q \
  -p no:cacheprovider

"$PYTHON" - <<'PY'
from backend.harness.sensitivity_execution.execute_controlled_family import (
    SUPPORTED_GENERATOR_VERSION_PAIRS,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    SUPPORTED_FACTORS,
)

assert "objective_count" in SUPPORTED_FACTORS

assert (
    SUPPORTED_GENERATOR_VERSION_PAIRS[
        "objective_count"
    ]
    == (
        "mcad-sensitivity-e2.2-objective-count-v1",
        "mcad-sensitivity-e2.1-objective-count-v1",
    )
)

print("post_merge_objective_count_capability=PASS")
PY

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "post_merge_validation=PASS"
echo "manuscript_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 11. Verify PR final state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 12. Cleanup local implementation branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo
echo "=== 13. Final state ==="

echo "sa5_objective_count_implementation_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_HEAD"
echo "changed_file_count=11"
echo "controlled_generator_ready=true"
echo "executor_ready=true"
echo "e3_contract_ready=true"
echo "direct_preregistration_ready=true"
echo "selected_objective_index=0"
echo "canonical_campaign_generated=false"
echo "campaign_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "manuscript_modified=false"
echo "next_stage=preregister_sa5_objective_count_campaign"

git status --short --branch
git log --oneline --decorate -5
