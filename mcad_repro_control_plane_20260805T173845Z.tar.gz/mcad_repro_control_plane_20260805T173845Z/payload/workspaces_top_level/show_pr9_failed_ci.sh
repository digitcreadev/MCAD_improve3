#!/usr/bin/env bash
set -Eeuo pipefail

REPO="digitcreadev/MCAD_improve3"
PR=9
EXPECTED_HEAD="3d1c6ad370f6b8612a46b362e54d2683e59187f4"

echo "=== 1. Failed PR checks ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,workflow,link,description
)"

jq . <<<"$CHECKS"

FAILED_COUNT="$(
  jq '[.[] | select(.bucket != "pass")] | length' \
    <<<"$CHECKS"
)"

echo "failed_check_count=$FAILED_COUNT"

test "$FAILED_COUNT" -eq 1

FAILED_NAME="$(
  jq -r \
    '.[] | select(.bucket != "pass") | .name' \
    <<<"$CHECKS"
)"

FAILED_STATE="$(
  jq -r \
    '.[] | select(.bucket != "pass") | .state' \
    <<<"$CHECKS"
)"

FAILED_LINK="$(
  jq -r \
    '.[] | select(.bucket != "pass") | .link' \
    <<<"$CHECKS"
)"

RUN_ID="$(
  sed -nE \
    's#.*[/]actions[/]runs[/]([0-9]+).*#\1#p' \
    <<<"$FAILED_LINK" \
    | head -n 1
)"

echo
echo "failed_check_name=$FAILED_NAME"
echo "failed_check_state=$FAILED_STATE"
echo "failed_check_link=$FAILED_LINK"
echo "workflow_run_id=$RUN_ID"

test -n "$RUN_ID"

echo
echo "=== 2. Workflow-run metadata ==="

gh run view "$RUN_ID" \
  --repo "$REPO" \
  --json databaseId,name,event,status,conclusion,headSha,url,jobs \
  --jq '{
    run_id: .databaseId,
    name,
    event,
    status,
    conclusion,
    head_sha: .headSha,
    url,
    jobs: [
      .jobs[] | {
        name,
        status,
        conclusion,
        databaseId
      }
    ]
  }'

ACTUAL_HEAD="$(
  gh run view "$RUN_ID" \
    --repo "$REPO" \
    --json headSha \
    --jq '.headSha'
)"

echo "workflow_head=$ACTUAL_HEAD"
test "$ACTUAL_HEAD" = "$EXPECTED_HEAD"

echo
echo "=== 3. Failed log excerpt ==="

gh run view "$RUN_ID" \
  --repo "$REPO" \
  --log-failed \
  | tail -n 300

echo
echo "ci_failure_inspection=PASS"
echo "pr_merged=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "next_stage=fix_only_the_failing_ci_check"
