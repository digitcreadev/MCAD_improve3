#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="bbe66c639c729322aeacb5f269e8e78ef3a3e42c"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

CAPABILITY="$REPORTS/planning/sa4_membership_density_capability_audit.json"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$REGISTRY"
test -f "$CAPABILITY"

echo "repository_gate=PASS"
echo "virtual_node_count_rerun_performed=false"
echo "membership_density_functional_rerun_performed=false"
echo "membership_density_timing_execution_performed=false"

echo
echo "=== 2. Registry state ==="

grep -n -A45 -B8 \
  -E \
'membership_density|remaining_sensitivity|global_state' \
  "$REGISTRY"

echo
echo "=== 3. Existing membership-density artifacts ==="

find \
  "$REPORTS" \
  experiments/article/frozen_campaigns \
  backend/harness/sensitivity_execution \
  -type f \
  \( \
    -iname '*membership*density*' \
    -o -path '*membership_density*' \
  \) \
  -printf '%p\n' \
  | sort

echo
echo "=== 4. Capability-audit temporal contract ==="

python - "$CAPABILITY" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

path = Path(sys.argv[1])

payload = json.loads(
    path.read_text(encoding="utf-8")
)

if not isinstance(payload, dict):
    raise SystemExit(
        "Capability audit must be a JSON object."
    )

terms = (
    "temporal",
    "timing",
    "latency",
    "functional",
    "freeze",
    "authorization",
    "preregister",
    "stage",
    "measurement",
    "bootstrap",
    "runner",
    "analyzer",
    "next",
    "status",
)


def walk(value: Any, prefix: str = "$") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            current = f"{prefix}.{key}"

            if any(
                term in key.lower()
                for term in terms
            ):
                compact = json.dumps(
                    child,
                    sort_keys=True,
                )

                if len(compact) <= 700:
                    print(f"{current} = {compact}")
                else:
                    print(
                        f"{current} = "
                        f"<{type(child).__name__}>"
                    )

            walk(child, current)

    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk(child, f"{prefix}[{index}]")


print(
    "capability_audit_top_level_keys="
    + ",".join(sorted(payload))
)

walk(payload)
PY

echo
echo "=== 5. Candidate plans, authorizations and timing evidence ==="

find "$REPORTS" \
  -type f \
  \( \
    -iname '*membership*density*' \
    -o -path '*membership_density*' \
  \) \
  \( \
    -iname '*preregistration*.json' \
    -o -iname '*authorization*.json' \
    -o -iname '*plan*.json' \
    -o -iname '*timing*.json' \
    -o -iname '*precision*.json' \
    -o -iname '*audit*.json' \
    -o -iname '*decision*.json' \
  \) \
  -printf '%p\n' \
  | sort

echo
echo "=== 6. Git history for membership-density evidence ==="

git log \
  --oneline \
  --decorate \
  --all \
  -- \
  '*membership_density*' \
  '*membership-density*' \
  | head -n 80

echo
echo "=== 7. Final state ==="

echo "membership_density_temporal_state_inspection=PASS"
echo "membership_density_functional_rerun_performed=false"
echo "membership_density_timing_execution_performed=false"
echo "membership_density_precision_analysis_performed=false"
echo "global_scientific_freeze=false"
echo "latency_claim_authorized=false"
echo "next_stage=resolve_membership_density_temporal_authorization"

git status --short --branch
