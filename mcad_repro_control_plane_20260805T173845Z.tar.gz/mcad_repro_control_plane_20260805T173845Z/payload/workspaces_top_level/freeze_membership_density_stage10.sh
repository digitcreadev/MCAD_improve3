#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="39da63c63a3062a79460377280758771d934c9b4"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
PLANNING="$REPORTS/planning"

TIMING_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"
AUDIT_ROOT="$REPORTS/audits/membership_density"
PRECISION_ROOT="$AUDIT_ROOT/timing_stage10/precision_analysis"

PREREG="$PLANNING/sa4_membership_density_non_mutating_precision_adapter_preregistration.json"
AUTH="$PLANNING/sa4_membership_density_portfolio_precision_analysis_authorization.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"
DECISION="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.json"
RAW_REPORT="$PRECISION_ROOT/raw_analyzer_report.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"
FREEZE_PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_stage10"

EXPECTED_PREREG_SHA="4e7041988c388837f5d4d71c07a659a209b479ddf4dd1f1cd7798cbb8aa2695b"
EXPECTED_AUTH_SHA="835a22c0f74f18c2da64ed91257fcd58839a85a7c4f6113579b9bba05cd068d1"
EXPECTED_INPUT_MANIFEST_SHA="449d0d54bb10df84327e3d757382e33c78abe9d2c9b3c5f55e3d8d5ee6ac2451"
EXPECTED_DECISION_SHA="92a9307a89e92c5e849b0e058f5e0a3c89633f6f8cd39f98ec9a2b9392cc88a4"
EXPECTED_RAW_REPORT_SHA="a58361d1927c771bd98c6428d013b91d46f1cc731795136c9ca122be9e7a6240"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

trap 'echo "[ERROR] Membership-density freeze stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Freeze gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"

for FILE in \
  "$PREREG" \
  "$AUTH" \
  "$INPUT_MANIFEST" \
  "$DECISION" \
  "$RAW_REPORT" \
  "$ANALYZER" \
  "$REGISTRY"
do
  test -f "$FILE"
done

test -d "$TIMING_ROOT"
test -d "$AUDIT_ROOT"
test ! -e "$FREEZE_PACKAGE"

test "$(sha256sum "$PREREG" | awk '{print $1}')" \
  = "$EXPECTED_PREREG_SHA"

test "$(sha256sum "$AUTH" | awk '{print $1}')" \
  = "$EXPECTED_AUTH_SHA"

test "$(sha256sum "$INPUT_MANIFEST" | awk '{print $1}')" \
  = "$EXPECTED_INPUT_MANIFEST_SHA"

test "$(sha256sum "$DECISION" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

test "$(sha256sum "$RAW_REPORT" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_SHA"

test "$(sha256sum "$ANALYZER" | awk '{print $1}')" \
  = "$EXPECTED_ANALYZER_SHA"

jq -e '
  .status == "pass"
  and .factor == "membership_density"
  and .stage == 10
  and .analysis_execution.authorized_execution_count == 1
  and .analysis_execution.successful_bootstrap_execution_count == 1
  and .analysis_execution.precision_analysis_performed == true
  and .precision_decision.all_median_targets_met == true
  and .precision_decision.all_p95_targets_met == true
  and .precision_decision.all_precision_targets_met == true
  and .precision_decision.failing_cell_count == 0
  and .precision_decision.stage10_sufficient == true
  and .precision_decision.stage20_extension_required == false
  and .precision_decision.stage20_execution_authorized == false
  and .scientific_controls.scientific_freeze == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage == "prepare_membership_density_stage10_freeze"
' "$DECISION" >/dev/null

if grep -Eq \
  '^[[:space:]]{2}sa4_membership_density_stage10:[[:space:]]*$' \
  "$REGISTRY"
then
  echo "[ERROR] Registry entry already exists."
  exit 1
fi

AVAILABLE_KB="$(
  df -Pk "$ROOT" |
    awk 'NR == 2 {print $4}'
)"

test "$AVAILABLE_KB" -ge 2000000

echo "freeze_gate=PASS"
echo "available_disk_kb=$AVAILABLE_KB"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=true"
echo "stage10_sufficient=true"
echo "scientific_freeze=false"
echo "latency_claim_authorized=false"

echo
echo "=== 2. Create freeze branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/freeze-membership-density-stage10-${STAMP}"

BUILD_ROOT="/workspaces/sa4_membership_density_stage10_freeze_${STAMP}"
ARCHIVE_ROOT="$BUILD_ROOT/archive_root"
VALIDATION_ROOT="$BUILD_ROOT/archive_validation"

ARCHIVE_NAME="membership_density_stage10_canonical_${STAMP}.tar.gz"
ARCHIVE_TMP="$BUILD_ROOT/$ARCHIVE_NAME"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

rm -rf "$BUILD_ROOT"
mkdir -p \
  "$ARCHIVE_ROOT/payload" \
  "$VALIDATION_ROOT"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"
echo "build_root=$BUILD_ROOT"

echo
echo "=== 3. Build canonical payload ==="

"$PYTHON" - \
  "$ROOT" \
  "$ARCHIVE_ROOT" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$PLANNING" \
  "$TIMING_ROOT" \
  "$AUDIT_ROOT" \
  "$PREREG" \
  "$AUTH" \
  "$INPUT_MANIFEST" \
  "$DECISION" \
  "$RAW_REPORT" \
  "$ANALYZER" \
  "$FREEZE_PACKAGE" <<'PY'
from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

root = Path(sys.argv[1]).resolve()
archive_root = Path(sys.argv[2]).resolve()
source_commit = sys.argv[3]
created_utc = sys.argv[4]

planning_dir = (root / sys.argv[5]).resolve()
timing_root = (root / sys.argv[6]).resolve()
audit_root = (root / sys.argv[7]).resolve()

prereg_path = (root / sys.argv[8]).resolve()
auth_path = (root / sys.argv[9]).resolve()
input_manifest_path = (root / sys.argv[10]).resolve()
decision_path = (root / sys.argv[11]).resolve()
raw_report_path = (root / sys.argv[12]).resolve()
analyzer_path = (root / sys.argv[13]).resolve()
freeze_package = (root / sys.argv[14]).resolve()

payload_root = archive_root / "payload"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def relative(path: Path) -> str:
    return path.resolve().relative_to(root).as_posix()


def referenced_paths(value: Any) -> Iterable[str]:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"path", "program"} and isinstance(item, str):
                yield item

            yield from referenced_paths(item)

    elif isinstance(value, list):
        for item in value:
            yield from referenced_paths(item)


selected_files: set[Path] = set()


def add_file(path: Path) -> None:
    path = path.resolve()

    try:
        path.relative_to(root)
    except ValueError:
        return

    if freeze_package == path or freeze_package in path.parents:
        return

    if ".git" in path.parts:
        return

    if path.is_file():
        selected_files.add(path)


def add_path(path: Path) -> None:
    path = path.resolve()

    if path.is_file():
        add_file(path)
        return

    if path.is_dir():
        for item in path.rglob("*"):
            if item.is_file():
                add_file(item)


# Include all membership-density planning records.
for path in planning_dir.glob("sa4_membership_density*"):
    if path.is_file():
        add_file(path)

# Include complete timing and audit evidence.
add_path(timing_root)
add_path(audit_root)
add_file(analyzer_path)

# Include every repository path referenced by canonical metadata.
metadata_paths = [
    prereg_path,
    auth_path,
    input_manifest_path,
    decision_path,
    raw_report_path,
]

for metadata_path in metadata_paths:
    add_file(metadata_path)

    payload = load_json(metadata_path)

    for value in referenced_paths(payload):
        candidate = Path(value)

        if not candidate.is_absolute():
            candidate = root / candidate

        add_path(candidate)

if not selected_files:
    raise SystemExit("Canonical payload selection is empty.")

entries: list[dict[str, Any]] = []
total_bytes = 0

for source in sorted(
    selected_files,
    key=lambda item: relative(item),
):
    rel = relative(source)
    destination = payload_root / rel

    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

    size = source.stat().st_size
    digest = sha256(source)

    entries.append({
        "path": f"payload/{rel}",
        "repository_path": rel,
        "sha256": digest,
        "size_bytes": size,
    })

    total_bytes += size

payload_manifest = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-canonical-payload-manifest-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "factor": "membership_density",
    "stage": 10,
    "created_utc": created_utc,
    "source_commit": source_commit,
    "file_count": len(entries),
    "total_uncompressed_bytes": total_bytes,
    "files": entries,
}

(archive_root / "PAYLOAD_MANIFEST.json").write_text(
    json.dumps(payload_manifest, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

with (archive_root / "PAYLOAD_SHA256SUMS").open(
    "w",
    encoding="utf-8",
    newline="\n",
) as handle:
    for entry in entries:
        handle.write(
            f"{entry['sha256']}  {entry['path']}\n"
        )

source_state = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-freeze-source-state-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "source_branch": "paper/phase3-controlled-execution",
    "source_commit": source_commit,
    "created_utc": created_utc,
    "canonical_artifacts": {
        "adapter_preregistration": {
            "path": relative(prereg_path),
            "sha256": sha256(prereg_path),
        },
        "precision_authorization": {
            "path": relative(auth_path),
            "sha256": sha256(auth_path),
        },
        "precision_input_manifest": {
            "path": relative(input_manifest_path),
            "sha256": sha256(input_manifest_path),
        },
        "precision_decision": {
            "path": relative(decision_path),
            "sha256": sha256(decision_path),
        },
        "raw_analyzer_report": {
            "path": relative(raw_report_path),
            "sha256": sha256(raw_report_path),
        },
        "precision_analyzer": {
            "path": relative(analyzer_path),
            "sha256": sha256(analyzer_path),
        },
    },
    "scientific_result": {
        "successful_bootstrap_execution_count": 1,
        "all_precision_targets_met": True,
        "failing_cell_count": 0,
        "stage10_sufficient": True,
        "stage20_extension_required": False,
        "stage20_execution_authorized": False,
    },
}

(archive_root / "SOURCE_STATE.json").write_text(
    json.dumps(source_state, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

(archive_root / "README.txt").write_text(
    "\n".join([
        "MCAD SA4 membership-density Stage-10 canonical payload",
        "",
        f"Source commit: {source_commit}",
        "Factor: membership_density",
        "Stage: 10",
        "Successful bootstrap executions: 1",
        "All precision targets met: true",
        "Stage-10 sufficient: true",
        "Stage-20 extension required: false",
        "",
        "Validate with:",
        "  sha256sum -c PAYLOAD_SHA256SUMS",
        "",
    ]),
    encoding="utf-8",
)

print("canonical_payload_build=PASS")
print(f"canonical_payload_file_count={len(entries)}")
print(f"canonical_payload_uncompressed_bytes={total_bytes}")
PY

PAYLOAD_FILE_COUNT="$(
  jq -r '.file_count' \
    "$ARCHIVE_ROOT/PAYLOAD_MANIFEST.json"
)"

PAYLOAD_BYTES="$(
  jq -r '.total_uncompressed_bytes' \
    "$ARCHIVE_ROOT/PAYLOAD_MANIFEST.json"
)"

test "$PAYLOAD_FILE_COUNT" -gt 0
test "$PAYLOAD_BYTES" -gt 0

echo "canonical_payload_file_count=$PAYLOAD_FILE_COUNT"
echo "canonical_payload_uncompressed_bytes=$PAYLOAD_BYTES"

echo
echo "=== 4. Create deterministic canonical archive ==="

tar \
  --sort=name \
  --mtime='UTC 1970-01-01' \
  --owner=0 \
  --group=0 \
  --numeric-owner \
  -C "$ARCHIVE_ROOT" \
  -cf - \
  PAYLOAD_MANIFEST.json \
  PAYLOAD_SHA256SUMS \
  README.txt \
  SOURCE_STATE.json \
  payload |
gzip -n > "$ARCHIVE_TMP"

test -s "$ARCHIVE_TMP"
gzip -t "$ARCHIVE_TMP"
tar -tzf "$ARCHIVE_TMP" >/dev/null

ARCHIVE_SHA="$(
  sha256sum "$ARCHIVE_TMP" |
    awk '{print $1}'
)"

ARCHIVE_SIZE="$(
  stat -c '%s' "$ARCHIVE_TMP"
)"

test "$ARCHIVE_SIZE" -lt 95000000

echo "canonical_archive_creation=PASS"
echo "canonical_archive_name=$ARCHIVE_NAME"
echo "canonical_archive_size_bytes=$ARCHIVE_SIZE"
echo "canonical_archive_sha256=$ARCHIVE_SHA"

echo
echo "=== 5. Validate extracted archive ==="

tar -xzf "$ARCHIVE_TMP" \
  -C "$VALIDATION_ROOT"

(
  cd "$VALIDATION_ROOT"
  sha256sum -c PAYLOAD_SHA256SUMS
)

"$PYTHON" - \
  "$VALIDATION_ROOT/PAYLOAD_MANIFEST.json" \
  "$VALIDATION_ROOT" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

manifest_path = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()

manifest = json.loads(
    manifest_path.read_text(encoding="utf-8")
)

files = manifest.get("files")

if not isinstance(files, list) or not files:
    raise SystemExit("Extracted payload manifest is empty.")

for record in files:
    path = root / record["path"]

    if not path.is_file():
        raise SystemExit(f"Missing extracted file: {path}")

    digest = hashlib.sha256(path.read_bytes()).hexdigest()

    if digest != record["sha256"]:
        raise SystemExit(
            f"Extracted file SHA mismatch: {path}"
        )

    if path.stat().st_size != record["size_bytes"]:
        raise SystemExit(
            f"Extracted file size mismatch: {path}"
        )

print("extracted_payload_manifest_validation=PASS")
print(f"validated_payload_file_count={len(files)}")
PY

echo "canonical_archive_validation=PASS"

echo
echo "=== 6. Create frozen campaign package ==="

mkdir -p \
  "$FREEZE_PACKAGE/archive" \
  "$FREEZE_PACKAGE/freeze"

cp \
  "$ARCHIVE_TMP" \
  "$FREEZE_PACKAGE/archive/$ARCHIVE_NAME"

printf '%s  %s\n' \
  "$ARCHIVE_SHA" \
  "$ARCHIVE_NAME" \
  > "$FREEZE_PACKAGE/archive/$ARCHIVE_NAME.sha256"

"$PYTHON" - \
  "$ROOT" \
  "$FREEZE_PACKAGE" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$ARCHIVE_NAME" \
  "$ARCHIVE_SHA" \
  "$ARCHIVE_SIZE" \
  "$PAYLOAD_FILE_COUNT" \
  "$PAYLOAD_BYTES" \
  "$PREREG" \
  "$AUTH" \
  "$INPUT_MANIFEST" \
  "$DECISION" \
  "$RAW_REPORT" \
  "$ANALYZER" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
package = (root / sys.argv[2]).resolve()

source_commit = sys.argv[3]
created_utc = sys.argv[4]
archive_name = sys.argv[5]
archive_sha = sys.argv[6]
archive_size = int(sys.argv[7])
payload_file_count = int(sys.argv[8])
payload_bytes = int(sys.argv[9])

prereg = (root / sys.argv[10]).resolve()
authorization = (root / sys.argv[11]).resolve()
input_manifest = (root / sys.argv[12]).resolve()
decision = (root / sys.argv[13]).resolve()
raw_report = (root / sys.argv[14]).resolve()
analyzer = (root / sys.argv[15]).resolve()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.resolve().relative_to(root).as_posix()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


decision_payload = load_object(decision)
authorization_payload = load_object(authorization)

cells = decision_payload["cell_results"]

status = {
    "schema_version": (
        "mcad-frozen-campaign-status-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "status": "completed_precision_targets_met",
    "factor": "membership_density",
    "stage": 10,
    "source_commit": source_commit,
    "frozen_utc": created_utc,
    "run_count": 10,
    "measurement_observation_count": 92000,
    "successful_bootstrap_execution_count": 1,
    "bootstrap_repetitions": 10000,
    "bootstrap_seed": 20260728,
    "all_precision_targets_met": True,
    "failing_cell_count": 0,
    "stage10_sufficient": True,
    "stage20_extension_required": False,
    "stage20_execution_authorized": False,
    "scientific_freeze": True,
    "latency_claim_authorized": True,
    "manuscript_resume_authorized": True,
    "global_scientific_freeze": False,
    "next_stage": (
        "integrate_membership_density_stage10_results_"
        "into_manuscript"
    ),
}

provenance = {
    "schema_version": (
        "mcad-frozen-campaign-provenance-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "source_repository": "digitcreadev/MCAD_improve3",
    "source_branch": "paper/phase3-controlled-execution",
    "source_commit": source_commit,
    "frozen_utc": created_utc,
    "canonical_archive": {
        "path": f"archive/{archive_name}",
        "sha256": archive_sha,
        "size_bytes": archive_size,
        "payload_file_count": payload_file_count,
        "payload_uncompressed_bytes": payload_bytes,
        "deterministic_tar_metadata": True,
        "gzip_timestamp_suppressed": True,
    },
    "canonical_artifacts": {
        "adapter_preregistration": {
            "path": relative(prereg),
            "sha256": sha256(prereg),
        },
        "precision_authorization": {
            "path": relative(authorization),
            "sha256": sha256(authorization),
        },
        "precision_input_manifest": {
            "path": relative(input_manifest),
            "sha256": sha256(input_manifest),
        },
        "precision_decision": {
            "path": relative(decision),
            "sha256": sha256(decision),
        },
        "raw_analyzer_report": {
            "path": relative(raw_report),
            "sha256": sha256(raw_report),
        },
        "precision_analyzer": {
            "path": relative(analyzer),
            "sha256": sha256(analyzer),
        },
    },
    "raw_analyzer_interpretation": {
        "raw_factor_label": "constraint_count",
        "raw_factor_label_authoritative": False,
        "raw_next_stage_authoritative": False,
        "canonical_factor": "membership_density",
    },
}

freeze = {
    "schema_version": (
        "mcad-scientific-freeze-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "freeze_status": "frozen",
    "factor": "membership_density",
    "stage": 10,
    "source_commit": source_commit,
    "frozen_utc": created_utc,
    "canonical_archive": {
        "path": f"archive/{archive_name}",
        "sha256": archive_sha,
        "size_bytes": archive_size,
    },
    "scientific_decision": {
        "successful_bootstrap_execution_count": 1,
        "all_median_targets_met": True,
        "all_p95_targets_met": True,
        "all_precision_targets_met": True,
        "failing_cell_count": 0,
        "stage10_sufficient": True,
        "stage20_extension_required": False,
        "stage20_execution_authorized": False,
    },
    "precision_cells": cells,
    "immutability": {
        "canonical_timing_rerun_allowed": False,
        "canonical_adapter_rematerialization_allowed": False,
        "canonical_bootstrap_rerun_allowed": False,
        "canonical_evidence_modification_allowed": False,
        "independent_external_reproduction_allowed": True,
    },
    "publication_controls": {
        "scientific_freeze": True,
        "latency_claim_authorized": True,
        "manuscript_resume_authorized": True,
        "global_scientific_freeze": False,
    },
    "next_stage": (
        "integrate_membership_density_stage10_results_"
        "into_manuscript"
    ),
}

(package / "STATUS.json").write_text(
    json.dumps(status, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

(package / "PROVENANCE.json").write_text(
    json.dumps(provenance, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

(package / "freeze" / "FREEZE.json").write_text(
    json.dumps(freeze, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

invocation = authorization_payload[
    "exact_analyzer_invocation"
]

argument_tokens = invocation["arguments"]

rendered_command = " \\\n  ".join(
    [
        (
            "python "
            + invocation["program"]
        ),
        *[
            str(token)
            for token in argument_tokens
        ],
    ]
)

(package / "README.md").write_text(
    "\n".join([
        "# SA4 membership-density Stage-10 campaign",
        "",
        (
            "Canonical frozen package for the completed "
            "`membership_density` sensitivity campaign."
        ),
        "",
        "## Scientific result",
        "",
        "- Status: `completed_precision_targets_met`",
        "- Stage: `10`",
        "- Formal timing replications: `10`",
        "- Measurement observations: `92,000`",
        "- Successful bootstrap executions: `1`",
        "- Bootstrap repetitions: `10,000`",
        "- Bootstrap seed: `20260728`",
        "- All precision targets met: `true`",
        "- Failing cells: `0`",
        "- Stage-10 sufficient: `true`",
        "- Stage-20 extension required: `false`",
        "",
        "## Publication status",
        "",
        "- Scientific freeze: `true`",
        "- Latency claims authorized: `true`",
        "- Manuscript integration authorized: `true`",
        "- Global scientific freeze: `false`",
        "",
        "## Canonical archive",
        "",
        f"- File: `archive/{archive_name}`",
        f"- SHA-256: `{archive_sha}`",
        f"- Size: `{archive_size}` bytes",
        f"- Payload files: `{payload_file_count}`",
        "",
        (
            "The raw analyzer label `constraint_count` and "
            "its raw next-stage value are retained only for "
            "provenance. The canonical factor is "
            "`membership_density`."
        ),
        "",
    ]),
    encoding="utf-8",
)

(package / "REPRODUCE.md").write_text(
    "\n".join([
        "# Verification and independent reproduction",
        "",
        "## Verify the frozen package",
        "",
        "```bash",
        "cd experiments/article/frozen_campaigns/"
        "sa4_membership_density_stage10",
        "sha256sum -c SHA256SUMS",
        (
            f"sha256sum -c archive/{archive_name}.sha256 "
            f"--ignore-missing"
        ),
        "```",
        "",
        "## Verify the canonical payload",
        "",
        "```bash",
        "mkdir -p /tmp/membership-density-stage10",
        (
            f"tar -xzf archive/{archive_name} "
            "-C /tmp/membership-density-stage10"
        ),
        "cd /tmp/membership-density-stage10",
        "sha256sum -c PAYLOAD_SHA256SUMS",
        "```",
        "",
        "## Independent analyzer reproduction",
        "",
        (
            "The canonical repository execution count remains "
            "exactly one. Independent reproduction must write "
            "outside the canonical repository output paths."
        ),
        "",
        "```bash",
        "cd /tmp/membership-density-stage10/payload",
        rendered_command,
        "```",
        "",
    ]),
    encoding="utf-8",
)

expected_contents = [
    "CONTENTS.txt",
    "MANIFEST.json",
    "PROVENANCE.json",
    "README.md",
    "REPRODUCE.md",
    "SHA256SUMS",
    "STATUS.json",
    f"archive/{archive_name}",
    f"archive/{archive_name}.sha256",
    "freeze/FREEZE.json",
]

(package / "CONTENTS.txt").write_text(
    "\n".join(expected_contents) + "\n",
    encoding="utf-8",
)

manifested_paths = [
    path
    for path in expected_contents
    if path not in {"MANIFEST.json", "SHA256SUMS"}
]

manifest_entries = []

for rel in manifested_paths:
    path = package / rel

    if not path.is_file():
        raise SystemExit(
            f"Missing package file before manifest: {rel}"
        )

    manifest_entries.append({
        "path": rel,
        "sha256": sha256(path),
        "size_bytes": path.stat().st_size,
    })

package_manifest = {
    "schema_version": (
        "mcad-frozen-campaign-manifest-v1"
    ),
    "campaign_id": "sa4_membership_density_stage10",
    "file_count": len(manifest_entries),
    "excluded_self_referential_files": [
        "MANIFEST.json",
        "SHA256SUMS",
    ],
    "files": manifest_entries,
}

(package / "MANIFEST.json").write_text(
    json.dumps(
        package_manifest,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

checksum_paths = [
    path
    for path in expected_contents
    if path != "SHA256SUMS"
]

with (package / "SHA256SUMS").open(
    "w",
    encoding="utf-8",
    newline="\n",
) as handle:
    for rel in checksum_paths:
        path = package / rel
        handle.write(f"{sha256(path)}  {rel}\n")

print("frozen_campaign_metadata=PASS")
print("scientific_freeze=true")
print("latency_claim_authorized=true")
print("manuscript_resume_authorized=true")
print("global_scientific_freeze=false")
PY

echo
echo "=== 7. Update frozen-campaign registry ==="

"$PYTHON" - \
  "$REGISTRY" \
  "$ARCHIVE_SHA" \
  "$ARCHIVE_SIZE" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import re
import sys
from pathlib import Path

registry = Path(sys.argv[1])
archive_sha = sys.argv[2]
archive_size = int(sys.argv[3])
source_commit = sys.argv[4]
frozen_utc = sys.argv[5]

text = registry.read_text(encoding="utf-8")

key_pattern = (
    r"^[ ]{2}sa4_membership_density_stage10:"
    r"[ \t]*$"
)

if re.search(key_pattern, text, flags=re.MULTILINE):
    raise SystemExit("Registry entry already exists.")

lines = text.splitlines(keepends=True)

campaigns_index = None

for index, line in enumerate(lines):
    if line.strip() == "campaigns:" and not line.startswith((" ", "\t")):
        campaigns_index = index
        break

if campaigns_index is None:
    raise SystemExit("Top-level campaigns mapping not found.")

insertion_index = len(lines)

for index in range(campaigns_index + 1, len(lines)):
    line = lines[index]

    if (
        line.strip()
        and not line.startswith((" ", "\t", "#"))
        and re.match(r"^[A-Za-z0-9_.-]+:", line)
    ):
        insertion_index = index
        break

block = [
    "\n",
    "  sa4_membership_density_stage10:\n",
    "    scientific_status: completed_precision_targets_met\n",
    "    repository_persistence_status: complete\n",
    "    path: sa4_membership_density_stage10\n",
    f"    source_commit: {source_commit}\n",
    f"    frozen_utc: {frozen_utc}\n",
    f"    canonical_archive_sha256: {archive_sha}\n",
    f"    canonical_archive_size_bytes: {archive_size}\n",
    "    scientific_freeze: true\n",
    "    factor: membership_density\n",
    "    stage: 10\n",
    "    run_count: 10\n",
    "    measurement_observation_count: 92000\n",
    "    successful_bootstrap_execution_count: 1\n",
    "    all_precision_targets_met: true\n",
    "    failing_cell_count: 0\n",
    "    stage10_sufficient: true\n",
    "    stage20_extension_required: false\n",
    "    stage20_execution_authorized: false\n",
    "    latency_claim_authorized: true\n",
    "    manuscript_resume_authorized: true\n",
]

lines[insertion_index:insertion_index] = block

registry.write_text(
    "".join(lines),
    encoding="utf-8",
)

print("frozen_campaign_registry_update=PASS")
PY

echo
echo "=== 8. Validate frozen package ==="

EXPECTED_PACKAGE_FILE_COUNT=10

ACTUAL_PACKAGE_FILE_COUNT="$(
  find "$FREEZE_PACKAGE" \
    -type f |
    wc -l
)"

test "$ACTUAL_PACKAGE_FILE_COUNT" \
  -eq "$EXPECTED_PACKAGE_FILE_COUNT"

(
  cd "$FREEZE_PACKAGE"
  sha256sum -c SHA256SUMS
)

test "$(
  sha256sum \
    "$FREEZE_PACKAGE/archive/$ARCHIVE_NAME" |
    awk '{print $1}'
)" = "$ARCHIVE_SHA"

jq -e \
  --arg archive_sha "$ARCHIVE_SHA" \
  --arg source_commit "$EXPECTED_HEAD" \
  '
    .campaign_id == "sa4_membership_density_stage10"
    and .status == "completed_precision_targets_met"
    and .factor == "membership_density"
    and .stage == 10
    and .source_commit == $source_commit
    and .run_count == 10
    and .measurement_observation_count == 92000
    and .successful_bootstrap_execution_count == 1
    and .all_precision_targets_met == true
    and .failing_cell_count == 0
    and .stage10_sufficient == true
    and .stage20_extension_required == false
    and .stage20_execution_authorized == false
    and .scientific_freeze == true
    and .latency_claim_authorized == true
    and .manuscript_resume_authorized == true
    and .global_scientific_freeze == false
  ' "$FREEZE_PACKAGE/STATUS.json" >/dev/null

jq -e \
  --arg archive_sha "$ARCHIVE_SHA" \
  '
    .campaign_id == "sa4_membership_density_stage10"
    and .freeze_status == "frozen"
    and .canonical_archive.sha256 == $archive_sha
    and .scientific_decision.successful_bootstrap_execution_count == 1
    and .scientific_decision.all_precision_targets_met == true
    and .scientific_decision.failing_cell_count == 0
    and .scientific_decision.stage10_sufficient == true
    and .scientific_decision.stage20_extension_required == false
    and .immutability.canonical_bootstrap_rerun_allowed == false
    and .immutability.canonical_evidence_modification_allowed == false
    and .publication_controls.scientific_freeze == true
    and .publication_controls.latency_claim_authorized == true
    and .publication_controls.manuscript_resume_authorized == true
  ' "$FREEZE_PACKAGE/freeze/FREEZE.json" >/dev/null

grep -Eq \
  '^[[:space:]]{2}sa4_membership_density_stage10:[[:space:]]*$' \
  "$REGISTRY"

grep -F \
  "    canonical_archive_sha256: $ARCHIVE_SHA" \
  "$REGISTRY" >/dev/null

grep -F \
  "    scientific_freeze: true" \
  "$REGISTRY" >/dev/null

# Reconfirm that canonical scientific inputs were not modified.
test "$(sha256sum "$PREREG" | awk '{print $1}')" \
  = "$EXPECTED_PREREG_SHA"

test "$(sha256sum "$AUTH" | awk '{print $1}')" \
  = "$EXPECTED_AUTH_SHA"

test "$(sha256sum "$INPUT_MANIFEST" | awk '{print $1}')" \
  = "$EXPECTED_INPUT_MANIFEST_SHA"

test "$(sha256sum "$DECISION" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

test "$(sha256sum "$RAW_REPORT" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_SHA"

test "$(sha256sum "$ANALYZER" | awk '{print $1}')" \
  = "$EXPECTED_ANALYZER_SHA"

echo "frozen_campaign_validation=PASS"
echo "package_file_count=$ACTUAL_PACKAGE_FILE_COUNT"
echo "canonical_archive_sha256=$ARCHIVE_SHA"
echo "canonical_archive_size_bytes=$ARCHIVE_SIZE"
echo "canonical_payload_file_count=$PAYLOAD_FILE_COUNT"
echo "scientific_freeze=true"
echo "latency_claim_authorized=true"
echo "manuscript_resume_authorized=true"

echo
echo "=== 9. Stage freeze package ==="

git add -f \
  "$FREEZE_PACKAGE" \
  "$REGISTRY"

STAGED_FILE_COUNT="$(
  git diff --cached --name-only |
    wc -l
)"

test "$STAGED_FILE_COUNT" -eq 11

git diff --cached --check -- \
  "$REGISTRY" \
  "$FREEZE_PACKAGE/CONTENTS.txt" \
  "$FREEZE_PACKAGE/MANIFEST.json" \
  "$FREEZE_PACKAGE/PROVENANCE.json" \
  "$FREEZE_PACKAGE/README.md" \
  "$FREEZE_PACKAGE/REPRODUCE.md" \
  "$FREEZE_PACKAGE/SHA256SUMS" \
  "$FREEZE_PACKAGE/STATUS.json" \
  "$FREEZE_PACKAGE/archive/$ARCHIVE_NAME.sha256" \
  "$FREEZE_PACKAGE/freeze/FREEZE.json"

echo "freeze_package_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"
echo "canonical_bootstrap_rerun_performed=false"

echo
echo "=== 10. Commit frozen package ==="

git commit \
  -m "evidence(experiments): freeze membership-density Stage-10 campaign"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 11. Push freeze branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 12. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Freeze membership-density Stage-10 campaign" \
    --body "$(cat <<EOF
## Canonical scientific freeze

- factor: \`membership_density\`;
- stage: \`10\`;
- formal timing replications: \`10\`;
- measurement observations: \`92,000\`;
- successful bootstrap executions: \`1\`;
- bootstrap repetitions: \`10,000\`;
- all precision targets met: \`true\`;
- failing cells: \`0\`;
- Stage-10 sufficient: \`true\`;
- Stage-20 extension required: \`false\`.

## Frozen package

- package: \`sa4_membership_density_stage10\`;
- payload files: \`$PAYLOAD_FILE_COUNT\`;
- archive size: \`$ARCHIVE_SIZE\` bytes;
- archive SHA-256:
  \`$ARCHIVE_SHA\`.

## Publication controls after merge

- scientific freeze: \`true\`;
- latency claims authorized: \`true\`;
- manuscript integration authorized: \`true\`;
- global scientific freeze: \`false\`.

## Immutability

- timing re-execution: \`false\`;
- adapter rematerialization: \`false\`;
- canonical bootstrap rerun: \`false\`;
- Stage-20 execution: \`false\`.

## Next stage

\`integrate_membership_density_stage10_results_into_manuscript\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 13. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_stage10_scientific_freeze=PASS"
echo "commit=$COMMIT"
echo "canonical_archive_sha256=$ARCHIVE_SHA"
echo "canonical_archive_size_bytes=$ARCHIVE_SIZE"
echo "canonical_payload_file_count=$PAYLOAD_FILE_COUNT"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=true"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"
echo "scientific_freeze=true"
echo "latency_claim_authorized=true"
echo "manuscript_resume_authorized=true"
echo "global_scientific_freeze=false"
echo "canonical_bootstrap_rerun_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_stage10_freeze"

git status --short --branch
git log --oneline --decorate -4
