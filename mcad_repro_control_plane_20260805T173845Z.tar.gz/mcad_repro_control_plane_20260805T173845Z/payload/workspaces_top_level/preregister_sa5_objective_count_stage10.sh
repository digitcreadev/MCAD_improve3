#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="496addef55cc60a3303fa1e62a12392be2296ece"
IMPLEMENTATION_COMMIT="a4f7767b2100c997456b55efce2714da6e29254f"

DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"

CONTROLLED="backend/harness/sensitivity_generator/families/controlled_families.py"
OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
E3_CONTRACT="backend/harness/sensitivity_execution/e3_contract.yaml"

PLANNING_DIR="reports/article_experiments/sensitivity/e3_controlled_execution/planning"

PREREG="$PLANNING_DIR/sa5_objective_count_stage10_campaign_preregistration.json"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"

FROZEN_DENSITY_PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_stage10"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"

DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

EXPECTED_E21_VERSION="mcad-sensitivity-e2.1-objective-count-v1"
EXPECTED_E22_VERSION="mcad-sensitivity-e2.2-objective-count-v1"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-sa5-objective-count-stage10-${STAMP}"

BUILD_ROOT="/workspaces/sa5_objective_count_stage10_preregistration_${STAMP}"

SEED_REPORT="$BUILD_ROOT/stage10_seed_schedule_discovery.json"

trap 'echo "[ERROR] SA5 preregistration stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. SA5 preregistration gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$DESIGN_MATRIX" \
  "$CONTROLLED" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$EXECUTOR" \
  "$E3_CONTRACT" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test -d "$FROZEN_DENSITY_PACKAGE"

test ! -e "$PREREG"
test ! -e "$PREREG_TEST"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

"$PYTHON" - <<'PY'
from backend.harness.sensitivity_execution.execute_controlled_family import (
    SUPPORTED_GENERATOR_VERSION_PAIRS,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    SUPPORTED_FACTORS,
)
from backend.harness.sensitivity_generator.families.objective_count_family import (
    CAMPAIGN_GENERATOR_VERSION,
    STRUCTURAL_GENERATOR_VERSION,
)

assert "objective_count" in SUPPORTED_FACTORS

assert STRUCTURAL_GENERATOR_VERSION == (
    "mcad-sensitivity-e2.1-objective-count-v1"
)

assert CAMPAIGN_GENERATOR_VERSION == (
    "mcad-sensitivity-e2.2-objective-count-v1"
)

assert (
    SUPPORTED_GENERATOR_VERSION_PAIRS[
        "objective_count"
    ]
    == (
        CAMPAIGN_GENERATOR_VERSION,
        STRUCTURAL_GENERATOR_VERSION,
    )
)

print("objective_count_implementation_binding=PASS")
PY

echo "preregistration_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "implementation_commit=$IMPLEMENTATION_COMMIT"
echo "canonical_campaign_generated=false"
echo "campaign_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Initialize detached preregistration build ==="

rm -rf "$BUILD_ROOT"

mkdir -p "$BUILD_ROOT"

echo "build_root=$BUILD_ROOT"

echo
echo "=== 3. Discover frozen Stage-10 seed schedule ==="

"$PYTHON" - \
  "$ROOT" \
  "$FROZEN_DENSITY_PACKAGE" \
  "$SEED_REPORT" <<'PY'
from __future__ import annotations

import hashlib
import json
import tarfile
import sys
from pathlib import Path
from typing import Any, Iterator

root = Path(sys.argv[1]).resolve()
package = (root / sys.argv[2]).resolve()
report_path = Path(sys.argv[3]).resolve()

planning_root = (
    root
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
)

accepted_seed_keys = {
    "seeds",
    "structural_seeds",
    "replication_seeds",
    "canonical_seeds",
    "stage10_seeds",
}

sources: list[dict[str, Any]] = []
schedules: dict[
    tuple[int, ...],
    list[dict[str, Any]],
] = {}


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def walk(
    value: Any,
    path: tuple[str, ...] = (),
) -> Iterator[tuple[tuple[str, ...], Any]]:
    yield path, value

    if isinstance(value, dict):
        for key, item in value.items():
            yield from walk(
                item,
                (*path, str(key)),
            )

    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(
                item,
                (*path, str(index)),
            )


def contains_density_stage10(value: Any) -> bool:
    factor_found = False
    stage10_found = False

    for path, item in walk(value):
        key = path[-1] if path else ""

        if (
            key == "factor"
            and item == "membership_density"
        ):
            factor_found = True

        if (
            key == "stage"
            and item == 10
        ):
            stage10_found = True

        if isinstance(item, str):
            lowered = item.lower()

            if (
                "membership_density" in lowered
                or "membership-density" in lowered
            ) and (
                "stage10" in lowered
                or "stage-10" in lowered
                or "stage_10" in lowered
            ):
                factor_found = True
                stage10_found = True

    return factor_found and stage10_found


def register_document(
    *,
    source: str,
    payload: bytes,
) -> None:
    try:
        value = json.loads(
            payload.decode("utf-8")
        )
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
    ):
        return

    if not contains_density_stage10(value):
        return

    for path, item in walk(value):
        if not path:
            continue

        key = path[-1]

        if key not in accepted_seed_keys:
            continue

        if (
            not isinstance(item, list)
            or len(item) != 10
            or any(
                isinstance(seed, bool)
                or not isinstance(seed, int)
                or seed <= 0
                for seed in item
            )
            or len(set(item)) != 10
        ):
            continue

        schedule = tuple(item)

        record = {
            "source": source,
            "json_path": ".".join(path),
            "source_sha256": sha256_bytes(payload),
            "seeds": list(schedule),
        }

        schedules.setdefault(
            schedule,
            [],
        ).append(record)


if planning_root.exists():
    for path in sorted(
        planning_root.rglob("*.json")
    ):
        try:
            payload = path.read_bytes()
        except OSError:
            continue

        register_document(
            source=path.relative_to(root).as_posix(),
            payload=payload,
        )


archive_candidates = sorted(
    (package / "archive").glob("*.tar.gz")
)

if len(archive_candidates) != 1:
    raise SystemExit(
        "Expected exactly one frozen "
        "membership-density archive."
    )

archive = archive_candidates[0]

with tarfile.open(
    archive,
    mode="r:gz",
) as handle:
    for member in handle.getmembers():
        if (
            not member.isfile()
            or not member.name.endswith(".json")
        ):
            continue

        extracted = handle.extractfile(member)

        if extracted is None:
            continue

        payload = extracted.read()

        register_document(
            source=(
                archive.relative_to(root).as_posix()
                + "!"
                + member.name
            ),
            payload=payload,
        )


if not schedules:
    raise SystemExit(
        "No canonical membership-density "
        "Stage-10 seed schedule was found."
    )

if len(schedules) != 1:
    rendered = {
        ",".join(str(seed) for seed in schedule):
            records
        for schedule, records in schedules.items()
    }

    raise SystemExit(
        "Ambiguous Stage-10 seed schedules:\n"
        + json.dumps(
            rendered,
            indent=2,
            sort_keys=True,
        )
    )

schedule, sources = next(
    iter(schedules.items())
)

report = {
    "schema_version": (
        "mcad-stage10-seed-schedule-discovery-v1"
    ),
    "factor_source": "membership_density",
    "stage_source": 10,
    "schedule_reuse_target": "objective_count",
    "seed_count": len(schedule),
    "seeds": list(schedule),
    "source_count": len(sources),
    "sources": sources,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print("stage10_seed_schedule_discovery=PASS")
print(f"seed_count={len(schedule)}")
print(
    "seeds="
    + ",".join(str(seed) for seed in schedule)
)
print(f"seed_schedule_source_count={len(sources)}")
PY

test -s "$SEED_REPORT"

jq -e '
  .schema_version
    == "mcad-stage10-seed-schedule-discovery-v1"
  and .factor_source == "membership_density"
  and .stage_source == 10
  and .schedule_reuse_target == "objective_count"
  and .seed_count == 10
  and (.seeds | length) == 10
  and (.seeds | unique | length) == 10
  and .source_count >= 1
' "$SEED_REPORT" >/dev/null

echo "seed_schedule_gate=PASS"

echo
echo "=== 4. Validate canonical SA5 design values ==="

"$PYTHON" - \
  "$DESIGN_MATRIX" \
  "$BUILD_ROOT/design_validation.json" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml

design_path = Path(sys.argv[1]).resolve()
report_path = Path(sys.argv[2]).resolve()

design = yaml.safe_load(
    design_path.read_text(encoding="utf-8")
)

axis = design["axes"]["objective_count"]
baseline = design["baseline"]

assert axis["primary_factor"] == "objective_count"
assert axis["levels"] == [1, 2, 5, 10, 20, 50]

fixed = axis["fixed"]

assert fixed["constraints_per_objective"] == 8
assert fixed["virtual_nodes_per_objective"] == 32
assert fixed["contribution_density"] == 0.50
assert fixed["workload_length"] == 40
assert fixed["noise_ratio"] == 0.25

noise_distribution = baseline[
    "noise_distribution"
]

assert set(noise_distribution) == {
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
}

assert abs(
    sum(float(value) for value in noise_distribution.values())
    - 1.0
) < 1.0e-12

assert all(
    abs(float(value) - 0.125) < 1.0e-12
    for value in noise_distribution.values()
)

report = {
    "factor": "objective_count",
    "levels": axis["levels"],
    "constraints_per_objective": (
        fixed["constraints_per_objective"]
    ),
    "virtual_nodes_per_objective": (
        fixed["virtual_nodes_per_objective"]
    ),
    "contribution_density": (
        fixed["contribution_density"]
    ),
    "workload_length": fixed["workload_length"],
    "noise_ratio": fixed["noise_ratio"],
    "noise_distribution": noise_distribution,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

print("sa5_design_value_validation=PASS")
print("levels=1,2,5,10,20,50")
print("constraints_per_objective=8")
print("virtual_nodes_per_objective=32")
print("workload_length=40")
print("noise_ratio=0.25")
PY

echo
echo "=== 5. Create preregistration branch ==="

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 6. Author exact SA5 preregistration ==="

mkdir -p "$PLANNING_DIR"

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$PREREG_TEST" \
  "$SEED_REPORT" \
  "$BUILD_ROOT/design_validation.json" \
  "$CREATED_UTC" \
  "$EXPECTED_HEAD" \
  "$IMPLEMENTATION_COMMIT" \
  "$EXPECTED_E21_VERSION" \
  "$EXPECTED_E22_VERSION" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()

prereg_path = root / sys.argv[2]
test_path = root / sys.argv[3]

seed_report_path = Path(sys.argv[4]).resolve()
design_report_path = Path(sys.argv[5]).resolve()

created_utc = sys.argv[6]
source_commit = sys.argv[7]
implementation_commit = sys.argv[8]
e21_version = sys.argv[9]
e22_version = sys.argv[10]

seeds = json.loads(
    seed_report_path.read_text(
        encoding="utf-8"
    )
)

design = json.loads(
    design_report_path.read_text(
        encoding="utf-8"
    )
)

levels = design["levels"]

constraints_per_objective = design[
    "constraints_per_objective"
]

virtual_nodes_per_objective = design[
    "virtual_nodes_per_objective"
]

planned_instances = [
    {
        "factor_level": level,
        "replication_count": len(seeds["seeds"]),
        "expected_instance_count": len(
            seeds["seeds"]
        ),
        "expected_total_constraint_count": (
            level * constraints_per_objective
        ),
        "expected_total_virtual_node_count": (
            level * virtual_nodes_per_objective
        ),
    }
    for level in levels
]

preregistration: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "campaign-preregistration-v1"
    ),
    "preregistration_id": (
        "sa5_objective_count_stage10_c8_nv32"
    ),
    "status": "preregistered_not_materialized",
    "phase": "SA5",
    "factor": "objective_count",
    "stage": 10,
    "created_utc": created_utc,
    "source_repository": "digitcreadev/MCAD_improve3",
    "source_branch": (
        "paper/phase3-controlled-execution"
    ),
    "source_commit": source_commit,
    "implementation_commit": implementation_commit,
    "scientific_question": (
        "Measure the effect of increasing the total "
        "number of objectives in the CKG while the "
        "selected objective, its per-objective "
        "structure, and its workload remain controlled."
    ),
    "implementation_binding": {
        "structural_generator_path": (
            "backend/harness/sensitivity_generator/"
            "objective_count_generator.py"
        ),
        "structural_generator_version": e21_version,
        "controlled_family_path": (
            "backend/harness/sensitivity_generator/"
            "families/objective_count_family.py"
        ),
        "campaign_generator_version": e22_version,
        "executor_path": (
            "backend/harness/sensitivity_execution/"
            "execute_controlled_family.py"
        ),
        "executor_version": "mcad-sensitivity-e3-v2",
    },
    "factor_contract": {
        "factor_levels": levels,
        "factor_level_encoding": (
            "integer_total_objective_count"
        ),
        "selected_objective_index": 0,
        "selected_objective_binding": (
            "first generated objective"
        ),
        "constraints_per_objective": (
            constraints_per_objective
        ),
        "virtual_nodes_per_objective": (
            virtual_nodes_per_objective
        ),
        "requirement_sets_per_constraint": 1,
        "membership_density": 1.0,
        "contribution_density": design[
            "contribution_density"
        ],
        "workload_length": design[
            "workload_length"
        ],
        "noise_ratio": design["noise_ratio"],
        "noise_distribution": design[
            "noise_distribution"
        ],
    },
    "replication_contract": {
        "stage": 10,
        "replication_count": len(
            seeds["seeds"]
        ),
        "structural_seeds": seeds["seeds"],
        "seed_schedule_policy": (
            "reuse the canonical first ten structural "
            "seeds already used for the frozen "
            "membership-density Stage-10 campaign"
        ),
        "seed_schedule_source_count": seeds[
            "source_count"
        ],
        "seed_schedule_sources": seeds[
            "sources"
        ],
        "level_count": len(levels),
        "expected_instance_count": (
            len(levels) * len(seeds["seeds"])
        ),
        "planned_instances_by_level": (
            planned_instances
        ),
    },
    "common_workload_contract": {
        "workload_count_per_replication": 1,
        "workload_length": design[
            "workload_length"
        ],
        "noise_ratio": design["noise_ratio"],
        "noise_distribution": design[
            "noise_distribution"
        ],
        "sharing_rule": (
            "For each structural seed, one deterministic "
            "canonical workload is shared across all six "
            "objective-count levels."
        ),
        "objective_binding_rule": (
            "Each level-specific workload is bound to "
            "selected_objective_index 0 by deterministic "
            "objective-identifier substitution only."
        ),
        "semantic_equivalence_rule": (
            "After selected-objective identifier "
            "normalization, query specifications must be "
            "byte-equivalent across levels for a given seed."
        ),
        "functional_execution_rule": (
            "Every generated level must execute the same "
            "ordered semantic query sequence for its seed."
        ),
    },
    "ofat_invariants": [
        (
            "realised objective count equals the "
            "registered factor level"
        ),
        (
            "selected objective index remains equal to 0"
        ),
        (
            "selected objective constraint count remains "
            "equal to 8"
        ),
        (
            "selected objective virtual-node count remains "
            "equal to 32"
        ),
        (
            "selected-objective structural shape digest "
            "is invariant across factor levels within "
            "each seed"
        ),
        (
            "total constraint count equals factor level "
            "multiplied by 8"
        ),
        (
            "total virtual-node count equals factor level "
            "multiplied by 32"
        ),
        (
            "membership density remains equal to 1.0"
        ),
        (
            "workload length remains equal to 40"
        ),
        (
            "realised workload noise ratio remains equal "
            "to 0.25 within the preregistered tolerance"
        ),
        (
            "campaign and structural generator versions "
            "match the objective-count E3 profile"
        ),
    ],
    "audit_contract": {
        "required_instance_count": (
            len(levels) * len(seeds["seeds"])
        ),
        "required_level_count": len(levels),
        "required_replication_count": len(
            seeds["seeds"]
        ),
        "required_semantic_mismatch_count": 0,
        "required_generator_failure_count": 0,
        "required_missing_instance_count": 0,
        "required_duplicate_condition_count": 0,
        "required_selected_shape_mismatch_count": 0,
        "required_workload_mismatch_count": 0,
    },
    "execution_sequence": [
        (
            "materialize Stage-10 structures and "
            "common workloads"
        ),
        (
            "audit structure, OFAT invariants, references, "
            "and workload equivalence"
        ),
        (
            "authorize functional execution in a separate "
            "immutable authorization artifact"
        ),
        (
            "execute and audit Stage-10 functional campaign"
        ),
        (
            "preregister timing only after functional "
            "completion and workload-cardinality audit"
        ),
    ],
    "authorization": {
        "preregistration_persistence_authorized": True,
        "campaign_materialization_authorized_now": False,
        (
            "campaign_materialization_authorized_"
            "after_preregistration_merge"
        ): True,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "manuscript_integration_authorized": False,
        "global_scientific_freeze": False,
    },
    "planned_repository_paths": {
        "campaign_root": (
            "reports/article_experiments/sensitivity/"
            "e3_controlled_execution/campaigns/"
            "objective_count_stage10_c8_nv32"
        ),
        "audit_root": (
            "reports/article_experiments/sensitivity/"
            "e3_controlled_execution/audits/"
            "objective_count/stage10"
        ),
        "timing_plan": None,
        "frozen_campaign": None,
        "deferred_manuscript_fragment": None,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "scientific_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": (
        "materialize_sa5_objective_count_stage10_"
        "structure_and_common_workloads"
    ),
}

prereg_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

prereg_path.write_text(
    json.dumps(
        preregistration,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

test_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

test_path.write_text(
    r'''from __future__ import annotations

import json
from pathlib import Path

import yaml

from backend.harness.sensitivity_execution.execute_controlled_family import (
    SUPPORTED_GENERATOR_VERSION_PAIRS,
)
from backend.harness.sensitivity_generator.families.objective_count_family import (
    CAMPAIGN_GENERATOR_VERSION,
    STRUCTURAL_GENERATOR_VERSION,
)

ROOT = Path(__file__).resolve().parents[4]

PREREGISTRATION_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_stage10_"
        "campaign_preregistration.json"
    )
)

DESIGN_MATRIX_PATH = (
    ROOT
    / "backend"
    / "harness"
    / "sensitivity_design"
    / "design_matrix.yaml"
)


def load_preregistration() -> dict:
    value = json.loads(
        PREREGISTRATION_PATH.read_text(
            encoding="utf-8"
        )
    )

    assert isinstance(value, dict)

    return value


def load_design() -> dict:
    value = yaml.safe_load(
        DESIGN_MATRIX_PATH.read_text(
            encoding="utf-8"
        )
    )

    assert isinstance(value, dict)

    return value


def test_preregistration_identity_and_status() -> None:
    preregistration = load_preregistration()

    assert preregistration["schema_version"] == (
        "mcad-sa5-objective-count-stage10-"
        "campaign-preregistration-v1"
    )

    assert preregistration[
        "preregistration_id"
    ] == "sa5_objective_count_stage10_c8_nv32"

    assert preregistration["phase"] == "SA5"
    assert preregistration["factor"] == "objective_count"
    assert preregistration["stage"] == 10
    assert preregistration["status"] == (
        "preregistered_not_materialized"
    )


def test_factor_contract_matches_frozen_design() -> None:
    preregistration = load_preregistration()
    design = load_design()

    contract = preregistration[
        "factor_contract"
    ]

    axis = design["axes"]["objective_count"]

    assert contract["factor_levels"] == [
        1,
        2,
        5,
        10,
        20,
        50,
    ]

    assert contract["factor_levels"] == (
        axis["levels"]
    )

    assert contract[
        "selected_objective_index"
    ] == 0

    assert contract[
        "constraints_per_objective"
    ] == 8

    assert contract[
        "virtual_nodes_per_objective"
    ] == 32

    assert contract["workload_length"] == 40
    assert contract["noise_ratio"] == 0.25
    assert contract["membership_density"] == 1.0

    assert abs(
        sum(
            contract[
                "noise_distribution"
            ].values()
        )
        - 1.0
    ) < 1.0e-12


def test_stage10_replication_contract() -> None:
    preregistration = load_preregistration()

    replication = preregistration[
        "replication_contract"
    ]

    seeds = replication[
        "structural_seeds"
    ]

    assert replication["stage"] == 10
    assert replication["replication_count"] == 10
    assert replication["level_count"] == 6
    assert replication[
        "expected_instance_count"
    ] == 60

    assert len(seeds) == 10
    assert len(set(seeds)) == 10

    assert all(
        isinstance(seed, int)
        and not isinstance(seed, bool)
        and seed > 0
        for seed in seeds
    )

    expected_by_level = {
        1: (8, 32),
        2: (16, 64),
        5: (40, 160),
        10: (80, 320),
        20: (160, 640),
        50: (400, 1600),
    }

    rows = replication[
        "planned_instances_by_level"
    ]

    assert len(rows) == 6

    for row in rows:
        level = row["factor_level"]

        constraints, virtual_nodes = (
            expected_by_level[level]
        )

        assert row[
            "replication_count"
        ] == 10

        assert row[
            "expected_instance_count"
        ] == 10

        assert row[
            "expected_total_constraint_count"
        ] == constraints

        assert row[
            "expected_total_virtual_node_count"
        ] == virtual_nodes


def test_generator_profiles_are_exact() -> None:
    preregistration = load_preregistration()

    binding = preregistration[
        "implementation_binding"
    ]

    assert STRUCTURAL_GENERATOR_VERSION == (
        "mcad-sensitivity-e2.1-"
        "objective-count-v1"
    )

    assert CAMPAIGN_GENERATOR_VERSION == (
        "mcad-sensitivity-e2.2-"
        "objective-count-v1"
    )

    assert binding[
        "structural_generator_version"
    ] == STRUCTURAL_GENERATOR_VERSION

    assert binding[
        "campaign_generator_version"
    ] == CAMPAIGN_GENERATOR_VERSION

    assert (
        SUPPORTED_GENERATOR_VERSION_PAIRS[
            "objective_count"
        ]
        == (
            CAMPAIGN_GENERATOR_VERSION,
            STRUCTURAL_GENERATOR_VERSION,
        )
    )


def test_common_workload_is_seed_shared() -> None:
    preregistration = load_preregistration()

    workload = preregistration[
        "common_workload_contract"
    ]

    assert workload[
        "workload_count_per_replication"
    ] == 1

    assert workload["workload_length"] == 40
    assert workload["noise_ratio"] == 0.25

    assert (
        "shared across all six"
        in workload["sharing_rule"]
    )

    assert (
        "selected_objective_index 0"
        in workload["objective_binding_rule"]
    )

    assert (
        "byte-equivalent"
        in workload[
            "semantic_equivalence_rule"
        ]
    )


def test_execution_remains_unauthorized() -> None:
    preregistration = load_preregistration()

    authorization = preregistration[
        "authorization"
    ]

    assert authorization[
        "preregistration_persistence_authorized"
    ] is True

    assert authorization[
        "campaign_materialization_authorized_now"
    ] is False

    assert authorization[
        (
            "campaign_materialization_authorized_"
            "after_preregistration_merge"
        )
    ] is True

    assert authorization[
        "functional_execution_authorized"
    ] is False

    assert authorization[
        "timing_execution_authorized"
    ] is False

    assert authorization[
        "precision_analysis_authorized"
    ] is False

    assert authorization[
        "bootstrap_execution_authorized"
    ] is False

    assert authorization[
        "stage20_execution_authorized"
    ] is False

    assert authorization[
        "latency_claim_authorized"
    ] is False

    assert authorization[
        "manuscript_integration_authorized"
    ] is False

    assert authorization[
        "global_scientific_freeze"
    ] is False


def test_preregistration_records_no_execution() -> None:
    preregistration = load_preregistration()

    controls = preregistration[
        "scientific_controls"
    ]

    assert controls[
        "canonical_campaign_generated"
    ] is False

    assert controls[
        "scientific_execution_performed"
    ] is False

    assert controls[
        "timing_execution_performed"
    ] is False

    assert controls[
        "bootstrap_execution_performed"
    ] is False

    assert controls[
        "manuscript_modified"
    ] is False

    assert preregistration["next_stage"] == (
        "materialize_sa5_objective_count_stage10_"
        "structure_and_common_workloads"
    )
'''.rstrip()
    + "\n",
    encoding="utf-8",
)

print("sa5_preregistration_authoring=PASS")
print(f"preregistration={prereg_path.relative_to(root)}")
print(f"test={test_path.relative_to(root)}")
print("factor_level_count=6")
print("replication_count=10")
print("expected_instance_count=60")
print("selected_objective_index=0")
print("campaign_materialization_authorized_now=false")
print("functional_execution_authorized=false")
print("timing_execution_authorized=false")
PY

echo
echo "=== 7. Validate preregistration JSON ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-campaign-preregistration-v1"
  and .status == "preregistered_not_materialized"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "496addef55cc60a3303fa1e62a12392be2296ece"
  and .implementation_commit
    == "a4f7767b2100c997456b55efce2714da6e29254f"
  and .factor_contract.factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .factor_contract.selected_objective_index == 0
  and .factor_contract.constraints_per_objective == 8
  and .factor_contract.virtual_nodes_per_objective == 32
  and .factor_contract.workload_length == 40
  and .factor_contract.noise_ratio == 0.25
  and .replication_contract.replication_count == 10
  and .replication_contract.expected_instance_count == 60
  and (
    .replication_contract.structural_seeds
    | length
  ) == 10
  and .authorization.campaign_materialization_authorized_now
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$PREREG" >/dev/null

echo "preregistration_json_validation=PASS"

echo
echo "=== 8. Compile and run preregistration tests ==="

"$PYTHON" -m py_compile \
  "$PREREG_TEST"

"$PYTHON" -m pytest \
  "$PREREG_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_e3_contract.py \
  -q \
  -p no:cacheprovider

echo "sa5_preregistration_tests=PASS"

echo
echo "=== 9. Repository-scope validation ==="

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

CHANGED_FILES="$(
  git status --short |
    sed -E 's/^.. //'
)"

CHANGED_FILE_COUNT="$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 2

for FILE in \
  "$PREREG" \
  "$PREREG_TEST"
do
  test "$(
    printf '%s\n' "$CHANGED_FILES" |
      grep -Fx "$FILE" |
      wc -l
  )" -eq 1
done

git diff --check

echo "preregistration_scope_validation=PASS"
echo "changed_file_count=2"
echo "manuscript_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 10. Stage preregistration ==="

git add \
  "$PREREG" \
  "$PREREG_TEST"

test "$(
  git diff --cached --name-only |
    wc -l
)" -eq 2

git diff --cached --check

echo "preregistration_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 11. Commit preregistration ==="

git commit \
  -m "chore(experiments): preregister SA5 objective-count Stage-10"

COMMIT="$(git rev-parse HEAD)"

PREREG_SHA="$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)"

echo "commit=PASS"
echo "commit=$COMMIT"
echo "preregistration_sha256=$PREREG_SHA"

echo
echo "=== 12. Push preregistration branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 13. Create pull request ==="

SEEDS="$(
  jq -r \
    '.replication_contract.structural_seeds
     | map(tostring)
     | join(", ")' \
    "$PREREG"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister SA5 objective-count Stage-10 campaign" \
    --body "$(cat <<EOF
## SA5 preregistration

Preregisters the canonical Stage-10 objective-count campaign before
materialization.

### Factor design

- levels: \`1, 2, 5, 10, 20, 50\`;
- replications: \`10\`;
- expected instances: \`60\`;
- selected objective index: \`0\`;
- constraints per objective: \`8\`;
- virtual nodes per objective: \`32\`;
- workload length: \`40\`;
- workload noise ratio: \`0.25\`.

### Structural seeds

\`$SEEDS\`

The schedule reuses the canonical first ten structural seeds already
used by the frozen membership-density Stage-10 campaign.

### Common-workload policy

For each seed, one deterministic workload is shared across all six
objective-count levels after deterministic selected-objective identifier
substitution.

### Scientific controls

- canonical campaign generated: \`false\`;
- functional execution authorized: \`false\`;
- timing execution authorized: \`false\`;
- bootstrap execution authorized: \`false\`;
- latency claims authorized: \`false\`;
- manuscript modified: \`false\`;
- global scientific freeze: \`false\`.

Materialization becomes eligible only after this preregistration is
merged.

### Integrity

- preregistration SHA-256: \`$PREREG_SHA\`.

## Next stage

\`materialize_sa5_objective_count_stage10_structure_and_common_workloads\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 14. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_stage10_preregistration=PASS"
echo "commit=$COMMIT"
echo "preregistration=$PREREG"
echo "preregistration_sha256=$PREREG_SHA"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "selected_objective_index=0"
echo "constraints_per_objective=8"
echo "virtual_nodes_per_objective=32"
echo "workload_length=40"
echo "noise_ratio=0.25"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_authorized_now=false"
echo "functional_execution_authorized=false"
echo "timing_execution_authorized=false"
echo "bootstrap_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_preregistration"

git status --short --branch
git log --oneline --decorate -4
