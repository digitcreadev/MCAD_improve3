#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="dd17d13104b90b5e24cf5b072f6ea66cc18e49db"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PRECISION_ROOT="$REPORTS/audits/membership_density/timing_stage10/precision_analysis"

PREREG="$REPORTS/planning/sa4_membership_density_non_mutating_precision_adapter_preregistration.json"
LEDGER="$REPORTS/timing_runs/membership_density_stage10_portfolio/stage10_execution_ledger.json"
OUTPUT_AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

OBSERVATIONS="$PRECISION_ROOT/stage10_portfolio_measurement_observations.csv"
TIMING_ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

AUTH_JSON="$REPORTS/planning/sa4_membership_density_portfolio_precision_analysis_authorization.json"
AUTH_MD="$REPORTS/planning/sa4_membership_density_portfolio_precision_analysis_authorization.md"

RAW_LOG="$PRECISION_ROOT/analyzer.log"
RAW_INTERVALS="$PRECISION_ROOT/raw_analyzer_intervals.csv"
RAW_REPORT_JSON="$PRECISION_ROOT/raw_analyzer_report.json"
RAW_REPORT_MD="$PRECISION_ROOT/raw_analyzer_report.md"

DECISION_JSON="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.json"
DECISION_MD="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.md"

EXPECTED_PREREG_SHA="4e7041988c388837f5d4d71c07a659a209b479ddf4dd1f1cd7798cbb8aa2695b"
EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"
EXPECTED_OUTPUT_AUDIT_SHA="fd3bf7ef8ee06e09ffe88548b361516ee9ad0760964932fed1ed3b7e83477888"

EXPECTED_OBSERVATIONS_SHA="757c8e7684396cf1b5d7a923a4b7935a95b746896fac357c7ef4ea93df36133a"
EXPECTED_TIMING_ADAPTER_SHA="0bd99f578b6aca3913536fd8b237f89a9607db369a1fa4ad2243b9ceb295f9c3"
EXPECTED_MANIFEST_SHA="449d0d54bb10df84327e3d757382e33c78abe9d2c9b3c5f55e3d8d5ee6ac2451"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

EXPECTED_OBSERVATIONS_SIZE=55447769

trap 'echo "[ERROR] Precision authorization stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Authorization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" | awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$OUTPUT_AUDIT" | awk '{print $1}'
)" = "$EXPECTED_OUTPUT_AUDIT_SHA"

test "$(
  sha256sum "$OBSERVATIONS" | awk '{print $1}'
)" = "$EXPECTED_OBSERVATIONS_SHA"

test "$(
  sha256sum "$TIMING_ADAPTER" | awk '{print $1}'
)" = "$EXPECTED_TIMING_ADAPTER_SHA"

test "$(
  sha256sum "$INPUT_MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

test "$(stat -c '%s' "$OBSERVATIONS")" -eq "$EXPECTED_OBSERVATIONS_SIZE"

for OUTPUT in \
  "$AUTH_JSON" \
  "$AUTH_MD" \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"
do
  test ! -e "$OUTPUT"
done

jq -e '
  .status
    == "membership_density_non_mutating_precision_adapter_inputs_materialized"
  and .factor == "membership_density"
  and .adapter_contract.derived_measurement_observation_count == 92000
  and .adapter_contract.analyzer_timing_cell_count == 40
  and .adapter_contract.inferential_cell_count == 4
  and .adapter_contract.structural_seed_count == 10
  and .adapter_contract.measurements_per_cluster == 2300
  and .adapter_contract.measurements_per_inferential_cell == 23000
  and .join_audit.unmatched_row_count == 0
  and .join_audit.ambiguous_plan_key_count == 0
  and .join_audit.step_id_mismatch_count == 0
  and .join_audit.duplicate_source_row_count == 0
  and .materialization_decision.adapter_inputs_validated == true
  and .materialization_decision.precision_analysis_ready_for_authorization
      == true
  and .materialization_decision.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$INPUT_MANIFEST" >/dev/null

jq -e '
  .status == "stage10_formal_timing_execution_success"
  and .factor == "membership_density"
  and .totals.successful_run_count == 10
  and .totals.cell_count == 40
  and .totals.measurement_observation_count == 92000
  and .totals.functional_mismatch_count == 0
  and .totals.structural_seed_count == 10
  and .scientific_controls.precision_analysis_performed == false
' "$TIMING_ADAPTER" >/dev/null

echo "authorization_gate=PASS"
echo "adapter_materialization_performed=true"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create authorization branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/authorize-membership-density-portfolio-precision-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Create exact precision-analysis authorization ==="

python - \
  "$ROOT" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$PREREG" \
  "$LEDGER" \
  "$OUTPUT_AUDIT" \
  "$OBSERVATIONS" \
  "$TIMING_ADAPTER" \
  "$INPUT_MANIFEST" \
  "$ANALYZER" \
  "$AUTH_JSON" \
  "$AUTH_MD" \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
source_commit = sys.argv[2]
created_utc = sys.argv[3]

prereg_path = (root / sys.argv[4]).resolve()
ledger_path = (root / sys.argv[5]).resolve()
output_audit_path = (root / sys.argv[6]).resolve()
observations_path = (root / sys.argv[7]).resolve()
timing_adapter_path = (root / sys.argv[8]).resolve()
manifest_path = (root / sys.argv[9]).resolve()
analyzer_path = (root / sys.argv[10]).resolve()

auth_json = (root / sys.argv[11]).resolve()
auth_md = (root / sys.argv[12]).resolve()

raw_log = (root / sys.argv[13]).resolve()
raw_intervals = (root / sys.argv[14]).resolve()
raw_report_json = (root / sys.argv[15]).resolve()
raw_report_md = (root / sys.argv[16]).resolve()
decision_json = (root / sys.argv[17]).resolve()
decision_md = (root / sys.argv[18]).resolve()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.resolve().relative_to(root).as_posix()


prereg = load_object(prereg_path)
ledger = load_object(ledger_path)
output_audit = load_object(output_audit_path)
manifest = load_object(manifest_path)
timing_adapter = load_object(timing_adapter_path)

if prereg.get("factor") != "membership_density":
    raise SystemExit("Preregistration factor mismatch.")

if manifest.get("status") != (
    "membership_density_non_mutating_"
    "precision_adapter_inputs_materialized"
):
    raise SystemExit("Adapter-input manifest status mismatch.")

if timing_adapter.get("factor") != "membership_density":
    raise SystemExit("Timing-report adapter factor mismatch.")

if (
    ledger.get("execution_totals", {})
    .get("measurement_observation_count")
    != 92000
):
    raise SystemExit("Execution-ledger measurement total mismatch.")

if (
    output_audit.get("audit_decision", {})
    .get("stage10_timing_execution_accepted")
    is not True
):
    raise SystemExit("Timing-output audit is not accepted.")

authorization = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "portfolio-precision-analysis-authorization-v1"
    ),
    "status": (
        "membership_density_portfolio_"
        "precision_analysis_authorized"
    ),
    "factor": "membership_density",
    "stage": 10,
    "created_utc": created_utc,
    "source_commit": source_commit,
    "authorization_scope": {
        "execution_count_authorized": 1,
        "successful_execution_count_observed": 0,
        "analyzer_execution_authorized": True,
        "adapter_rematerialization_authorized": False,
        "timing_reexecution_authorized": False,
        "functional_rerun_authorized": False,
        "stage20_execution_authorized": False,
        "canonical_decision_materialization_authorized": True,
    },
    "source_artifacts": {
        "adapter_preregistration": {
            "path": relative(prereg_path),
            "sha256": sha256(prereg_path),
        },
        "execution_ledger": {
            "path": relative(ledger_path),
            "sha256": sha256(ledger_path),
        },
        "stage10_output_audit": {
            "path": relative(output_audit_path),
            "sha256": sha256(output_audit_path),
        },
        "derived_observations": {
            "path": relative(observations_path),
            "sha256": sha256(observations_path),
            "size_bytes": observations_path.stat().st_size,
            "row_count": 92000,
        },
        "timing_report_adapter": {
            "path": relative(timing_adapter_path),
            "sha256": sha256(timing_adapter_path),
        },
        "precision_input_manifest": {
            "path": relative(manifest_path),
            "sha256": sha256(manifest_path),
        },
        "precision_analyzer": {
            "path": relative(analyzer_path),
            "sha256": sha256(analyzer_path),
        },
    },
    "analysis_contract": {
        "stage_size": 10,
        "levels": [25, 50, 75, 100],
        "steps": [0],
        "analyzer_timing_cell_count": 40,
        "inferential_cell_count": 4,
        "structural_seed_count": 10,
        "measurements_per_cluster": 2300,
        "measurements_per_inferential_cell": 23000,
        "measurement_observation_count": 92000,
        "bootstrap_repetitions": 10000,
        "bootstrap_seed": 20260728,
        "confidence_level": 0.95,
        "median_relative_half_width_target": 0.10,
        "p95_relative_half_width_target": 0.15,
        "all_cells_must_pass": True,
    },
    "exact_analyzer_invocation": {
        "python_module_mode": False,
        "program": relative(analyzer_path),
        "arguments": [
            "--stage-size", "10",
            "--observations", relative(observations_path),
            "--timing-report", relative(timing_adapter_path),
            "--intervals-csv", relative(raw_intervals),
            "--report-json", relative(raw_report_json),
            "--report-md", relative(raw_report_md),
            "--levels", "25,50,75,100",
            "--steps", "0",
            "--measurements-per-cluster", "2300",
            "--bootstrap-repetitions", "10000",
            "--bootstrap-seed", "20260728",
            "--confidence-level", "0.95",
            "--median-target", "0.10",
            "--p95-target", "0.15",
        ],
        "stdout_stderr_log": relative(raw_log),
    },
    "planned_outputs": {
        "raw_analyzer_log": relative(raw_log),
        "raw_intervals_csv": relative(raw_intervals),
        "raw_report_json": relative(raw_report_json),
        "raw_report_markdown": relative(raw_report_md),
        "canonical_decision_json": relative(decision_json),
        "canonical_decision_markdown": relative(decision_md),
    },
    "raw_report_interpretation": {
        "expected_raw_factor_label": "constraint_count",
        "raw_factor_label_authoritative": False,
        "raw_next_stage_authoritative": False,
        "canonical_factor": "membership_density",
        "canonical_decision_wrapper_required": True,
    },
    "decision_rule": {
        "pass": {
            "all_median_targets_met": True,
            "all_p95_targets_met": True,
            "all_precision_targets_met": True,
            "failing_cell_count": 0,
            "stage10_sufficient": True,
            "stage20_extension_required": False,
            "next_stage": (
                "prepare_membership_density_stage10_freeze"
            ),
        },
        "fail": {
            "stage10_sufficient": False,
            "stage20_extension_required": True,
            "stage20_execution_authorized": False,
            "next_stage": (
                "preregister_membership_density_stage20_extension"
            ),
        },
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_reexecution_performed": False,
        "adapter_materialization_performed": True,
        "adapter_rematerialization_performed": False,
        "precision_analysis_authorized": True,
        "precision_analysis_performed": False,
        "successful_bootstrap_execution_count": 0,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "execute_membership_density_portfolio_precision_analysis_once"
    ),
}

auth_json.parent.mkdir(parents=True, exist_ok=True)

auth_json.write_text(
    json.dumps(authorization, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

auth_md.write_text(
    "\n".join([
        (
            "# SA4 membership-density portfolio precision "
            "analysis authorization"
        ),
        "",
        "- Status: `authorized`",
        "- Authorized analyzer executions: `1`",
        "- Successful analyzer executions observed: `0`",
        "- Measurements: `92,000`",
        "- Structural clusters: `10`",
        "- Inferential cells: `4`",
        "- Measurements per cluster: `2,300`",
        "- Bootstrap repetitions: `10,000`",
        "- Bootstrap seed: `20260728`",
        "- Confidence level: `0.95`",
        "- Median RHW target: `0.10`",
        "- p95 RHW target: `0.15`",
        "",
        "## Controls",
        "",
        "- Timing re-execution: `not authorized`",
        "- Adapter rematerialization: `not authorized`",
        "- Stage-20 execution: `not authorized`",
        "- Latency claims: `not authorized`",
        "",
        (
            "The raw analyzer factor label and raw next-stage "
            "value are non-authoritative. A canonical "
            "`membership_density` decision wrapper is required."
        ),
        "",
        "## Next stage",
        "",
        (
            "`execute_membership_density_"
            "portfolio_precision_analysis_once`"
        ),
        "",
    ]),
    encoding="utf-8",
)

print("precision_analysis_authorization=PASS")
print("authorized_execution_count=1")
print("successful_bootstrap_execution_count=0")
print("measurement_observation_count=92000")
print("analyzer_timing_cell_count=40")
print("inferential_cell_count=4")
print("measurements_per_cluster=2300")
print("bootstrap_repetitions=10000")
print("bootstrap_seed=20260728")
print("precision_analysis_authorized=true")
print("precision_analysis_performed=false")
PY

echo
echo "=== 4. Validate authorization artifact ==="

test -f "$AUTH_JSON"
test -f "$AUTH_MD"

jq -e '
  .status
    == "membership_density_portfolio_precision_analysis_authorized"
  and .factor == "membership_density"
  and .authorization_scope.execution_count_authorized == 1
  and .authorization_scope.successful_execution_count_observed == 0
  and .authorization_scope.analyzer_execution_authorized == true
  and .authorization_scope.adapter_rematerialization_authorized == false
  and .authorization_scope.timing_reexecution_authorized == false
  and .authorization_scope.stage20_execution_authorized == false
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.analyzer_timing_cell_count == 40
  and .analysis_contract.inferential_cell_count == 4
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.measurements_per_cluster == 2300
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .analysis_contract.confidence_level == 0.95
  and .analysis_contract.median_relative_half_width_target == 0.10
  and .analysis_contract.p95_relative_half_width_target == 0.15
  and .raw_report_interpretation.raw_factor_label_authoritative == false
  and .raw_report_interpretation.raw_next_stage_authoritative == false
  and .raw_report_interpretation.canonical_factor
      == "membership_density"
  and .scientific_controls.precision_analysis_authorized == true
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.successful_bootstrap_execution_count == 0
  and .scientific_controls.stage20_execution_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "execute_membership_density_portfolio_precision_analysis_once"
' "$AUTH_JSON" >/dev/null

AUTH_SHA="$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)"

echo "precision_authorization_validation=PASS"
echo "precision_authorization_sha256=$AUTH_SHA"

echo
echo "=== 5. Commit authorization ==="

git add -f \
  "$AUTH_JSON" \
  "$AUTH_MD"

git diff --cached --check

test "$(
  git diff --cached --name-only | wc -l
)" -eq 2

git commit \
  -m "chore(experiments): authorize membership-density precision analysis"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 6. Push authorization branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Authorize membership-density portfolio precision analysis" \
    --body "$(cat <<EOF
## Authorized analysis

- analyzer executions authorized: \`1\`;
- measurements: \`92,000\`;
- analyzer timing cells: \`40\`;
- inferential cells: \`4\`;
- structural clusters: \`10\`;
- measurements per cluster: \`2,300\`;
- bootstrap repetitions: \`10,000\`;
- bootstrap seed: \`20260728\`;
- confidence level: \`0.95\`;
- median RHW target: \`0.10\`;
- p95 RHW target: \`0.15\`.

## Controls

- timing re-execution: \`false\`;
- adapter rematerialization: \`false\`;
- successful bootstrap executions so far: \`0\`;
- Stage-20 execution: \`false\`;
- latency claims: \`false\`.

## Integrity

- observation adapter SHA-256:
  \`$EXPECTED_OBSERVATIONS_SHA\`;
- timing-report adapter SHA-256:
  \`$EXPECTED_TIMING_ADAPTER_SHA\`;
- input-manifest SHA-256:
  \`$EXPECTED_MANIFEST_SHA\`;
- authorization SHA-256:
  \`$AUTH_SHA\`.

## Next stage

\`execute_membership_density_portfolio_precision_analysis_once\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_portfolio_precision_analysis_authorization=PASS"
echo "commit=$COMMIT"
echo "precision_authorization_sha256=$AUTH_SHA"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=0"
echo "precision_analysis_authorized=true"
echo "precision_analysis_performed=false"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_precision_analysis_authorization"

git status --short --branch
git log --oneline --decorate -4
