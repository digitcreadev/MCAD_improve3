#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="20dfec11a502cc0fccbcc07f6e2df0734debe29c"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
EXPECTED_SETUP_MANIFEST_SHA="5e5baad8a32d5c9c8e647d8d2365d68a9e3a286e620fc783373ec577a26cf155"

SETUP_FILES="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"
EXPECTED_SETUP_FILES_SHA="c785ab0fafc1c424e7a737d0dfd4282cb01b7ef071cf54c2adeb4304fb9ad9af"

AUTHORIZATION="$E3/planning/sa5_objective_count_stage10_timing_execution_authorization.json"
EXPECTED_AUTHORIZATION_SHA="bb8805eaaedb3277e25197a1eab2d5b4e484aa66006fc4a4dcf0bff424b47c20"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

SAMPLE_SPEC="$SETUP_ROOT/specs/objective_count_rep_000_portfolio_timing_stage10.json"
TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_timing_runner_interface_${STAMP}"
REPORT="$AUDIT_ROOT/sa5_objective_count_timing_runner_interface.json"
SURFACE="$AUDIT_ROOT/sa5_objective_count_timing_runner_interface.txt"
HELP="$AUDIT_ROOT/run_timing_repetitions_help.txt"

trap 'echo "[ERROR] Timing runner interface probe stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact merged Timing Setup gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_FILES" "$EXPECTED_SETUP_FILES_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
verify_sha "$RUNNER" "$EXPECTED_RUNNER_SHA"

sha256sum -c "$SETUP_FILES" >/dev/null
test -f "$SAMPLE_SPEC"
test ! -e "$TIMING_RUN_ROOT"

jq -e '
  .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .timing_spec_count == 10
  and .measured_repetitions_per_factor_level == 2530
  and .expected_total_observation_rows == 151800
  and .next_stage == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION" >/dev/null

echo "merged_timing_setup_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo
echo "=== 2. Read-only CLI help and AST contract extraction ==="

mkdir -p "$AUDIT_ROOT"

set +e
env -u BASH_ENV \
  "$PYTHON" "$RUNNER" --help \
  >"$HELP" 2>&1
HELP_STATUS=$?
set -e

# argparse help normally exits 0. Reject anything else.
test "$HELP_STATUS" -eq 0

export ROOT RUNNER SAMPLE_SPEC SETUP_MANIFEST REPORT SURFACE HELP
export EXPECTED_HEAD EXPECTED_RUNNER_SHA

"$PYTHON" - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any


root = Path(os.environ["ROOT"]).resolve()
runner = root / os.environ["RUNNER"]
sample_spec = root / os.environ["SAMPLE_SPEC"]
setup_manifest = root / os.environ["SETUP_MANIFEST"]
report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])
help_path = Path(os.environ["HELP"])


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def literal(node: ast.AST) -> Any:
    try:
        return ast.literal_eval(node)
    except Exception:
        return ast.unparse(node)


source = runner.read_text(encoding="utf-8")
tree = ast.parse(source, filename=str(runner))

arguments: list[dict[str, Any]] = []
functions: list[dict[str, Any]] = []
relevant_strings: set[str] = set()
main_guard_body: list[str] = []

for node in ast.walk(tree):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        functions.append({
            "name": node.name,
            "line": node.lineno,
            "arguments": [arg.arg for arg in node.args.args],
        })

    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        lowered = node.value.lower()
        if any(
            token in lowered
            for token in (
                "timing",
                "repetition",
                "warmup",
                "output",
                "manifest",
                "observation",
                "functional",
                "instance",
                "spec",
            )
        ):
            relevant_strings.add(node.value)

    if not isinstance(node, ast.Call):
        continue
    if not (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == "add_argument"
    ):
        continue

    arguments.append({
        "line": node.lineno,
        "names": [
            arg.value
            for arg in node.args
            if isinstance(arg, ast.Constant)
            and isinstance(arg.value, str)
        ],
        "keywords": {
            keyword.arg: literal(keyword.value)
            for keyword in node.keywords
            if keyword.arg is not None
        },
    })

for node in tree.body:
    if not isinstance(node, ast.If):
        continue
    test = ast.unparse(node.test)
    if "__name__" in test and "__main__" in test:
        main_guard_body = [ast.unparse(item) for item in node.body]

spec = json.loads(sample_spec.read_text(encoding="utf-8"))
setup = json.loads(setup_manifest.read_text(encoding="utf-8"))

report = {
    "schema_version": "mcad-sa5-timing-runner-interface-probe-v1",
    "status": "timing_runner_interface_probe_complete",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "runner": {
        "path": os.environ["RUNNER"],
        "sha256": sha(runner),
        "expected_sha256": os.environ["EXPECTED_RUNNER_SHA"],
        "ast_parse": "PASS",
        "argparse_argument_count": len(arguments),
        "argparse_arguments": arguments,
        "functions": sorted(functions, key=lambda row: row["line"]),
        "main_guard_body": main_guard_body,
        "relevant_string_constants": sorted(relevant_strings),
        "help_path": str(help_path),
        "help_sha256": sha(help_path),
    },
    "sample_timing_spec": spec,
    "setup_plan": setup["objective_count_timing_plan"],
    "scientific_controls": {
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "manuscript_modified": False,
    },
    "repository_modified": False,
    "probe_complete": True,
    "next_stage": "construct_and_execute_exact_timing_campaign_command",
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT TIMING RUNNER INTERFACE",
    "=" * 70,
    f"source_commit={report['source_commit']}",
    f"runner_sha256={report['runner']['sha256']}",
    f"argparse_argument_count={len(arguments)}",
]

for index, argument in enumerate(arguments):
    surface_lines.append(
        f"arg_{index}_names="
        + ",".join(argument["names"])
    )
    surface_lines.append(
        f"arg_{index}_keywords="
        + json.dumps(argument["keywords"], sort_keys=True)
    )

surface_lines.extend([
    f"main_guard_body={json.dumps(main_guard_body)}",
    f"sample_spec={sample_spec.relative_to(root).as_posix()}",
    f"sample_output_dir={spec['timing_output_dir']}",
    f"sample_functional_run_dir={spec['functional_run_dir']}",
    (
        "measured_repetitions_per_factor_level="
        f"{spec['measured_repetitions_per_factor_level']}"
    ),
    f"expected_observation_rows={spec['expected_observation_rows']}",
    "timing_execution_performed=false",
    "repository_modified=false",
    "probe_complete=true",
    f"next_stage={report['next_stage']}",
    "",
])

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("timing_runner_interface_probe=PASS")
print(f"argparse_argument_count={len(arguments)}")
for index, argument in enumerate(arguments):
    print(f"arg_{index}_names={','.join(argument['names'])}")
    print(
        f"arg_{index}_keywords="
        + json.dumps(argument["keywords"], sort_keys=True)
    )
print(f"main_guard_body={json.dumps(main_guard_body)}")
print(f"sample_output_dir={spec['timing_output_dir']}")
print(f"sample_functional_run_dir={spec['functional_run_dir']}")
print(
    "measured_repetitions_per_factor_level="
    f"{spec['measured_repetitions_per_factor_level']}"
)
print(f"expected_observation_rows={spec['expected_observation_rows']}")
print(f"report={report_path}")
print(f"report_sha256={sha(report_path)}")
print(f"surface={surface_path}")
print(f"surface_sha256={sha(surface_path)}")
print(f"help={help_path}")
print(f"help_sha256={sha(help_path)}")
print(f"next_stage={report['next_stage']}")
PY

echo
echo "=== 3. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test ! -e "$TIMING_RUN_ROOT"

echo "repository_immutability_gate=PASS"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 4. Final state ==="

echo "sa5_objective_count_timing_runner_interface_probe=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$(sha256sum "$REPORT" | awk '{print $1}')"
echo "surface=$SURFACE"
echo "surface_sha256=$(sha256sum "$SURFACE" | awk '{print $1}')"
echo "help=$HELP"
echo "help_sha256=$(sha256sum "$HELP" | awk '{print $1}')"
echo "timing_execution_performed=false"
echo "next_stage=construct_and_execute_exact_timing_campaign_command"

git status --short --branch
