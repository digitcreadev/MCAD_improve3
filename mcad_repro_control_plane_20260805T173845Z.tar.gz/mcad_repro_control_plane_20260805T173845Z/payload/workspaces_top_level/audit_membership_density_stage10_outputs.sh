#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BRANCH="paper/execute-membership-density-timing-stage10-20260803T111214Z"
EXPECTED_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="$ROOT/reports/article_experiments/sensitivity/e3_controlled_execution"

AUTH="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.json"
RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"
LEDGER="$RUN_ROOT/stage10_execution_ledger.json"

RUNNER="$ROOT/backend/harness/sensitivity_execution/run_timing_repetitions.py"

EXPECTED_AUTH_SHA="dc9010e319e238f1419e4fdb4d52cd184fc9470d346cef8833ef0355ff0c4be0"
EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Output audit stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only audit gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$AUTH"
test -f "$LEDGER"
test -f "$RUNNER"

test "$(
  sha256sum "$AUTH" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$RUNNER" | awk '{print $1}'
)" = "$EXPECTED_RUNNER_SHA"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.failed_replication_count == 0
  and .execution_totals.raw_timing_cell_count == 920
  and .execution_totals.warmup_observation_count == 9200
  and .execution_totals.measurement_observation_count == 92000
  and .execution_totals.total_observation_count == 101200
  and (.replications | length) == 10
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$LEDGER" >/dev/null

echo "read_only_audit_gate=PASS"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Audit all timing bundles ==="

"$PYTHON" - \
  "$LEDGER" \
  "$RUNNER" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Iterator

ledger_path = Path(sys.argv[1])
runner_path = Path(sys.argv[2])

ledger = json.loads(
    ledger_path.read_text(encoding="utf-8")
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def scalar_items(
    value: Any,
    prefix: str = "$",
) -> Iterator[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from scalar_items(
                child,
                f"{prefix}.{key}",
            )

    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from scalar_items(
                child,
                f"{prefix}[{index}]",
            )

    else:
        yield prefix, value


expected_levels = [25, 50, 75, 100]
expected_steps = list(range(1, 24))

total_rows = 0
total_warmups = 0
total_measurements = 0
total_cells = 0

all_declared_balance_values: list[Any] = []
all_mismatch_values: list[Any] = []

replications = ledger["replications"]

if [
    row["replication_index"]
    for row in replications
] != list(range(10)):
    raise SystemExit("Ledger replication order is incomplete.")

for replication, result in enumerate(replications):
    output_dir = Path(result["output_dir"])

    files = {
        name: Path(declaration["path"])
        for name, declaration in result["files"].items()
    }

    expected_names = {
        "timing_manifest",
        "timing_observations",
        "functional_references",
        "timing_summary",
    }

    if set(files) != expected_names:
        raise SystemExit(
            f"Replication {replication}: unexpected file map."
        )

    for name, path in files.items():
        if not path.is_file():
            raise SystemExit(
                f"Replication {replication}: missing {name}: {path}"
            )

        declared_sha = result["files"][name]["sha256"]
        actual_sha = sha256(path)

        if actual_sha != declared_sha:
            raise SystemExit(
                f"Replication {replication}: SHA mismatch "
                f"for {name}."
            )

        if path.parent.resolve() != output_dir.resolve():
            raise SystemExit(
                f"Replication {replication}: output path mismatch "
                f"for {name}."
            )

    manifest = load_object(files["timing_manifest"])
    summary = load_object(files["timing_summary"])
    load_object(files["functional_references"])

    observations = files["timing_observations"]

    phase_counts: Counter[str] = Counter()
    cell_phase_counts: Counter[
        tuple[int, int, str]
    ] = Counter()

    levels: set[int] = set()
    steps: set[int] = set()
    row_count = 0

    with observations.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)

        if reader.fieldnames is None:
            raise SystemExit(
                f"Replication {replication}: CSV header absent."
            )

        required_columns = {
            "phase",
            "factor_level",
            "step_index",
            "wall_latency_ms",
        }

        missing = required_columns - set(reader.fieldnames)

        if missing:
            raise SystemExit(
                f"Replication {replication}: missing columns "
                + ", ".join(sorted(missing))
            )

        for row in reader:
            row_count += 1

            phase = row["phase"]
            level = int(row["factor_level"])
            step = int(row["step_index"])
            latency = float(row["wall_latency_ms"])

            if phase not in {"warmup", "measurement"}:
                raise SystemExit(
                    f"Replication {replication}: "
                    f"unexpected phase {phase!r}."
                )

            if not math.isfinite(latency) or latency < 0:
                raise SystemExit(
                    f"Replication {replication}: invalid latency."
                )

            phase_counts[phase] += 1
            cell_phase_counts[
                (level, step, phase)
            ] += 1

            levels.add(level)
            steps.add(step)

    if row_count != 10120:
        raise SystemExit(
            f"Replication {replication}: expected 10,120 rows, "
            f"got {row_count}."
        )

    if phase_counts != Counter({
        "warmup": 920,
        "measurement": 9200,
    }):
        raise SystemExit(
            f"Replication {replication}: phase imbalance "
            f"{dict(phase_counts)}."
        )

    if sorted(levels) != expected_levels:
        raise SystemExit(
            f"Replication {replication}: unexpected levels."
        )

    if sorted(steps) != expected_steps:
        raise SystemExit(
            f"Replication {replication}: unexpected steps."
        )

    for level in expected_levels:
        for step in expected_steps:
            warmups = cell_phase_counts[
                (level, step, "warmup")
            ]

            measurements = cell_phase_counts[
                (level, step, "measurement")
            ]

            if warmups != 10:
                raise SystemExit(
                    f"Replication {replication}: "
                    f"warmup count={warmups}, "
                    f"level={level}, step={step}."
                )

            if measurements != 100:
                raise SystemExit(
                    f"Replication {replication}: "
                    f"measurement count={measurements}, "
                    f"level={level}, step={step}."
                )

    declared_balance_values: list[Any] = []
    mismatch_values: list[Any] = []

    for document_name, document in (
        ("manifest", manifest),
        ("summary", summary),
    ):
        for field, value in scalar_items(document):
            field_lower = field.lower()

            if "all_cells_exactly_balanced" in field_lower:
                declared_balance_values.append(
                    {
                        "document": document_name,
                        "field": field,
                        "value": value,
                    }
                )

            if "functional_mismatch_count" in field_lower:
                mismatch_values.append(
                    {
                        "document": document_name,
                        "field": field,
                        "value": value,
                    }
                )

    numeric_mismatches = [
        item["value"]
        for item in mismatch_values
        if isinstance(item["value"], (int, float))
        and not isinstance(item["value"], bool)
    ]

    if any(value != 0 for value in numeric_mismatches):
        raise SystemExit(
            f"Replication {replication}: "
            f"nonzero functional mismatch declaration."
        )

    all_declared_balance_values.extend(
        declared_balance_values
    )
    all_mismatch_values.extend(mismatch_values)

    total_rows += row_count
    total_warmups += phase_counts["warmup"]
    total_measurements += phase_counts["measurement"]
    total_cells += len(expected_levels) * len(expected_steps)

    print(
        f"replication_{replication}_output_audit=PASS"
    )
    print(
        f"replication_{replication}_csv_rows={row_count}"
    )
    print(
        f"replication_{replication}_direct_cell_balance=true"
    )
    print(
        f"replication_{replication}_functional_mismatch_values="
        + json.dumps(
            mismatch_values,
            sort_keys=True,
        )
    )
    print(
        f"replication_{replication}_declared_balance_values="
        + json.dumps(
            declared_balance_values,
            sort_keys=True,
        )
    )

if total_cells != 920:
    raise SystemExit(
        f"Expected 920 cells, got {total_cells}."
    )

if total_warmups != 9200:
    raise SystemExit(
        f"Expected 9,200 warmups, got {total_warmups}."
    )

if total_measurements != 92000:
    raise SystemExit(
        f"Expected 92,000 measurements, "
        f"got {total_measurements}."
    )

if total_rows != 101200:
    raise SystemExit(
        f"Expected 101,200 rows, got {total_rows}."
    )

false_balance_declarations = [
    item
    for item in all_declared_balance_values
    if item["value"] is False
]

print()
print("stage10_output_bundle_audit=PASS")
print("successful_replication_count=10")
print("directly_verified_raw_timing_cell_count=920")
print("directly_verified_warmup_observation_count=9200")
print(
    "directly_verified_measurement_observation_count=92000"
)
print("directly_verified_total_observation_count=101200")
print("direct_csv_cell_balance=true")
print(
    "declared_false_balance_value_count="
    f"{len(false_balance_declarations)}"
)
print(
    "balance_flag_semantic_review_required="
    + (
        "true"
        if false_balance_declarations
        else "false"
    )
)
print("functional_mismatch_audit=PASS")

source_lines = runner_path.read_text(
    encoding="utf-8"
).splitlines()

occurrences = [
    index
    for index, line in enumerate(source_lines)
    if "all_cells_exactly_balanced" in line
]

print()
print("runner_balance_flag_source_context:")

if not occurrences:
    print("NO_OCCURRENCE")
else:
    emitted: set[int] = set()

    for occurrence in occurrences:
        start = max(0, occurrence - 10)
        end = min(
            len(source_lines),
            occurrence + 11,
        )

        for index in range(start, end):
            if index not in emitted:
                print(
                    f"{index + 1}:{source_lines[index]}"
                )
                emitted.add(index)

        print("...")
PY

echo
echo "=== 3. Final read-only state ==="

echo "membership_density_stage10_output_audit=PASS"
echo "timing_execution_performed=true"
echo "timing_reexecution_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "audit_artifact_created=false"
echo "next_stage=interpret_balance_flag_then_persist_stage10_output_audit"

git status --short --branch
