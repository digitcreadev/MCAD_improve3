#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=22

BASE="paper/phase3-controlled-execution"
BRANCH="paper/authorize-membership-density-portfolio-precision-20260804T154127Z"

EXPECTED_HEAD="54fc0823fc20f505946d2ab8be22ef2a03e1e832"
EXPECTED_BASE_HEAD="dd17d13104b90b5e24cf5b072f6ea66cc18e49db"

AUTH_JSON="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_portfolio_precision_analysis_authorization.json"
AUTH_MD="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_portfolio_precision_analysis_authorization.md"

EXPECTED_AUTH_SHA="835a22c0f74f18c2da64ed91257fcd58839a85a7c4f6113579b9bba05cd068d1"

trap 'echo "[ERROR] PR #22 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local authorization gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -f "$AUTH_JSON"
test -f "$AUTH_MD"

test "$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

jq -e '
  .status
    == "membership_density_portfolio_precision_analysis_authorized"
  and .factor == "membership_density"
  and .authorization_scope.execution_count_authorized == 1
  and .authorization_scope.successful_execution_count_observed == 0
  and .authorization_scope.analyzer_execution_authorized == true
  and .authorization_scope.adapter_rematerialization_authorized == false
  and .authorization_scope.timing_reexecution_authorized == false
  and .authorization_scope.functional_rerun_authorized == false
  and .authorization_scope.stage20_execution_authorized == false
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.analyzer_timing_cell_count == 40
  and .analysis_contract.inferential_cell_count == 4
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.measurements_per_cluster == 2300
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .analysis_contract.confidence_level == 0.95
  and .analysis_contract.median_relative_half_width_target == 0.10
  and .analysis_contract.p95_relative_half_width_target == 0.15
  and .raw_report_interpretation.raw_factor_label_authoritative == false
  and .raw_report_interpretation.raw_next_stage_authoritative == false
  and .raw_report_interpretation.canonical_factor
      == "membership_density"
  and .scientific_controls.precision_analysis_authorized == true
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.successful_bootstrap_execution_count == 0
  and .scientific_controls.stage20_execution_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "execute_membership_density_portfolio_precision_analysis_once"
' "$AUTH_JSON" >/dev/null

CHANGED_FILE_COUNT="$(
  git diff \
    --name-only \
    "$EXPECTED_BASE_HEAD..$EXPECTED_HEAD" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 2

echo "local_authorization_gate=PASS"
echo "changed_file_count=$CHANGED_FILE_COUNT"
echo "precision_authorization_sha256=$EXPECTED_AUTH_SHA"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=0"
echo "precision_analysis_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' >/dev/null 2>&1 <<<"$CHECKS"; then
  CHECKS='[]'
fi

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "precision_authorization_ci=PASS"
else
  echo "precision_authorization_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #22 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "authorization_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged authorization ==="

test -f "$AUTH_JSON"
test -f "$AUTH_MD"

test "$(
  sha256sum "$AUTH_JSON" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

jq -e '
  .status
    == "membership_density_portfolio_precision_analysis_authorized"
  and .authorization_scope.execution_count_authorized == 1
  and .authorization_scope.successful_execution_count_observed == 0
  and .authorization_scope.analyzer_execution_authorized == true
  and .scientific_controls.precision_analysis_authorized == true
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.successful_bootstrap_execution_count == 0
  and .scientific_controls.stage20_execution_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "execute_membership_density_portfolio_precision_analysis_once"
' "$AUTH_JSON" >/dev/null

echo "merged_precision_analysis_authorization=PASS"
echo "precision_authorization_sha256=$EXPECTED_AUTH_SHA"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=0"
echo "precision_analysis_authorized=true"
echo "precision_analysis_performed=false"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

test -z "$(git status --porcelain)"

echo "membership_density_precision_analysis_authorization_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=0"
echo "precision_analysis_authorized=true"
echo "precision_analysis_performed=false"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=execute_membership_density_portfolio_precision_analysis_once"

git status --short --branch
git log --oneline --decorate -5
