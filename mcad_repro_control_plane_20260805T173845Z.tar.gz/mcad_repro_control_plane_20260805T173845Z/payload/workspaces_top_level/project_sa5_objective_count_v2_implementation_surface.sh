#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
CONTROLLED_DISPATCHER="backend/harness/sensitivity_generator/families/controlled_families.py"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
E3_VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"
WORKLOAD_VALIDATOR="backend/harness/sensitivity_execution/validate_workload_spec.py"
WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"

DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"
SEMANTIC_BINDING="backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml"

GENERATOR_TEST="backend/harness/sensitivity_generator/tests/test_objective_count_family.py"
COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"
PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"

WORKFLOW=".github/workflows/phase3-regression.yml"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

TARGET_E21_VERSION="mcad-sensitivity-e2.1-objective-count-v2"
TARGET_E22_VERSION="mcad-sensitivity-e2.2-objective-count-v2"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_implementation_surface_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_implementation_surface.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_implementation_surface.txt"

trap 'echo "[ERROR] SA5 v2 implementation-surface projection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Post-amendment repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$CONTROLLED_DISPATCHER" \
  "$EXECUTOR" \
  "$E3_VALIDATOR" \
  "$WORKLOAD_VALIDATOR" \
  "$WORKLOAD_SCHEMA" \
  "$DESIGN_MATRIX" \
  "$SEMANTIC_BINDING" \
  "$GENERATOR_TEST" \
  "$COMPATIBILITY_TEST" \
  "$PREREG_TEST" \
  "$AMENDMENT_TEST" \
  "$WORKFLOW" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e \
  --arg e21 "$TARGET_E21_VERSION" \
  --arg e22 "$TARGET_E22_VERSION" \
  '
    .status == "preregistered_implementation_required"
    and .implementation_contract.implementation_required_before_materialization
      == true
    and .implementation_contract.target_structural_generator_version
      == $e21
    and .implementation_contract.target_campaign_generator_version
      == $e22
    and .authorization.v2_implementation_authorized_after_amendment_merge
      == true
    and .authorization.canonical_campaign_materialization_authorized
      == false
    and .authorization.functional_execution_authorized
      == false
    and .scientific_controls.canonical_campaign_generated
      == false
    and .next_stage
      == "implement_sa5_objective_count_materialization_contract_v2"
  ' "$AMENDMENT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "amendment_sha256=$EXPECTED_AMENDMENT_SHA"
echo "v2_implementation_eligible=true"
echo "canonical_campaign_materialization_authorized=false"
echo "repository_modified=false"

echo
echo "=== 2. Initialize detached implementation-surface output ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

echo "output_root=$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export PREREG
export AMENDMENT
export OBJECTIVE_GENERATOR
export OBJECTIVE_FAMILY
export CONTROLLED_DISPATCHER
export EXECUTOR
export E3_VALIDATOR
export WORKLOAD_VALIDATOR
export WORKLOAD_SCHEMA
export DESIGN_MATRIX
export SEMANTIC_BINDING
export GENERATOR_TEST
export COMPATIBILITY_TEST
export PREREG_TEST
export AMENDMENT_TEST
export WORKFLOW
export TARGET_E21_VERSION
export TARGET_E22_VERSION
export REPORT
export SURFACE

python3 - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
source_commit = os.environ["EXPECTED_HEAD"]

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])

target_e21 = os.environ["TARGET_E21_VERSION"]
target_e22 = os.environ["TARGET_E22_VERSION"]

paths = {
    "preregistration": Path(os.environ["PREREG"]),
    "amendment": Path(os.environ["AMENDMENT"]),
    "objective_generator_v1": Path(
        os.environ["OBJECTIVE_GENERATOR"]
    ),
    "objective_family_v1": Path(
        os.environ["OBJECTIVE_FAMILY"]
    ),
    "controlled_dispatcher": Path(
        os.environ["CONTROLLED_DISPATCHER"]
    ),
    "executor": Path(os.environ["EXECUTOR"]),
    "e3_validator": Path(os.environ["E3_VALIDATOR"]),
    "workload_validator": Path(
        os.environ["WORKLOAD_VALIDATOR"]
    ),
    "workload_schema": Path(
        os.environ["WORKLOAD_SCHEMA"]
    ),
    "design_matrix": Path(
        os.environ["DESIGN_MATRIX"]
    ),
    "semantic_binding": Path(
        os.environ["SEMANTIC_BINDING"]
    ),
    "generator_test": Path(
        os.environ["GENERATOR_TEST"]
    ),
    "compatibility_test": Path(
        os.environ["COMPATIBILITY_TEST"]
    ),
    "preregistration_test": Path(
        os.environ["PREREG_TEST"]
    ),
    "amendment_test": Path(
        os.environ["AMENDMENT_TEST"]
    ),
    "workflow": Path(os.environ["WORKFLOW"]),
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_lines(path: Path) -> list[str]:
    return path.read_text(
        encoding="utf-8"
    ).splitlines()


def ast_surface(
    path: Path,
    *,
    patterns: tuple[str, ...],
) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    tree = ast.parse(text, filename=str(path))

    imports: list[dict[str, Any]] = []
    nodes: list[dict[str, Any]] = []

    for node in tree.body:
        if isinstance(
            node,
            (ast.Import, ast.ImportFrom),
        ):
            start = int(node.lineno)
            end = int(
                getattr(node, "end_lineno", start)
            )

            imports.append(
                {
                    "start_line": start,
                    "end_line": end,
                    "source": "\n".join(
                        lines[start - 1 : end]
                    ),
                }
            )

        name: str | None = None

        if isinstance(
            node,
            (
                ast.ClassDef,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            name = node.name

        elif isinstance(node, ast.Assign):
            targets = [
                target.id
                for target in node.targets
                if isinstance(target, ast.Name)
            ]

            if targets:
                name = ",".join(targets)

        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name):
                name = node.target.id

        if not name:
            continue

        start = int(
            getattr(node, "lineno", 1)
        )
        end = int(
            getattr(node, "end_lineno", start)
        )

        selected_source = "\n".join(
            lines[start - 1 : end]
        )

        if not any(
            re.search(
                pattern,
                name,
                re.IGNORECASE,
            )
            or re.search(
                pattern,
                selected_source,
                re.IGNORECASE,
            )
            for pattern in patterns
        ):
            continue

        class_fields: list[str] = []

        if isinstance(node, ast.ClassDef):
            for child in node.body:
                if (
                    isinstance(
                        child,
                        ast.AnnAssign,
                    )
                    and isinstance(
                        child.target,
                        ast.Name,
                    )
                ):
                    class_fields.append(
                        child.target.id
                    )

        nodes.append(
            {
                "kind": type(node).__name__,
                "name": name,
                "start_line": start,
                "end_line": end,
                "class_fields": class_fields,
                "source": selected_source,
            }
        )

    return {
        "path": str(path),
        "sha256": sha256_file(path),
        "line_count": len(lines),
        "imports": imports,
        "selected_nodes": nodes,
    }


preregistration = json.loads(
    paths["preregistration"].read_text(
        encoding="utf-8"
    )
)

amendment = json.loads(
    paths["amendment"].read_text(
        encoding="utf-8"
    )
)

design_matrix = yaml.safe_load(
    paths["design_matrix"].read_text(
        encoding="utf-8"
    )
)

semantic_binding = yaml.safe_load(
    paths["semantic_binding"].read_text(
        encoding="utf-8"
    )
)

workload_schema = json.loads(
    paths["workload_schema"].read_text(
        encoding="utf-8"
    )
)

python_surfaces = {
    "objective_generator_v1": ast_surface(
        paths["objective_generator_v1"],
        patterns=(
            r"VERSION",
            r"Config",
            r"Manifest",
            r"objective",
            r"constraint",
            r"virtual",
            r"requirement",
            r"membership",
            r"density",
            r"generate",
            r"validate",
            r"digest",
            r"write",
        ),
    ),
    "objective_family_v1": ast_surface(
        paths["objective_family_v1"],
        patterns=(
            r"VERSION",
            r"Spec",
            r"Record",
            r"Manifest",
            r"objective",
            r"generate",
            r"validate",
            r"condition",
            r"ofat",
            r"write",
            r"digest",
        ),
    ),
    "controlled_dispatcher": ast_surface(
        paths["controlled_dispatcher"],
        patterns=(
            r"objective_count",
            r"SUPPORTED_FACTORS",
            r"generate_controlled_family",
            r"generator",
        ),
    ),
    "executor": ast_surface(
        paths["executor"],
        patterns=(
            r"OBJECTIVE_COUNT",
            r"SUPPORTED_GENERATOR",
            r"_expected_generator_versions",
            r"_expected_bootstrap_objective_ids",
            r"_validate_instance_manifest",
            r"_discover_all_instances",
            r"_build_instance_ckg",
        ),
    ),
    "e3_validator": ast_surface(
        paths["e3_validator"],
        patterns=(
            r"objective_count",
            r"generator",
            r"profile",
            r"validate_contract",
        ),
    ),
    "workload_validator": ast_surface(
        paths["workload_validator"],
        patterns=(
            r"SCHEMA_VERSION",
            r"query",
            r"workload",
            r"validate",
        ),
    ),
    "generator_test": ast_surface(
        paths["generator_test"],
        patterns=(
            r"objective",
            r"manifest",
            r"density",
            r"determin",
            r"version",
            r"generate",
        ),
    ),
    "compatibility_test": ast_surface(
        paths["compatibility_test"],
        patterns=(
            r"objective",
            r"version",
            r"profile",
            r"bootstrap",
            r"campaign",
        ),
    ),
    "preregistration_test": ast_surface(
        paths["preregistration_test"],
        patterns=(
            r"objective",
            r"prereg",
            r"factor",
            r"workload",
            r"noise",
        ),
    ),
    "amendment_test": ast_surface(
        paths["amendment_test"],
        patterns=(
            r"amend",
            r"structural",
            r"noise",
            r"material",
            r"version",
        ),
    ),
}

all_source_text = {
    label: path.read_text(encoding="utf-8")
    for label, path in paths.items()
    if path.suffix == ".py"
}

generator_text = all_source_text[
    "objective_generator_v1"
]

family_text = all_source_text[
    "objective_family_v1"
]

dispatcher_text = all_source_text[
    "controlled_dispatcher"
]

executor_text = all_source_text[
    "executor"
]

workflow_text = paths["workflow"].read_text(
    encoding="utf-8"
)

current_versions = {
    "structural_v1_present": (
        "mcad-sensitivity-e2.1-objective-count-v1"
        in (
            generator_text
            + family_text
            + executor_text
        )
    ),
    "campaign_v1_present": (
        "mcad-sensitivity-e2.2-objective-count-v1"
        in (
            family_text
            + executor_text
        )
    ),
    "target_structural_v2_present": (
        target_e21
        in (
            generator_text
            + family_text
            + dispatcher_text
            + executor_text
        )
    ),
    "target_campaign_v2_present": (
        target_e22
        in (
            family_text
            + dispatcher_text
            + executor_text
        )
    ),
}

required_current_tokens = {
    "objective_generator_v1": [
        "objective_ids",
        "selected_objective_id",
        "requested_objective_count",
        "realised_objective_count",
        "requirement_set_count",
        "requirement_membership_link_count",
        "membership_density",
        "configuration_digest",
        "instance_digest",
    ],
    "objective_family_v1": [
        "campaign_generator_version",
        "structural_generator_version",
        "factor_level",
        "replication_index",
        "instances.csv",
        "campaign_manifest.json",
    ],
    "controlled_dispatcher": [
        "objective_count",
    ],
    "executor": [
        "objective_count",
        "_expected_bootstrap_objective_ids",
        "SUPPORTED_GENERATOR_VERSION_PAIRS",
    ],
}

token_presence: dict[
    str,
    dict[str, bool],
] = {}

for label, tokens in (
    required_current_tokens.items()
):
    source = all_source_text[label]

    token_presence[label] = {
        token: token in source
        for token in tokens
    }


structural_contract = amendment[
    "structural_control_contract"
]

workload_contract = amendment[
    "workload_noise_contract"
]

implementation_contract = amendment[
    "implementation_contract"
]

assert structural_contract[
    "objective_count_levels"
] == [1, 2, 5, 10, 20, 50]

assert structural_contract[
    "requirement_set_membership_indices"
] == [[0, 1], [1, 2]]

assert structural_contract[
    "useful_virtual_nodes_per_objective"
] == 24

assert structural_contract[
    "irrelevant_virtual_nodes_per_objective"
] == 8

assert structural_contract[
    "expected_realised_density"
] == 0.5

assert workload_contract[
    "workload_length"
] == 40

assert workload_contract[
    "non_contributive_query_count"
] == 10

assert workload_contract[
    "stage10_total_noise_query_count"
] == 100

assert implementation_contract[
    "target_structural_generator_version"
] == target_e21

assert implementation_contract[
    "target_campaign_generator_version"
] == target_e22


new_files = [
    (
        "backend/harness/sensitivity_generator/"
        "objective_count_generator_v2.py"
    ),
    (
        "backend/harness/sensitivity_generator/"
        "families/objective_count_family_v2.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tools/audit_objective_count_structure_v2.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tools/prepare_objective_count_stage10_"
        "common_workloads_v2.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tools/audit_objective_count_stage10_"
        "common_workloads_v2.py"
    ),
    (
        "backend/harness/sensitivity_generator/"
        "tests/test_objective_count_generator_v2.py"
    ),
    (
        "backend/harness/sensitivity_generator/"
        "tests/test_objective_count_family_v2.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_structure_auditor_v2.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_stage10_"
        "common_workloads_v2.py"
    ),
]

modified_files = [
    (
        "backend/harness/sensitivity_generator/"
        "families/controlled_families.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "execute_controlled_family.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_compatibility.py"
    ),
    ".github/workflows/phase3-regression.yml",
]

for relative_path in new_files:
    if (root / relative_path).exists():
        raise AssertionError(
            "Proposed v2 file already exists: "
            f"{relative_path}"
        )

missing_current_tokens = {
    label: [
        token
        for token, present
        in values.items()
        if not present
    ]
    for label, values
    in token_presence.items()
    if not all(values.values())
}

required_executor_helper_present = (
    "_expected_bootstrap_objective_ids"
    in executor_text
)

dispatcher_objective_route_present = (
    "objective_count"
    in dispatcher_text
)

workflow_objective_tests_present = (
    "test_objective_count"
    in workflow_text
)

query_schema = (
    workload_schema
    .get("properties", {})
    .get("steps", {})
    .get("items", {})
    .get("properties", {})
    .get("query_spec", {})
)

query_extensions_supported = (
    query_schema.get(
        "additionalProperties"
    )
    is True
)

blockers: list[str] = []

if missing_current_tokens:
    blockers.append(
        "current_objective_count_surface_incomplete"
    )

if not current_versions[
    "structural_v1_present"
]:
    blockers.append(
        "objective_count_structural_v1_binding_missing"
    )

if not current_versions[
    "campaign_v1_present"
]:
    blockers.append(
        "objective_count_campaign_v1_binding_missing"
    )

if current_versions[
    "target_structural_v2_present"
] or current_versions[
    "target_campaign_v2_present"
]:
    blockers.append(
        "unexpected_preexisting_objective_count_v2_binding"
    )

if not required_executor_helper_present:
    blockers.append(
        "multi_objective_bootstrap_helper_missing"
    )

if not dispatcher_objective_route_present:
    blockers.append(
        "objective_count_dispatch_route_missing"
    )

if not query_extensions_supported:
    blockers.append(
        "query_spec_extension_fields_not_supported"
    )

if blockers:
    status = (
        "sa5_objective_count_v2_"
        "implementation_surface_incomplete"
    )
    next_stage = (
        "resolve_sa5_objective_count_v2_"
        "implementation_surface_blockers"
    )
else:
    status = (
        "sa5_objective_count_v2_"
        "implementation_surface_resolved"
    )
    next_stage = (
        "author_sa5_objective_count_"
        "materialization_contract_v2_patch"
    )

report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "implementation-surface-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "source_hashes": {
        label: sha256_file(path)
        for label, path
        in paths.items()
    },
    "amendment_binding": {
        "preregistration_sha256": (
            sha256_file(
                paths["preregistration"]
            )
        ),
        "amendment_sha256": (
            sha256_file(
                paths["amendment"]
            )
        ),
        "target_structural_generator_version": (
            target_e21
        ),
        "target_campaign_generator_version": (
            target_e22
        ),
        "canonical_materialization_authorized": False,
        "functional_execution_authorized": False,
    },
    "implementation_strategy": {
        "strategy": (
            "isolated_v2_modules_with_explicit_"
            "dispatcher_and_e3_rebinding"
        ),
        "preserve_v1_module_bytes": True,
        "preserve_historical_factor_behavior": True,
        "new_files": new_files,
        "modified_files": modified_files,
        "new_file_count": len(new_files),
        "modified_file_count": len(
            modified_files
        ),
        "expected_total_patch_file_count": (
            len(new_files)
            + len(modified_files)
        ),
    },
    "resolved_structural_contract": {
        "objective_count_levels": (
            structural_contract[
                "objective_count_levels"
            ]
        ),
        "constraints_per_objective": 8,
        "virtual_nodes_per_objective": 32,
        "local_virtual_nodes_per_constraint": 4,
        "requirement_sets_per_constraint": 2,
        "requirement_set_membership_indices": [
            [0, 1],
            [1, 2],
        ],
        "useful_virtual_nodes_per_objective": 24,
        "irrelevant_virtual_nodes_per_objective": 8,
        "useful_virtual_node_ratio": 0.75,
        "requirement_sets_per_objective": 16,
        "membership_links_per_objective": 32,
        "maximum_membership_links_per_objective": 64,
        "realised_density": 0.5,
    },
    "resolved_workload_contract": {
        "replication_count": 10,
        "workload_count": 10,
        "workload_length": 40,
        "contributive_query_count": 30,
        "non_contributive_query_count": 10,
        "stage10_noise_query_count": 100,
        "noise_class_order": (
            workload_contract[
                "noise_class_order"
            ]
        ),
        "integer_allocation_method": (
            workload_contract[
                "integer_allocation_method"
            ]
        ),
        "counts_by_replication": (
            workload_contract[
                "counts_by_replication"
            ]
        ),
        "stage10_class_totals": (
            workload_contract[
                "stage10_class_totals"
            ]
        ),
        "noise_position_selection": (
            workload_contract[
                "noise_position_selection"
            ]
        ),
        "class_to_position_assignment": (
            workload_contract[
                "class_to_position_assignment"
            ]
        ),
    },
    "current_version_presence": (
        current_versions
    ),
    "current_token_presence": (
        token_presence
    ),
    "query_spec_extension_fields_supported": (
        query_extensions_supported
    ),
    "executor_multi_objective_bootstrap_helper_present": (
        required_executor_helper_present
    ),
    "dispatcher_objective_count_route_present": (
        dispatcher_objective_route_present
    ),
    "workflow_objective_count_tests_present": (
        workflow_objective_tests_present
    ),
    "python_surfaces": python_surfaces,
    "design_matrix_objective_axis": (
        design_matrix[
            "axes"
        ]["objective_count"]
    ),
    "semantic_density_binding": (
        semantic_binding["density"]
    ),
    "blockers": blockers,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface: list[str] = [
    "SA5 OBJECTIVE-COUNT V2 IMPLEMENTATION SURFACE",
    "=" * 88,
    f"source_commit={source_commit}",
    f"status={status}",
    (
        "implementation_strategy="
        "isolated_v2_modules_with_explicit_"
        "dispatcher_and_e3_rebinding"
    ),
    "preserve_v1_module_bytes=true",
    (
        "expected_total_patch_file_count="
        f"{len(new_files) + len(modified_files)}"
    ),
    "",
    "=== PROPOSED NEW FILES ===",
    *new_files,
    "",
    "=== PROPOSED MODIFIED FILES ===",
    *modified_files,
    "",
    "=== CURRENT VERSION PRESENCE ===",
]

for key, value in current_versions.items():
    surface.append(
        f"{key}={str(value).lower()}"
    )

surface.extend(
    [
        "",
        "=== STRUCTURAL CONTRACT ===",
        "constraints_per_objective=8",
        "virtual_nodes_per_objective=32",
        "local_virtual_nodes_per_constraint=4",
        "requirement_sets_per_constraint=2",
        "requirement_set_0=[0,1]",
        "requirement_set_1=[1,2]",
        "useful_virtual_nodes_per_objective=24",
        "irrelevant_virtual_nodes_per_objective=8",
        "useful_virtual_node_ratio=0.75",
        "requirement_sets_per_objective=16",
        "membership_links_per_objective=32",
        "maximum_membership_links_per_objective=64",
        "realised_density=0.50",
        "",
        "=== WORKLOAD CONTRACT ===",
        "replication_count=10",
        "workload_count=10",
        "workload_length=40",
        "contributive_query_count=30",
        "non_contributive_query_count=10",
        "stage10_noise_query_count=100",
        (
            "integer_allocation_method="
            + workload_contract[
                "integer_allocation_method"
            ]
        ),
        "",
        "=== PATCH PREREQUISITES ===",
        (
            "query_spec_extension_fields_supported="
            f"{str(query_extensions_supported).lower()}"
        ),
        (
            "executor_multi_objective_bootstrap_"
            "helper_present="
            f"{str(required_executor_helper_present).lower()}"
        ),
        (
            "dispatcher_objective_count_route_present="
            f"{str(dispatcher_objective_route_present).lower()}"
        ),
        "",
        "=== BLOCKERS ===",
    ]
)

if blockers:
    surface.extend(
        f"blocker={blocker}"
        for blocker in blockers
    )
else:
    surface.append("blocker_count=0")

surface.extend(
    [
        "",
        "=== EXACT CURRENT SOURCE SURFACES ===",
    ]
)

for label, projection in (
    python_surfaces.items()
):
    surface.extend(
        [
            "",
            "=" * 88,
            f"SOURCE={label}",
            f"PATH={projection['path']}",
            f"SHA256={projection['sha256']}",
            f"LINE_COUNT={projection['line_count']}",
            "=" * 88,
            "",
            "--- IMPORTS ---",
        ]
    )

    for import_item in projection[
        "imports"
    ]:
        surface.append(
            import_item["source"]
        )

    surface.append("")
    surface.append(
        "--- SELECTED DEFINITIONS ---"
    )

    for node in projection[
        "selected_nodes"
    ]:
        surface.extend(
            [
                "",
                (
                    f"### {node['kind']} "
                    f"{node['name']} "
                    f"[{node['start_line']}-"
                    f"{node['end_line']}]"
                ),
                (
                    "CLASS_FIELDS="
                    + json.dumps(
                        node["class_fields"],
                        ensure_ascii=False,
                    )
                    if node["class_fields"]
                    else "CLASS_FIELDS=[]"
                ),
                node["source"],
            ]
        )

surface.extend(
    [
        "",
        "=== FINAL CONTROLS ===",
        "canonical_campaign_generated=false",
        "campaign_materialization_performed=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface),
    encoding="utf-8",
)

print("v2_implementation_surface_projection=PASS")
print(f"status={status}")
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(
    "new_file_count="
    f"{len(new_files)}"
)
print(
    "modified_file_count="
    f"{len(modified_files)}"
)
print(
    "expected_total_patch_file_count="
    f"{len(new_files) + len(modified_files)}"
)
print(
    "blocker_count="
    f"{len(blockers)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 3. Validate implementation-surface report ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-implementation-surface-v1"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .read_only == true
  and .amendment_binding.target_structural_generator_version
    == "mcad-sensitivity-e2.1-objective-count-v2"
  and .amendment_binding.target_campaign_generator_version
    == "mcad-sensitivity-e2.2-objective-count-v2"
  and .amendment_binding.canonical_materialization_authorized
    == false
  and .implementation_strategy.preserve_v1_module_bytes
    == true
  and .resolved_structural_contract.useful_virtual_node_ratio
    == 0.75
  and .resolved_structural_contract.realised_density
    == 0.5
  and .resolved_workload_contract.workload_length
    == 40
  and .resolved_workload_contract.non_contributive_query_count
    == 10
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false
' "$REPORT" >/dev/null

echo "implementation_surface_report_validation=PASS"

echo
echo "=== 4. Compact implementation decision ==="

jq '{
  status,
  source_commit,
  amendment_binding,
  implementation_strategy,
  resolved_structural_contract,
  resolved_workload_contract: {
    replication_count,
    workload_count,
    workload_length,
    contributive_query_count,
    non_contributive_query_count,
    stage10_noise_query_count,
    integer_allocation_method,
    stage10_class_totals
  },
  current_version_presence,
  query_spec_extension_fields_supported,
  executor_multi_objective_bootstrap_helper_present,
  dispatcher_objective_count_route_present,
  workflow_objective_count_tests_present,
  blockers,
  next_stage
}' "$REPORT"

echo
echo "=== 5. High-value source index ==="

grep -nE \
  '^(SOURCE=|PATH=|### .*VERSION|### .*Config|### .*Manifest|### .*generate|### .*validate|### .*objective|### .*bootstrap|blocker=|next_stage=)' \
  "$SURFACE" |
  head -n 500 || true

echo
echo "=== 6. Repository immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Final state ==="

STATUS_VALUE="$(
  jq -r '.status' "$REPORT"
)"

BLOCKER_COUNT="$(
  jq '.blockers | length' "$REPORT"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$REPORT"
)"

echo "sa5_objective_count_v2_implementation_surface=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "status=$STATUS_VALUE"
echo "blocker_count=$BLOCKER_COUNT"
echo "report=$REPORT"
echo "surface=$SURFACE"
echo "v2_implementation_eligible=true"
echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=$NEXT_STAGE"

git status --short --branch
