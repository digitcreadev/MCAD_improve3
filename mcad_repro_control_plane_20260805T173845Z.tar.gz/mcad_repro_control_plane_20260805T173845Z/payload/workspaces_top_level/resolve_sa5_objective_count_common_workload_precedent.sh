#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="729b73b7716a4c32c610241256b7e42dd9ba6bfc"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

SA4_ARCHIVE="experiments/article/frozen_campaigns/sa4_membership_density_stage10/archive/membership_density_stage10_canonical_20260804T161119Z.tar.gz"
EXPECTED_SA4_ARCHIVE_SHA="1729d7913e68407f754804c9d23468559e0eeefbf616e8f7ecc6be5fab940ffc"

SOURCE_FILES=(
  "backend/harness/sensitivity_execution/validate_workload_spec.py"
  "backend/harness/sensitivity_execution/workload_spec.schema.json"
  "backend/harness/sensitivity_execution/execute_controlled_family.py"
  "backend/harness/sensitivity_execution/tools/prepare_virtual_node_count_stage10_common_workloads.py"
  "backend/harness/sensitivity_execution/tools/prepare_constraint_count_replication_runs.py"
  "backend/harness/sensitivity_execution/tools/prepare_virtual_node_count_replication_runs.py"
  "backend/harness/sensitivity_execution/tools/audit_membership_density_common_workload.py"
  "backend/harness/sensitivity_execution/tools/audit_constraint_count_common_workload.py"
  "backend/harness/sensitivity_execution/tests/test_virtual_node_count_stage10_common_workloads.py"
  "backend/harness/sensitivity_execution/tests/test_membership_density_common_workload_auditor.py"
  "backend/harness/sensitivity_execution/tests/test_workload_spec.py"
)

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="/workspaces/sa5_objective_count_common_workload_precedent_${STAMP}"

REPORT="$OUT/sa5_objective_count_common_workload_precedent.json"
SURFACE="$OUT/sa5_objective_count_common_workload_surface.txt"

trap 'echo "[ERROR] SA5 common-workload resolution stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only resolution gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

test -f "$PREREG"
test -f "$SA4_ARCHIVE"
test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$SA4_ARCHIVE" |
    awk '{print $1}'
)" = "$EXPECTED_SA4_ARCHIVE_SHA"

for FILE in "${SOURCE_FILES[@]}"; do
  test -f "$FILE"
done

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "resolution_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "source_file_count=${#SOURCE_FILES[@]}"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Initialize detached resolution output ==="

rm -rf "$OUT"
mkdir -p "$OUT"

printf '%s\n' "${SOURCE_FILES[@]}" \
  > "$OUT/source_files.txt"

echo "output_root=$OUT"

echo
echo "=== 3. Resolve repository and frozen-archive precedent ==="

python3 - \
  "$ROOT" \
  "$SA4_ARCHIVE" \
  "$OUT/source_files.txt" \
  "$REPORT" \
  "$SURFACE" \
  "$EXPECTED_HEAD" <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import re
import sys
import tarfile
from pathlib import Path
from typing import Any, Iterator

import yaml


root = Path(sys.argv[1]).resolve()
archive_path = (root / sys.argv[2]).resolve()
source_list_path = Path(sys.argv[3]).resolve()
report_path = Path(sys.argv[4]).resolve()
surface_path = Path(sys.argv[5]).resolve()
source_commit = sys.argv[6]

source_paths = [
    Path(line.strip())
    for line in source_list_path.read_text(
        encoding="utf-8"
    ).splitlines()
    if line.strip()
]

required_workload_keys = {
    "workload_id",
    "objective_id",
    "session_id",
    "steps",
}

keywords = re.compile(
    r"("
    r"workload|query_spec|common_query|"
    r"non_contributive|noise|"
    r"wrong_measure|wrong_context|"
    r"insufficient_grain|invalid_aggregation|"
    r"invalid_unit|invalid_time_window|"
    r"missing_cube|redundant_contribution|"
    r"contribution_density|"
    r"objective_binding|semantic_equivalence|"
    r"replication|seed|session"
    r")",
    re.IGNORECASE,
)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def canonical_digest(value: Any) -> str:
    return sha256_bytes(
        canonical_json(value).encode("utf-8")
    )


def walk(
    value: Any,
    path: tuple[str, ...] = (),
) -> Iterator[tuple[tuple[str, ...], Any]]:
    yield path, value

    if isinstance(value, dict):
        for key, item in value.items():
            yield from walk(
                item,
                (*path, str(key)),
            )

    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(
                item,
                (*path, str(index)),
            )


def parse_structured(
    name: str,
    payload: bytes,
) -> Any | None:
    lowered = name.lower()

    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError:
        return None

    try:
        if lowered.endswith(".json"):
            return json.loads(text)

        if lowered.endswith((".yaml", ".yml")):
            return yaml.safe_load(text)

        if lowered.endswith(".jsonl"):
            values = []

            for line in text.splitlines():
                if line.strip():
                    values.append(json.loads(line))

            return values
    except Exception:
        return None

    stripped = text.lstrip()

    if stripped.startswith(("{", "[")):
        try:
            return json.loads(text)
        except Exception:
            return None

    return None


def workload_summary(
    member: str,
    object_path: tuple[str, ...],
    value: dict[str, Any],
) -> dict[str, Any]:
    steps = value.get("steps")

    if not isinstance(steps, list):
        raise AssertionError(
            "Workload object has non-list steps"
        )

    query_key_set: set[str] = set()
    step_key_set: set[str] = set()
    query_count = 0
    noise_values: set[str] = set()

    normalized_steps: list[Any] = []

    for step in steps:
        if not isinstance(step, dict):
            normalized_steps.append(step)
            continue

        step_key_set.update(
            str(key) for key in step
        )

        query = step.get("query_spec")

        if isinstance(query, dict):
            query_count += 1
            query_key_set.update(
                str(key) for key in query
            )

        for nested_path, item in walk(step):
            if not nested_path:
                continue

            final_key = nested_path[-1]

            if (
                keywords.search(final_key)
                and isinstance(item, str)
            ):
                noise_values.add(item)

        normalized_step = json.loads(
            json.dumps(step)
        )

        if isinstance(
            normalized_step.get("query_spec"),
            dict,
        ):
            query_spec = normalized_step[
                "query_spec"
            ]

            for key in (
                "objective_id",
                "session_id",
            ):
                if key in query_spec:
                    query_spec[key] = (
                        f"<{key.upper()}>"
                    )

        normalized_steps.append(
            normalized_step
        )

    return {
        "member": member,
        "object_path": ".".join(object_path),
        "top_level_keys": sorted(value),
        "contract_version": value.get(
            "contract_version"
        ),
        "workload_id": value.get(
            "workload_id"
        ),
        "objective_id": value.get(
            "objective_id"
        ),
        "session_id": value.get(
            "session_id"
        ),
        "step_count": len(steps),
        "query_spec_count": query_count,
        "step_keys": sorted(step_key_set),
        "query_spec_keys": sorted(
            query_key_set
        ),
        "noise_or_class_values": sorted(
            noise_values
        ),
        "canonical_sha256": canonical_digest(
            value
        ),
        "normalized_steps_sha256": (
            canonical_digest(
                normalized_steps
            )
        ),
        "first_two_steps": steps[:2],
        "last_two_steps": steps[-2:],
    }


def extract_python_surface(
    relative_path: Path,
) -> dict[str, Any]:
    path = root / relative_path
    source = path.read_text(
        encoding="utf-8"
    )

    tree = ast.parse(source)
    lines = source.splitlines()

    selected: list[dict[str, Any]] = []

    for node in tree.body:
        name: str | None = None

        if isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        ):
            name = node.name

        elif isinstance(
            node,
            (ast.Assign, ast.AnnAssign),
        ):
            targets: list[str] = []

            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        targets.append(target.id)

            elif isinstance(
                node.target,
                ast.Name,
            ):
                targets.append(node.target.id)

            if targets:
                name = ",".join(targets)

        if not name:
            continue

        start = int(
            getattr(node, "lineno", 1)
        )
        end = int(
            getattr(node, "end_lineno", start)
        )

        node_source = "\n".join(
            lines[start - 1 : end]
        )

        if not (
            keywords.search(name)
            or keywords.search(node_source)
        ):
            continue

        selected.append({
            "kind": type(node).__name__,
            "name": name,
            "start_line": start,
            "end_line": end,
            "source": node_source,
        })

    imports = []

    for node in tree.body:
        if isinstance(
            node,
            (ast.Import, ast.ImportFrom),
        ):
            start = int(node.lineno)
            end = int(
                getattr(node, "end_lineno", start)
            )

            imports.append(
                "\n".join(
                    lines[start - 1 : end]
                )
            )

    return {
        "path": relative_path.as_posix(),
        "sha256": sha256_file(path),
        "line_count": len(lines),
        "imports": imports,
        "selected_nodes": selected,
    }


repository_sources: list[dict[str, Any]] = []
schema_sources: list[dict[str, Any]] = []

for relative_path in source_paths:
    path = root / relative_path

    if path.suffix == ".py":
        repository_sources.append(
            extract_python_surface(
                relative_path
            )
        )
    else:
        schema_sources.append({
            "path": relative_path.as_posix(),
            "sha256": sha256_file(path),
            "content": path.read_text(
                encoding="utf-8"
            ),
        })


workload_objects: list[dict[str, Any]] = []
archive_references: list[dict[str, Any]] = []
archive_text_snippets: list[dict[str, Any]] = []
archive_member_names: list[str] = []

with tarfile.open(
    archive_path,
    mode="r:gz",
) as archive:
    for member in archive.getmembers():
        if not member.isfile():
            continue

        archive_member_names.append(
            member.name
        )

        extracted = archive.extractfile(member)

        if extracted is None:
            continue

        payload = extracted.read()
        parsed = parse_structured(
            member.name,
            payload,
        )

        if parsed is not None:
            for object_path, value in walk(
                parsed
            ):
                if (
                    isinstance(value, dict)
                    and required_workload_keys
                    .issubset(value)
                ):
                    workload_objects.append(
                        workload_summary(
                            member.name,
                            object_path,
                            value,
                        )
                    )

                if isinstance(value, str):
                    lowered = value.lower()

                    if (
                        "workload" in lowered
                        or "common_query" in lowered
                        or "query_spec" in lowered
                    ):
                        archive_references.append({
                            "member": member.name,
                            "object_path": ".".join(
                                object_path
                            ),
                            "value": value,
                        })

        if len(archive_text_snippets) >= 240:
            continue

        try:
            text = payload.decode("utf-8")
        except UnicodeDecodeError:
            continue

        lines = text.splitlines()

        for index, line in enumerate(
            lines,
            start=1,
        ):
            if not keywords.search(line):
                continue

            start = max(1, index - 3)
            end = min(
                len(lines),
                index + 3,
            )

            archive_text_snippets.append({
                "member": member.name,
                "start_line": start,
                "end_line": end,
                "text": "\n".join(
                    lines[start - 1 : end]
                ),
            })

            if len(
                archive_text_snippets
            ) >= 240:
                break


deduplicated_workloads: dict[
    tuple[str, str, str],
    dict[str, Any],
] = {}

for item in workload_objects:
    key = (
        item["member"],
        item["object_path"],
        item["canonical_sha256"],
    )
    deduplicated_workloads[key] = item

workload_objects = list(
    deduplicated_workloads.values()
)

deduplicated_references: dict[
    tuple[str, str, str],
    dict[str, Any],
] = {}

for item in archive_references:
    key = (
        item["member"],
        item["object_path"],
        item["value"],
    )
    deduplicated_references[key] = item

archive_references = list(
    deduplicated_references.values()
)[:500]


preparer_paths = {
    item["path"]
    for item in repository_sources
    if "prepare_" in Path(
        item["path"]
    ).name
}

preparer_node_count = sum(
    len(item["selected_nodes"])
    for item in repository_sources
    if item["path"] in preparer_paths
)

auditor_node_count = sum(
    len(item["selected_nodes"])
    for item in repository_sources
    if (
        "audit_" in Path(
            item["path"]
        ).name
    )
)

validator_node_count = sum(
    len(item["selected_nodes"])
    for item in repository_sources
    if "validate_workload" in item["path"]
)

test_node_count = sum(
    len(item["selected_nodes"])
    for item in repository_sources
    if "/tests/" in item["path"]
)

if (
    workload_objects
    and preparer_node_count > 0
    and auditor_node_count > 0
    and validator_node_count > 0
):
    status = (
        "frozen_precedent_and_repository_"
        "contract_resolved"
    )
    next_stage = (
        "author_sa5_objective_count_stage10_"
        "materializer_and_auditor"
    )

elif (
    preparer_node_count > 0
    and auditor_node_count > 0
    and validator_node_count > 0
    and test_node_count > 0
):
    status = (
        "repository_contract_resolved_"
        "archive_payload_not_directly_exposed"
    )
    next_stage = (
        "author_sa5_objective_count_stage10_"
        "materializer_and_auditor"
    )

else:
    status = (
        "materialization_contract_unresolved"
    )
    next_stage = (
        "formalize_sa5_common_workload_"
        "construction_contract"
    )


report = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "common-workload-precedent-v1"
    ),
    "source_commit": source_commit,
    "read_only": True,
    "status": status,
    "repository_contract": {
        "source_file_count": len(
            repository_sources
        ),
        "schema_file_count": len(
            schema_sources
        ),
        "preparer_file_count": len(
            preparer_paths
        ),
        "preparer_node_count": (
            preparer_node_count
        ),
        "auditor_node_count": (
            auditor_node_count
        ),
        "validator_node_count": (
            validator_node_count
        ),
        "test_node_count": (
            test_node_count
        ),
        "sources": repository_sources,
        "schemas": schema_sources,
    },
    "frozen_archive_precedent": {
        "archive_path": str(
            archive_path.relative_to(root)
        ),
        "archive_sha256": (
            sha256_file(archive_path)
        ),
        "member_count": len(
            archive_member_names
        ),
        "workload_object_count": len(
            workload_objects
        ),
        "workload_objects": (
            workload_objects
        ),
        "workload_reference_count": len(
            archive_references
        ),
        "workload_references": (
            archive_references
        ),
        "text_snippet_count": len(
            archive_text_snippets
        ),
        "text_snippets": (
            archive_text_snippets
        ),
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "functional_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)


surface: list[str] = [
    (
        "SA5 OBJECTIVE-COUNT COMMON-WORKLOAD "
        "PRECEDENT SURFACE"
    ),
    "=" * 88,
    f"source_commit={source_commit}",
    f"status={status}",
    (
        "workload_object_count="
        f"{len(workload_objects)}"
    ),
    (
        "workload_reference_count="
        f"{len(archive_references)}"
    ),
    (
        "preparer_node_count="
        f"{preparer_node_count}"
    ),
    (
        "auditor_node_count="
        f"{auditor_node_count}"
    ),
    (
        "validator_node_count="
        f"{validator_node_count}"
    ),
    (
        "test_node_count="
        f"{test_node_count}"
    ),
    "",
    "=== REPOSITORY SOURCE CONTRACT ===",
]

for source in repository_sources:
    surface.extend([
        "",
        "=" * 88,
        f"FILE={source['path']}",
        f"SHA256={source['sha256']}",
        f"LINE_COUNT={source['line_count']}",
        "=" * 88,
        "",
        "--- IMPORTS ---",
        *source["imports"],
        "",
        "--- RELEVANT DEFINITIONS ---",
    ])

    for node in source[
        "selected_nodes"
    ]:
        surface.extend([
            "",
            (
                f"### {node['kind']} "
                f"{node['name']} "
                f"[{node['start_line']}-"
                f"{node['end_line']}]"
            ),
            node["source"],
        ])

surface.extend([
    "",
    "=== WORKLOAD SCHEMAS ===",
])

for schema in schema_sources:
    surface.extend([
        "",
        "=" * 88,
        f"FILE={schema['path']}",
        f"SHA256={schema['sha256']}",
        "=" * 88,
        schema["content"],
    ])

surface.extend([
    "",
    "=== FROZEN ARCHIVE WORKLOAD OBJECTS ===",
])

for item in workload_objects:
    surface.extend([
        "",
        canonical_json(item),
    ])

surface.extend([
    "",
    "=== FROZEN ARCHIVE WORKLOAD REFERENCES ===",
])

for item in archive_references:
    surface.append(
        canonical_json(item)
    )

surface.extend([
    "",
    "=== FROZEN ARCHIVE TEXT SNIPPETS ===",
])

for item in archive_text_snippets:
    surface.extend([
        "",
        (
            f"MEMBER={item['member']} "
            f"LINES={item['start_line']}-"
            f"{item['end_line']}"
        ),
        item["text"],
    ])

surface_path.write_text(
    "\n".join(surface) + "\n",
    encoding="utf-8",
)

print(
    "common_workload_precedent_resolution=PASS"
)
print(f"resolution_status={status}")
print(
    "repository_source_file_count="
    f"{len(repository_sources)}"
)
print(
    "repository_schema_file_count="
    f"{len(schema_sources)}"
)
print(
    "preparer_file_count="
    f"{len(preparer_paths)}"
)
print(
    "preparer_node_count="
    f"{preparer_node_count}"
)
print(
    "auditor_node_count="
    f"{auditor_node_count}"
)
print(
    "validator_node_count="
    f"{validator_node_count}"
)
print(
    "test_node_count="
    f"{test_node_count}"
)
print(
    "archive_member_count="
    f"{len(archive_member_names)}"
)
print(
    "archive_workload_object_count="
    f"{len(workload_objects)}"
)
print(
    "archive_workload_reference_count="
    f"{len(archive_references)}"
)
print(
    "archive_text_snippet_count="
    f"{len(archive_text_snippets)}"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate resolution report ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-common-workload-precedent-v1"
  and .source_commit
    == "729b73b7716a4c32c610241256b7e42dd9ba6bfc"
  and .read_only == true
  and (
    .status
      == "frozen_precedent_and_repository_contract_resolved"
    or
    .status
      == "repository_contract_resolved_archive_payload_not_directly_exposed"
    or
    .status
      == "materialization_contract_unresolved"
  )
  and .repository_contract.source_file_count >= 10
  and .repository_contract.schema_file_count >= 1
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false
' "$REPORT" >/dev/null

echo "resolution_report_validation=PASS"

echo
echo "=== 5. Compact resolution summary ==="

jq '{
  schema_version,
  source_commit,
  status,
  repository_contract: {
    source_file_count:
      .repository_contract.source_file_count,
    schema_file_count:
      .repository_contract.schema_file_count,
    preparer_file_count:
      .repository_contract.preparer_file_count,
    preparer_node_count:
      .repository_contract.preparer_node_count,
    auditor_node_count:
      .repository_contract.auditor_node_count,
    validator_node_count:
      .repository_contract.validator_node_count,
    test_node_count:
      .repository_contract.test_node_count
  },
  frozen_archive_precedent: {
    member_count:
      .frozen_archive_precedent.member_count,
    workload_object_count:
      .frozen_archive_precedent.workload_object_count,
    workload_reference_count:
      .frozen_archive_precedent.workload_reference_count,
    text_snippet_count:
      .frozen_archive_precedent.text_snippet_count,
    workload_objects:
      .frozen_archive_precedent.workload_objects
  },
  scientific_controls,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value source index ==="

grep -nE \
  '^(FILE=|### .*workload|### .*query|### .*noise|### .*prepare|### .*audit|### .*validate|MEMBER=|status=|workload_object_count=)' \
  "$SURFACE" |
  head -n 400 || true

echo
echo "=== 7. Final repository immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

STATUS_VALUE="$(
  jq -r '.status' "$REPORT"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$REPORT"
)"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

echo "sa5_common_workload_precedent_resolution=PASS"
echo "resolution_status=$STATUS_VALUE"
echo "report=$REPORT"
echo "surface=$SURFACE"
echo "campaign_materialization_eligible=true"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=$NEXT_STAGE"

git status --short --branch
