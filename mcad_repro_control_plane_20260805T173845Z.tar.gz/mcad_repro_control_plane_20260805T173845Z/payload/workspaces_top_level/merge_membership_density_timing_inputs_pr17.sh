#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=17

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-membership-density-timing-inputs-20260803T105122Z"

EXPECTED_HEAD="1eac65e4a93ddb5d4b490362ccc127997cdb3439"
EXPECTED_BASE_HEAD="5a25d5e5a90c0fd821d9c0c21dc539fcfb9e8766"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

INPUT_ROOT="$REPORTS/timing_inputs/membership_density_stage10_portfolio"
WORKLOADS="$INPUT_ROOT/workloads"
SPECS="$INPUT_ROOT/execution_specs"
MANIFEST="$INPUT_ROOT/materialization_manifest.json"

REPORT_JSON="$REPORTS/planning/sa4_membership_density_timing_input_materialization.json"
REPORT_MD="$REPORTS/planning/sa4_membership_density_timing_input_materialization.md"

TIMING_RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

EXPECTED_MANIFEST_SHA="b8557e6b129d7405f9f7b8fb3e82db177d8e9a69a29e808cd174ea028efa5510"

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -d "$WORKLOADS"
test -d "$SPECS"
test -f "$MANIFEST"
test -f "$REPORT_JSON"
test -f "$REPORT_MD"
test ! -e "$TIMING_RUN_ROOT"

test "$(
  sha256sum "$MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

echo "local_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Materialized-input gate ==="

test "$(
  find "$WORKLOADS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

test "$(
  find "$SPECS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

jq -e '
  .status
    == "membership_density_timing_inputs_materialized"
  and .input_contract.replication_count == 10
  and .input_contract.density_levels == [25, 50, 75, 100]
  and .input_contract.selected_step_indexes == [range(1; 24)]
  and .input_contract.selected_step_count_per_replication == 23
  and .input_contract.derived_workload_count == 10
  and .input_contract.derived_execution_spec_count == 10
  and .input_contract.selected_instance_count == 40
  and .input_contract.raw_timing_cell_count == 920
  and .input_contract.warmup_observation_count == 9200
  and .input_contract.measurement_observation_count == 92000
  and .source_balance.source_workload_step_count == 238
  and .source_balance.derived_workload_step_count == 230
  and .source_balance.excluded_step_occurrence_count == 8
  and .immutability_controls.source_workload_files_modified == false
  and .immutability_controls.source_execution_specs_modified == false
  and .immutability_controls.source_functional_output_dirs_modified
      == false
  and .immutability_controls.source_hashes_verified_before_and_after
      == true
  and .immutability_controls.timing_run_directories_created == false
  and .scientific_controls.timing_input_materialization_performed
      == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .materialization_decision.derived_inputs_complete == true
  and .materialization_decision.derived_inputs_auditable == true
  and .materialization_decision.timing_execution_ready_for_authorization
      == true
  and .materialization_decision.timing_execution_authorized == false
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$MANIFEST" >/dev/null

jq -e '
  .status
    == "membership_density_timing_input_materialization_complete"
  and .derived_workload_count == 10
  and .derived_execution_spec_count == 10
  and .selected_step_count_per_replication == 23
  and .selected_instance_count == 40
  and .raw_timing_cell_count == 920
  and .warmup_observation_count == 9200
  and .measurement_observation_count == 92000
  and .excluded_step_occurrence_count == 8
  and .source_files_modified == false
  and .timing_run_directories_created == false
  and .timing_execution_authorized == false
  and .timing_execution_performed == false
  and .precision_analysis_authorized == false
  and .precision_analysis_performed == false
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$REPORT_JSON" >/dev/null

echo "materialized_input_gate=PASS"
echo "materialization_manifest_sha256=$EXPECTED_MANIFEST_SHA"
echo "derived_workload_count=10"
echo "derived_execution_spec_count=10"
echo "raw_timing_cell_count=920"
echo "measurement_observation_count=92000"
echo "timing_execution_authorized=false"

echo
echo "=== 3. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 4. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASSING="$(
    jq \
      '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASSING" -eq 0

  echo "timing_inputs_ci=PASS"
else
  echo "timing_inputs_ci=NOT_APPLICABLE"
fi

echo
echo "=== 5. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 6. Merge PR #17 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 7. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "materialization_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 8. Verify merged timing inputs ==="

test -f "$MANIFEST"
test -f "$REPORT_JSON"
test -f "$REPORT_MD"
test ! -e "$TIMING_RUN_ROOT"

test "$(
  sha256sum "$MANIFEST" | awk '{print $1}'
)" = "$EXPECTED_MANIFEST_SHA"

test "$(
  find "$WORKLOADS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

test "$(
  find "$SPECS" \
    -maxdepth 1 \
    -type f \
    -name '*.json' \
    | wc -l
)" -eq 10

jq -e '
  .status
    == "membership_density_timing_inputs_materialized"
  and .input_contract.derived_workload_count == 10
  and .input_contract.derived_execution_spec_count == 10
  and .input_contract.selected_step_count_per_replication == 23
  and .input_contract.raw_timing_cell_count == 920
  and .input_contract.measurement_observation_count == 92000
  and .source_balance.excluded_step_occurrence_count == 8
  and .immutability_controls.source_workload_files_modified == false
  and .immutability_controls.source_execution_specs_modified == false
  and .immutability_controls.timing_run_directories_created == false
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .materialization_decision.timing_execution_ready_for_authorization
      == true
  and .materialization_decision.timing_execution_authorized == false
  and .next_stage
      == "audit_and_authorize_membership_density_timing_execution"
' "$MANIFEST" >/dev/null

echo "merged_timing_inputs=PASS"
echo "materialization_manifest_sha256=$EXPECTED_MANIFEST_SHA"
echo "derived_workload_count=10"
echo "derived_execution_spec_count=10"
echo "timing_run_directories_created=false"
echo "timing_execution_authorized=false"

echo
echo "=== 9. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 10. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "membership_density_timing_inputs_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=audit_and_authorize_membership_density_timing_execution"

git status --short --branch
git log --oneline --decorate -5
