#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="f4b270c4092905d721476015f384c46b864d8182"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"

TIMING_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/virtual_node_count_stage10_c4"

FORMAL_TIMING_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution/formal_timing_execution_report.json"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis"

OBSERVATIONS="$PRECISION_ROOT/stage10_measurement_observations.csv"
ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"

INTERVALS="$PRECISION_ROOT/clustered_precision_intervals.csv"
RAW_REPORT="$PRECISION_ROOT/raw_analyzer_report.json"
RAW_MD="$PRECISION_ROOT/raw_analyzer_report.md"
ANALYZER_LOG="$PRECISION_ROOT/analyzer.log"

DECISION="$PRECISION_ROOT/stage10_precision_decision_report.json"
DECISION_MD="$PRECISION_ROOT/stage10_precision_decision_report.md"

trap 'echo "[ERROR] Precision analysis stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Precision-analysis gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$PREREG"
test -f "$FORMAL_TIMING_REPORT"
test -d "$TIMING_ROOT"
test ! -e "$PRECISION_ROOT"

echo "branch=$BASE"
echo "head=$EXPECTED_HEAD"
echo "precision_analysis_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create precision-analysis branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/analyze-virtual-node-count-stage10-precision-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Prepare deterministic analyzer inputs ==="

"$PYTHON" - \
  "$ROOT" \
  "$ANALYZER" \
  "$PREREG" \
  "$TIMING_ROOT" \
  "$FORMAL_TIMING_REPORT" \
  "$OBSERVATIONS" \
  "$ADAPTER" \
  "$INPUT_MANIFEST" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
analyzer_path = root / sys.argv[2]
prereg_path = root / sys.argv[3]
timing_root = root / sys.argv[4]
formal_report_path = root / sys.argv[5]
observations_path = root / sys.argv[6]
adapter_path = root / sys.argv[7]
manifest_path = root / sys.argv[8]
created_utc = sys.argv[9]


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SystemExit(f"Missing JSON artifact: {path}")

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def as_bool(value: Any) -> bool:
    return str(value).strip().lower() in {
        "true",
        "1",
        "yes",
    }


spec = importlib.util.spec_from_file_location(
    "mcad_precision_analyzer_v2",
    analyzer_path,
)

if spec is None or spec.loader is None:
    raise SystemExit("Unable to import precision analyzer.")

module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

contract = module.stage_contract(10)

prereg = load_json(prereg_path)
formal = load_json(formal_report_path)

precision_protocol = prereg.get(
    "precision_protocol",
    {},
)

expected_analyzer_sha = precision_protocol.get(
    "analyzer_sha256"
)
actual_analyzer_sha = sha256_file(analyzer_path)

if actual_analyzer_sha != expected_analyzer_sha:
    raise SystemExit(
        "Analyzer SHA-256 differs from preregistration."
    )

expected_formal = {
    "status": "pass",
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
}

for key, expected_value in expected_formal.items():
    actual = formal.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"Formal timing report {key}: "
            f"expected {expected_value!r}, "
            f"got {actual!r}"
        )

replication_reports = formal.get("replications")

if not isinstance(replication_reports, list):
    raise SystemExit(
        "Formal timing report lacks replications."
    )

if len(replication_reports) != 10:
    raise SystemExit(
        "Expected ten timing replication reports."
    )

reports_by_index = {
    int(item["replication_index"]): item
    for item in replication_reports
}

if sorted(reports_by_index) != list(range(10)):
    raise SystemExit(
        "Timing replication matrix is incomplete."
    )

csv_paths = sorted(
    timing_root.glob(
        "rep_*/timing_observations.csv"
    )
)

if len(csv_paths) != 10:
    raise SystemExit(
        f"Expected 10 timing CSV files, "
        f"got {len(csv_paths)}."
    )

measurement_rows: list[dict[str, str]] = []
source_records: list[dict[str, Any]] = []
headers: tuple[str, ...] | None = None
cell_counts: Counter[
    tuple[int, int, int]
] = Counter()

structural_seeds: set[int] = set()

for expected_index, csv_path in enumerate(csv_paths):
    report = reports_by_index[expected_index]

    expected_path = (
        timing_root
        / f"rep_{expected_index:03d}"
        / "timing_observations.csv"
    )

    if csv_path != expected_path:
        raise SystemExit(
            f"Unexpected CSV order: {csv_path}"
        )

    actual_sha = sha256_file(csv_path)
    expected_sha = report.get(
        "timing_observations_sha256"
    )

    if actual_sha != expected_sha:
        raise SystemExit(
            f"Replication {expected_index}: "
            "timing CSV SHA-256 mismatch."
        )

    with csv_path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as stream:
        reader = csv.DictReader(stream)
        current_headers = tuple(
            reader.fieldnames or ()
        )
        rows = list(reader)

    if not current_headers:
        raise SystemExit(
            f"Replication {expected_index}: "
            "missing CSV header."
        )

    if headers is None:
        headers = current_headers
    elif current_headers != headers:
        raise SystemExit(
            "Timing observation schemas differ."
        )

    warmup_rows = [
        row
        for row in rows
        if row.get("phase", "").lower()
        == "warmup"
    ]

    current_measurements = [
        row
        for row in rows
        if row.get("phase", "").lower()
        == "measurement"
    ]

    if len(rows) != 660:
        raise SystemExit(
            f"Replication {expected_index}: "
            f"expected 660 rows, got {len(rows)}."
        )

    if len(warmup_rows) != 60:
        raise SystemExit(
            f"Replication {expected_index}: "
            f"expected 60 warmups, "
            f"got {len(warmup_rows)}."
        )

    if len(current_measurements) != 600:
        raise SystemExit(
            f"Replication {expected_index}: "
            f"expected 600 measurements, "
            f"got {len(current_measurements)}."
        )

    replication_indexes = {
        int(row["replication_index"])
        for row in current_measurements
    }

    if replication_indexes != {expected_index}:
        raise SystemExit(
            f"Replication {expected_index}: "
            "observation replication index mismatch."
        )

    seeds = {
        int(row["seed"])
        for row in current_measurements
    }

    if len(seeds) != 1:
        raise SystemExit(
            f"Replication {expected_index}: "
            f"expected one structural seed, got {seeds}."
        )

    structural_seed = next(iter(seeds))
    expected_seed = int(report["structural_seed"])

    if structural_seed != expected_seed:
        raise SystemExit(
            f"Replication {expected_index}: "
            "structural seed mismatch."
        )

    structural_seeds.add(structural_seed)

    for row in current_measurements:
        if not as_bool(row.get("fresh_state")):
            raise SystemExit(
                f"Replication {expected_index}: "
                "non-fresh measurement state."
            )

        if not as_bool(row.get("semantic_match")):
            raise SystemExit(
                f"Replication {expected_index}: "
                "semantic mismatch."
            )

        level = int(row["factor_level"])
        step = int(row["step_index"])

        if level not in {6, 12, 24}:
            raise SystemExit(
                f"Unexpected factor level: {level}"
            )

        if step not in {1, 2}:
            raise SystemExit(
                f"Unexpected step index: {step}"
            )

        cell_counts[
            (
                expected_index,
                level,
                step,
            )
        ] += 1

    measurement_rows.extend(
        current_measurements
    )

    source_records.append(
        {
            "replication_index": expected_index,
            "structural_seed": structural_seed,
            "source_path": (
                csv_path.relative_to(root).as_posix()
            ),
            "source_sha256": actual_sha,
            "source_row_count": 660,
            "warmup_row_count": 60,
            "measurement_row_count": 600,
        }
    )

if headers is None:
    raise SystemExit("Missing observation CSV schema.")

if len(structural_seeds) != 10:
    raise SystemExit(
        f"Expected 10 structural seeds, "
        f"got {len(structural_seeds)}."
    )

if len(measurement_rows) != 6000:
    raise SystemExit(
        f"Expected 6000 measurement rows, "
        f"got {len(measurement_rows)}."
    )

expected_cells = {
    (replication, level, step)
    for replication in range(10)
    for level in (6, 12, 24)
    for step in (1, 2)
}

if set(cell_counts) != expected_cells:
    raise SystemExit(
        "Measurement cell matrix is incomplete."
    )

invalid_cell_counts = {
    key: value
    for key, value in cell_counts.items()
    if value != 100
}

if invalid_cell_counts:
    raise SystemExit(
        f"Unbalanced measurement cells: "
        f"{invalid_cell_counts}"
    )

observations_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

with observations_path.open(
    "w",
    encoding="utf-8",
    newline="",
) as stream:
    writer = csv.DictWriter(
        stream,
        fieldnames=list(headers),
        lineterminator="\n",
    )

    writer.writeheader()
    writer.writerows(measurement_rows)

totals = {
    "run_count": 10,
    "successful_run_count": 10,
    "cell_count": 60,
    "measurement_observation_count": 6000,
    "functional_mismatch_count": 0,
    "exactly_balanced_run_count": 10,
    "structural_seed_count": 10,
}

adapter = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "precision-analyzer-input-adapter-v1"
    ),
    "status": contract["timing_status"],
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "adapter_purpose": (
        "Expose the formally validated timing evidence "
        "through the preregistered analyzer's immutable "
        "stage-contract interface."
    ),
    "source_formal_timing_report": {
        "path": (
            formal_report_path
            .relative_to(root)
            .as_posix()
        ),
        "sha256": sha256_file(
            formal_report_path
        ),
        "status": formal["status"],
    },
    contract["totals_key"]: totals,
    "scientific_constraints": {
        "functional_execution_rerun_performed": False,
        "timing_execution_rerun_performed": False,
        "latency_claim_authorized": False,
        "stage20_execution_authorized": False,
        "scientific_freeze_authorized": False,
    },
}

write_json(adapter_path, adapter)

manifest = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "precision-input-manifest-v1"
    ),
    "status": "pass",
    "created_utc": created_utc,
    "campaign_id": "virtual_node_count_stage10_c4",
    "factor": "virtual_node_count",
    "analyzer": {
        "path": (
            analyzer_path.relative_to(root).as_posix()
        ),
        "sha256": actual_analyzer_sha,
        "preregistered_sha256": expected_analyzer_sha,
        "sha256_matches_preregistration": True,
        "stage_contract": contract,
    },
    "observations": {
        "path": (
            observations_path
            .relative_to(root)
            .as_posix()
        ),
        "sha256": sha256_file(
            observations_path
        ),
        "phase": "measurement",
        "row_count": 6000,
        "structural_seed_count": 10,
        "replication_count": 10,
        "factor_levels": [6, 12, 24],
        "step_indexes": [1, 2],
        "cell_count": 60,
        "measurements_per_cluster_and_cell": 100,
        "line_ending": "LF",
    },
    "timing_report_adapter": {
        "path": (
            adapter_path.relative_to(root).as_posix()
        ),
        "sha256": sha256_file(adapter_path),
        "status": adapter["status"],
        "totals_key": contract["totals_key"],
        "totals": totals,
    },
    "source_timing_csv_files": source_records,
    "execution_state": {
        "precision_analysis_performed": False,
        "functional_execution_rerun_performed": False,
        "timing_execution_rerun_performed": False,
    },
}

write_json(manifest_path, manifest)

print("precision_input_preparation=PASS")
print(f"contract_timing_status={contract['timing_status']}")
print(f"contract_totals_key={contract['totals_key']}")
print("source_timing_csv_count=10")
print("structural_seed_count=10")
print("timing_cell_count=60")
print("measurement_observation_count=6000")
print("measurements_per_cluster_and_cell=100")
print("all_functional_semantic_matches=true")
print("analyzer_sha256_matches_preregistration=true")
print("functional_execution_rerun_performed=false")
print("timing_execution_rerun_performed=false")
print("precision_analysis_performed=false")
PY

echo
echo "=== 4. Execute preregistered analyzer exactly once ==="

if PYTHONPATH="$ROOT" \
  "$PYTHON" "$ANALYZER" \
    --stage-size 10 \
    --observations "$OBSERVATIONS" \
    --timing-report "$ADAPTER" \
    --intervals-csv "$INTERVALS" \
    --report-json "$RAW_REPORT" \
    --report-md "$RAW_MD" \
    --levels "6,12,24" \
    --steps "1,2" \
    --measurements-per-cluster 100 \
    --bootstrap-repetitions 10000 \
    --bootstrap-seed 20260728 \
    --confidence-level 0.95 \
    --median-target 0.10 \
    --p95-target 0.15 \
    >"$ANALYZER_LOG" 2>&1
then
  ANALYZER_STATUS=0
else
  ANALYZER_STATUS=$?
fi

cat "$ANALYZER_LOG"

echo "analyzer_exit_status=$ANALYZER_STATUS"

test "$ANALYZER_STATUS" -eq 0
test -f "$INTERVALS"
test -f "$RAW_REPORT"
test -f "$RAW_MD"

echo "clustered_precision_analyzer_execution=PASS"
echo "precision_analysis_performed=true"

echo
echo "=== 5. Validate analysis and create campaign decision ==="

COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$ANALYZER" \
  "$PREREG" \
  "$OBSERVATIONS" \
  "$ADAPTER" \
  "$INTERVALS" \
  "$RAW_REPORT" \
  "$RAW_MD" \
  "$ANALYZER_LOG" \
  "$DECISION" \
  "$DECISION_MD" \
  "$BRANCH" \
  "$CREATED_UTC" \
  "$COMPLETED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
analyzer_path = root / sys.argv[2]
prereg_path = root / sys.argv[3]
observations_path = root / sys.argv[4]
adapter_path = root / sys.argv[5]
intervals_path = root / sys.argv[6]
raw_report_path = root / sys.argv[7]
raw_md_path = root / sys.argv[8]
log_path = root / sys.argv[9]
decision_path = root / sys.argv[10]
decision_md_path = root / sys.argv[11]
execution_branch = sys.argv[12]
started_utc = sys.argv[13]
completed_utc = sys.argv[14]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


spec = importlib.util.spec_from_file_location(
    "mcad_precision_analyzer_v2_validation",
    analyzer_path,
)

if spec is None or spec.loader is None:
    raise SystemExit("Unable to import analyzer.")

module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

contract = module.stage_contract(10)

prereg = load_json(prereg_path)
raw = load_json(raw_report_path)

precision = prereg["precision_protocol"]

expected_analyzer_sha = precision[
    "analyzer_sha256"
]
actual_analyzer_sha = sha256_file(
    analyzer_path
)

if actual_analyzer_sha != expected_analyzer_sha:
    raise SystemExit(
        "Analyzer SHA-256 changed during analysis."
    )

expected_raw_statuses = {
    contract["success_status"],
    contract["failure_status"],
}

if raw.get("status") not in expected_raw_statuses:
    raise SystemExit(
        f"Unexpected analyzer status: "
        f"{raw.get('status')!r}"
    )

if raw.get("stage_size") != 10:
    raise SystemExit("Expected Stage-10 analysis.")

if raw.get("structural_seed_count") != 10:
    raise SystemExit(
        "Expected 10 structural-seed clusters."
    )

if raw.get("scientific_freeze") is not False:
    raise SystemExit(
        "Scientific freeze must remain false."
    )

if raw.get("latency_claim_authorized") is not False:
    raise SystemExit(
        "Latency claims must remain unauthorized."
    )

bootstrap = raw.get("bootstrap_contract", {})

expected_bootstrap = {
    "unit_of_resampling": (
        "structural seed cluster"
    ),
    "within_cluster_measurements": (
        "retained together"
    ),
    "bootstrap_repetitions": 10000,
    "bootstrap_seed": 20260728,
    "confidence_level": 0.95,
    "median_relative_half_width_target": 0.10,
    "p95_relative_half_width_target": 0.15,
}

for key, expected_value in expected_bootstrap.items():
    actual = bootstrap.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"Bootstrap {key}: expected "
            f"{expected_value!r}, got {actual!r}"
        )

inputs = raw.get("inputs", {})

if inputs.get("observation_count") != 6000:
    raise SystemExit(
        "Analyzer did not consume 6000 observations."
    )

if (
    inputs.get("observations_sha256")
    != sha256_file(observations_path)
):
    raise SystemExit(
        "Analyzer observation SHA-256 mismatch."
    )

if (
    inputs.get("timing_report_sha256")
    != sha256_file(adapter_path)
):
    raise SystemExit(
        "Analyzer timing-adapter SHA-256 mismatch."
    )

cells = raw.get("cell_results")

if not isinstance(cells, list):
    raise SystemExit(
        "Analyzer report lacks cell results."
    )

if len(cells) != 6:
    raise SystemExit(
        f"Expected six precision cells, "
        f"got {len(cells)}."
    )

observed_cells = {
    (
        int(row["factor_level"]),
        int(row["step_index"]),
    )
    for row in cells
}

expected_cells = {
    (level, step)
    for level in (6, 12, 24)
    for step in (1, 2)
}

if observed_cells != expected_cells:
    raise SystemExit(
        f"Unexpected precision cell matrix: "
        f"{observed_cells}"
    )

with intervals_path.open(
    "r",
    encoding="utf-8",
    newline="",
) as stream:
    interval_rows = list(csv.DictReader(stream))

if len(interval_rows) != 6:
    raise SystemExit(
        f"Expected six interval rows, "
        f"got {len(interval_rows)}."
    )

all_targets = raw.get(
    "all_precision_targets_met"
)
sufficient = raw.get(
    contract["sufficient_key"]
)
extension_required = raw.get(
    contract["extension_key"]
)

if not isinstance(all_targets, bool):
    raise SystemExit(
        "Missing precision-target decision."
    )

if not isinstance(sufficient, bool):
    raise SystemExit(
        "Missing Stage-10 sufficiency decision."
    )

if not isinstance(extension_required, bool):
    raise SystemExit(
        "Missing extension decision."
    )

if sufficient != all_targets:
    raise SystemExit(
        "Sufficiency decision differs from "
        "all-target result."
    )

if extension_required == sufficient:
    raise SystemExit(
        "Invalid sufficiency/extension relation."
    )

expected_status = (
    contract["success_status"]
    if sufficient
    else contract["failure_status"]
)

if raw["status"] != expected_status:
    raise SystemExit(
        "Analyzer status differs from gate result."
    )

failing_cell_count = int(
    raw["failing_cell_count"]
)

if sufficient and failing_cell_count != 0:
    raise SystemExit(
        "Sufficient stage has failing cells."
    )

if (
    not sufficient
    and failing_cell_count <= 0
):
    raise SystemExit(
        "Insufficient stage lacks failing cells."
    )

if sufficient:
    campaign_gate = "stage10_precision_sufficient"
    campaign_next_stage = (
        "prepare_virtual_node_count_stage10_freeze"
    )
else:
    campaign_gate = (
        "stage10_precision_insufficient"
    )
    campaign_next_stage = (
        "prepare_virtual_node_count_stage20_authorization"
    )

decision = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "precision-decision-v1"
    ),
    "status": "pass",
    "campaign_id": (
        "virtual_node_count_stage10_c4"
    ),
    "factor": "virtual_node_count",
    "execution_branch": execution_branch,
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "analysis": {
        "performed": True,
        "analyzer_path": (
            analyzer_path.relative_to(root).as_posix()
        ),
        "analyzer_sha256": actual_analyzer_sha,
        "analyzer_sha256_matches_preregistration": (
            True
        ),
        "raw_report_path": (
            raw_report_path
            .relative_to(root)
            .as_posix()
        ),
        "raw_report_sha256": sha256_file(
            raw_report_path
        ),
        "raw_markdown_path": (
            raw_md_path.relative_to(root).as_posix()
        ),
        "raw_markdown_sha256": sha256_file(
            raw_md_path
        ),
        "analyzer_log_path": (
            log_path.relative_to(root).as_posix()
        ),
        "analyzer_log_sha256": sha256_file(
            log_path
        ),
        "intervals_csv_path": (
            intervals_path
            .relative_to(root)
            .as_posix()
        ),
        "intervals_csv_sha256": sha256_file(
            intervals_path
        ),
    },
    "bootstrap_contract": bootstrap,
    "replication_count": 10,
    "structural_seed_count": 10,
    "timing_cell_count": 60,
    "precision_cell_count": 6,
    "measurement_observation_count": 6000,
    "all_median_targets_met": raw[
        "all_median_targets_met"
    ],
    "all_p95_targets_met": raw[
        "all_p95_targets_met"
    ],
    "all_precision_targets_met": all_targets,
    "failing_cell_count": failing_cell_count,
    "failing_cells": raw["failing_cells"],
    "stage10_sufficient": sufficient,
    "stage20_extension_required": (
        extension_required
    ),
    "campaign_gate": campaign_gate,
    "raw_analyzer_next_stage": raw[
        "next_stage"
    ],
    "scientific_constraints": {
        "functional_execution_rerun_performed": False,
        "timing_execution_rerun_performed": False,
        "latency_claim_authorized": False,
        "stage20_execution_authorized": False,
        "scientific_freeze_authorized": False,
    },
    "next_stage": campaign_next_stage,
}

write_json(decision_path, decision)

lines = [
    (
        "# Virtual-node-count Stage-10 "
        "precision analysis"
    ),
    "",
    f"- Status: `{decision['status']}`",
    (
        "- Structural-seed clusters: "
        f"`{decision['structural_seed_count']}`"
    ),
    (
        "- Measurement observations: "
        f"`{decision['measurement_observation_count']}`"
    ),
    (
        "- Bootstrap repetitions: "
        f"`{bootstrap['bootstrap_repetitions']}`"
    ),
    (
        "- Confidence level: "
        f"`{bootstrap['confidence_level']:.0%}`"
    ),
    (
        "- All precision targets met: "
        f"`{str(all_targets).lower()}`"
    ),
    (
        "- Failing cells: "
        f"`{failing_cell_count}`"
    ),
    (
        "- Stage-10 sufficient: "
        f"`{str(sufficient).lower()}`"
    ),
    (
        "- Stage-20 extension required: "
        f"`{str(extension_required).lower()}`"
    ),
    "- Stage-20 execution authorized: `false`",
    "- Latency claims authorized: `false`",
    "- Scientific freeze authorized: `false`",
    "",
    (
        "| Level | Step | Median RHW | "
        "p95 RHW | Pass |"
    ),
    "|---:|---:|---:|---:|---|",
]

for row in sorted(
    cells,
    key=lambda item: (
        int(item["factor_level"]),
        int(item["step_index"]),
    ),
):
    lines.append(
        f"| {row['factor_level']} "
        f"| {row['step_index']} "
        f"| "
        f"{float(row['median_relative_half_width']):.2%} "
        f"| "
        f"{float(row['p95_relative_half_width']):.2%} "
        f"| {row['all_cell_targets_met']} |"
    )

lines.extend(
    [
        "",
        "## Next stage",
        "",
        f"`{campaign_next_stage}`",
        "",
    ]
)

decision_md_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

decision_md_path.write_text(
    "\n".join(lines),
    encoding="utf-8",
)

print("stage10_precision_analysis_validation=PASS")
print("structural_seed_count=10")
print("precision_cell_count=6")
print("measurement_observation_count=6000")
print(
    "all_median_targets_met="
    f"{str(raw['all_median_targets_met']).lower()}"
)
print(
    "all_p95_targets_met="
    f"{str(raw['all_p95_targets_met']).lower()}"
)
print(
    "all_precision_targets_met="
    f"{str(all_targets).lower()}"
)
print(
    f"failing_cell_count={failing_cell_count}"
)
print(
    "stage10_sufficient="
    f"{str(sufficient).lower()}"
)
print(
    "stage20_extension_required="
    f"{str(extension_required).lower()}"
)
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("scientific_freeze_authorized=false")
print(
    "functional_execution_rerun_performed=false"
)
print("timing_execution_rerun_performed=false")
print("precision_analysis_performed=true")
print(f"next_stage={campaign_next_stage}")
PY

echo
echo "=== 6. Commit precision evidence ==="

git add -f "$PRECISION_ROOT"

git diff --cached --check -- \
  . \
  ":(exclude)$INTERVALS"

echo "non_generated_csv_diff_check=PASS"

git diff --cached --stat

git commit \
  -m "evidence(experiments): analyze virtual-node-count Stage-10 precision"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 7. Push precision-analysis branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

ALL_TARGETS="$(
  jq -r '.all_precision_targets_met' \
    "$DECISION"
)"

STAGE10_SUFFICIENT="$(
  jq -r '.stage10_sufficient' \
    "$DECISION"
)"

EXTENSION_REQUIRED="$(
  jq -r '.stage20_extension_required' \
    "$DECISION"
)"

FAILING_CELL_COUNT="$(
  jq -r '.failing_cell_count' \
    "$DECISION"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' \
    "$DECISION"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Analyze virtual-node-count Stage-10 timing precision" \
    --body "$(cat <<EOF
## Scope

- consolidates the ten formal timing outputs into 6000 measurement observations;
- excludes the 600 warmup observations from inferential analysis;
- validates all source CSV SHA-256 values;
- adapts the campaign timing report to the immutable preregistered Stage-10 analyzer contract;
- executes the preregistered analyzer exactly once;
- performs a 10000-repetition structural-seed cluster bootstrap;
- retains measurements within each structural-seed cluster;
- evaluates all six level-step cells.

## Precision gate

- all precision targets met: \`$ALL_TARGETS\`;
- failing cells: \`$FAILING_CELL_COUNT\`;
- Stage-10 sufficient: \`$STAGE10_SUFFICIENT\`;
- Stage-20 extension required: \`$EXTENSION_REQUIRED\`;
- Stage-20 execution authorized: \`false\`;
- latency claims authorized: \`false\`;
- scientific freeze authorized: \`false\`.

## Execution safeguards

- functional rerun performed: \`false\`;
- timing rerun performed: \`false\`;
- precision analysis performed: \`true\`.

## Next stage

\`$NEXT_STAGE\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

echo "virtual_node_count_stage10_precision_analysis=PASS"
echo "commit=$COMMIT"
echo "structural_seed_count=10"
echo "precision_cell_count=6"
echo "measurement_observation_count=6000"
echo "all_precision_targets_met=$ALL_TARGETS"
echo "failing_cell_count=$FAILING_CELL_COUNT"
echo "stage10_sufficient=$STAGE10_SUFFICIENT"
echo "stage20_extension_required=$EXTENSION_REQUIRED"
echo "stage20_execution_authorized=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_performed=true"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_precision_analysis"

git status --short --branch
git log --oneline --decorate -4
