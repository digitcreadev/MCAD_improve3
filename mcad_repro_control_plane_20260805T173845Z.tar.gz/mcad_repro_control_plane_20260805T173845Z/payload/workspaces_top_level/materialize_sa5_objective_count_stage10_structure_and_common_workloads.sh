#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_FEATURE_COMMIT="2b3150b83108fe50e6f6db7841b9fa5076693628"
EXPECTED_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

READINESS_ROOT="/workspaces/sa5_objective_count_v2_post_merge_materialization_readiness_20260805T102938Z"
READINESS_REPORT="$READINESS_ROOT/sa5_objective_count_v2_post_merge_materialization_readiness.json"
EXPECTED_READINESS_REPORT_SHA="2acc274086cf0ff8187132596c5177b350c87e774f4be3597782c9f23341f472"
READINESS_SURFACE="$READINESS_ROOT/sa5_objective_count_v2_post_merge_materialization_readiness.txt"
EXPECTED_READINESS_SURFACE_SHA="209aaac5411822ec21519515518b2a41c0dd57ffa0c9bbe783df210a3c9f0f98"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"
EXPECTED_WORKLOAD_SCHEMA_SHA="df4f868365594f629dc0b9d5946e6b5fd90ee16d759fce6bd0b0c34f8de81027"

V1_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
EXPECTED_V1_GENERATOR_SHA="556654c4286adaeb88ebc9dd70939df96d70d8e8ba94265cd1684b763e826788"

V1_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
EXPECTED_V1_FAMILY_SHA="e2389ca35cdfcff14dcb0ee940482a374470f32a49af5e70ddffcb685d8bfdb5"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/$CAMPAIGN_ID"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/$CAMPAIGN_ID"
STRUCTURE_AUDIT="$AUDIT_ROOT/structure_audit.json"
WORKLOAD_AUDIT="$AUDIT_ROOT/common_workload_audit.json"
CAMPAIGN_FILE_MANIFEST="$AUDIT_ROOT/canonical_campaign_file_manifest.sha256"

MATERIALIZATION_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.json"
MATERIALIZATION_SUMMARY="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.md"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/materialize-sa5-objective-count-stage10-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_objective_count_materialization.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 objective-count canonical materialization stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

cat > "$TMP_ROOT/implementation_sha256sums.txt" <<'EOF'
b9fc580f1e178da0f4701a427389a5b5f78055d16341fa16734c9e4889927560  .github/workflows/phase3-regression.yml
6faaa8b7dea5b682ac9ea6ecf3cf790ff6d7a4c5c56d105a52c4e7acf2ad739d  backend/ckg/ckg_updater.py
261a3883b070c739937e24245a47483ed904194e3ea0840bae788c2b5bcdea57  backend/harness/sensitivity_execution/e3_contract.yaml
dde835674506c5167aa4065146d494ab4a932837e392c28e099d09a176b8162d  backend/harness/sensitivity_execution/execute_controlled_family.py
835a5c8315f01582d9114b159fa874c8a4c30afcce234a43547227a2954ded48  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
1dc1ffd9ca9dec985eb8d8fb998997958651a9aa2e5b51e4119d430004cd5c49  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
35ef4af11bb2b0d3197895676d033d3abf92f01e42e7e8918b7bb9dea1f8307b  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
2fd703d251ada566a84bdf4e73ace78a0a7f3163becf8a769ffb71a45bd1fa7d  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
d869f5e839dc86546295deb9ccc66360b11d3ebd2bf43fbb3504737cdb885c77  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
aec33a7e254a5e55a56c7962429f10f60c5fc23f009cc83d5742d39541087341  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
326bf6337fc58a0282f0f0b6a743a61873b2545b2532d2f21086f567b9409d5b  backend/harness/sensitivity_execution/tests/test_workload_spec.py
b8aa28b16f78df5a5ba4acc71807818b39282925bea8f0f798fd24a82892b616  backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
63c1e7674b2861b7e3dbfcd9009e31cd2676f27d5d90eb5b27de30de6ead1e4e  backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
de7ebaab3218d4f533ba83910015cdb45a7aff6479f62d3e0b653fceaed4b691  backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
d9952914589f185a64bc7735331ba25e490656d822030fee5e73f5f51d1e35a5  backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
98d87e9ce01277bdeafd94eed4cab1516fb4bb871f378e2bf04ece4b0a0940a2  backend/harness/sensitivity_execution/validate_e3_contract.py
e725bedfff82a75708c2e889469fc0f8441619a98215addf059017297f974d1f  backend/harness/sensitivity_execution/validate_workload_spec.py
2bc6a431e18f4cd8cca646d8b47d19dc5a4e2cf5e120cfa466848fa6772420df  backend/harness/sensitivity_generator/families/controlled_families.py
7ed4a8756f7426739d4c8f4914d59a86eeef448491915bc23ef776ba8654b12f  backend/harness/sensitivity_generator/families/objective_count_family_v2.py
7fbbe99c0ea6c4d7505c8290c791ec8826a4d36b8f85c888543524a30cc03863  backend/harness/sensitivity_generator/objective_count_generator_v2.py
cbfc114661cef0ddf673bd377c97e9a8a4d60521057da33c2e045613da86ce9b  backend/harness/sensitivity_generator/tests/test_controlled_families.py
55a90bca7518c44a387976f7762d41fdedb6b0121563d9cb9789e7b2c7a0326f  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
a8eb5d296c4e50c8468b3e51c6f8c0ece73231a2d294430403279eba6d3b13eb  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
a76fd8d752941cd9673cbb6dcfae227a3d1f1e7818d70d467868234e884e8b95  backend/mcad/models.py
9de16bdc0a03994d3e3eebd92a9036394801e0f4750d7698470dec663acaf8b4  backend/mcad/objectives.py
EOF

echo "=== 1. Exact canonical-materialization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

sha256sum \
  -c \
  "$TMP_ROOT/implementation_sha256sums.txt" \
  >/dev/null

verify_sha "$READINESS_REPORT" "$EXPECTED_READINESS_REPORT_SHA"
verify_sha "$READINESS_SURFACE" "$EXPECTED_READINESS_SURFACE_SHA"

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

test ! -e "$CAMPAIGN_ROOT"
test ! -e "$AUDIT_ROOT"
test ! -e "$MATERIALIZATION_REPORT"
test ! -e "$MATERIALIZATION_SUMMARY"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

jq -e '
  .status
    == "sa5_objective_count_v2_canonical_materialization_ready"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .feature_commit
    == "2b3150b83108fe50e6f6db7841b9fa5076693628"
  and .patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .detached_noncanonical_probe.level_sweep.instance_count
    == 6
  and .detached_noncanonical_probe.level_sweep.workload_count
    == 1
  and .detached_noncanonical_probe.seed_sweep.instance_count
    == 10
  and .detached_noncanonical_probe.seed_sweep.workload_count
    == 10
  and .detached_noncanonical_probe.operator_oracle_mismatch_count
    == 0
  and .detached_noncanonical_probe.structure_failure_count
    == 0
  and .detached_noncanonical_probe.workload_failure_count
    == 0

  and .effective_contract.levels
    == [1, 2, 5, 10, 20, 50]
  and (
    .effective_contract.seeds
    | length
  ) == 10
  and .effective_contract.expected_canonical_instance_count
    == 60
  and .effective_contract.expected_common_workload_count
    == 10
  and .effective_contract.workload_length
    == 32
  and .effective_contract.oracle_contributive_query_count
    == 24
  and .effective_contract.non_contributive_query_count
    == 8
  and .effective_contract.noise_ratio
    == 0.25
  and .effective_contract.session_support_policy
    == "union_requirement_sets"

  and .authorization.canonical_campaign_materialization_authorized
    == true
  and .authorization.canonical_structure_materialization_authorized
    == true
  and .authorization.canonical_common_workload_materialization_authorized
    == true
  and .authorization.functional_execution_authorized
    == false
  and .authorization.scientific_execution_authorized
    == false

  and .canonical_target
    == "reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"
  and .blocker_count == 0
  and .readiness_complete == true
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$READINESS_REPORT" >/dev/null

echo "canonical_materialization_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "readiness_report_sha256=$EXPECTED_READINESS_REPORT_SHA"
echo "canonical_target=$CAMPAIGN_ROOT"
echo "expected_instance_count=60"
echo "expected_common_workload_count=10"
echo "canonical_campaign_materialization_authorized=true"
echo "functional_execution_authorized=false"

echo
echo "=== 2. Revalidate materializer implementation ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py \
  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py \
  -q \
  -p no:cacheprovider

sha256sum \
  -c \
  "$TMP_ROOT/implementation_sha256sums.txt" \
  >/dev/null

test -z "$(git status --porcelain)"

echo "materializer_regression_gate=PASS"

echo
echo "=== 3. Create isolated canonical-materialization branch ==="

git switch -c "$BRANCH"

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "materialization_branch_creation=PASS"
echo "branch=$BRANCH"

echo
echo "=== 4. Materialize canonical structure and common workloads ==="
echo "materialization_notice=full_generation_may_take_several_minutes"

export CAMPAIGN_ID
export CAMPAIGN_ROOT
export WORKLOAD_ROOT
export STRUCTURE_AUDIT
export WORKLOAD_AUDIT
export EXPECTED_HEAD
export EXPECTED_FEATURE_COMMIT

"$PYTHON" - <<'PY'
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from backend.harness.sensitivity_execution.tools.audit_objective_count_stage10_common_workloads_v2 import (
    audit_common_workloads,
)
from backend.harness.sensitivity_execution.tools.audit_objective_count_structure_v2 import (
    audit_objective_count_structure_v2,
)
from backend.harness.sensitivity_execution.tools.prepare_objective_count_stage10_common_workloads_v2 import (
    prepare_common_workloads,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)


campaign_id = os.environ["CAMPAIGN_ID"]
campaign_root = Path(os.environ["CAMPAIGN_ROOT"])
workload_root = Path(os.environ["WORKLOAD_ROOT"])
structure_audit_path = Path(os.environ["STRUCTURE_AUDIT"])
workload_audit_path = Path(os.environ["WORKLOAD_AUDIT"])

levels = (1, 2, 5, 10, 20, 50)
seeds = (
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
)

print("canonical_structure_generation=START", flush=True)
print(f"levels={','.join(str(value) for value in levels)}", flush=True)
print(f"replication_count={len(seeds)}", flush=True)

manifest = generate_controlled_family(
    ControlledFamilySpec(
        campaign_id=campaign_id,
        factor="objective_count",
        levels=levels,
        seeds=seeds,
        baseline_constraint_count=8,
        baseline_virtual_node_count=32,
        output_dir=str(campaign_root),
    )
)

assert manifest.campaign_generator_version == (
    "mcad-sensitivity-e2.2-objective-count-v2"
)
assert manifest.structural_generator_version == (
    "mcad-sensitivity-e2.1-objective-count-v2"
)
assert manifest.campaign_id == campaign_id
assert manifest.factor == "objective_count"
assert tuple(manifest.levels) == levels
assert tuple(manifest.seeds) == seeds
assert manifest.level_count == 6
assert manifest.replication_count == 10
assert manifest.expected_instance_count == 60
assert manifest.realised_instance_count == 60
assert manifest.selected_objective_index == 0
assert manifest.session_support_policy == "union_requirement_sets"

print("canonical_structure_generation=PASS", flush=True)
print("canonical_instance_count=60", flush=True)
print(
    f"campaign_spec_digest={manifest.campaign_spec_digest}",
    flush=True,
)
print(
    f"campaign_digest={manifest.campaign_digest}",
    flush=True,
)

print("canonical_common_workload_materialization=START", flush=True)

workload_manifest = prepare_common_workloads(
    campaign_root,
    workload_root,
)

assert workload_manifest["campaign_id"] == campaign_id
assert workload_manifest["factor"] == "objective_count"
assert workload_manifest["workload_count"] == 10
assert workload_manifest["workload_length"] == 32
assert workload_manifest["contributive_query_count_per_workload"] == 24
assert workload_manifest["non_contributive_query_count_per_workload"] == 8
assert len(workload_manifest["entries"]) == 10

assert {
    int(entry["replication_index"])
    for entry in workload_manifest["entries"]
} == set(range(10))

assert [
    int(entry["seed"])
    for entry in workload_manifest["entries"]
] == list(seeds)

assert all(
    entry["shared_factor_levels"] == list(levels)
    for entry in workload_manifest["entries"]
)

print("canonical_common_workload_materialization=PASS", flush=True)
print("canonical_common_workload_count=10", flush=True)

print("canonical_structure_audit=START", flush=True)

structure_report = audit_objective_count_structure_v2(
    campaign_root
)

assert structure_report["status"] == "PASS"
assert structure_report["failure_count"] == 0
assert structure_report["instance_count"] == 60
assert len(structure_report["instance_reports"]) == 60

assert all(
    item["support_resource_count"] == 24
    for item in structure_report["instance_reports"]
)

assert all(
    item["support_query_signature_count"] == 24
    for item in structure_report["instance_reports"]
)

print("canonical_structure_audit=PASS", flush=True)

print("canonical_common_workload_audit=START", flush=True)

workload_report = audit_common_workloads(
    campaign_root,
    workload_root,
)

assert workload_report["status"] == "PASS"
assert workload_report["failure_count"] == 0
assert workload_report["workload_count"] == 10
assert len(workload_report["workload_reports"]) == 10

assert all(
    item["workload_length"] == 32
    for item in workload_report["workload_reports"]
)

assert all(
    item["oracle_contributive_query_count"] == 24
    for item in workload_report["workload_reports"]
)

assert all(
    item["non_contributive_query_count"] == 8
    for item in workload_report["workload_reports"]
)

assert all(
    item["realised_noise_ratio"] == 0.25
    for item in workload_report["workload_reports"]
)

assert all(
    item["operator_oracle_mismatch_count"] == 0
    for item in workload_report["workload_reports"]
)

expected_noise_totals = {
    "insufficient_grain": 10,
    "invalid_aggregation": 10,
    "invalid_time_window": 10,
    "invalid_unit": 10,
    "missing_cube": 10,
    "redundant_contribution": 10,
    "wrong_context": 10,
    "wrong_measure": 10,
}

assert workload_report["stage10_noise_class_counts"] == (
    expected_noise_totals
)

print("canonical_common_workload_audit=PASS", flush=True)
print("operator_oracle_mismatch_count=0", flush=True)

structure_audit_path.parent.mkdir(
    parents=True,
    exist_ok=False,
)

structure_audit_path.write_text(
    json.dumps(
        structure_report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

workload_audit_path.write_text(
    json.dumps(
        workload_report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

for runtime_dir in workload_root.glob("audit_runtime_*"):
    if runtime_dir.is_dir():
        shutil.rmtree(runtime_dir)

for runtime_dir in campaign_root.rglob("ckg_runtime"):
    if runtime_dir.is_dir():
        shutil.rmtree(runtime_dir)

assert not list(
    campaign_root.rglob("ckg_runtime")
)

assert not list(
    workload_root.glob("audit_runtime_*")
)

print("ephemeral_runtime_cleanup=PASS", flush=True)
PY

echo "canonical_materialization_and_audit=PASS"

echo
echo "=== 5. Freeze canonical campaign file manifest ==="

test -f "$CAMPAIGN_ROOT/campaign_spec.json"
test -f "$CAMPAIGN_ROOT/campaign_manifest.json"
test -f "$CAMPAIGN_ROOT/instances.csv"
test -f "$WORKLOAD_ROOT/common_workloads_manifest.json"

CAMPAIGN_FILE_COUNT="$(
  find "$CAMPAIGN_ROOT" \
    -type f |
    wc -l
)"

test "$CAMPAIGN_FILE_COUNT" -eq 134

INSTANCE_MANIFEST_COUNT="$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name manifest.json |
    wc -l
)"

OBJECTIVES_FILE_COUNT="$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name objectives.yaml |
    wc -l
)"

WORKLOAD_FILE_COUNT="$(
  find "$WORKLOAD_ROOT" \
    -maxdepth 1 \
    -type f \
    -name 'replication_*_seed_*.json' |
    wc -l
)"

test "$INSTANCE_MANIFEST_COUNT" -eq 60
test "$OBJECTIVES_FILE_COUNT" -eq 60
test "$WORKLOAD_FILE_COUNT" -eq 10

test -z "$(
  find "$CAMPAIGN_ROOT" \
    -type d \
    \( \
      -name ckg_runtime \
      -o -name 'audit_runtime_*' \
    \) \
    -print \
    -quit
)"

(
  find "$CAMPAIGN_ROOT" \
    -type f \
    -print0 |
    sort -z |
    xargs -0 sha256sum
) > "$CAMPAIGN_FILE_MANIFEST"

test "$(
  wc -l < "$CAMPAIGN_FILE_MANIFEST"
)" -eq 134

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

CAMPAIGN_FILE_MANIFEST_SHA="$(
  sha256sum "$CAMPAIGN_FILE_MANIFEST" |
    awk '{print $1}'
)"

echo "canonical_campaign_file_manifest=PASS"
echo "canonical_campaign_file_count=$CAMPAIGN_FILE_COUNT"
echo "instance_manifest_count=$INSTANCE_MANIFEST_COUNT"
echo "objectives_file_count=$OBJECTIVES_FILE_COUNT"
echo "common_workload_file_count=$WORKLOAD_FILE_COUNT"
echo "canonical_campaign_file_manifest_sha256=$CAMPAIGN_FILE_MANIFEST_SHA"

echo
echo "=== 6. Write canonical materialization provenance ==="

export AUDIT_ROOT
export CAMPAIGN_FILE_MANIFEST
export MATERIALIZATION_REPORT
export MATERIALIZATION_SUMMARY
export READINESS_REPORT
export EXPECTED_READINESS_REPORT_SHA
export EXPECTED_PATCH_SHA
export CAMPAIGN_FILE_COUNT
export INSTANCE_MANIFEST_COUNT
export OBJECTIVES_FILE_COUNT
export WORKLOAD_FILE_COUNT
export CAMPAIGN_FILE_MANIFEST_SHA

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path

from backend.harness.sensitivity_execution.tools.objective_count_noise_operators_v2 import (
    NOISE_CLASS_ORDER,
    OPERATOR_REGISTRY_VERSION,
    build_noise_schedule,
)


def read_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


campaign_root = Path(os.environ["CAMPAIGN_ROOT"])
workload_root = Path(os.environ["WORKLOAD_ROOT"])
structure_audit_path = Path(os.environ["STRUCTURE_AUDIT"])
workload_audit_path = Path(os.environ["WORKLOAD_AUDIT"])
file_manifest_path = Path(os.environ["CAMPAIGN_FILE_MANIFEST"])
report_path = Path(os.environ["MATERIALIZATION_REPORT"])
summary_path = Path(os.environ["MATERIALIZATION_SUMMARY"])
readiness_path = Path(os.environ["READINESS_REPORT"])

campaign_manifest = read_json(
    campaign_root / "campaign_manifest.json"
)

campaign_spec = read_json(
    campaign_root / "campaign_spec.json"
)

common_manifest = read_json(
    workload_root / "common_workloads_manifest.json"
)

structure_audit = read_json(
    structure_audit_path
)

workload_audit = read_json(
    workload_audit_path
)

with (campaign_root / "instances.csv").open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    instance_rows = [
        dict(row)
        for row in csv.DictReader(handle)
    ]

levels = [1, 2, 5, 10, 20, 50]
seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

assert len(instance_rows) == 60

assert {
    int(row["factor_level"])
    for row in instance_rows
} == set(levels)

assert {
    int(row["replication_index"])
    for row in instance_rows
} == set(range(10))

for level in levels:
    rows = [
        row
        for row in instance_rows
        if int(row["factor_level"]) == level
    ]

    assert len(rows) == 10

    assert [
        int(row["seed"])
        for row in rows
    ] == seeds

for replication_index, seed in enumerate(seeds):
    rows = [
        row
        for row in instance_rows
        if int(row["replication_index"]) == replication_index
    ]

    assert len(rows) == 6
    assert {int(row["seed"]) for row in rows} == {seed}
    assert len(
        {
            row["selected_objective_shape_digest"]
            for row in rows
        }
    ) == 1

schedule_rows = []

for replication_index, seed in enumerate(seeds):
    schedule = build_noise_schedule(seed)

    schedule_rows.append(
        {
            "replication_index": replication_index,
            "seed": seed,
            "noise_positions": list(
                schedule.noise_positions
            ),
            "redundant_contribution_position": (
                schedule.redundant_contribution_position
            ),
            "redundant_source_step_index": (
                schedule.redundant_source_step_index
            ),
        }
    )

assert schedule_rows[2] == {
    "replication_index": 2,
    "seed": 1198202409,
    "noise_positions": [
        1,
        8,
        9,
        13,
        14,
        17,
        29,
        32,
    ],
    "redundant_contribution_position": 8,
    "redundant_source_step_index": 7,
}

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "canonical-materialization-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "structure_and_common_workloads_materialized"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "feature_commit": os.environ[
        "EXPECTED_FEATURE_COMMIT"
    ],
    "implementation_patch_sha256": os.environ[
        "EXPECTED_PATCH_SHA"
    ],
    "readiness_evidence": {
        "report_name": readiness_path.name,
        "report_sha256": os.environ[
            "EXPECTED_READINESS_REPORT_SHA"
        ],
        "status": (
            "sa5_objective_count_v2_"
            "canonical_materialization_ready"
        ),
    },
    "canonical_campaign": {
        "campaign_id": campaign_manifest["campaign_id"],
        "path": campaign_root.as_posix(),
        "campaign_generator_version": (
            campaign_manifest[
                "campaign_generator_version"
            ]
        ),
        "structural_generator_version": (
            campaign_manifest[
                "structural_generator_version"
            ]
        ),
        "levels": campaign_manifest["levels"],
        "seeds": campaign_manifest["seeds"],
        "level_count": campaign_manifest[
            "level_count"
        ],
        "replication_count": campaign_manifest[
            "replication_count"
        ],
        "expected_instance_count": (
            campaign_manifest[
                "expected_instance_count"
            ]
        ),
        "realised_instance_count": (
            campaign_manifest[
                "realised_instance_count"
            ]
        ),
        "selected_objective_index": (
            campaign_manifest[
                "selected_objective_index"
            ]
        ),
        "session_support_policy": (
            campaign_manifest[
                "session_support_policy"
            ]
        ),
        "campaign_spec_digest": (
            campaign_manifest[
                "campaign_spec_digest"
            ]
        ),
        "campaign_digest": (
            campaign_manifest[
                "campaign_digest"
            ]
        ),
        "campaign_file_count": int(
            os.environ["CAMPAIGN_FILE_COUNT"]
        ),
        "instance_manifest_count": int(
            os.environ[
                "INSTANCE_MANIFEST_COUNT"
            ]
        ),
        "objectives_file_count": int(
            os.environ["OBJECTIVES_FILE_COUNT"]
        ),
        "file_manifest_path": (
            file_manifest_path.as_posix()
        ),
        "file_manifest_sha256": os.environ[
            "CAMPAIGN_FILE_MANIFEST_SHA"
        ],
    },
    "common_workloads": {
        "path": workload_root.as_posix(),
        "workload_count": common_manifest[
            "workload_count"
        ],
        "workload_file_count": int(
            os.environ["WORKLOAD_FILE_COUNT"]
        ),
        "workload_length": common_manifest[
            "workload_length"
        ],
        "contributive_query_count_per_workload": (
            common_manifest[
                "contributive_query_count_per_workload"
            ]
        ),
        "non_contributive_query_count_per_workload": (
            common_manifest[
                "non_contributive_query_count_per_workload"
            ]
        ),
        "noise_class_order": common_manifest[
            "noise_class_order"
        ],
        "operator_registry_version": (
            common_manifest[
                "operator_registry_version"
            ]
        ),
    },
    "audits": {
        "structure": {
            "path": structure_audit_path.as_posix(),
            "status": structure_audit["status"],
            "instance_count": structure_audit[
                "instance_count"
            ],
            "failure_count": structure_audit[
                "failure_count"
            ],
            "sha256": sha256_file(
                structure_audit_path
            ),
        },
        "common_workloads": {
            "path": workload_audit_path.as_posix(),
            "status": workload_audit["status"],
            "workload_count": workload_audit[
                "workload_count"
            ],
            "failure_count": workload_audit[
                "failure_count"
            ],
            "operator_oracle_mismatch_count": sum(
                int(
                    item[
                        "operator_oracle_mismatch_count"
                    ]
                )
                for item in workload_audit[
                    "workload_reports"
                ]
            ),
            "stage10_noise_class_counts": (
                workload_audit[
                    "stage10_noise_class_counts"
                ]
            ),
            "sha256": sha256_file(
                workload_audit_path
            ),
        },
    },
    "registered_controls": {
        "constraints_per_objective": 8,
        "virtual_nodes_per_objective": 32,
        "requirement_sets_per_objective": 16,
        "membership_links_per_objective": 32,
        "membership_density": 0.5,
        "useful_virtual_nodes_per_objective": 24,
        "irrelevant_virtual_nodes_per_objective": 8,
        "workload_length": 32,
        "oracle_contributive_query_count": 24,
        "non_contributive_query_count": 8,
        "noise_ratio": 0.25,
        "noise_classes": list(
            NOISE_CLASS_ORDER
        ),
        "operator_registry_version": (
            OPERATOR_REGISTRY_VERSION
        ),
        "schedule_rows": schedule_rows,
    },
    "scientific_controls": {
        "canonical_campaign_materialization_performed": True,
        "canonical_campaign_generated": True,
        "canonical_structure_materialized": True,
        "canonical_common_workloads_materialized": True,
        "canonical_materialization_audit_evaluator_probe_performed": True,
        "canonical_stage10_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_execution_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "authorization": {
        "canonical_materialization_complete": True,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "scientific_execution_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "materialization_complete": True,
    "next_stage": (
        "review_and_merge_sa5_objective_count_"
        "stage10_materialization_then_audit_"
        "functional_execution_readiness"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

summary_lines = [
    "# SA5 objective-count Stage-10 canonical materialization",
    "",
    f"- Source commit: `{report['source_commit']}`",
    f"- Campaign: `{campaign_root.as_posix()}`",
    "- Levels: `1, 2, 5, 10, 20, 50`",
    "- Replications: `10`",
    "- Canonical instances: `60`",
    "- Common workloads: `10`",
    "- Steps per workload: `32`",
    "- Contributive steps: `24`",
    "- Non-contributive steps: `8`",
    "- Realised noise ratio: `0.25`",
    "- Structure audit: `PASS`",
    "- Common-workload audit: `PASS`",
    "- Operator-oracle mismatches: `0`",
    (
        "- Canonical file-manifest SHA-256: "
        f"`{report['canonical_campaign']['file_manifest_sha256']}`"
    ),
    "",
    "## Scientific control",
    "",
    "- Canonical materialization: performed",
    "- Formal Stage-10 functional execution: not performed",
    "- Timing execution: not performed",
    "- Bootstrap: not performed",
    "- Precision analysis: not performed",
    "- Manuscript modification: not performed",
    "",
    (
        "Next stage: review and merge the materialization, "
        "then audit functional-execution readiness."
    ),
    "",
]

summary_path.write_text(
    "\n".join(summary_lines),
    encoding="utf-8",
)

print("canonical_materialization_provenance=PASS")
print(f"materialization_report={report_path}")
print(f"materialization_report_sha256={sha256_file(report_path)}")
print(f"materialization_summary={summary_path}")
print(f"materialization_summary_sha256={sha256_file(summary_path)}")
PY

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-canonical-materialization-v1"
  and .status
    == "sa5_objective_count_stage10_structure_and_common_workloads_materialized"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .feature_commit
    == "2b3150b83108fe50e6f6db7841b9fa5076693628"
  and .implementation_patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .canonical_campaign.campaign_id
    == "objective_count_stage10_c8_nv32"
  and .canonical_campaign.levels
    == [1, 2, 5, 10, 20, 50]
  and (
    .canonical_campaign.seeds
    | length
  ) == 10
  and .canonical_campaign.level_count
    == 6
  and .canonical_campaign.replication_count
    == 10
  and .canonical_campaign.expected_instance_count
    == 60
  and .canonical_campaign.realised_instance_count
    == 60
  and .canonical_campaign.selected_objective_index
    == 0
  and .canonical_campaign.session_support_policy
    == "union_requirement_sets"
  and .canonical_campaign.campaign_file_count
    == 134
  and .canonical_campaign.instance_manifest_count
    == 60
  and .canonical_campaign.objectives_file_count
    == 60

  and .common_workloads.workload_count
    == 10
  and .common_workloads.workload_file_count
    == 10
  and .common_workloads.workload_length
    == 32
  and .common_workloads.contributive_query_count_per_workload
    == 24
  and .common_workloads.non_contributive_query_count_per_workload
    == 8
  and (
    .common_workloads.noise_class_order
    | length
  ) == 8

  and .audits.structure.status
    == "PASS"
  and .audits.structure.instance_count
    == 60
  and .audits.structure.failure_count
    == 0

  and .audits.common_workloads.status
    == "PASS"
  and .audits.common_workloads.workload_count
    == 10
  and .audits.common_workloads.failure_count
    == 0
  and .audits.common_workloads.operator_oracle_mismatch_count
    == 0

  and .scientific_controls.canonical_campaign_materialization_performed
    == true
  and .scientific_controls.canonical_campaign_generated
    == true
  and .scientific_controls.canonical_structure_materialized
    == true
  and .scientific_controls.canonical_common_workloads_materialized
    == true
  and .scientific_controls.canonical_materialization_audit_evaluator_probe_performed
    == true
  and .scientific_controls.canonical_stage10_functional_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .authorization.canonical_materialization_complete
    == true
  and .authorization.functional_execution_authorized
    == false
  and .authorization.scientific_execution_authorized
    == false

  and .blocker_count == 0
  and .materialization_complete == true
  and .next_stage
    == "review_and_merge_sa5_objective_count_stage10_materialization_then_audit_functional_execution_readiness"
' "$MATERIALIZATION_REPORT" >/dev/null

echo "canonical_materialization_report_validation=PASS"

echo
echo "=== 7. Exact generated scope gate ==="

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/campaign_files.txt" \
  "$TMP_ROOT/audit_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_generated_files.txt"

test "$(
  wc -l < "$TMP_ROOT/campaign_files.txt"
)" -eq 134

test "$(
  wc -l < "$TMP_ROOT/audit_files.txt"
)" -eq 3

test "$(
  wc -l < "$TMP_ROOT/planning_files.txt"
)" -eq 2

test "$(
  wc -l < "$TMP_ROOT/expected_generated_files.txt"
)" -eq 139

git status \
  --porcelain |
  awk '{print $2}' |
  sort > "$TMP_ROOT/actual_generated_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/actual_generated_files.txt"

echo "generated_scope_gate=PASS"
echo "canonical_campaign_file_count=134"
echo "audit_file_count=3"
echo "planning_file_count=2"
echo "total_generated_file_count=139"

echo
echo "=== 8. Repository and scientific-control gate before commit ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

sha256sum \
  -c \
  "$TMP_ROOT/implementation_sha256sums.txt" \
  >/dev/null

verify_sha "$READINESS_REPORT" "$EXPECTED_READINESS_REPORT_SHA"
verify_sha "$READINESS_SURFACE" "$EXPECTED_READINESS_SURFACE_SHA"

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"

verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

echo "precommit_integrity_gate=PASS"
echo "canonical_campaign_generated=true"
echo "canonical_materialization_audit_evaluator_probe_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 9. Stage exact canonical materialization ==="

git add -- \
  "$CAMPAIGN_ROOT" \
  "$AUDIT_ROOT" \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY"

git diff \
  --cached \
  --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/staged_files.txt"

STAGED_FILE_COUNT="$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)"

test "$STAGED_FILE_COUNT" -eq 139

echo "materialization_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"

echo
echo "=== 10. Commit canonical materialization ==="

git commit \
  -m "chore(experiments): materialize SA5 objective-count Stage-10 inputs"

COMMIT="$(
  git rev-parse HEAD
)"

test "$COMMIT" != "$EXPECTED_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "materialization_commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 11. Push materialization branch ==="

git push \
  -u \
  origin \
  "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "materialization_push=PASS"

echo
echo "=== 12. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Materialize SA5 objective-count Stage-10 inputs" \
    --body-file - <<EOF
## Scope

Materialize the preregistered SA5 objective-count Stage-10 canonical inputs from merged commit \`$EXPECTED_HEAD\`.

- 6 objective-count levels: 1, 2, 5, 10, 20, 50
- 10 fixed replications
- 60 canonical structural instances
- 10 common workloads
- 32 steps per workload
- 24 contributive and 8 non-contributive steps
- one occurrence of each registered noise class per replication

## Validation

- structure audit: PASS
- common-workload audit: PASS
- operator-oracle mismatches: 0
- campaign file count: 134
- complete committed scope: 139 files
- implementation patch SHA-256: \`$EXPECTED_PATCH_SHA\`
- readiness report SHA-256: \`$EXPECTED_READINESS_REPORT_SHA\`

## Scientific control

This PR materializes inputs only. It does not perform the formal Stage-10 functional campaign, timing execution, bootstrap, precision analysis, or manuscript integration.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 13. Verify pull-request identity and scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,isDraft,headRefOid,headRefName,baseRefName,title,files
)"

jq -e \
  --arg commit "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $commit
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
    and (.files | length) == 139
  ' <<<"$PR_DATA" >/dev/null

jq -r '.files[].path' <<<"$PR_DATA" |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 14. Final state ==="

MATERIALIZATION_REPORT_SHA="$(
  sha256sum "$MATERIALIZATION_REPORT" |
    awk '{print $1}'
)"

MATERIALIZATION_SUMMARY_SHA="$(
  sha256sum "$MATERIALIZATION_SUMMARY" |
    awk '{print $1}'
)"

echo "sa5_objective_count_stage10_materialization=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "canonical_campaign_root=$CAMPAIGN_ROOT"
echo "canonical_campaign_file_count=134"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"
echo "total_generated_file_count=139"

echo "materialization_report=$MATERIALIZATION_REPORT"
echo "materialization_report_sha256=$MATERIALIZATION_REPORT_SHA"
echo "materialization_summary=$MATERIALIZATION_SUMMARY"
echo "materialization_summary_sha256=$MATERIALIZATION_SUMMARY_SHA"
echo "canonical_campaign_file_manifest_sha256=$CAMPAIGN_FILE_MANIFEST_SHA"

echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"
echo "blocker_count=0"
echo "materialization_complete=true"

echo "canonical_campaign_generated=true"
echo "canonical_campaign_materialization_performed=true"
echo "canonical_materialization_audit_evaluator_probe_performed=true"

echo "functional_execution_authorized=false"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_materialization"

git status --short --branch
git log --oneline --decorate -5
