#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BRANCH="paper/analyze-virtual-node-count-stage10-precision-20260802T175624Z"
EXPECTED_HEAD="f4b270c4092905d721476015f384c46b864d8182"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis"

OBSERVATIONS="$PRECISION_ROOT/stage10_measurement_observations.csv"
ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"
ANALYZER_LOG="$PRECISION_ROOT/analyzer.log"

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$OBSERVATIONS"
test -f "$ADAPTER"
test -f "$INPUT_MANIFEST"
test -f "$ANALYZER_LOG"

echo "recovery_gate=PASS"
echo "precision_analysis_successful=false"
echo "analyzer_rerun_performed=false"

echo
echo "=== 2. Generated adapter header ==="

"$PYTHON" - "$OBSERVATIONS" <<'PY'
from __future__ import annotations

import csv
import sys
from pathlib import Path

path = Path(sys.argv[1])

with path.open(
    "r",
    encoding="utf-8",
    newline="",
) as stream:
    reader = csv.DictReader(stream)
    first = next(reader)

print(
    "generated_columns="
    + ",".join(reader.fieldnames or ())
)

print(
    "generated_first_row_selected="
    + repr(
        {
            key: first.get(key)
            for key in (
                "phase",
                "replication_index",
                "seed",
                "factor_level",
                "step_index",
                "wall_latency_ms",
            )
        }
    )
)
PY

echo
echo "=== 3. Functions referencing the missing field ==="

"$PYTHON" - "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

needle = "formal_replication_index"
selected = []

for node in ast.walk(tree):
    if not isinstance(
        node,
        (ast.FunctionDef, ast.AsyncFunctionDef),
    ):
        continue

    segment = ast.get_source_segment(
        source,
        node,
    ) or ""

    if needle in segment:
        selected.append(
            (
                node.lineno,
                getattr(
                    node,
                    "end_lineno",
                    node.lineno,
                ),
                node.name,
                segment,
            )
        )

if not selected:
    raise SystemExit(
        "No function references formal_replication_index."
    )

selected.sort()

for start, end, name, segment in selected:
    print()
    print(
        f"--- function={name} "
        f"lines={start}-{end} ---"
    )
    print(segment)

print()
print(
    f"matching_function_count={len(selected)}"
)
PY

echo
echo "=== 4. All literal observation-field names ==="

"$PYTHON" - "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

target_functions = []

for node in ast.walk(tree):
    if not isinstance(node, ast.FunctionDef):
        continue

    segment = ast.get_source_segment(
        source,
        node,
    ) or ""

    if "formal_replication_index" in segment:
        target_functions.append(node)

fields: set[str] = set()

for function in target_functions:
    for node in ast.walk(function):
        if not isinstance(node, ast.Subscript):
            continue

        slice_node = node.slice

        if (
            isinstance(slice_node, ast.Constant)
            and isinstance(slice_node.value, str)
        ):
            fields.add(slice_node.value)

print(
    "literal_subscript_fields="
    + ",".join(sorted(fields))
)
PY

echo
echo "=== 5. Compatible CSV precedents ==="

mapfile -t PRECEDENTS < <(
  grep -RIl \
    --include='*.csv' \
    'formal_replication_index' \
    reports \
    experiments \
    2>/dev/null |
    sort |
    head -n 20
)

echo "compatible_csv_count=${#PRECEDENTS[@]}"

for FILE in "${PRECEDENTS[@]}"; do
  echo
  echo "--- precedent=$FILE ---"

  "$PYTHON" - "$FILE" <<'PY'
from __future__ import annotations

import csv
import sys
from pathlib import Path

path = Path(sys.argv[1])

with path.open(
    "r",
    encoding="utf-8",
    newline="",
) as stream:
    reader = csv.DictReader(stream)
    first = next(reader, None)

print(
    "columns="
    + ",".join(reader.fieldnames or ())
)

if first is not None:
    print(
        "first_row="
        + repr(first)
    )
PY
done

echo
echo "=== 6. Exact analyzer error context ==="

grep -n -B25 -A45 \
  -E \
'Invalid timing observation|formal_replication_index' \
  "$ANALYZER"

echo
echo "=== 7. Final state ==="

echo "precision_v2_row_schema_inspection=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "analyzer_rerun_performed=false"
echo "precision_analysis_successful=false"
echo "next_stage=repair_precision_input_schema_then_run_analyzer_once"

git status --short --branch
