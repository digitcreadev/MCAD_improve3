#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=33

BASE="paper/phase3-controlled-execution"
BRANCH="paper/implement-sa5-objective-count-v2-20260805T100615Z"

EXPECTED_BASE_HEAD="0674825017698f25562d43400ff4e72cb6484e2f"
EXPECTED_FEATURE_HEAD="2b3150b83108fe50e6f6db7841b9fa5076693628"
EXPECTED_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

AMENDMENT_003="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_noise_operator_and_redundancy_ordering_amendment.json"
EXPECTED_AMENDMENT_003_SHA="806d6e935d34d8c54e4b6cca21b996adbd2dd3bee5fb1615c8887845e7cfff82"

WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"
EXPECTED_WORKLOAD_SCHEMA_SHA="df4f868365594f629dc0b9d5946e6b5fd90ee16d759fce6bd0b0c34f8de81027"

V1_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
EXPECTED_V1_GENERATOR_SHA="556654c4286adaeb88ebc9dd70939df96d70d8e8ba94265cd1684b763e826788"

V1_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
EXPECTED_V1_FAMILY_SHA="e2389ca35cdfcff14dcb0ee940482a374470f32a49af5e70ddffcb685d8bfdb5"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"
CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_objective_count_v2_pr33.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #33 controlled merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"
  ACTUAL="$(sha256sum "$FILE" | awk '{print $1}')"
  test "$ACTUAL" = "$EXPECTED"
}

cat > "$TMP_ROOT/modified_files.txt" <<'EOF'
.github/workflows/phase3-regression.yml
backend/ckg/ckg_updater.py
backend/harness/sensitivity_execution/e3_contract.yaml
backend/harness/sensitivity_execution/execute_controlled_family.py
backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
backend/harness/sensitivity_execution/tests/test_workload_spec.py
backend/harness/sensitivity_execution/validate_e3_contract.py
backend/harness/sensitivity_execution/validate_workload_spec.py
backend/harness/sensitivity_generator/families/controlled_families.py
backend/harness/sensitivity_generator/tests/test_controlled_families.py
backend/mcad/models.py
backend/mcad/objectives.py
EOF

cat > "$TMP_ROOT/new_files.txt" <<'EOF'
backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
backend/harness/sensitivity_generator/families/objective_count_family_v2.py
backend/harness/sensitivity_generator/objective_count_generator_v2.py
backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
EOF

cat \
  "$TMP_ROOT/modified_files.txt" \
  "$TMP_ROOT/new_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/modified_files.txt")" -eq 13
test "$(wc -l < "$TMP_ROOT/new_files.txt")" -eq 12
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 25

cat > "$TMP_ROOT/final_sha256sums.txt" <<'EOF'
b9fc580f1e178da0f4701a427389a5b5f78055d16341fa16734c9e4889927560  .github/workflows/phase3-regression.yml
6faaa8b7dea5b682ac9ea6ecf3cf790ff6d7a4c5c56d105a52c4e7acf2ad739d  backend/ckg/ckg_updater.py
261a3883b070c739937e24245a47483ed904194e3ea0840bae788c2b5bcdea57  backend/harness/sensitivity_execution/e3_contract.yaml
dde835674506c5167aa4065146d494ab4a932837e392c28e099d09a176b8162d  backend/harness/sensitivity_execution/execute_controlled_family.py
835a5c8315f01582d9114b159fa874c8a4c30afcce234a43547227a2954ded48  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py
d869f5e839dc86546295deb9ccc66360b11d3ebd2bf43fbb3504737cdb885c77  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py
326bf6337fc58a0282f0f0b6a743a61873b2545b2532d2f21086f567b9409d5b  backend/harness/sensitivity_execution/tests/test_workload_spec.py
98d87e9ce01277bdeafd94eed4cab1516fb4bb871f378e2bf04ece4b0a0940a2  backend/harness/sensitivity_execution/validate_e3_contract.py
e725bedfff82a75708c2e889469fc0f8441619a98215addf059017297f974d1f  backend/harness/sensitivity_execution/validate_workload_spec.py
2bc6a431e18f4cd8cca646d8b47d19dc5a4e2cf5e120cfa466848fa6772420df  backend/harness/sensitivity_generator/families/controlled_families.py
cbfc114661cef0ddf673bd377c97e9a8a4d60521057da33c2e045613da86ce9b  backend/harness/sensitivity_generator/tests/test_controlled_families.py
a76fd8d752941cd9673cbb6dcfae227a3d1f1e7818d70d467868234e884e8b95  backend/mcad/models.py
9de16bdc0a03994d3e3eebd92a9036394801e0f4750d7698470dec663acaf8b4  backend/mcad/objectives.py
1dc1ffd9ca9dec985eb8d8fb998997958651a9aa2e5b51e4119d430004cd5c49  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py
35ef4af11bb2b0d3197895676d033d3abf92f01e42e7e8918b7bb9dea1f8307b  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py
2fd703d251ada566a84bdf4e73ace78a0a7f3163becf8a769ffb71a45bd1fa7d  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py
aec33a7e254a5e55a56c7962429f10f60c5fc23f009cc83d5742d39541087341  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py
b8aa28b16f78df5a5ba4acc71807818b39282925bea8f0f798fd24a82892b616  backend/harness/sensitivity_execution/tools/audit_objective_count_stage10_common_workloads_v2.py
63c1e7674b2861b7e3dbfcd9009e31cd2676f27d5d90eb5b27de30de6ead1e4e  backend/harness/sensitivity_execution/tools/audit_objective_count_structure_v2.py
de7ebaab3218d4f533ba83910015cdb45a7aff6479f62d3e0b653fceaed4b691  backend/harness/sensitivity_execution/tools/objective_count_noise_operators_v2.py
d9952914589f185a64bc7735331ba25e490656d822030fee5e73f5f51d1e35a5  backend/harness/sensitivity_execution/tools/prepare_objective_count_stage10_common_workloads_v2.py
7ed4a8756f7426739d4c8f4914d59a86eeef448491915bc23ef776ba8654b12f  backend/harness/sensitivity_generator/families/objective_count_family_v2.py
7fbbe99c0ea6c4d7505c8290c791ec8826a4d36b8f85c888543524a30cc03863  backend/harness/sensitivity_generator/objective_count_generator_v2.py
55a90bca7518c44a387976f7762d41fdedb6b0121563d9cb9789e7b2c7a0326f  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py
a8eb5d296c4e50c8468b3e51c6f8c0ece73231a2d294430403279eba6d3b13eb  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py
EOF

awk '{print $2}' "$TMP_ROOT/final_sha256sums.txt" |
  sort > "$TMP_ROOT/hash_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/hash_files.txt"

test "$(wc -l < "$TMP_ROOT/final_sha256sums.txt")" -eq 25

echo "=== 1. Exact local implementation gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(wc -l < "$TMP_ROOT/actual_files.txt")" -eq 25

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"
verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
FRAGMENT_SHA_BEFORE="$(sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}')"

echo "local_implementation_gate=PASS"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "changed_file_count=25"
echo "patch_sha256=$EXPECTED_PATCH_SHA"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Compile and revalidate exact implementation ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

mapfile -t PYTHON_FILES < <(
  grep -E '\.py$' "$TMP_ROOT/expected_files.txt"
)

"$PYTHON" -m py_compile "${PYTHON_FILES[@]}"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null

test -z "$(git status --porcelain)"

echo "pre_merge_compile_and_regression_gate=PASS"
echo "compiled_python_file_count=${#PYTHON_FILES[@]}"

echo
echo "=== 3. Pull-request identity and exact-scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Implement SA5 objective-count v2 materialization contract"
    and (.files | length) == 25
  ' <<<"$PR_DATA" >/dev/null

jq -r '.files[].path' <<<"$PR_DATA" |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 4. Wait for CI registration ==="

CHECKS='[]'
CHECK_COUNT=0

for ATTEMPT in $(seq 1 60); do
  CANDIDATE="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || true
  )"

  if jq -e 'type == "array"' \
    >/dev/null 2>&1 \
    <<<"$CANDIDATE"
  then
    CHECKS="$CANDIDATE"
    CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"
  else
    CHECKS='[]'
    CHECK_COUNT=0
  fi

  echo \
    "ci_registration_attempt=$ATTEMPT " \
    "check_count=$CHECK_COUNT"

  if [ "$CHECK_COUNT" -gt 0 ]; then
    break
  fi

  sleep 10
done

test "$CHECK_COUNT" -gt 0

echo "ci_registration_gate=PASS"
echo "check_count=$CHECK_COUNT"

echo
echo "=== 5. CI completion gate ==="

gh pr checks "$PR" \
  --repo "$REPO" \
  --watch \
  --interval 10

FINAL_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link
)"

test "$(jq 'length' <<<"$FINAL_CHECKS")" -gt 0

NON_PASS_COUNT="$(
  jq '
    [
      .[]
      | select(.bucket != "pass")
    ]
    | length
  ' <<<"$FINAL_CHECKS"
)"

test "$NON_PASS_COUNT" -eq 0

jq -r '
  .[]
  | [
      .name,
      .bucket,
      .state
    ]
  | @tsv
' <<<"$FINAL_CHECKS"

echo "sa5_objective_count_v2_ci=PASS"

echo
echo "=== 6. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 7. Merge PR #33 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 8. Update and validate base lineage ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 9. Post-merge implementation integrity gate ==="

while IFS= read -r FILE; do
  test -f "$FILE"
  git ls-files --error-unmatch "$FILE" >/dev/null
done < "$TMP_ROOT/expected_files.txt"

sha256sum -c "$TMP_ROOT/final_sha256sums.txt" >/dev/null

verify_sha "$PREREG" "$EXPECTED_PREREG_SHA"
verify_sha "$AMENDMENT_001" "$EXPECTED_AMENDMENT_001_SHA"
verify_sha "$AMENDMENT_002" "$EXPECTED_AMENDMENT_002_SHA"
verify_sha "$AMENDMENT_003" "$EXPECTED_AMENDMENT_003_SHA"
verify_sha "$WORKLOAD_SCHEMA" "$EXPECTED_WORKLOAD_SCHEMA_SHA"
verify_sha "$V1_GENERATOR" "$EXPECTED_V1_GENERATOR_SHA"
verify_sha "$V1_FAMILY" "$EXPECTED_V1_FAMILY_SHA"

"$PYTHON" -m py_compile "${PYTHON_FILES[@]}"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA_BEFORE"
test "$(sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}')" = "$FRAGMENT_SHA_BEFORE"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"
test -z "$(git status --porcelain)"

echo "post_merge_implementation_integrity_gate=PASS"
echo "final_patch_file_count=25"
echo "v1_generator_preserved=true"
echo "v1_family_preserved=true"
echo "workload_schema_preserved=true"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 10. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 11. Cleanup implementation branch ==="

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo "branch_cleanup_gate=PASS"

echo
echo "=== 12. Final state ==="

echo "sa5_objective_count_v2_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "patch_sha256=$EXPECTED_PATCH_SHA"

echo "final_new_file_count=12"
echo "final_modified_file_count=13"
echo "final_total_patch_file_count=25"

echo "structural_generator_version=mcad-sensitivity-e2.1-objective-count-v2"
echo "campaign_generator_version=mcad-sensitivity-e2.2-objective-count-v2"
echo "session_support_policy=union_requirement_sets"
echo "workload_length=32"
echo "oracle_contributive_query_count=24"
echo "non_contributive_query_count=8"

echo "v1_generator_preserved=true"
echo "v1_family_preserved=true"
echo "workload_schema_preserved=true"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "post_merge_materialization_readiness_audit_eligible=true"
echo "next_stage=audit_sa5_objective_count_v2_post_merge_materialization_readiness"

git status --short --branch
git log --oneline --decorate -6
