#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

SURFACE_ROOT="/workspaces/sa5_objective_count_v2_implementation_surface_20260804T211657Z"
IMPLEMENTATION_REPORT="$SURFACE_ROOT/sa5_objective_count_v2_implementation_surface.json"
EXPECTED_REPORT_SHA="3a5268fc56810719dc5532872a0b4d92fb43aec9f7f8dcbd90757f458c3e1866"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
E3_VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"
E3_CONTRACT="backend/harness/sensitivity_execution/e3_contract.yaml"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"

V1_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
V1_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

V1_E21="mcad-sensitivity-e2.1-objective-count-v1"
V1_E22="mcad-sensitivity-e2.2-objective-count-v1"
V2_E21="mcad-sensitivity-e2.1-objective-count-v2"
V2_E22="mcad-sensitivity-e2.2-objective-count-v2"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_objective_count_v2_binding_closure_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_v2_binding_closure.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_v2_binding_closure.txt"

trap 'echo "[ERROR] SA5 v2 binding-closure audit stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$IMPLEMENTATION_REPORT" \
  "$PREREG" \
  "$AMENDMENT" \
  "$EXECUTOR" \
  "$E3_VALIDATOR" \
  "$E3_CONTRACT" \
  "$PREREG_TEST" \
  "$V1_GENERATOR" \
  "$V1_FAMILY"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$IMPLEMENTATION_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_REPORT_SHA"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Confirm projected patch scope ==="

jq -e '
  .status
    == "sa5_objective_count_v2_implementation_surface_resolved"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .blockers == []
  and .implementation_strategy.new_file_count == 9
  and .implementation_strategy.modified_file_count == 4
  and .implementation_strategy.expected_total_patch_file_count == 13
  and .implementation_strategy.preserve_v1_module_bytes == true
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch"
' "$IMPLEMENTATION_REPORT" >/dev/null

echo "projected_patch_scope_gate=PASS"
echo "projected_new_file_count=9"
echo "projected_modified_file_count=4"
echo "projected_total_patch_file_count=13"

echo
echo "=== 3. Confirm known omitted binding surfaces ==="

grep -F "$V1_E21" \
  "$E3_VALIDATOR" >/dev/null

grep -F "$V1_E22" \
  "$E3_VALIDATOR" >/dev/null

grep -F \
  'CONTRACT_PATH = Path(__file__).with_name("e3_contract.yaml")' \
  "$E3_VALIDATOR" >/dev/null

grep -F "$V1_E21" \
  "$E3_CONTRACT" >/dev/null

grep -F "$V1_E22" \
  "$E3_CONTRACT" >/dev/null

grep -F \
  'SUPPORTED_GENERATOR_VERSION_PAIRS' \
  "$PREREG_TEST" >/dev/null

grep -F "$V1_GENERATOR" \
  /dev/null 2>/dev/null || true

echo "known_omitted_binding_surface_gate=PASS"
echo "validator_v1_binding_present=true"
echo "e3_contract_v1_binding_present=true"
echo "preregistration_test_active_profile_binding_present=true"

echo
echo "=== 4. Initialize detached closure audit ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export IMPLEMENTATION_REPORT
export REPORT
export SURFACE
export EXPECTED_HEAD
export V1_E21
export V1_E22
export V2_E21
export V2_E22
export V1_GENERATOR
export V1_FAMILY
export PREREG
export AMENDMENT

python3 - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any


root = Path(os.environ["ROOT"]).resolve()

implementation_report_path = Path(
    os.environ["IMPLEMENTATION_REPORT"]
).resolve()

report_path = Path(os.environ["REPORT"]).resolve()
surface_path = Path(os.environ["SURFACE"]).resolve()

source_commit = os.environ["EXPECTED_HEAD"]

v1_e21 = os.environ["V1_E21"]
v1_e22 = os.environ["V1_E22"]
v2_e21 = os.environ["V2_E21"]
v2_e22 = os.environ["V2_E22"]

implementation_report = json.loads(
    implementation_report_path.read_text(
        encoding="utf-8"
    )
)

planned_new_files = set(
    implementation_report[
        "implementation_strategy"
    ]["new_files"]
)

planned_modified_files = set(
    implementation_report[
        "implementation_strategy"
    ]["modified_files"]
)

preserved_v1_files = {
    os.environ["V1_GENERATOR"],
    os.environ["V1_FAMILY"],
    os.environ["PREREG"],
    os.environ["AMENDMENT"],
    (
        "backend/harness/sensitivity_generator/"
        "tests/test_objective_count_family.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_"
        "materialization_contract_amendment.py"
    ),
}

active_binding_paths = {
    (
        "backend/harness/sensitivity_execution/"
        "execute_controlled_family.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "validate_e3_contract.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "e3_contract.yaml"
    ),
    (
        "backend/harness/sensitivity_generator/"
        "families/controlled_families.py"
    ),
}

tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]

tokens = {
    "objective_count_v1_e21": v1_e21,
    "objective_count_v1_e22": v1_e22,
    "objective_count_v2_e21": v2_e21,
    "objective_count_v2_e22": v2_e22,
    "supported_executor_pairs": (
        "SUPPORTED_GENERATOR_VERSION_PAIRS"
    ),
    "supported_contract_profiles": (
        "SUPPORTED_FACTOR_GENERATOR_PROFILES"
    ),
    "factor_generator_profiles": (
        "factor_generator_profiles"
    ),
    "validate_e3_contract": (
        "validate_e3_contract"
    ),
}

hits: list[dict[str, Any]] = []
text_file_count = 0

for relative in tracked_files:
    path = root / relative

    try:
        text = path.read_text(
            encoding="utf-8"
        )
    except (
        UnicodeDecodeError,
        OSError,
    ):
        continue

    text_file_count += 1

    lines = text.splitlines()

    for line_number, line in enumerate(
        lines,
        start=1,
    ):
        matched_tokens = [
            name
            for name, token in tokens.items()
            if token in line
        ]

        if not matched_tokens:
            continue

        hits.append(
            {
                "path": relative.as_posix(),
                "line": line_number,
                "tokens": matched_tokens,
                "text": line.rstrip(),
            }
        )

version_hit_files = {
    hit["path"]
    for hit in hits
    if (
        "objective_count_v1_e21"
        in hit["tokens"]
        or
        "objective_count_v1_e22"
        in hit["tokens"]
    )
}

test_binding_files = {
    path
    for path in version_hit_files
    if (
        "/tests/" in path
        or path.startswith("tests/")
    )
}

contract_binding_files = {
    path
    for path in version_hit_files
    if (
        path.endswith((".yaml", ".yml"))
        or "validate_e3_contract" in path
    )
}

runtime_binding_files = {
    path
    for path in version_hit_files
    if (
        path.startswith(
            "backend/harness/"
            "sensitivity_execution/"
        )
        and "/tests/" not in path
        and not path.endswith((".yaml", ".yml"))
    )
}

additional_modified_candidates: set[str] = set()

for path in version_hit_files:
    if path in preserved_v1_files:
        continue

    if path in planned_modified_files:
        continue

    if (
        path in active_binding_paths
        or path in test_binding_files
        or path in contract_binding_files
        or path in runtime_binding_files
    ):
        additional_modified_candidates.add(
            path
        )

# Independently include known semantic coupling even if the exact
# version strings are split across multiple lines.
known_required_candidates = {
    (
        "backend/harness/sensitivity_execution/"
        "validate_e3_contract.py"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "e3_contract.yaml"
    ),
    (
        "backend/harness/sensitivity_execution/"
        "tests/test_objective_count_stage10_"
        "preregistration.py"
    ),
}

for path in known_required_candidates:
    if path not in planned_modified_files:
        additional_modified_candidates.add(path)

# Any test that imports or checks either active profile mapping must
# be reviewed even when it does not contain the literal version on
# the same line.
for hit in hits:
    path = hit["path"]

    if "/tests/" not in path:
        continue

    if (
        "supported_executor_pairs"
        in hit["tokens"]
        or
        "supported_contract_profiles"
        in hit["tokens"]
        or
        "factor_generator_profiles"
        in hit["tokens"]
        or
        "validate_e3_contract"
        in hit["tokens"]
    ):
        if (
            path not in planned_modified_files
            and path not in preserved_v1_files
        ):
            additional_modified_candidates.add(
                path
            )

revised_modified_files = (
    planned_modified_files
    | additional_modified_candidates
)

revised_total_patch_file_count = (
    len(planned_new_files)
    + len(revised_modified_files)
)

scope_complete = (
    len(additional_modified_candidates)
    == 0
)

if scope_complete:
    status = (
        "sa5_objective_count_v2_"
        "binding_closure_complete"
    )
    next_stage = (
        "author_sa5_objective_count_"
        "materialization_contract_v2_patch"
    )
else:
    status = (
        "sa5_objective_count_v2_"
        "projected_patch_scope_incomplete"
    )
    next_stage = (
        "revise_sa5_objective_count_v2_"
        "patch_scope_before_authoring"
    )

report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "binding-closure-audit-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "text_file_count": text_file_count,
    "tracked_file_count": len(
        tracked_files
    ),
    "projected_scope": {
        "new_files": sorted(
            planned_new_files
        ),
        "modified_files": sorted(
            planned_modified_files
        ),
        "new_file_count": len(
            planned_new_files
        ),
        "modified_file_count": len(
            planned_modified_files
        ),
        "total_patch_file_count": (
            len(planned_new_files)
            + len(planned_modified_files)
        ),
    },
    "binding_hits": hits,
    "binding_hit_file_count": len(
        {
            hit["path"]
            for hit in hits
        }
    ),
    "version_hit_files": sorted(
        version_hit_files
    ),
    "runtime_binding_files": sorted(
        runtime_binding_files
    ),
    "contract_binding_files": sorted(
        contract_binding_files
    ),
    "test_binding_files": sorted(
        test_binding_files
    ),
    "preserved_v1_files": sorted(
        preserved_v1_files
    ),
    "additional_modified_candidates": sorted(
        additional_modified_candidates
    ),
    "additional_modified_candidate_count": len(
        additional_modified_candidates
    ),
    "revised_scope": {
        "new_files": sorted(
            planned_new_files
        ),
        "modified_files": sorted(
            revised_modified_files
        ),
        "new_file_count": len(
            planned_new_files
        ),
        "modified_file_count": len(
            revised_modified_files
        ),
        "total_patch_file_count": (
            revised_total_patch_file_count
        ),
    },
    "scope_complete": scope_complete,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 BINDING-CLOSURE AUDIT",
    "=" * 88,
    f"source_commit={source_commit}",
    f"status={status}",
    (
        "projected_total_patch_file_count="
        f"{len(planned_new_files) + len(planned_modified_files)}"
    ),
    (
        "additional_modified_candidate_count="
        f"{len(additional_modified_candidates)}"
    ),
    (
        "revised_total_patch_file_count="
        f"{revised_total_patch_file_count}"
    ),
    (
        "scope_complete="
        f"{str(scope_complete).lower()}"
    ),
    "",
    "=== PROJECTED MODIFIED FILES ===",
    *sorted(planned_modified_files),
    "",
    "=== ADDITIONAL MODIFIED CANDIDATES ===",
]

if additional_modified_candidates:
    surface_lines.extend(
        sorted(additional_modified_candidates)
    )
else:
    surface_lines.append(
        "additional_modified_candidate_count=0"
    )

surface_lines.extend(
    [
        "",
        "=== PRESERVED V1 FILES ===",
        *sorted(preserved_v1_files),
        "",
        "=== EXACT BINDING HITS ===",
    ]
)

for hit in hits:
    surface_lines.append(
        (
            f"{hit['path']}:{hit['line']}: "
            f"[{','.join(hit['tokens'])}] "
            f"{hit['text']}"
        )
    )

surface_lines.extend(
    [
        "",
        "=== SCIENTIFIC CONTROLS ===",
        "canonical_campaign_generated=false",
        "campaign_materialization_performed=false",
        "functional_execution_performed=false",
        "timing_execution_performed=false",
        "bootstrap_execution_performed=false",
        "scientific_execution_performed=false",
        "manuscript_modified=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("binding_closure_projection=PASS")
print(f"status={status}")
print(
    "tracked_file_count="
    f"{len(tracked_files)}"
)
print(
    "text_file_count="
    f"{text_file_count}"
)
print(
    "binding_hit_file_count="
    f"{report['binding_hit_file_count']}"
)
print(
    "projected_modified_file_count="
    f"{len(planned_modified_files)}"
)
print(
    "additional_modified_candidate_count="
    f"{len(additional_modified_candidates)}"
)
print(
    "revised_modified_file_count="
    f"{len(revised_modified_files)}"
)
print(
    "revised_total_patch_file_count="
    f"{revised_total_patch_file_count}"
)
print(
    "scope_complete="
    f"{str(scope_complete).lower()}"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{hashlib.sha256(report_path.read_bytes()).hexdigest()}"
)
print(
    "surface_sha256="
    f"{hashlib.sha256(surface_path.read_bytes()).hexdigest()}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 5. Validate closure report ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-binding-closure-audit-v1"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .read_only == true
  and .projected_scope.new_file_count == 9
  and .projected_scope.modified_file_count == 4
  and .projected_scope.total_patch_file_count == 13
  and (
    .additional_modified_candidates
    | index(
        "backend/harness/sensitivity_execution/validate_e3_contract.py"
      )
  ) != null
  and (
    .additional_modified_candidates
    | index(
        "backend/harness/sensitivity_execution/e3_contract.yaml"
      )
  ) != null
  and (
    .additional_modified_candidates
    | index(
        "backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
      )
  ) != null
  and .additional_modified_candidate_count >= 3
  and .scope_complete == false
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false
  and .next_stage
    == "revise_sa5_objective_count_v2_patch_scope_before_authoring"
' "$REPORT" >/dev/null

echo "binding_closure_report_validation=PASS"

echo
echo "=== 6. Compact corrected scope ==="

jq '{
  status,
  source_commit,
  projected_scope,
  additional_modified_candidates,
  additional_modified_candidate_count,
  revised_scope,
  scope_complete,
  next_stage
}' "$REPORT"

echo
echo "=== 7. High-value binding surface ==="

grep -nE \
  '^(status=|projected_total|additional_modified|revised_total|scope_complete=|backend/|\\.github/|reports/|next_stage=)' \
  "$SURFACE" |
  head -n 500 || true

echo
echo "=== 8. Repository immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 9. Final state ==="

STATUS_VALUE="$(
  jq -r '.status' "$REPORT"
)"

ADDITIONAL_COUNT="$(
  jq '.additional_modified_candidate_count' "$REPORT"
)"

REVISED_TOTAL="$(
  jq '.revised_scope.total_patch_file_count' "$REPORT"
)"

NEXT_STAGE="$(
  jq -r '.next_stage' "$REPORT"
)"

echo "sa5_objective_count_v2_binding_closure_audit=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "status=$STATUS_VALUE"
echo "additional_modified_candidate_count=$ADDITIONAL_COUNT"
echo "revised_total_patch_file_count=$REVISED_TOTAL"
echo "scope_complete=false"
echo "report=$REPORT"
echo "surface=$SURFACE"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=$NEXT_STAGE"

git status --short --branch
