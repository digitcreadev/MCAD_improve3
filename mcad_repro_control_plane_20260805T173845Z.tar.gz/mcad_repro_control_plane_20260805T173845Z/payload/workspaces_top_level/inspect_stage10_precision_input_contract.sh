#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="f4b270c4092905d721476015f384c46b864d8182"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

TIMING_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/virtual_node_count_stage10_c4"

TIMING_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution/formal_timing_execution_report.json"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$TIMING_REPORT"

echo "repository_gate=PASS"

echo
echo "=== 2. Existing analyzer invocations and precedents ==="

grep -RIn \
  --exclude-dir='.git' \
  -E \
'analyze_clustered_timing_precision_v2\.py|--stage-size|--observations|intervals-csv' \
  backend \
  reports \
  experiments \
  2>/dev/null \
  | head -n 240 || true

echo
echo "=== 3. Analyzer functions handling inputs and outputs ==="

"$PYTHON" - "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
tree = ast.parse(source)

terms = (
    "observations",
    "timing_report",
    "intervals_csv",
    "report_json",
    "report_md",
    "dictreader",
    "csv.",
)

selected = []

for node in tree.body:
    if not isinstance(
        node,
        (ast.FunctionDef, ast.AsyncFunctionDef),
    ):
        continue

    segment = ast.get_source_segment(source, node) or ""
    lowered = segment.lower()

    if any(term in lowered for term in terms):
        selected.append(
            (
                node.lineno,
                getattr(node, "end_lineno", node.lineno),
                node.name,
                segment,
            )
        )

for start, end, name, segment in selected:
    print()
    print(
        f"--- function={name} "
        f"lines={start}-{end} ---"
    )
    print(segment)

print()
print(
    f"selected_function_count={len(selected)}"
)
PY

echo
echo "=== 4. Available Stage-10 observation files ==="

find "$TIMING_ROOT" \
  -mindepth 2 \
  -maxdepth 2 \
  -type f \
  -name 'timing_observations.csv' \
  -print \
  | sort

CSV_COUNT="$(
  find "$TIMING_ROOT" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    -name 'timing_observations.csv' \
    | wc -l \
    | tr -d ' '
)"

echo "timing_csv_count=$CSV_COUNT"
test "$CSV_COUNT" -eq 10

echo
echo "=== 5. Observation schema and timing-report linkage ==="

"$PYTHON" - \
  "$ROOT" \
  "$TIMING_ROOT" \
  "$TIMING_REPORT" <<'PY'
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
timing_root = root / sys.argv[2]
report_path = root / sys.argv[3]

csv_paths = sorted(
    timing_root.glob(
        "rep_*/timing_observations.csv"
    )
)

if len(csv_paths) != 10:
    raise SystemExit(
        f"Expected 10 CSV files, got {len(csv_paths)}."
    )

headers = []
row_counts = []

for path in csv_paths:
    with path.open(
        newline="",
        encoding="utf-8",
    ) as stream:
        reader = csv.DictReader(stream)
        headers.append(tuple(reader.fieldnames or ()))
        row_counts.append(sum(1 for _ in reader))

if len(set(headers)) != 1:
    raise SystemExit(
        "Timing CSV schemas are not identical."
    )

if row_counts != [660] * 10:
    raise SystemExit(
        f"Unexpected row counts: {row_counts}"
    )

report = json.loads(
    report_path.read_text(encoding="utf-8")
)

print(
    "observation_columns="
    + ",".join(headers[0])
)
print(f"per_replication_row_counts={row_counts}")
print(f"total_observation_rows={sum(row_counts)}")

print(
    "timing_report_top_level_keys="
    + ",".join(sorted(report))
)

replications = report.get("replications", [])

print(
    f"timing_report_replication_count="
    f"{len(replications)}"
)

if replications:
    print(
        "timing_report_replication_keys="
        + ",".join(
            sorted(replications[0])
        )
    )

print(
    "observation_schema_consistency=PASS"
)
print(
    "timing_report_linkage_inspection=PASS"
)
PY

echo
echo "=== 6. Final state ==="

echo "precision_input_contract_inspection=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_performed=false"
echo "next_stage=execute_stage10_clustered_precision_analysis_once"

git status --short --branch
