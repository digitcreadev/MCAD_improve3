#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"

DIAGNOSIS_ROOT="/workspaces/sa5_noise_operator_line456_diagnosis_20260804T232101Z"

DIAGNOSIS_REPORT="$DIAGNOSIS_ROOT/sa5_noise_operator_line456_diagnosis.json"
EXPECTED_DIAGNOSIS_REPORT_SHA="1389e242220906b675e9178da05f8776619c7ecfa8c033daf5a25202a9707432"

DIAGNOSIS_SURFACE="$DIAGNOSIS_ROOT/sa5_noise_operator_line456_diagnosis.txt"
EXPECTED_DIAGNOSIS_SURFACE_SHA="018cbba8e25d07dc4c62ea514742228e68f8e4a1de6e4aadb51af06b06b862aa"

SCOPE_REPORT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

SAT_WITNESS_TOOL="backend/harness/tools/find_sat_ablation_witness.py"
ARTICLE_RUNNER="experiments/article/run_article_experiments.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_existing_noise_production_hit_classification_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_existing_noise_production_hit_classification.json"
SURFACE="$OUTPUT_ROOT/sa5_existing_noise_production_hit_classification.txt"

trap 'echo "[ERROR] SA5 existing-noise-hit classification stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact read-only classification gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$DIAGNOSIS_REPORT" \
  "$DIAGNOSIS_SURFACE" \
  "$SCOPE_REPORT" \
  "$AMENDMENT_002" \
  "$SAT_WITNESS_TOOL" \
  "$ARTICLE_RUNNER" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$DIAGNOSIS_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_DIAGNOSIS_REPORT_SHA"

test "$(
  sha256sum "$DIAGNOSIS_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_DIAGNOSIS_SURFACE_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "sa5_noise_operator_line456_production_hits_confirmed"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .failed_python_line_number == 456
  and .failed_python_line
    == "assert production_operator_hits == []"
  and .production_hit_count == 2
  and .production_hit_file_count == 2
  and .production_hit_files
    == [
      "backend/harness/tools/find_sat_ablation_witness.py",
      "experiments/article/run_article_experiments.py"
    ]
  and .classification_complete == false
  and .v2_patch_authoring_authorized == false
  and .next_stage
    == "classify_existing_noise_class_production_hits_before_operator_contract_decision"
' "$DIAGNOSIS_REPORT" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_v2_post_capacity_scope_resolved"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .final_scope.new_file_count == 10
  and .final_scope.modified_file_count == 11
  and .final_scope.total_patch_file_count == 21
  and .scope_complete == true
' "$SCOPE_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "classification_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "diagnosed_production_hit_count=2"
echo "source_scope_file_count=21"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Compile classified source files ==="

python3 -m py_compile \
  "$SAT_WITNESS_TOOL" \
  "$ARTICLE_RUNNER"

echo "classified_source_compile_gate=PASS"

echo
echo "=== 3. Run exact semantic classification ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export DIAGNOSIS_REPORT
export SCOPE_REPORT
export AMENDMENT_002
export SAT_WITNESS_TOOL
export ARTICLE_RUNNER
export REPORT
export SURFACE

python3 - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any


root = Path(os.environ["ROOT"]).resolve()
source_commit = os.environ["EXPECTED_HEAD"]

diagnosis_path = Path(
    os.environ["DIAGNOSIS_REPORT"]
).resolve()

scope_path = Path(
    os.environ["SCOPE_REPORT"]
).resolve()

amendment_path = (
    root / os.environ["AMENDMENT_002"]
)

sat_tool_relative = os.environ[
    "SAT_WITNESS_TOOL"
]

article_runner_relative = os.environ[
    "ARTICLE_RUNNER"
]

sat_tool_path = root / sat_tool_relative
article_runner_path = (
    root / article_runner_relative
)

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(value, dict):
        raise AssertionError(
            f"JSON root is not an object: {path}"
        )

    return value


def top_level_function(
    path: Path,
    function_name: str,
) -> tuple[ast.FunctionDef, str]:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()

    tree = ast.parse(
        text,
        filename=str(path),
    )

    for node in tree.body:
        if (
            isinstance(node, ast.FunctionDef)
            and node.name == function_name
        ):
            start = int(node.lineno)
            end = int(
                getattr(node, "end_lineno", start)
            )

            return (
                node,
                "\n".join(
                    lines[start - 1 : end]
                ),
            )

    raise AssertionError(
        f"Missing function {function_name} in {path}"
    )


def enclosing_owner(
    tree: ast.AST,
    line_number: int,
) -> dict[str, Any] | None:
    candidates: list[
        tuple[int, ast.AST]
    ] = []

    for node in ast.walk(tree):
        if not isinstance(
            node,
            (
                ast.ClassDef,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            continue

        start = int(
            getattr(node, "lineno", 0)
        )

        end = int(
            getattr(
                node,
                "end_lineno",
                start,
            )
        )

        if start <= line_number <= end:
            candidates.append(
                (
                    end - start,
                    node,
                )
            )

    if not candidates:
        return None

    _, node = min(
        candidates,
        key=lambda item: item[0],
    )

    return {
        "kind": type(node).__name__,
        "name": getattr(
            node,
            "name",
            "<anonymous>",
        ),
        "start_line": int(node.lineno),
        "end_line": int(
            getattr(
                node,
                "end_lineno",
                node.lineno,
            )
        ),
    }


diagnosis = load_json(
    diagnosis_path
)

scope = load_json(
    scope_path
)

amendment = load_json(
    amendment_path
)

noise_classes = list(
    amendment[
        "revised_workload_contract"
    ]["noise_class_order"]
)

expected_noise_classes = [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

assert noise_classes == expected_noise_classes

assert diagnosis[
    "production_hit_files"
] == [
    sat_tool_relative,
    article_runner_relative,
]

assert scope[
    "final_scope"
]["total_patch_file_count"] == 21


# --------------------------------------------------------------
# Classify find_sat_ablation_witness.generate_mutations
# --------------------------------------------------------------

sat_function, sat_function_source = (
    top_level_function(
        sat_tool_path,
        "generate_mutations",
    )
)

sat_add_labels: list[str] = []

for node in ast.walk(sat_function):
    if not isinstance(node, ast.Call):
        continue

    if not (
        isinstance(node.func, ast.Name)
        and node.func.id == "add"
    ):
        continue

    if not node.args:
        continue

    first_argument = node.args[0]

    if (
        isinstance(first_argument, ast.Constant)
        and isinstance(
            first_argument.value,
            str,
        )
    ):
        sat_add_labels.append(
            first_argument.value
        )

sat_add_labels = sorted(
    set(sat_add_labels)
)

sat_exact_noise_operator_classes = sorted(
    set(sat_add_labels)
    & set(noise_classes)
)

assert sat_exact_noise_operator_classes == [
    "missing_cube"
]

sat_function_text_lower = (
    sat_function_source.lower()
)

sat_uses_deepcopy = (
    "deepcopy" in sat_function_text_lower
)

sat_returns_mutation_collection = (
    isinstance(
        sat_function.returns,
        (
            ast.Name,
            ast.Subscript,
            ast.BinOp,
            ast.Constant,
            ast.Attribute,
        ),
    )
    or any(
        isinstance(node, ast.Return)
        for node in ast.walk(sat_function)
    )
)

sat_classification = (
    "partial_query_mutation_precedent"
)


# --------------------------------------------------------------
# Classify run_article_experiments.objective_templates
# --------------------------------------------------------------

article_function, article_function_source = (
    top_level_function(
        article_runner_path,
        "objective_templates",
    )
)

article_role_values: list[str] = []
article_query_template_call_count = 0
article_add_call_count = 0

for node in ast.walk(article_function):
    if not isinstance(node, ast.Call):
        continue

    if (
        isinstance(node.func, ast.Name)
        and node.func.id == "QueryTemplate"
    ):
        article_query_template_call_count += 1

        for keyword in node.keywords:
            if (
                keyword.arg == "role"
                and isinstance(
                    keyword.value,
                    ast.Constant,
                )
                and isinstance(
                    keyword.value.value,
                    str,
                )
            ):
                article_role_values.append(
                    keyword.value.value
                )

    if (
        isinstance(node.func, ast.Name)
        and node.func.id == "add"
    ):
        article_add_call_count += 1

article_role_values = sorted(
    set(article_role_values)
)

article_exact_noise_template_classes = sorted(
    set(article_role_values)
    & set(noise_classes)
)

assert article_exact_noise_template_classes == [
    "wrong_measure"
]

assert article_query_template_call_count >= 1
assert article_add_call_count == 0

article_classification = (
    "label_only_query_template_precedent"
)


# --------------------------------------------------------------
# Recompute exact production string-constant closure
# --------------------------------------------------------------

tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]

production_constant_hits: list[
    dict[str, Any]
] = []

for relative in tracked_files:
    relative_text = relative.as_posix()

    if relative.suffix != ".py":
        continue

    if (
        "/tests/" in relative_text
        or relative_text.endswith(
            "validate_design.py"
        )
        or "/planning/" in relative_text
    ):
        continue

    path = root / relative

    try:
        text = path.read_text(
            encoding="utf-8"
        )

        tree = ast.parse(
            text,
            filename=str(path),
        )

    except (
        OSError,
        UnicodeDecodeError,
        SyntaxError,
    ):
        continue

    lines = text.splitlines()

    for node in ast.walk(tree):
        if not (
            isinstance(node, ast.Constant)
            and isinstance(node.value, str)
            and node.value in noise_classes
        ):
            continue

        line_number = int(
            getattr(node, "lineno", 0)
        )

        production_constant_hits.append(
            {
                "path": relative_text,
                "line": line_number,
                "noise_class": node.value,
                "line_text": (
                    lines[line_number - 1]
                    if line_number >= 1
                    else ""
                ),
                "enclosing_owner": (
                    enclosing_owner(
                        tree,
                        line_number,
                    )
                ),
            }
        )

production_constant_files = sorted(
    {
        hit["path"]
        for hit in production_constant_hits
    }
)

production_constant_classes = sorted(
    {
        hit["noise_class"]
        for hit in production_constant_hits
    }
)

assert production_constant_files == [
    sat_tool_relative,
    article_runner_relative,
]

assert production_constant_classes == [
    "missing_cube",
    "wrong_measure",
]


# --------------------------------------------------------------
# Determine whether the 21-file scope integrates either precedent
# --------------------------------------------------------------

final_scope_paths = (
    list(
        scope[
            "final_scope"
        ]["new_files"]
    )
    + list(
        scope[
            "final_scope"
        ]["modified_files"]
    )
)

integration_tokens = (
    "find_sat_ablation_witness",
    "run_article_experiments",
    "generate_mutations",
    "objective_templates",
)

scope_integration_hits: list[
    dict[str, Any]
] = []

for relative_text in final_scope_paths:
    path = root / relative_text

    if not path.is_file():
        continue

    try:
        text = path.read_text(
            encoding="utf-8"
        )
    except (
        OSError,
        UnicodeDecodeError,
    ):
        continue

    for line_number, line in enumerate(
        text.splitlines(),
        start=1,
    ):
        matched = [
            token
            for token in integration_tokens
            if token in line
        ]

        if matched:
            scope_integration_hits.append(
                {
                    "path": relative_text,
                    "line": line_number,
                    "tokens": matched,
                    "text": line.rstrip(),
                }
            )

assert scope_integration_hits == []


# --------------------------------------------------------------
# Revalidate redundancy-ordering failure
# --------------------------------------------------------------

workload = amendment[
    "revised_workload_contract"
]

rows = list(
    workload["counts_by_replication"]
)


def digest(value: str) -> str:
    return hashlib.sha256(
        value.encode("utf-8")
    ).hexdigest()


def selected_noise_positions(
    seed: int,
) -> list[int]:
    ranked = sorted(
        range(1, 33),
        key=lambda position: (
            digest(
                "mcad-sa5-noise-position-v2"
                f"|{seed}|{position}"
            ),
            position,
        ),
    )

    return sorted(ranked[:8])


def ranked_noise_classes(
    seed: int,
) -> list[str]:
    return sorted(
        noise_classes,
        key=lambda noise_class: (
            digest(
                "mcad-sa5-noise-class-v2"
                f"|{seed}|{noise_class}"
            ),
            noise_class,
        ),
    )


ordering_failures: list[
    dict[str, Any]
] = []

for row in rows:
    replication_index = int(
        row["replication_index"]
    )
    seed = int(row["seed"])

    positions = selected_noise_positions(
        seed
    )

    classes = ranked_noise_classes(
        seed
    )

    assignment = dict(
        zip(
            positions,
            classes,
            strict=True,
        )
    )

    redundant_positions = [
        position
        for position, noise_class
        in assignment.items()
        if noise_class
        == "redundant_contribution"
    ]

    assert len(redundant_positions) == 1

    redundant_position = (
        redundant_positions[0]
    )

    prior_contributive_positions = [
        position
        for position in range(
            1,
            redundant_position,
        )
        if position not in assignment
    ]

    if not prior_contributive_positions:
        ordering_failures.append(
            {
                "replication_index": (
                    replication_index
                ),
                "seed": seed,
                "redundant_contribution_position": (
                    redundant_position
                ),
                "prior_contributive_positions": [],
            }
        )

assert ordering_failures == [
    {
        "replication_index": 2,
        "seed": 1198202409,
        "redundant_contribution_position": 1,
        "prior_contributive_positions": [],
    }
]


# --------------------------------------------------------------
# Final classification
# --------------------------------------------------------------

exact_operator_classes = (
    sat_exact_noise_operator_classes
)

exact_template_label_classes = (
    article_exact_noise_template_classes
)

missing_exact_operator_classes = [
    noise_class
    for noise_class in noise_classes
    if noise_class
    not in exact_operator_classes
]

assert len(exact_operator_classes) == 1
assert len(missing_exact_operator_classes) == 7

authoritative_operator_suite_present = (
    set(exact_operator_classes)
    == set(noise_classes)
)

partial_reusable_operator_precedent_present = (
    "missing_cube"
    in exact_operator_classes
)

redundant_contribution_operator_present = (
    "redundant_contribution"
    in exact_operator_classes
)

wrong_measure_operator_present = (
    "wrong_measure"
    in exact_operator_classes
)

assert authoritative_operator_suite_present is False
assert partial_reusable_operator_precedent_present is True
assert redundant_contribution_operator_present is False
assert wrong_measure_operator_present is False

status = (
    "sa5_objective_count_v2_existing_"
    "noise_hits_classified_partial_"
    "operator_suite"
)

next_stage = (
    "preregister_sa5_objective_count_"
    "noise_operator_and_redundancy_"
    "ordering_amendment"
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-v2-"
        "existing-noise-hit-classification-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "source_hashes": {
        "diagnosis_report": (
            sha256_file(diagnosis_path)
        ),
        "scope_report": (
            sha256_file(scope_path)
        ),
        "capacity_amendment": (
            sha256_file(amendment_path)
        ),
        "sat_witness_tool": (
            sha256_file(sat_tool_path)
        ),
        "article_runner": (
            sha256_file(
                article_runner_path
            )
        ),
    },
    "source_scope": {
        "resolved_file_count": 21,
        "source_ownership_complete": True,
        "scope_integration_hits": (
            scope_integration_hits
        ),
        "existing_precedents_already_integrated": False,
    },
    "sat_witness_tool": {
        "path": sat_tool_relative,
        "function": "generate_mutations",
        "classification": (
            sat_classification
        ),
        "all_add_labels": (
            sat_add_labels
        ),
        "exact_noise_operator_classes": (
            exact_operator_classes
        ),
        "exact_noise_operator_class_count": (
            len(exact_operator_classes)
        ),
        "uses_deepcopy": (
            sat_uses_deepcopy
        ),
        "returns_mutation_collection": (
            sat_returns_mutation_collection
        ),
        "source": sat_function_source,
        "authoritative_for_sa5": False,
        "reuse_disposition": (
            "The missing_cube mutation mechanic may "
            "serve as a reviewed implementation "
            "precedent, but it is not an authoritative "
            "SA5 workload operator contract."
        ),
    },
    "article_runner": {
        "path": article_runner_relative,
        "function": "objective_templates",
        "classification": (
            article_classification
        ),
        "query_template_call_count": (
            article_query_template_call_count
        ),
        "role_values": (
            article_role_values
        ),
        "exact_noise_template_classes": (
            exact_template_label_classes
        ),
        "exact_noise_template_class_count": (
            len(
                exact_template_label_classes
            )
        ),
        "mutation_add_call_count": (
            article_add_call_count
        ),
        "source": article_function_source,
        "authoritative_for_sa5": False,
        "reuse_disposition": (
            "The wrong_measure role is a label and "
            "scenario precedent only; it does not "
            "define a query mutation operator."
        ),
    },
    "production_constant_closure": {
        "hit_count": len(
            production_constant_hits
        ),
        "files": (
            production_constant_files
        ),
        "classes": (
            production_constant_classes
        ),
        "hits": (
            production_constant_hits
        ),
    },
    "operator_suite": {
        "required_noise_classes": (
            noise_classes
        ),
        "exact_operator_classes": (
            exact_operator_classes
        ),
        "exact_operator_class_count": (
            len(exact_operator_classes)
        ),
        "template_label_only_classes": (
            exact_template_label_classes
        ),
        "missing_exact_operator_classes": (
            missing_exact_operator_classes
        ),
        "missing_exact_operator_class_count": (
            len(
                missing_exact_operator_classes
            )
        ),
        "authoritative_operator_suite_present": (
            authoritative_operator_suite_present
        ),
        "partial_reusable_operator_precedent_present": (
            partial_reusable_operator_precedent_present
        ),
        "wrong_measure_operator_present": (
            wrong_measure_operator_present
        ),
        "redundant_contribution_operator_present": (
            redundant_contribution_operator_present
        ),
    },
    "redundancy_ordering": {
        "failure_count": len(
            ordering_failures
        ),
        "failures": ordering_failures,
        "blocker_persists": True,
    },
    "classification_complete": True,
    "noise_operator_contract_amendment_required": True,
    "v2_source_scope_resolved": True,
    "v2_patch_authoring_authorized": False,
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT V2 EXISTING NOISE-HIT CLASSIFICATION",
    "=" * 92,
    f"source_commit={source_commit}",
    f"status={status}",
    "",
    "=== SAT WITNESS TOOL ===",
    f"path={sat_tool_relative}",
    "function=generate_mutations",
    (
        "classification="
        f"{sat_classification}"
    ),
    (
        "all_add_labels="
        + json.dumps(
            sat_add_labels,
            ensure_ascii=False,
        )
    ),
    (
        "exact_noise_operator_classes="
        + json.dumps(
            exact_operator_classes,
            ensure_ascii=False,
        )
    ),
    "authoritative_for_sa5=false",
    "",
    "=== ARTICLE RUNNER ===",
    f"path={article_runner_relative}",
    "function=objective_templates",
    (
        "classification="
        f"{article_classification}"
    ),
    (
        "exact_noise_template_classes="
        + json.dumps(
            exact_template_label_classes,
            ensure_ascii=False,
        )
    ),
    "mutation_add_call_count=0",
    "authoritative_for_sa5=false",
    "",
    "=== OPERATOR SUITE ===",
    (
        "required_noise_class_count="
        f"{len(noise_classes)}"
    ),
    (
        "exact_operator_class_count="
        f"{len(exact_operator_classes)}"
    ),
    (
        "missing_exact_operator_class_count="
        f"{len(missing_exact_operator_classes)}"
    ),
    (
        "missing_exact_operator_classes="
        + json.dumps(
            missing_exact_operator_classes,
            ensure_ascii=False,
        )
    ),
    "authoritative_operator_suite_present=false",
    "partial_reusable_operator_precedent_present=true",
    "wrong_measure_operator_present=false",
    "redundant_contribution_operator_present=false",
    "",
    "=== REDUNDANCY ORDERING ===",
    (
        "ordering_failure_count="
        f"{len(ordering_failures)}"
    ),
    "failure_replication_index=2",
    "failure_seed=1198202409",
    "redundant_contribution_position=1",
    "prior_contributive_step_count=0",
    "redundancy_ordering_blocker_persists=true",
    "",
    "=== EXACT GENERATE_MUTATIONS SOURCE ===",
    sat_function_source,
    "",
    "=== EXACT OBJECTIVE_TEMPLATES SOURCE ===",
    article_function_source,
    "",
    "=== DECISION ===",
    "classification_complete=true",
    "noise_operator_contract_amendment_required=true",
    "v2_source_scope_resolved=true",
    "v2_patch_authoring_authorized=false",
    "canonical_campaign_materialization_authorized=false",
    "canonical_campaign_generated=false",
    "scientific_execution_performed=false",
    f"next_stage={next_stage}",
    "",
]

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("existing_noise_hit_classification=PASS")
print(f"status={status}")
print(
    "sat_witness_classification="
    f"{sat_classification}"
)
print(
    "article_runner_classification="
    f"{article_classification}"
)
print(
    "exact_operator_class_count="
    f"{len(exact_operator_classes)}"
)
print(
    "exact_operator_classes="
    + ",".join(exact_operator_classes)
)
print(
    "template_label_only_classes="
    + ",".join(
        exact_template_label_classes
    )
)
print(
    "missing_exact_operator_class_count="
    f"{len(missing_exact_operator_classes)}"
)
print(
    "authoritative_operator_suite_present=false"
)
print(
    "partial_reusable_operator_precedent_present=true"
)
print(
    "redundant_contribution_operator_present=false"
)
print(
    "redundancy_ordering_failure_count="
    f"{len(ordering_failures)}"
)
print(
    "noise_operator_contract_amendment_required=true"
)
print(
    "classification_complete=true"
)
print(
    "v2_patch_authoring_authorized=false"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate classification report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-v2-existing-noise-hit-classification-v1"
  and .status
    == "sa5_objective_count_v2_existing_noise_hits_classified_partial_operator_suite"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .read_only == true

  and .source_scope.resolved_file_count == 21
  and .source_scope.source_ownership_complete == true
  and .source_scope.existing_precedents_already_integrated
    == false
  and .source_scope.scope_integration_hits == []

  and .sat_witness_tool.classification
    == "partial_query_mutation_precedent"
  and .sat_witness_tool.exact_noise_operator_classes
    == ["missing_cube"]
  and .sat_witness_tool.exact_noise_operator_class_count
    == 1
  and .sat_witness_tool.authoritative_for_sa5
    == false

  and .article_runner.classification
    == "label_only_query_template_precedent"
  and .article_runner.exact_noise_template_classes
    == ["wrong_measure"]
  and .article_runner.exact_noise_template_class_count
    == 1
  and .article_runner.mutation_add_call_count
    == 0
  and .article_runner.authoritative_for_sa5
    == false

  and .production_constant_closure.files
    == [
      "backend/harness/tools/find_sat_ablation_witness.py",
      "experiments/article/run_article_experiments.py"
    ]
  and .production_constant_closure.classes
    == [
      "missing_cube",
      "wrong_measure"
    ]

  and .operator_suite.exact_operator_classes
    == ["missing_cube"]
  and .operator_suite.exact_operator_class_count
    == 1
  and .operator_suite.template_label_only_classes
    == ["wrong_measure"]
  and .operator_suite.missing_exact_operator_class_count
    == 7
  and .operator_suite.authoritative_operator_suite_present
    == false
  and .operator_suite.partial_reusable_operator_precedent_present
    == true
  and .operator_suite.wrong_measure_operator_present
    == false
  and .operator_suite.redundant_contribution_operator_present
    == false

  and .redundancy_ordering.failure_count == 1
  and .redundancy_ordering.failures[0].replication_index
    == 2
  and .redundancy_ordering.failures[0].seed
    == 1198202409
  and .redundancy_ordering.failures[0].redundant_contribution_position
    == 1
  and .redundancy_ordering.failures[0].prior_contributive_positions
    == []
  and .redundancy_ordering.blocker_persists
    == true

  and .classification_complete == true
  and .noise_operator_contract_amendment_required
    == true
  and .v2_source_scope_resolved == true
  and .v2_patch_authoring_authorized == false

  and .canonical_campaign_materialization_authorized
    == false
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false

  and .next_stage
    == "preregister_sa5_objective_count_noise_operator_and_redundancy_ordering_amendment"
' "$REPORT" >/dev/null

echo "classification_report_validation=PASS"

echo
echo "=== 5. Compact classification decision ==="

jq '{
  status,
  source_commit,
  source_scope,
  sat_witness_tool: {
    path,
    function,
    classification,
    all_add_labels,
    exact_noise_operator_classes,
    authoritative_for_sa5,
    reuse_disposition
  },
  article_runner: {
    path,
    function,
    classification,
    exact_noise_template_classes,
    mutation_add_call_count,
    authoritative_for_sa5,
    reuse_disposition
  },
  operator_suite,
  redundancy_ordering,
  classification_complete,
  noise_operator_contract_amendment_required,
  v2_patch_authoring_authorized,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value classification surface ==="

grep -nE \
  '^(status=|path=|function=|classification=|all_add_labels=|exact_noise|mutation_add|authoritative_|required_noise|missing_exact|partial_reusable|wrong_measure_operator|redundant_contribution_operator|ordering_failure|failure_|prior_contributive|redundancy_ordering|noise_operator_contract|v2_patch|next_stage=)' \
  "$SURFACE" |
  head -n 300 || true

echo
echo "=== 7. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$DIAGNOSIS_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_DIAGNOSIS_REPORT_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_existing_noise_production_hit_classification=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"

echo "sat_witness_classification=partial_query_mutation_precedent"
echo "article_runner_classification=label_only_query_template_precedent"

echo "exact_operator_class_count=1"
echo "exact_operator_classes=missing_cube"
echo "template_label_only_classes=wrong_measure"
echo "missing_exact_operator_class_count=7"

echo "authoritative_operator_suite_present=false"
echo "partial_reusable_operator_precedent_present=true"
echo "redundant_contribution_operator_present=false"
echo "redundancy_ordering_failure_count=1"

echo "classification_complete=true"
echo "noise_operator_contract_amendment_required=true"
echo "v2_patch_authoring_authorized=false"

echo "canonical_campaign_materialization_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo "next_stage=preregister_sa5_objective_count_noise_operator_and_redundancy_ordering_amendment"

git status --short --branch
