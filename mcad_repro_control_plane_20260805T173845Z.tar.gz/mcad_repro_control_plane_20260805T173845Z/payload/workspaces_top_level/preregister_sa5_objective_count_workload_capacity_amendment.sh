#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT_001="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_001_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"

AMENDMENT_002_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py"

PREREG_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py"
AMENDMENT_001_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"

CLASSIFICATION_REPORT="/workspaces/sa5_objective_count_v2_binding_candidate_classification_20260804T223518Z/sa5_objective_count_v2_binding_candidate_classification.json"
EXPECTED_CLASSIFICATION_REPORT_SHA="7cbd688bfe149b2a21d8306ccadb4534da890f3d2608725f2c74e540a05cff36"

CAPACITY_REPORT="/workspaces/sa5_objective_count_workload_contribution_capacity_20260804T224333Z/sa5_objective_count_workload_contribution_capacity.json"
EXPECTED_CAPACITY_REPORT_SHA="ee16b7c41d5c02bad6e3f8a525f5d59283f3ffce9acb365d30dfce6abe469a98"

CAPACITY_SURFACE="/workspaces/sa5_objective_count_workload_contribution_capacity_20260804T224333Z/sa5_objective_count_workload_contribution_capacity.txt"
EXPECTED_CAPACITY_SURFACE_SHA="5a6fdb2cacf9c76243ee235125eed7a541f77231b5faef194abbf070f8ad45ab"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

TARGET_E21_VERSION="mcad-sensitivity-e2.1-objective-count-v2"
TARGET_E22_VERSION="mcad-sensitivity-e2.2-objective-count-v2"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-sa5-objective-count-workload-capacity-amendment-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_capacity_amendment.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 workload-capacity amendment stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Capacity-amendment preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$PREREG_TEST" \
  "$AMENDMENT_001_TEST" \
  "$CLASSIFICATION_REPORT" \
  "$CAPACITY_REPORT" \
  "$CAPACITY_SURFACE" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$CLASSIFICATION_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_CLASSIFICATION_REPORT_SHA"

test "$(
  sha256sum "$CAPACITY_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_CAPACITY_REPORT_SHA"

test "$(
  sha256sum "$CAPACITY_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_CAPACITY_SURFACE_SHA"

test ! -e "$AMENDMENT_002"
test ! -e "$AMENDMENT_002_TEST"
test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "sa5_objective_count_workload_contribution_capacity_incompatible"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .preregistered_contract.workload_length == 40
  and .preregistered_contract.non_contributive_query_count == 10
  and .preregistered_contract.oracle_contributive_query_count == 30
  and .capacity_proof.useful_union_capacity == 24
  and .capacity_proof.evaluator_support_capacity == 16
  and .capacity_proof.useful_union_deficit == 6
  and .capacity_proof.evaluator_support_deficit == 14
  and .capacity_proof.contract_feasible_under_useful_union_semantics
    == false
  and .capacity_proof.contract_feasible_under_current_evaluator_semantics
    == false
  and .v2_patch_authoring_authorized == false
  and .next_stage
    == "preregister_sa5_objective_count_workload_contribution_capacity_amendment"
' "$CAPACITY_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "capacity_amendment_preflight_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "capacity_report_sha256=$EXPECTED_CAPACITY_REPORT_SHA"
echo "old_workload_length=40"
echo "old_contributive_query_count=30"
echo "useful_union_capacity=24"
echo "current_evaluator_support_capacity=16"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Create capacity-amendment branch ==="

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Author authoritative capacity amendment ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$AMENDMENT_001" \
  "$AMENDMENT_002" \
  "$AMENDMENT_002_TEST" \
  "$CREATED_UTC" \
  "$EXPECTED_HEAD" \
  "$EXPECTED_PREREG_SHA" \
  "$EXPECTED_AMENDMENT_001_SHA" \
  "$EXPECTED_CLASSIFICATION_REPORT_SHA" \
  "$EXPECTED_CAPACITY_REPORT_SHA" \
  "$EXPECTED_CAPACITY_SURFACE_SHA" \
  "$TARGET_E21_VERSION" \
  "$TARGET_E22_VERSION" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


root = Path(sys.argv[1]).resolve()

prereg_path = root / sys.argv[2]
amendment_001_path = root / sys.argv[3]
amendment_002_path = root / sys.argv[4]
test_path = root / sys.argv[5]

created_utc = sys.argv[6]
source_commit = sys.argv[7]

prereg_sha = sys.argv[8]
amendment_001_sha = sys.argv[9]
classification_report_sha = sys.argv[10]
capacity_report_sha = sys.argv[11]
capacity_surface_sha = sys.argv[12]

target_e21 = sys.argv[13]
target_e22 = sys.argv[14]

prereg = json.loads(
    prereg_path.read_text(encoding="utf-8")
)

amendment_001 = json.loads(
    amendment_001_path.read_text(encoding="utf-8")
)

levels = amendment_001[
    "structural_control_contract"
]["objective_count_levels"]

seeds = prereg[
    "replication_contract"
]["structural_seeds"]

noise_classes = amendment_001[
    "workload_noise_contract"
]["noise_class_order"]

assert levels == [1, 2, 5, 10, 20, 50]
assert len(seeds) == 10
assert len(noise_classes) == 8

support_coordinates = [
    {
        "support_ordinal": support_ordinal,
        "constraint_index": constraint_index,
        "local_virtual_node_index": local_index,
    }
    for support_ordinal, (
        constraint_index,
        local_index,
    ) in enumerate(
        (
            (constraint_index, local_index)
            for constraint_index in range(8)
            for local_index in (0, 1, 2)
        )
    )
]

assert len(support_coordinates) == 24

noise_counts_by_replication = [
    {
        "replication_index": replication_index,
        "seed": seed,
        "class_counts": {
            noise_class: 1
            for noise_class in noise_classes
        },
    }
    for replication_index, seed
    in enumerate(seeds)
]

stage10_class_totals = {
    noise_class: sum(
        row["class_counts"][noise_class]
        for row in noise_counts_by_replication
    )
    for noise_class in noise_classes
}

assert set(stage10_class_totals.values()) == {10}
assert sum(stage10_class_totals.values()) == 80

amendment: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-workload-"
        "contribution-capacity-amendment-v1"
    ),
    "amendment_id": (
        "sa5_objective_count_workload_"
        "contribution_capacity_amendment_002"
    ),
    "status": (
        "preregistered_implementation_required"
    ),
    "phase": "SA5",
    "factor": "objective_count",
    "stage": 10,
    "created_utc": created_utc,
    "source_repository": (
        "digitcreadev/MCAD_improve3"
    ),
    "source_branch": (
        "paper/phase3-controlled-execution"
    ),
    "source_commit": source_commit,
    "amends": {
        "original_preregistration": {
            "artifact_path": str(
                prereg_path.relative_to(root)
            ),
            "artifact_sha256": prereg_sha,
        },
        "materialization_contract_amendment_001": {
            "artifact_path": str(
                amendment_001_path.relative_to(root)
            ),
            "artifact_sha256": amendment_001_sha,
        },
        "amendment_precedence": (
            "This capacity amendment is authoritative "
            "for workload length, contributive-query "
            "capacity, noise counts, evaluator support "
            "policy, and the post-amendment "
            "implementation-scope projection."
        ),
        "superseded_fields": [
            (
                "materialization amendment 001: "
                "workload_noise_contract.workload_length"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "non_contributive_query_count"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "oracle_contributive_query_count"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "counts_by_replication"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "stage10_class_totals"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "stage10_total_noise_query_count"
            ),
            (
                "materialization amendment 001: "
                "workload_noise_contract."
                "noise_position_selection.selection_count"
            ),
            (
                "binding-candidate classification: "
                "final 17-file implementation scope"
            ),
        ],
        "preserved_fields": [
            "objective-count levels",
            "ten structural seeds",
            "ten replications",
            "constraints per objective: 8",
            "virtual nodes per objective: 32",
            "useful virtual nodes per objective: 24",
            "irrelevant virtual nodes per objective: 8",
            "useful virtual-node ratio: 0.75",
            "realised membership density: 0.50",
            "requested workload-noise ratio: 0.25",
            "eight preregistered noise classes",
            "common-workload sharing across six levels",
            "all execution prohibitions",
        ],
    },
    "capacity_audit_provenance": {
        "classification_report_sha256": (
            classification_report_sha
        ),
        "capacity_report_sha256": (
            capacity_report_sha
        ),
        "capacity_surface_sha256": (
            capacity_surface_sha
        ),
        "incompatibility_status": (
            "sa5_objective_count_workload_"
            "contribution_capacity_incompatible"
        ),
        "old_workload_length": 40,
        "old_non_contributive_query_count": 10,
        "old_oracle_contributive_query_count": 30,
        "useful_union_capacity": 24,
        "current_evaluator_support_capacity": 16,
        "useful_union_deficit": 6,
        "current_evaluator_support_deficit": 14,
    },
    "factor_scoped_support_contract": {
        "metadata_field": (
            "session_support_policy"
        ),
        "objective_count_v2_value": (
            "union_requirement_sets"
        ),
        "historical_default_value": (
            "shortest_requirement_set_"
            "then_lexicographic_tie_break"
        ),
        "scope": (
            "Only objectives generated by the "
            "objective-count v2 structural profile."
        ),
        "support_definition": (
            "For each constraint, session support is "
            "the sorted unique union of all resources "
            "declared in its requirement sets."
        ),
        "requirement_set_membership_indices": [
            [0, 1],
            [1, 2],
        ],
        "support_local_virtual_node_indices": [
            0,
            1,
            2,
        ],
        "support_resources_per_constraint": 3,
        "constraint_count": 8,
        "support_resources_per_objective": 24,
        "historical_profiles_must_remain_unchanged": True,
        "factor_local_dispatch_required": True,
        "missing_or_unknown_policy_must_use_historical_default": True,
    },
    "revised_workload_contract": {
        "workload_length": 32,
        "requested_noise_ratio": 0.25,
        "non_contributive_query_count": 8,
        "oracle_contributive_query_count": 24,
        "realised_noise_ratio": 0.25,
        "contributive_capacity": 24,
        "capacity_equality_required": True,
        "support_coordinates": support_coordinates,
        "contributive_step_contract": {
            "count": 24,
            "uniqueness": (
                "Each support coordinate occurs exactly "
                "once in one oracle-contributive step."
            ),
            "assignment": (
                "Select the 24 non-noise positions in "
                "ascending numeric order and map them "
                "bijectively to support coordinates in "
                "ascending support_ordinal order."
            ),
            "repeat_contribution_allowed": False,
            "multi_resource_gain_allowed": False,
            "expected_resources_gained_per_step": 1,
        },
        "noise_class_order": noise_classes,
        "requested_class_weights": {
            noise_class: 0.125
            for noise_class in noise_classes
        },
        "integer_allocation_method": (
            "exact_one_per_class_per_replication"
        ),
        "counts_by_replication": (
            noise_counts_by_replication
        ),
        "stage10_class_totals": (
            stage10_class_totals
        ),
        "stage10_total_noise_query_count": 80,
        "stage10_minimum_class_count": 10,
        "stage10_maximum_class_count": 10,
        "stage10_maximum_pairwise_class_imbalance": 0,
        "noise_position_selection": {
            "position_domain": "1..32",
            "selection_count": 8,
            "algorithm": (
                "Rank all positions by ascending SHA-256 "
                "of UTF-8 string "
                "'mcad-sa5-noise-position-v2|"
                "<seed>|<position>'; select the eight "
                "lowest digests; ties are resolved by "
                "ascending numeric position."
            ),
        },
        "class_to_position_assignment": {
            "algorithm": (
                "Rank the eight noise classes by "
                "ascending SHA-256 of UTF-8 string "
                "'mcad-sa5-noise-class-v2|<seed>|"
                "<class>'; assign that order to selected "
                "noise positions in ascending numeric "
                "order."
            ),
        },
        "common_workload_rule": (
            "For each seed, the exact ordered 32-step "
            "semantic workload, support-coordinate "
            "assignments, noise positions, noise classes, "
            "and oracle labels are shared across all six "
            "objective-count levels. Only deterministic "
            "selected-objective identifier substitution "
            "is permitted."
        ),
    },
    "implementation_contract": {
        "implementation_required_before_materialization": True,
        "target_structural_generator_version": target_e21,
        "target_campaign_generator_version": target_e22,
        "required_factor_scoped_changes": [
            (
                "objective-count v2 structural generator "
                "writes session_support_policy="
                "union_requirement_sets"
            ),
            (
                "CKG support resolution honors the "
                "factor-scoped policy while preserving "
                "the historical default"
            ),
            (
                "objective-count v2 family records and "
                "audits the support policy"
            ),
            (
                "Stage-10 workload materializer creates "
                "32-step workloads with 24 unique "
                "contributions and 8 noise steps"
            ),
            (
                "independent workload auditor verifies "
                "the support-coordinate bijection"
            ),
            (
                "E3 objective-count profile bindings "
                "move to v2"
            ),
        ],
        "prior_17_file_scope_authoritative": False,
        "implementation_scope_must_be_reprojected_after_merge": True,
        "preserve_v1_generator_module_bytes": True,
        "preserve_historical_factor_behavior": True,
        "preserve_membership_density_profile": True,
    },
    "materialization_acceptance_contract": {
        "required_instance_count": 60,
        "required_replication_count": 10,
        "required_level_count": 6,
        "required_common_workload_count": 10,
        "required_workload_length": 32,
        "required_contributive_query_count_per_workload": 24,
        "required_non_contributive_query_count_per_workload": 8,
        "required_noise_ratio": 0.25,
        "required_support_resource_count_per_selected_objective": 24,
        "required_support_coordinate_duplicate_count": 0,
        "required_support_coordinate_missing_count": 0,
        "required_noise_class_count_per_replication": 8,
        "required_stage10_noise_query_count": 80,
        "required_stage10_noise_class_imbalance": 0,
        "required_cross_level_workload_mismatch_count": 0,
        "required_oracle_mismatch_count": 0,
    },
    "authorization": {
        "amendment_persistence_authorized": True,
        "v2_implementation_authorized_after_amendment_merge": True,
        "v2_patch_authoring_authorized_before_amendment_merge": False,
        "canonical_campaign_materialization_authorized": False,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "manuscript_integration_authorized": False,
        "global_scientific_freeze": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "campaign_materialization_performed": False,
        "canonical_stage10_bootstrap_performed": False,
        "functional_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": (
        "reproject_sa5_objective_count_v2_"
        "implementation_scope_after_capacity_"
        "amendment_merge"
    ),
}

amendment_002_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

amendment_002_path.write_text(
    json.dumps(
        amendment,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

test_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

test_path.write_text(
    r'''from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]

PREREG_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_stage10_"
        "campaign_preregistration.json"
    )
)

AMENDMENT_001_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_"
        "materialization_contract_amendment.json"
    )
)

AMENDMENT_002_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_workload_"
        "contribution_capacity_amendment.json"
    )
)

EXPECTED_PREREG_SHA = (
    "a92bb672c2c0ac61d3700ce49c9f3340"
    "ffe6b2f01f08b0f94dd354f96c8c8d5e"
)

EXPECTED_AMENDMENT_001_SHA = (
    "2e0ff32570d9e427e753fdda5bc81699"
    "6d2608778879c1c4c5568fc47bf088e1"
)


def load_amendment() -> dict:
    value = json.loads(
        AMENDMENT_002_PATH.read_text(
            encoding="utf-8"
        )
    )

    assert isinstance(value, dict)

    return value


def test_prior_artifacts_remain_unchanged() -> None:
    assert hashlib.sha256(
        PREREG_PATH.read_bytes()
    ).hexdigest() == EXPECTED_PREREG_SHA

    assert hashlib.sha256(
        AMENDMENT_001_PATH.read_bytes()
    ).hexdigest() == EXPECTED_AMENDMENT_001_SHA


def test_capacity_amendment_identity_and_precedence() -> None:
    amendment = load_amendment()

    assert amendment["schema_version"] == (
        "mcad-sa5-objective-count-workload-"
        "contribution-capacity-amendment-v1"
    )

    assert amendment["amendment_id"] == (
        "sa5_objective_count_workload_"
        "contribution_capacity_amendment_002"
    )

    assert amendment["status"] == (
        "preregistered_implementation_required"
    )

    assert amendment["factor"] == "objective_count"
    assert amendment["stage"] == 10

    superseded = amendment[
        "amends"
    ]["superseded_fields"]

    assert any(
        "workload_length" in value
        for value in superseded
    )

    assert any(
        "final 17-file implementation scope"
        in value
        for value in superseded
    )


def test_factor_scoped_support_policy_is_exact() -> None:
    support = load_amendment()[
        "factor_scoped_support_contract"
    ]

    assert support["metadata_field"] == (
        "session_support_policy"
    )

    assert support[
        "objective_count_v2_value"
    ] == "union_requirement_sets"

    assert support[
        "historical_default_value"
    ] == (
        "shortest_requirement_set_"
        "then_lexicographic_tie_break"
    )

    assert support[
        "requirement_set_membership_indices"
    ] == [[0, 1], [1, 2]]

    assert support[
        "support_local_virtual_node_indices"
    ] == [0, 1, 2]

    assert support[
        "support_resources_per_constraint"
    ] == 3

    assert support[
        "support_resources_per_objective"
    ] == 24

    assert support[
        "historical_profiles_must_remain_unchanged"
    ] is True

    assert support[
        "factor_local_dispatch_required"
    ] is True


def test_revised_workload_matches_capacity_and_noise_ratio() -> None:
    workload = load_amendment()[
        "revised_workload_contract"
    ]

    assert workload["workload_length"] == 32
    assert workload["non_contributive_query_count"] == 8
    assert workload["oracle_contributive_query_count"] == 24

    assert (
        workload["non_contributive_query_count"]
        / workload["workload_length"]
    ) == 0.25

    assert workload["contributive_capacity"] == 24
    assert workload["capacity_equality_required"] is True

    coordinates = workload["support_coordinates"]

    assert len(coordinates) == 24

    assert {
        (
            row["constraint_index"],
            row["local_virtual_node_index"],
        )
        for row in coordinates
    } == {
        (
            constraint_index,
            local_index,
        )
        for constraint_index in range(8)
        for local_index in (0, 1, 2)
    }

    assert [
        row["support_ordinal"]
        for row in coordinates
    ] == list(range(24))


def test_noise_allocation_is_exactly_balanced() -> None:
    workload = load_amendment()[
        "revised_workload_contract"
    ]

    classes = workload["noise_class_order"]
    rows = workload["counts_by_replication"]

    assert len(classes) == 8
    assert len(rows) == 10

    totals = {
        noise_class: 0
        for noise_class in classes
    }

    for row in rows:
        assert set(
            row["class_counts"]
        ) == set(classes)

        assert set(
            row["class_counts"].values()
        ) == {1}

        assert sum(
            row["class_counts"].values()
        ) == 8

        for noise_class, count in (
            row["class_counts"].items()
        ):
            totals[noise_class] += count

    assert set(totals.values()) == {10}

    assert totals == workload[
        "stage10_class_totals"
    ]

    assert workload[
        "stage10_total_noise_query_count"
    ] == 80

    assert workload[
        "stage10_maximum_pairwise_class_imbalance"
    ] == 0


def test_implementation_scope_requires_reprojection() -> None:
    amendment = load_amendment()

    implementation = amendment[
        "implementation_contract"
    ]

    authorization = amendment[
        "authorization"
    ]

    assert implementation[
        "prior_17_file_scope_authoritative"
    ] is False

    assert implementation[
        "implementation_scope_must_be_reprojected_after_merge"
    ] is True

    assert implementation[
        "preserve_v1_generator_module_bytes"
    ] is True

    assert implementation[
        "preserve_historical_factor_behavior"
    ] is True

    assert authorization[
        "v2_patch_authoring_authorized_before_amendment_merge"
    ] is False

    assert authorization[
        "canonical_campaign_materialization_authorized"
    ] is False

    assert authorization[
        "functional_execution_authorized"
    ] is False

    assert amendment["next_stage"] == (
        "reproject_sa5_objective_count_v2_"
        "implementation_scope_after_capacity_"
        "amendment_merge"
    )
'''.rstrip()
    + "\n",
    encoding="utf-8",
)

print("capacity_amendment_authoring=PASS")
print(
    f"amendment={amendment_002_path.relative_to(root)}"
)
print(f"test={test_path.relative_to(root)}")
print("revised_workload_length=32")
print("revised_contributive_query_count=24")
print("revised_non_contributive_query_count=8")
print("revised_noise_ratio=0.25")
print("factor_scoped_support_policy=union_requirement_sets")
print("prior_17_file_scope_authoritative=false")
PY

echo
echo "=== 4. Validate amendment JSON ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-workload-contribution-capacity-amendment-v1"
  and .amendment_id
    == "sa5_objective_count_workload_contribution_capacity_amendment_002"
  and .status
    == "preregistered_implementation_required"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .capacity_audit_provenance.old_workload_length == 40
  and .capacity_audit_provenance.old_oracle_contributive_query_count
    == 30
  and .capacity_audit_provenance.useful_union_capacity
    == 24
  and .capacity_audit_provenance.current_evaluator_support_capacity
    == 16
  and .factor_scoped_support_contract.metadata_field
    == "session_support_policy"
  and .factor_scoped_support_contract.objective_count_v2_value
    == "union_requirement_sets"
  and .factor_scoped_support_contract.support_resources_per_constraint
    == 3
  and .factor_scoped_support_contract.support_resources_per_objective
    == 24
  and .factor_scoped_support_contract.historical_profiles_must_remain_unchanged
    == true
  and .revised_workload_contract.workload_length
    == 32
  and .revised_workload_contract.non_contributive_query_count
    == 8
  and .revised_workload_contract.oracle_contributive_query_count
    == 24
  and .revised_workload_contract.realised_noise_ratio
    == 0.25
  and (
    .revised_workload_contract.support_coordinates
    | length
  ) == 24
  and (
    .revised_workload_contract.counts_by_replication
    | length
  ) == 10
  and .revised_workload_contract.stage10_total_noise_query_count
    == 80
  and .revised_workload_contract.stage10_minimum_class_count
    == 10
  and .revised_workload_contract.stage10_maximum_class_count
    == 10
  and .revised_workload_contract.stage10_maximum_pairwise_class_imbalance
    == 0
  and .implementation_contract.prior_17_file_scope_authoritative
    == false
  and .implementation_contract.implementation_scope_must_be_reprojected_after_merge
    == true
  and .authorization.v2_patch_authoring_authorized_before_amendment_merge
    == false
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.campaign_materialization_performed
    == false
  and .next_stage
    == "reproject_sa5_objective_count_v2_implementation_scope_after_capacity_amendment_merge"
' "$AMENDMENT_002" >/dev/null

echo "capacity_amendment_json_validation=PASS"

echo
echo "=== 5. Compile and test capacity amendment ==="

"$PYTHON" -m py_compile \
  "$AMENDMENT_002_TEST"

"$PYTHON" -m pytest \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_001_TEST" \
  "$PREREG_TEST" \
  -q \
  -p no:cacheprovider

echo "capacity_amendment_tests=PASS"

echo
echo "=== 6. Repository-scope gate ==="

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT_001" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_001_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

test -f "$AMENDMENT_002"
test -f "$AMENDMENT_002_TEST"

test -n "$(
  git check-ignore -v "$AMENDMENT_002" || true
)"

test "$(
  git status --porcelain -- "$AMENDMENT_002_TEST"
)" = "?? $AMENDMENT_002_TEST"

test -z "$(git diff --name-only)"
test -z "$(git diff --cached --name-only)"

echo "repository_scope_gate=PASS"
echo "prior_artifacts_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Force-stage capacity amendment ==="

git add -f "$AMENDMENT_002"
git add "$AMENDMENT_002_TEST"

printf '%s\n' \
  "$AMENDMENT_002_TEST" \
  "$AMENDMENT_002" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

git diff --cached --name-only |
  sort \
  > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)" -eq 2

git diff --cached --check

echo "capacity_amendment_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 8. Commit capacity amendment ==="

git commit \
  -m "chore(experiments): amend SA5 workload capacity"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"

AMENDMENT_002_SHA="$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)"

echo "commit=PASS"
echo "commit=$COMMIT"
echo "capacity_amendment_sha256=$AMENDMENT_002_SHA"

echo
echo "=== 9. Push capacity-amendment branch ==="

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 10. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister SA5 objective-count workload-capacity amendment" \
    --body "$(cat <<EOF
## SA5 workload-contribution capacity amendment

The detached semantic audit proved that the previously preregistered
40-step workload is infeasible:

- required contributive steps: \`30\`;
- useful-resource union capacity: \`24\`;
- current evaluator support capacity: \`16\`.

### Revised workload

- workload length: \`32\`;
- contributive steps: \`24\`;
- non-contributive steps: \`8\`;
- realised noise ratio: \`0.25\`;
- noise allocation: exactly one step per each of eight classes;
- Stage-10 noise total: \`80\`;
- per-class Stage-10 total: \`10\`.

### Factor-scoped support policy

Objective-count v2 objectives must declare:

\`session_support_policy: union_requirement_sets\`

This produces exactly three support resources per constraint and
24 per selected objective. Missing or unknown policy values retain the
historical shortest-requirement-set behavior.

### Scope consequence

The prior 17-file implementation scope is no longer authoritative.
After this amendment merges, the complete v2 implementation scope must
be reprojected, including the factor-scoped CKG support change and its
regressions.

### Scientific controls

- canonical campaign generated: \`false\`;
- campaign materialization performed: \`false\`;
- functional execution authorized: \`false\`;
- timing execution authorized: \`false\`;
- manuscript modified: \`false\`.

### Integrity

- capacity amendment SHA-256: \`$AMENDMENT_002_SHA\`;
- capacity report SHA-256: \`$EXPECTED_CAPACITY_REPORT_SHA\`;
- capacity surface SHA-256: \`$EXPECTED_CAPACITY_SURFACE_SHA\`;
- original preregistration SHA-256: \`$EXPECTED_PREREG_SHA\`;
- amendment 001 SHA-256: \`$EXPECTED_AMENDMENT_001_SHA\`.

## Next stage

\`reproject_sa5_objective_count_v2_implementation_scope_after_capacity_amendment_merge\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 11. Verify pull-request scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count workload-capacity amendment"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 12. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_workload_capacity_amendment=PASS"
echo "commit=$COMMIT"
echo "capacity_amendment=$AMENDMENT_002"
echo "capacity_amendment_sha256=$AMENDMENT_002_SHA"
echo "revised_workload_length=32"
echo "revised_contributive_query_count=24"
echo "revised_non_contributive_query_count=8"
echo "revised_noise_ratio=0.25"
echo "factor_scoped_support_policy=union_requirement_sets"
echo "support_resources_per_objective=24"
echo "prior_17_file_scope_authoritative=false"
echo "canonical_campaign_generated=false"
echo "canonical_campaign_materialization_authorized=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_workload_capacity_amendment"

git status --short --branch
git log --oneline --decorate -4
