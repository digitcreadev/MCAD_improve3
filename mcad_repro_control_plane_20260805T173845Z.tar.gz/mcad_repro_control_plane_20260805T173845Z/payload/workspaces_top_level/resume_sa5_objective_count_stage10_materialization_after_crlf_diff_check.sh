#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-20260805T104339Z"

EXPECTED_BASE_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/$CAMPAIGN_ID"
INSTANCES_CSV="$CAMPAIGN_ROOT/instances.csv"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/$CAMPAIGN_ID"
STRUCTURE_AUDIT="$AUDIT_ROOT/structure_audit.json"
WORKLOAD_AUDIT="$AUDIT_ROOT/common_workload_audit.json"
CAMPAIGN_FILE_MANIFEST="$AUDIT_ROOT/canonical_campaign_file_manifest.sha256"

MATERIALIZATION_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MATERIALIZATION_SUMMARY="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d4d253da2bf739d65763fa2c44d0e7df15f352bd8b48ce7e96930c4ff93e3705"

EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

READINESS_REPORT="/workspaces/sa5_objective_count_v2_post_merge_materialization_readiness_20260805T102938Z/sa5_objective_count_v2_post_merge_materialization_readiness.json"
EXPECTED_READINESS_REPORT_SHA="2acc274086cf0ff8187132596c5177b350c87e774f4be3597782c9f23341f472"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

TMP_ROOT="$(mktemp -d /workspaces/sa5_materialization_crlf_resume.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 CRLF-aware materialization recovery stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact staged recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test -z "$(git diff --name-only)"

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

EXISTING_PR_COUNT="$(
  gh pr list \
    --repo "$REPO" \
    --head "$BRANCH" \
    --state all \
    --json number |
    jq 'length'
)"

test "$EXISTING_PR_COUNT" -eq 0

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/campaign_files.txt" \
  "$TMP_ROOT/audit_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/campaign_files.txt")" -eq 134
test "$(wc -l < "$TMP_ROOT/audit_files.txt")" -eq 3
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 139

git diff \
  --cached \
  --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 139

git diff \
  --cached \
  --name-status \
  > "$TMP_ROOT/staged_name_status.txt"

test "$(
  awk '$1 != "A" {count += 1} END {print count + 0}' \
    "$TMP_ROOT/staged_name_status.txt"
)" -eq 0

verify_sha \
  "$READINESS_REPORT" \
  "$EXPECTED_READINESS_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -f "$STRUCTURE_AUDIT"
test -f "$WORKLOAD_AUDIT"
test -f "$INSTANCES_CSV"
test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "staged_recovery_gate=PASS"
echo "branch=$BRANCH"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "staged_file_count=139"
echo "tracked_unstaged_change_count=0"
echo "remote_branch_present=false"
echo "existing_pull_request_count=0"

echo
echo "=== 2. Diagnose exact diff-check failure ==="

export INSTANCES_CSV

python3 - <<'PY'
from __future__ import annotations

import os
import re
import subprocess


instances_csv = os.environ["INSTANCES_CSV"]

process = subprocess.run(
    [
        "git",
        "diff",
        "--cached",
        "--check",
    ],
    check=False,
    capture_output=True,
)

assert process.returncode != 0, (
    "Expected the staged CRLF CSV to trigger "
    "git diff --cached --check."
)

text = process.stdout.decode(
    "utf-8",
    errors="replace",
)

pattern = re.compile(
    rf"^{re.escape(instances_csv)}:"
    r"([0-9]+): trailing whitespace\.$",
    re.MULTILINE,
)

line_numbers = [
    int(match)
    for match in pattern.findall(text)
]

assert line_numbers == list(range(1, 62)), (
    "Expected exactly one CRLF-related diagnostic "
    "for each of the 61 CSV records; got "
    f"{line_numbers!r}."
)

diagnostic_lines = [
    line
    for line in text.splitlines()
    if ": trailing whitespace." in line
    or ": new blank line at EOF." in line
    or ": space before tab in indent." in line
]

expected_diagnostics = {
    f"{instances_csv}:{line}: trailing whitespace."
    for line in range(1, 62)
}

assert set(diagnostic_lines) == expected_diagnostics, (
    "git diff --check reported an unexpected "
    "whitespace problem."
)

assert "new blank line at EOF" not in text
assert "space before tab in indent" not in text

print("diff_check_failure_classification=PASS")
print("diff_check_failure_scope=instances_csv_crlf_only")
print("diff_check_diagnostic_count=61")
print("unexpected_diff_check_problem_count=0")
PY

echo
echo "=== 3. Validate CSV CRLF as canonical generated serialization ==="

python3 - <<'PY'
from __future__ import annotations

import csv
import io
import os
import re
from pathlib import Path


path = Path(os.environ["INSTANCES_CSV"])
payload = path.read_bytes()

assert payload.endswith(b"\r\n")
assert payload.count(b"\r\n") == 61
assert payload.count(b"\n") == 61
assert payload.count(b"\r") == 61

assert not re.search(
    rb"[ \t]+\r\n",
    payload,
), "Found actual spaces or tabs before a CRLF terminator."

assert b"\x00" not in payload

text = payload.decode("utf-8")

rows = list(
    csv.reader(
        io.StringIO(
            text,
            newline="",
        )
    )
)

assert len(rows) == 61

header = rows[0]
data_rows = rows[1:]

assert len(data_rows) == 60
assert len(header) > 0
assert all(
    len(row) == len(header)
    for row in data_rows
)

required_columns = {
    "campaign_id",
    "factor",
    "factor_level",
    "replication_index",
    "seed",
    "objective_id",
    "relative_instance_dir",
    "selected_objective_index",
    "selected_objective_shape_digest",
    "session_support_policy",
}

assert required_columns.issubset(
    set(header)
)

factor_index = header.index("factor")
level_index = header.index("factor_level")
replication_index = header.index(
    "replication_index"
)
seed_index = header.index("seed")
policy_index = header.index(
    "session_support_policy"
)

levels = {
    int(row[level_index])
    for row in data_rows
}

replications = {
    int(row[replication_index])
    for row in data_rows
}

assert levels == {1, 2, 5, 10, 20, 50}
assert replications == set(range(10))
assert all(
    row[factor_index] == "objective_count"
    for row in data_rows
)
assert all(
    row[policy_index]
    == "union_requirement_sets"
    for row in data_rows
)

for level in sorted(levels):
    level_rows = [
        row
        for row in data_rows
        if int(row[level_index]) == level
    ]
    assert len(level_rows) == 10

for replication in sorted(replications):
    replication_rows = [
        row
        for row in data_rows
        if int(row[replication_index])
        == replication
    ]
    assert len(replication_rows) == 6
    assert len(
        {
            int(row[seed_index])
            for row in replication_rows
        }
    ) == 1

print("instances_csv_serialization_gate=PASS")
print("instances_csv_line_ending=CRLF")
print("instances_csv_record_count=61")
print("instances_csv_instance_count=60")
print("actual_trailing_space_or_tab_count=0")
print("csv_semantic_validation=PASS")
PY

echo
echo "=== 4. Verify staged index bytes exactly match audited files ==="

while IFS= read -r FILE; do
  cmp \
    "$FILE" \
    <(
      git show ":$FILE"
    )
done < "$TMP_ROOT/expected_files.txt"

echo "staged_index_byte_identity_gate=PASS"
echo "staged_index_file_count=139"
echo "instances_csv_bytes_preserved=true"
echo "canonical_campaign_file_manifest_preserved=true"
echo "materialization_report_preserved=true"

echo
echo "=== 5. Revalidate materialization evidence and controls ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_structure_and_common_workloads_materialized"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .implementation_patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .canonical_campaign.expected_instance_count
    == 60
  and .canonical_campaign.realised_instance_count
    == 60
  and .canonical_campaign.campaign_file_count
    == 134
  and .canonical_campaign.instance_manifest_count
    == 60
  and .canonical_campaign.objectives_file_count
    == 60

  and .common_workloads.workload_count
    == 10
  and .common_workloads.workload_length
    == 32
  and .common_workloads.contributive_query_count_per_workload
    == 24
  and .common_workloads.non_contributive_query_count_per_workload
    == 8

  and .audits.structure.status == "PASS"
  and .audits.structure.failure_count == 0
  and .audits.common_workloads.status == "PASS"
  and .audits.common_workloads.failure_count == 0
  and .audits.common_workloads.operator_oracle_mismatch_count
    == 0

  and .scientific_controls.canonical_campaign_generated
    == true
  and .scientific_controls.canonical_campaign_materialization_performed
    == true
  and .scientific_controls.canonical_stage10_functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.precision_analysis_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "materialization_evidence_gate=PASS"
echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 6. Commit exact audited materialization bytes ==="

git commit \
  -m "chore(experiments): materialize SA5 objective-count Stage-10 inputs"

COMMIT="$(
  git rev-parse HEAD
)"

test "$COMMIT" != "$EXPECTED_BASE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git diff-tree \
  --no-commit-id \
  --name-only \
  -r \
  "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/committed_files.txt"

test "$(wc -l < "$TMP_ROOT/committed_files.txt")" -eq 139

while IFS= read -r FILE; do
  cmp \
    "$FILE" \
    <(
      git show "$COMMIT:$FILE"
    )
done < "$TMP_ROOT/expected_files.txt"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

echo "materialization_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=139"
echo "committed_byte_identity_gate=PASS"

echo
echo "=== 7. Push materialization branch ==="

git push \
  -u \
  origin \
  "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "materialization_push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Materialize SA5 objective-count Stage-10 inputs" \
    --body-file - <<EOF
## Scope

Materialize the preregistered SA5 objective-count Stage-10 canonical inputs from merged commit \`$EXPECTED_BASE_HEAD\`.

- 6 objective-count levels
- 10 fixed replications
- 60 canonical structural instances
- 10 common workloads
- 32 steps per workload
- 24 contributive and 8 non-contributive steps
- one occurrence of every registered noise class per replication

## Validation

- structure audit: PASS
- common-workload audit: PASS
- operator-oracle mismatches: 0
- canonical campaign files: 134
- total committed files: 139
- implementation patch SHA-256: \`$EXPECTED_PATCH_SHA\`
- readiness report SHA-256: \`$EXPECTED_READINESS_REPORT_SHA\`
- canonical campaign file-manifest SHA-256: \`$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA\`

## Serialization note

\`instances.csv\` preserves the Python CSV writer's deterministic CRLF record terminators. Validation confirmed 61 records, no spaces or tabs before the terminators, and byte identity with the audited campaign file manifest.

## Scientific control

This PR materializes canonical inputs only. Formal Stage-10 functional execution, timing, bootstrap, precision analysis, and manuscript integration have not been performed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Verify PR identity and paginated exact scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg commit "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $commit
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 139

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=139"

echo
echo "=== 10. Final state ==="

echo "sa5_objective_count_stage10_materialization_crlf_recovery=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "canonical_campaign_file_count=134"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"
echo "total_committed_file_count=139"

echo "instances_csv_line_ending=CRLF"
echo "instances_csv_record_count=61"
echo "actual_trailing_space_or_tab_count=0"

echo "materialization_report_sha256=$EXPECTED_MATERIALIZATION_REPORT_SHA"
echo "materialization_summary_sha256=$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
echo "canonical_campaign_file_manifest_sha256=$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

echo "canonical_campaign_generated=true"
echo "canonical_campaign_materialization_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_materialization"

git status --short --branch
git log --oneline --decorate -5
