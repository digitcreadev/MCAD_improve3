#!/usr/bin/env bash
set -Eeuo pipefail

BUNDLE="/workspaces/sa5_functional_authorization_exact_bundle_29eb8894.tar.gz"
EXPECTED_BUNDLE_SHA="9f97c717d31e0ff4b435192583a6c4c0865a73976db883bb17c0fbe93c62f31a"

EXTRACT_DIR="/workspaces/sa5_functional_authorization_exact_bundle_29eb8894"
SCRIPT_NAME="audit_sa5_objective_count_stage10_functional_execution_authorization_exact.sh"
EXPECTED_SCRIPT_SHA="29eb88941bdadc45d30e9adb5795c689367bd230cb450efd0b2ebf9f113153aa"

REPO="/workspaces/MCAD_improve3"

trap 'echo "[ERROR] Exact authorization wrapper stopped at line $LINENO."' ERR

test -f "$BUNDLE"

ACTUAL_BUNDLE_SHA="$(
  sha256sum "$BUNDLE" |
    awk '{print $1}'
)"

echo "actual_bundle_sha256=$ACTUAL_BUNDLE_SHA"

test "$ACTUAL_BUNDLE_SHA" = "$EXPECTED_BUNDLE_SHA"

rm -rf "$EXTRACT_DIR"
mkdir -p "$EXTRACT_DIR"

tar \
  -xzf "$BUNDLE" \
  -C "$EXTRACT_DIR"

cd "$EXTRACT_DIR"

sha256sum \
  -c \
  SHA256SUMS

SCRIPT="$EXTRACT_DIR/$SCRIPT_NAME"

test -f "$SCRIPT"

ACTUAL_SCRIPT_SHA="$(
  sha256sum "$SCRIPT" |
    awk '{print $1}'
)"

echo "actual_script_sha256=$ACTUAL_SCRIPT_SHA"

test "$ACTUAL_SCRIPT_SHA" = "$EXPECTED_SCRIPT_SHA"

chmod +x "$SCRIPT"

cd "$REPO"

env -u BASH_ENV \
  bash \
  --noprofile \
  --norc \
  "$SCRIPT"

STATUS=$?

echo
echo "sa5_functional_authorization_exact_wrapper=PASS"
echo "sa5_functional_authorization_exact_wrapper_exit_status=$STATUS"
git status --short --branch
