#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BRANCH="paper/execute-membership-density-timing-stage10-20260803T111214Z"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

AUTH="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.json"
LEDGER="$RUN_ROOT/stage10_execution_ledger.json"
LEDGER_MD="$RUN_ROOT/stage10_execution_ledger.md"

AUDIT_ROOT="$REPORTS/audits/membership_density/timing_stage10"
AUDIT_JSON="$AUDIT_ROOT/stage10_output_audit.json"
AUDIT_MD="$AUDIT_ROOT/stage10_output_audit.md"

RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

EXPECTED_AUTH_SHA="dc9010e319e238f1419e4fdb4d52cd184fc9470d346cef8833ef0355ff0c4be0"
EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Evidence persistence stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Persistence gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$AUTH"
test -f "$LEDGER"
test -f "$LEDGER_MD"
test -f "$RUNNER"
test ! -e "$AUDIT_JSON"
test ! -e "$AUDIT_MD"

test "$(
  sha256sum "$AUTH" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

test "$(
  sha256sum "$RUNNER" | awk '{print $1}'
)" = "$EXPECTED_RUNNER_SHA"

echo "persistence_gate=PASS"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Persist semantic balance audit ==="

CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$AUTH" \
  "$LEDGER" \
  "$RUNNER" \
  "$AUDIT_JSON" \
  "$AUDIT_MD" \
  "$CREATED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
auth_path = (root / sys.argv[2]).resolve()
ledger_path = (root / sys.argv[3]).resolve()
runner_path = (root / sys.argv[4]).resolve()
audit_json = (root / sys.argv[5]).resolve()
audit_md = (root / sys.argv[6]).resolve()
created_utc = sys.argv[7]


def load_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(value, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return value


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


authorization = load_object(auth_path)
ledger = load_object(ledger_path)

if ledger.get("status") != (
    "membership_density_stage10_timing_execution_complete"
):
    raise SystemExit("Stage-10 execution ledger is incomplete.")

replications = ledger.get("replications")

if not isinstance(replications, list) or len(replications) != 10:
    raise SystemExit("Expected ten replication records.")

expected_levels = [25, 50, 75, 100]
expected_steps = list(range(1, 24))

measurement_round_count = 100
order_position_count = 92

quotient, remainder = divmod(
    measurement_round_count,
    order_position_count,
)

if (quotient, remainder) != (1, 8):
    raise SystemExit("Unexpected order-balance arithmetic.")

records: list[dict[str, Any]] = []

total_warmups = 0
total_measurements = 0
total_rows = 0
total_cells = 0

for replication, ledger_record in enumerate(replications):
    if ledger_record.get("replication_index") != replication:
        raise SystemExit("Replication order mismatch.")

    output_dir = Path(ledger_record["output_dir"]).resolve()

    manifest_path = (
        output_dir / "timing_manifest.json"
    )

    observations_path = (
        output_dir / "timing_observations.csv"
    )

    references_path = (
        output_dir / "functional_references.json"
    )

    summary_path = (
        output_dir / "timing_summary.json"
    )

    paths = {
        "timing_manifest": manifest_path,
        "timing_observations": observations_path,
        "functional_references": references_path,
        "timing_summary": summary_path,
    }

    for name, path in paths.items():
        if not path.is_file():
            raise SystemExit(
                f"Replication {replication}: missing {name}."
            )

        declaration = ledger_record["files"][name]

        if sha256(path) != declaration["sha256"]:
            raise SystemExit(
                f"Replication {replication}: SHA mismatch "
                f"for {name}."
            )

    manifest = load_object(manifest_path)
    summary = load_object(summary_path)
    load_object(references_path)

    if manifest.get("functional_mismatch_count") != 0:
        raise SystemExit(
            f"Replication {replication}: functional mismatch."
        )

    if manifest.get("all_cells_exactly_balanced") is not False:
        raise SystemExit(
            f"Replication {replication}: unexpected manifest "
            "balance declaration."
        )

    if summary.get("all_cells_exactly_balanced") is not False:
        raise SystemExit(
            f"Replication {replication}: unexpected summary "
            "balance declaration."
        )

    order_balance = summary.get("order_balance")

    if not isinstance(order_balance, list):
        raise SystemExit(
            f"Replication {replication}: order_balance absent."
        )

    if len(order_balance) != 92:
        raise SystemExit(
            f"Replication {replication}: expected 92 "
            "order-balance records."
        )

    if any(
        item.get("exact_full_balance") is not False
        for item in order_balance
    ):
        raise SystemExit(
            f"Replication {replication}: unexpected exact "
            "full-balance value."
        )

    warmup_counts: Counter[
        tuple[int, int]
    ] = Counter()

    measurement_counts: Counter[
        tuple[int, int]
    ] = Counter()

    position_counts: dict[
        tuple[int, int],
        Counter[int],
    ] = {}

    row_count = 0

    with observations_path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)

        required = {
            "phase",
            "factor_level",
            "step_index",
            "order_position",
            "wall_latency_ms",
        }

        if reader.fieldnames is None:
            raise SystemExit(
                f"Replication {replication}: CSV header absent."
            )

        missing = required - set(reader.fieldnames)

        if missing:
            raise SystemExit(
                f"Replication {replication}: missing CSV fields "
                + ", ".join(sorted(missing))
            )

        for row in reader:
            row_count += 1

            phase = row["phase"]
            level = int(row["factor_level"])
            step = int(row["step_index"])
            position = int(row["order_position"])

            cell = (level, step)

            if phase == "warmup":
                warmup_counts[cell] += 1

            elif phase == "measurement":
                measurement_counts[cell] += 1
                position_counts.setdefault(
                    cell,
                    Counter(),
                )[position] += 1

            else:
                raise SystemExit(
                    f"Replication {replication}: "
                    f"unknown phase {phase!r}."
                )

    expected_cells = {
        (level, step)
        for level in expected_levels
        for step in expected_steps
    }

    if set(warmup_counts) != expected_cells:
        raise SystemExit(
            f"Replication {replication}: warmup-cell set mismatch."
        )

    if set(measurement_counts) != expected_cells:
        raise SystemExit(
            f"Replication {replication}: "
            "measurement-cell set mismatch."
        )

    for cell in expected_cells:
        if warmup_counts[cell] != 10:
            raise SystemExit(
                f"Replication {replication}: "
                f"warmup imbalance for {cell}."
            )

        if measurement_counts[cell] != 100:
            raise SystemExit(
                f"Replication {replication}: "
                f"measurement imbalance for {cell}."
            )

        counts = position_counts[cell]

        if len(counts) != 92:
            raise SystemExit(
                f"Replication {replication}: expected all "
                f"92 positions for {cell}."
            )

        frequency_histogram = Counter(counts.values())

        if frequency_histogram != Counter({
            1: 84,
            2: 8,
        }):
            raise SystemExit(
                f"Replication {replication}: unexpected "
                f"position-frequency histogram for {cell}: "
                f"{dict(frequency_histogram)}"
            )

    if row_count != 10120:
        raise SystemExit(
            f"Replication {replication}: expected 10,120 rows."
        )

    records.append({
        "replication_index": replication,
        "output_dir": str(output_dir),
        "raw_timing_cell_count": 92,
        "warmup_observation_count": 920,
        "measurement_observation_count": 9200,
        "total_observation_count": 10120,
        "functional_mismatch_count": 0,
        "direct_cell_count_balance": True,
        "declared_all_cells_exactly_balanced": False,
        "order_position_balance": {
            "measurement_round_count": 100,
            "order_position_count": 92,
            "quotient": 1,
            "remainder": 8,
            "positions_seen_once_per_cell": 84,
            "positions_seen_twice_per_cell": 8,
            "all_positions_seen_per_cell": True,
            "exact_full_balance_possible": False,
            "near_balance_verified": True,
        },
        "files": {
            name: {
                "path": str(path.relative_to(root)),
                "sha256": sha256(path),
            }
            for name, path in paths.items()
        },
    })

    total_warmups += 920
    total_measurements += 9200
    total_rows += 10120
    total_cells += 92

if total_cells != 920:
    raise SystemExit("Expected 920 raw timing cells.")

if total_warmups != 9200:
    raise SystemExit("Expected 9,200 warmups.")

if total_measurements != 92000:
    raise SystemExit("Expected 92,000 measurements.")

if total_rows != 101200:
    raise SystemExit("Expected 101,200 observations.")

audit = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-output-audit-v1"
    ),
    "status": (
        "membership_density_stage10_output_audit_complete"
    ),
    "created_utc": created_utc,
    "factor": "membership_density",
    "stage": 10,
    "source_artifacts": {
        "authorization": {
            "path": str(auth_path.relative_to(root)),
            "sha256": sha256(auth_path),
        },
        "execution_ledger": {
            "path": str(ledger_path.relative_to(root)),
            "sha256": sha256(ledger_path),
        },
        "timing_runner": {
            "path": str(runner_path.relative_to(root)),
            "sha256": sha256(runner_path),
        },
    },
    "execution_results": {
        "successful_replication_count": 10,
        "failed_replication_count": 0,
        "raw_timing_cell_count": total_cells,
        "warmup_observation_count": total_warmups,
        "measurement_observation_count": total_measurements,
        "total_observation_count": total_rows,
        "functional_mismatch_count": 0,
        "direct_cell_count_balance": True,
    },
    "balance_flag_interpretation": {
        "field": "all_cells_exactly_balanced",
        "declared_value": False,
        "semantic_domain": "measurement-order positions",
        "does_not_measure": (
            "Per-cell warmup or measurement observation counts."
        ),
        "measurement_round_count": 100,
        "order_position_count": 92,
        "division_quotient": quotient,
        "division_remainder": remainder,
        "exact_full_position_balance_possible": False,
        "expected_value_under_protocol": False,
        "positions_seen_once_per_cell": 84,
        "positions_seen_twice_per_cell": 8,
        "all_positions_seen_per_cell": True,
        "near_balance_verified": True,
        "scientific_defect": False,
        "timing_rerun_required": False,
        "protocol_change_required": False,
    },
    "replications": records,
    "audit_decision": {
        "timing_outputs_complete": True,
        "timing_outputs_integrity_verified": True,
        "functional_equivalence_verified": True,
        "cell_counts_exactly_balanced": True,
        "order_position_near_balance_verified": True,
        "balance_flag_explained": True,
        "stage10_timing_execution_accepted": True,
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_execution_authorized": True,
        "timing_execution_performed": True,
        "timing_reexecution_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "prepare_membership_density_portfolio_analysis_adapter"
    ),
}

write_json(audit_json, audit)

audit_md.parent.mkdir(parents=True, exist_ok=True)

audit_md.write_text(
    "\n".join([
        "# SA4 membership-density Stage-10 output audit",
        "",
        "- Status: `PASS`",
        "- Successful replications: `10/10`",
        "- Raw timing cells: `920`",
        "- Warmups: `9,200`",
        "- Measurements: `92,000`",
        "- Total observations: `101,200`",
        "- Functional mismatches: `0`",
        "- Direct per-cell count balance: `true`",
        "",
        "## Interpretation of `all_cells_exactly_balanced=false`",
        "",
        (
            "The field concerns measurement-order positions, "
            "not the number of observations assigned to each "
            "factor-level/query cell."
        ),
        "",
        (
            "There are 100 measurement rounds and 92 order "
            "positions. Division gives quotient 1 and remainder "
            "8. Each cell therefore occupies 84 positions once "
            "and 8 positions twice."
        ),
        "",
        (
            "Exact full positional balance is impossible under "
            "the preregistered 100-round protocol. The reported "
            "`false` value is therefore expected and does not "
            "invalidate the timing evidence."
        ),
        "",
        "- Timing rerun required: `false`",
        "- Precision analysis authorized: `false`",
        "- Latency claims authorized: `false`",
        "",
        "## Next stage",
        "",
        "`prepare_membership_density_portfolio_analysis_adapter`",
        "",
    ]),
    encoding="utf-8",
)

print("stage10_output_audit_persistence=PASS")
print("successful_replication_count=10")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print("total_observation_count=101200")
print("direct_cell_count_balance=true")
print("order_position_quotient=1")
print("order_position_remainder=8")
print("positions_seen_once_per_cell=84")
print("positions_seen_twice_per_cell=8")
print("balance_flag_expected_under_protocol=true")
print("scientific_defect=false")
print("timing_rerun_required=false")
print("precision_analysis_authorized=false")
PY

echo
echo "=== 3. Validate persisted audit ==="

test -f "$AUDIT_JSON"
test -f "$AUDIT_MD"

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .execution_results.successful_replication_count == 10
  and .execution_results.failed_replication_count == 0
  and .execution_results.raw_timing_cell_count == 920
  and .execution_results.warmup_observation_count == 9200
  and .execution_results.measurement_observation_count == 92000
  and .execution_results.total_observation_count == 101200
  and .execution_results.functional_mismatch_count == 0
  and .execution_results.direct_cell_count_balance == true
  and .balance_flag_interpretation.declared_value == false
  and .balance_flag_interpretation.semantic_domain
      == "measurement-order positions"
  and .balance_flag_interpretation.measurement_round_count == 100
  and .balance_flag_interpretation.order_position_count == 92
  and .balance_flag_interpretation.division_quotient == 1
  and .balance_flag_interpretation.division_remainder == 8
  and .balance_flag_interpretation.positions_seen_once_per_cell == 84
  and .balance_flag_interpretation.positions_seen_twice_per_cell == 8
  and .balance_flag_interpretation.all_positions_seen_per_cell == true
  and .balance_flag_interpretation.expected_value_under_protocol == false
  and .balance_flag_interpretation.scientific_defect == false
  and .balance_flag_interpretation.timing_rerun_required == false
  and (.replications | length) == 10
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.timing_reexecution_performed == false
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "prepare_membership_density_portfolio_analysis_adapter"
' "$AUDIT_JSON" >/dev/null

AUDIT_SHA="$(
  sha256sum "$AUDIT_JSON" | awk '{print $1}'
)"

echo "persisted_output_audit_validation=PASS"
echo "output_audit_sha256=$AUDIT_SHA"

echo
echo "=== 4. Stage canonical timing evidence ==="

for REPLICATION in $(seq 0 9); do
  OUTPUT_DIR="$RUN_ROOT/membership_density_rep_$(printf '%03d' "$REPLICATION")_portfolio_timing_stage10"

  for FILE in \
    timing_manifest.json \
    timing_observations.csv \
    functional_references.json \
    timing_summary.json
  do
    test -f "$OUTPUT_DIR/$FILE"
    git add -f "$OUTPUT_DIR/$FILE"
  done
done

git add -f \
  "$LEDGER" \
  "$LEDGER_MD" \
  "$AUDIT_JSON" \
  "$AUDIT_MD"

git diff --cached --check
git diff --cached --stat

STAGED_FILE_COUNT="$(
  git diff --cached --name-only | wc -l
)"

test "$STAGED_FILE_COUNT" -eq 44

echo "canonical_evidence_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"

echo
echo "=== 5. Commit evidence ==="

git commit \
  -m "evidence(experiments): persist membership-density Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 6. Push execution branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 7. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Persist membership-density Stage-10 timing evidence" \
    --body "$(cat <<EOF
## Timing execution

- successful replications: \`10/10\`;
- raw timing cells: \`920\`;
- warmups: \`9,200\`;
- measurements: \`92,000\`;
- total observations: \`101,200\`;
- functional mismatches: \`0\`;
- timing re-execution: \`false\`.

## Balance audit

The runner field \`all_cells_exactly_balanced=false\` concerns
order-position coverage, not per-cell observation counts.

With 100 measurement rounds and 92 order positions:

- quotient: \`1\`;
- remainder: \`8\`;
- positions visited once per cell: \`84\`;
- positions visited twice per cell: \`8\`;
- direct per-cell measurement count: exactly \`100\`;
- scientific defect: \`false\`;
- timing rerun required: \`false\`.

## Integrity

- execution ledger SHA-256:
  \`$EXPECTED_LEDGER_SHA\`;
- output audit SHA-256:
  \`$AUDIT_SHA\`;
- precision analysis performed: \`false\`;
- latency claims authorized: \`false\`.

## Next scientific stage

\`prepare_membership_density_portfolio_analysis_adapter\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 8. Final state ==="

echo "membership_density_stage10_timing_evidence_persistence=PASS"
echo "commit=$COMMIT"
echo "execution_ledger_sha256=$EXPECTED_LEDGER_SHA"
echo "output_audit_sha256=$AUDIT_SHA"
echo "staged_file_count=44"
echo "successful_replication_count=10"
echo "measurement_observation_count=92000"
echo "timing_reexecution_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_stage10_timing_evidence"

git status --short --branch
git log --oneline --decorate -4
