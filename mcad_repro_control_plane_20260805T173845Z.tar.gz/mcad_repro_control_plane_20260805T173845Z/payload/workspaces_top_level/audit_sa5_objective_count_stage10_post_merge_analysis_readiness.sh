#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=36

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"
EXPECTED_FIRST_PARENT="809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
EXPECTED_SECOND_PARENT="539c928a118ffcf45bfedc7a98a5cac9aee5e1de"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"
RUN_ROOT="$E3/runs"
TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"

SPEC_MANIFEST="$E3/execution_specs/objective_count_stage10_execution_spec_manifest.json"
SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/functional_execution"
EVIDENCE_MANIFEST="$EVIDENCE_ROOT/functional_execution_evidence_manifest.json"
EVIDENCE_MANIFEST_SHA="d2b66ccf52bde34aee15596a898ddf7fa95cb51aad6ce6bd4b0fa14f59e37dbc"

RUN_FILE_MANIFEST="$EVIDENCE_ROOT/source_post_execution/canonical_functional_run_file_manifest.sha256"
RUN_FILE_MANIFEST_SHA="10f2795a20c27c7ba2222636eee8d0800709e12f3fe290138bf4e31c29db6bf1"

MATERIALIZATION_REPORT="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.json"
MATERIALIZATION_REPORT_SHA="69fd9c4d291adefefef50fb595c779b222cfc1e4299796f9e9fa525a1c150e07"

MATERIALIZATION_SUMMARY="$E3/planning/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.md"
MATERIALIZATION_SUMMARY_SHA="24faa78e4e2a2f01efd8842fa2ece035c4f04d4038af73c67f8aaccbe93b4869"

CI_AUDIT="/workspaces/sa5_objective_count_pr36_ci_eligibility_audit_20260805T141114Z/sa5_objective_count_pr36_ci_eligibility_audit.json"
CI_AUDIT_SHA="b1ec1438bb0c31943dea0ff3300d07970a6088c6ecb7dfe1ee882fcbf5b20964"

RESUME_ROOT="/workspaces/sa5_objective_count_pr36_postmerge_resume_audit_20260805T145438Z"
RESUME_REPORT="$RESUME_ROOT/sa5_objective_count_pr36_postmerge_resume_audit.json"
RESUME_REPORT_SHA="6b4b2b4ff275646a03d35b651d0231eb813b3d2b1ec426ad8dc4af0183d4c22d"
RESUME_SURFACE="$RESUME_ROOT/sa5_objective_count_pr36_postmerge_resume_audit.txt"
RESUME_SURFACE_SHA="a3da6eb4e3971f2589e6808d446b2b35b29b4d25a3208cf589aa41926edb98b9"

TIMING_RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
PRECISION_V1="backend/harness/sensitivity_execution/analyze_clustered_timing_precision.py"
PRECISION_V2="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_stage10_post_merge_analysis_readiness_${STAMP}"
REPORT="$AUDIT_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.json"
SURFACE="$AUDIT_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.txt"
SCHEMA_INVENTORY="$AUDIT_ROOT/sa5_objective_count_stage10_functional_schema_inventory.json"

trap 'echo "[ERROR] SA5 post-merge analysis-readiness audit stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact post-merge state gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

read -r COMMIT P1 P2 EXTRA <<<"$(git rev-list --parents -n 1 "$EXPECTED_HEAD")"
test "$COMMIT" = "$EXPECTED_HEAD"
test "$P1" = "$EXPECTED_FIRST_PARENT"
test "$P2" = "$EXPECTED_SECOND_PARENT"
test -z "${EXTRA:-}"

gh pr view "$PR" --repo "$REPO" \
  --json state,mergedAt,mergeCommit,headRefOid,baseRefName |
jq -e \
  --arg merge "$EXPECTED_HEAD" \
  --arg feature "$EXPECTED_SECOND_PARENT" \
  --arg base "$BASE" \
  '.state=="MERGED"
   and .mergedAt!=null
   and .mergeCommit.oid==$merge
   and .headRefOid==$feature
   and .baseRefName==$base' >/dev/null

verify_sha "$CI_AUDIT" "$CI_AUDIT_SHA"
verify_sha "$RESUME_REPORT" "$RESUME_REPORT_SHA"
verify_sha "$RESUME_SURFACE" "$RESUME_SURFACE_SHA"

jq -e '
  .status=="pr36_postmerge_validation_resumed_and_completed"
  and .merge_commit=="0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .corrected_scope.canonical_run_count==10
  and .corrected_scope.canonical_run_file_count==280
  and .corrected_scope.total_merged_file_count==300
  and .validation.canonical_evidence_integrity=="PASS"
  and .validation.post_merge_full_regression=="PASS"
  and .validation.repository_clean==true
  and .blocker_count==0
  and .resume_complete==true
  and .next_stage=="audit_sa5_objective_count_stage10_post_merge_analysis_readiness"
' "$RESUME_REPORT" >/dev/null

echo "post_merge_state_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "post_merge_regression_preserved=PASS"
echo "repository_clean=true"

echo
echo "=== 2. Frozen functional-evidence gate ==="

verify_sha "$SPEC_MANIFEST" "$SPEC_MANIFEST_SHA"
verify_sha "$EVIDENCE_MANIFEST" "$EVIDENCE_MANIFEST_SHA"
verify_sha "$RUN_FILE_MANIFEST" "$RUN_FILE_MANIFEST_SHA"
verify_sha "$MATERIALIZATION_REPORT" "$MATERIALIZATION_REPORT_SHA"
verify_sha "$MATERIALIZATION_SUMMARY" "$MATERIALIZATION_SUMMARY_SHA"

test "$(wc -l < "$RUN_FILE_MANIFEST")" -eq 280
sha256sum -c "$RUN_FILE_MANIFEST" >/dev/null

jq -e '
  .status=="sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .completion.successful_execution_spec_count==10
  and .completion.failed_execution_spec_count==0
  and .completion.canonical_run_count==10
  and .completion.total_instance_count==60
  and .completion.unique_instance_count==60
  and .completion.total_step_evaluations==1920
  and .completion.canonical_run_file_count==280
  and .completion.canonical_run_total_bytes==25018782
  and .completion.unique_execution_digest_count==10
  and .scientific_controls.functional_execution_completion_audited==true
  and .scientific_controls.functional_execution_evidence_materialized==true
  and .scientific_controls.timing_analysis_performed==false
  and .scientific_controls.precision_analysis_performed==false
  and .scientific_controls.bootstrap_analysis_performed==false
  and .scientific_controls.scientific_result_interpretation_performed==false
  and .scientific_controls.manuscript_modified==false
  and .blocker_count==0
  and .materialization_complete==true
' "$EVIDENCE_MANIFEST" >/dev/null

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "frozen_functional_evidence_gate=PASS"
echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"

echo
echo "=== 3. Structural schema inventory without analysis ==="

rm -rf "$AUDIT_ROOT"
mkdir -p "$AUDIT_ROOT"

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"
export ROOT RUN_ROOT SPEC_MANIFEST SCHEMA_INVENTORY

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


root = Path(os.environ["ROOT"]).resolve()
run_root = root / os.environ["RUN_ROOT"]
spec_manifest_path = root / os.environ["SPEC_MANIFEST"]
inventory_path = Path(os.environ["SCHEMA_INVENTORY"])


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def leaf_paths(value: Any, prefix: str = "") -> set[str]:
    result: set[str] = set()
    if isinstance(value, dict):
        for key, child in value.items():
            child_prefix = f"{prefix}.{key}" if prefix else str(key)
            result.update(leaf_paths(child, child_prefix))
    elif isinstance(value, list):
        marker = f"{prefix}[]" if prefix else "[]"
        result.add(marker)
        for child in value[:5]:
            result.update(leaf_paths(child, marker))
    else:
        result.add(prefix)
    return result


manifest = read_json(spec_manifest_path)
assert manifest["execution_spec_count"] == 10
assert len(manifest["entries"]) == 10

factor_levels: list[int] = []
replications: list[int] = []
instance_ids: list[str] = []
all_keys: set[str] = set()
csv_fields: list[list[str]] = []

json_count = 0
csv_count = 0
timeline_count = 0
metrics_count = 0

for entry in manifest["entries"]:
    spec_path = spec_manifest_path.parent / entry["filename"]
    payload = read_json(spec_path)
    validate_execution_spec(payload)
    inputs = load_execution_inputs(spec_path)

    assert len(inputs.instances) == 6
    assert [x.factor_level for x in inputs.instances] == [1, 2, 5, 10, 20, 50]
    assert inputs.output_dir.is_dir()
    assert inputs.output_dir.parent == run_root.resolve()

    factor_levels.extend(x.factor_level for x in inputs.instances)
    replications.extend(x.replication_index for x in inputs.instances)
    instance_ids.extend(x.canonical_instance_id for x in inputs.instances)

    for filename in (
        "campaign_metrics.json",
        "execution_manifest.json",
        "execution_spec.json",
    ):
        document = read_json(inputs.output_dir / filename)
        all_keys.update(leaf_paths(document))
        json_count += 1

    validate_execution_spec(
        read_json(inputs.output_dir / "execution_spec.json")
    )

    with (inputs.output_dir / "instance_results.csv").open(
        "r", encoding="utf-8", newline=""
    ) as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    assert len(rows) == 6
    assert fields
    csv_fields.append(fields)
    csv_count += 1

    instance_dirs = sorted(
        path
        for path in (inputs.output_dir / "instances").glob("level_*/*")
        if path.is_dir()
    )
    assert len(instance_dirs) == 6

    for instance_dir in instance_dirs:
        for filename in (
            "audit.json",
            "execution_manifest.json",
            "metrics.json",
            "timeline.json",
        ):
            document = read_json(instance_dir / filename)
            all_keys.update(leaf_paths(document))
            json_count += 1

        metrics_count += 1
        timeline_count += 1

assert len(instance_ids) == 60
assert len(set(instance_ids)) == 60
assert Counter(factor_levels) == {
    1: 10, 2: 10, 5: 10, 10: 10, 20: 10, 50: 10
}
assert Counter(replications) == {index: 6 for index in range(10)}
assert json_count == 270
assert csv_count == 10
assert timeline_count == 60
assert metrics_count == 60

timing_tokens = ("time", "timing", "latency", "duration", "elapsed", "perf")
precision_tokens = (
    "bootstrap", "confidence", "quantile", "median", "p95", "precision"
)

timing_keys = sorted(
    key for key in all_keys
    if any(token in key.lower() for token in timing_tokens)
)
precision_keys = sorted(
    key for key in all_keys
    if any(token in key.lower() for token in precision_tokens)
)

inventory = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-functional-schema-inventory-v1"
    ),
    "status": "structural_inventory_complete_without_analysis",
    "run_count": 10,
    "instance_count": 60,
    "factor_level_counts": {
        str(level): count
        for level, count in sorted(Counter(factor_levels).items())
    },
    "replication_counts": {
        str(index): count
        for index, count in sorted(Counter(replications).items())
    },
    "json_file_count": json_count,
    "csv_file_count": csv_count,
    "timeline_file_count": timeline_count,
    "instance_metric_file_count": metrics_count,
    "schema_key_count": len(all_keys),
    "timing_candidate_schema_keys": timing_keys,
    "precision_candidate_schema_keys": precision_keys,
    "instance_results_csv_field_sets": csv_fields,
    "values_aggregated": False,
    "timing_statistics_computed": False,
    "precision_statistics_computed": False,
    "bootstrap_computed": False,
    "scientific_interpretation_performed": False,
}

inventory_path.write_text(
    json.dumps(
        inventory,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

print("functional_schema_inventory=PASS")
print("run_count=10")
print("instance_count=60")
print("json_file_count=270")
print("csv_file_count=10")
print("timeline_file_count=60")
print("instance_metric_file_count=60")
print(f"timing_candidate_key_count={len(timing_keys)}")
print(f"precision_candidate_key_count={len(precision_keys)}")
print("values_aggregated=false")
print("timing_statistics_computed=false")
print("precision_statistics_computed=false")
print("bootstrap_computed=false")
print(
    "schema_inventory_sha256="
    + hashlib.sha256(inventory_path.read_bytes()).hexdigest()
)
PY

echo "structural_schema_inventory_gate=PASS"

echo
echo "=== 4. Tooling and controlled-sequence precedent gate ==="

for FILE in "$TIMING_RUNNER" "$PRECISION_V1" "$PRECISION_V2"; do
  test -f "$FILE"
done

export TIMING_RUNNER PRECISION_V1 PRECISION_V2

"$PYTHON" - <<'PY'
from __future__ import annotations

import ast
import hashlib
import os
from pathlib import Path

for variable in ("TIMING_RUNNER", "PRECISION_V1", "PRECISION_V2"):
    path = Path(os.environ[variable])
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    function_count = sum(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        for node in ast.walk(tree)
    )
    print(f"{variable.lower()}_ast=PASS")
    print(
        f"{variable.lower()}_sha256="
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}"
    )
    print(f"{variable.lower()}_function_count={function_count}")
PY

for SUBJECT in \
  'chore(experiments): preflight membership-density timing preregistration' \
  'chore(experiments): preregister membership-density portfolio timing' \
  'chore(experiments): materialize membership-density timing inputs' \
  'chore(experiments): authorize membership-density Stage-10 timing' \
  'evidence(experiments): persist membership-density Stage-10 timing' \
  'chore(experiments): preregister membership-density precision adapter'
do
  git log --all --format='%s' | grep -Fxq "$SUBJECT"
done

CURRENT_TIMING_PATH_COUNT="$(
  git ls-files |
    grep -Eic \
      '(^|/)(sa5[_-])?objective[_-]count.*stage10.*timing|timing.*(sa5[_-])?objective[_-]count.*stage10' \
    || true
)"

test "$CURRENT_TIMING_PATH_COUNT" -eq 0
test ! -e "$TIMING_RUN_ROOT"

echo "analysis_tooling_precedent_gate=PASS"
echo "controlled_sequence_precedent_stage_count=6"
echo "current_sa5_stage10_timing_path_count=0"
echo "objective_count_stage10_timing_run_root_exists=false"
echo "timing_execution_performed=false"

echo
echo "=== 5. Sequencing and authorization decision ==="

export REPORT SURFACE SCHEMA_INVENTORY
export EXPECTED_HEAD EVIDENCE_MANIFEST_SHA RUN_FILE_MANIFEST_SHA RESUME_REPORT_SHA
export TIMING_RUNNER PRECISION_V1 PRECISION_V2

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])
inventory_path = Path(os.environ["SCHEMA_INVENTORY"])
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-post-merge-analysis-readiness-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_post_merge_analysis_readiness_complete"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "canonical_evidence": {
        "functional_evidence_manifest_sha256": os.environ[
            "EVIDENCE_MANIFEST_SHA"
        ],
        "canonical_run_file_manifest_sha256": os.environ[
            "RUN_FILE_MANIFEST_SHA"
        ],
        "postmerge_resume_audit_sha256": os.environ["RESUME_REPORT_SHA"],
        "run_count": 10,
        "instance_count": 60,
        "functional_step_evaluation_count": 1920,
        "canonical_run_file_count": 280,
        "functional_completion_audited": True,
        "functional_evidence_committed": True,
    },
    "structural_readiness": {
        "schema_inventory_path": str(inventory_path),
        "schema_inventory_sha256": sha(inventory_path),
        "json_file_count": inventory["json_file_count"],
        "csv_file_count": inventory["csv_file_count"],
        "timeline_file_count": inventory["timeline_file_count"],
        "instance_metric_file_count": inventory[
            "instance_metric_file_count"
        ],
        "all_six_factor_levels_covered": True,
        "all_ten_replications_covered": True,
        "values_aggregated": False,
        "timing_statistics_computed": False,
        "precision_statistics_computed": False,
        "bootstrap_computed": False,
    },
    "tooling": {
        "timing_runner": {
            "path": os.environ["TIMING_RUNNER"],
            "sha256": sha(Path(os.environ["TIMING_RUNNER"])),
            "ast_parse": "PASS",
        },
        "precision_analyzer_v1": {
            "path": os.environ["PRECISION_V1"],
            "sha256": sha(Path(os.environ["PRECISION_V1"])),
            "ast_parse": "PASS",
        },
        "precision_analyzer_v2": {
            "path": os.environ["PRECISION_V2"],
            "sha256": sha(Path(os.environ["PRECISION_V2"])),
            "ast_parse": "PASS",
        },
        "controlled_sequence_precedent_stage_count": 6,
        "controlled_sequence_precedent_confirmed": True,
    },
    "sequence_decision": {
        "required_order": [
            "preflight_timing_preregistration",
            "preregister_timing",
            "materialize_timing_inputs",
            "authorize_timing_execution",
            "execute_and_persist_timing",
            "preregister_precision_adapter",
            "materialize_precision_inputs",
            "authorize_precision_analysis",
            "analyze_precision",
            "freeze_stage10_if_precision_targets_met",
        ],
        "timing_preflight_is_next": True,
        "precision_must_not_precede_timing_persistence": True,
        "bootstrap_must_not_precede_precision_authorization": True,
        "scientific_interpretation_must_not_precede_precision_decision": True,
        "manuscript_integration_must_not_precede_scientific_freeze": True,
    },
    "authorization": {
        "timing_preregistration_preflight_authorized": True,
        "timing_preregistration_authorized": False,
        "timing_input_materialization_authorized": False,
        "timing_execution_authorized": False,
        "precision_adapter_preregistration_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "scientific_freeze_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "functional_execution_performed": True,
        "functional_execution_completion_audited": True,
        "functional_execution_evidence_committed": True,
        "timing_execution_performed": False,
        "timing_analysis_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "scientific_freeze_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "readiness_complete": True,
    "next_stage": (
        "preflight_sa5_objective_count_stage10_timing_preregistration"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

surface_path.write_text(
    "\n".join([
        "SA5 OBJECTIVE-COUNT STAGE-10 POST-MERGE ANALYSIS READINESS",
        "=" * 84,
        f"source_commit={report['source_commit']}",
        "functional_execution_performed=true",
        "functional_completion_audited=true",
        "functional_evidence_committed=true",
        "canonical_run_count=10",
        "instance_count=60",
        "functional_step_evaluation_count=1920",
        "canonical_run_file_count=280",
        "structural_schema_inventory=PASS",
        "controlled_sequence_precedent_confirmed=true",
        "timing_preregistration_preflight_authorized=true",
        "timing_preregistration_authorized=false",
        "timing_execution_authorized=false",
        "precision_adapter_preregistration_authorized=false",
        "precision_analysis_authorized=false",
        "bootstrap_analysis_authorized=false",
        "scientific_result_interpretation_authorized=false",
        "scientific_freeze_authorized=false",
        "manuscript_integration_authorized=false",
        "timing_execution_performed=false",
        "precision_analysis_performed=false",
        "bootstrap_analysis_performed=false",
        "manuscript_modified=false",
        "blocker_count=0",
        "readiness_complete=true",
        f"next_stage={report['next_stage']}",
        "",
    ]),
    encoding="utf-8",
)

print("analysis_readiness_decision=PASS")
print("timing_preregistration_preflight_authorized=true")
print("timing_preregistration_authorized=false")
print("timing_execution_authorized=false")
print("precision_analysis_authorized=false")
print("bootstrap_analysis_authorized=false")
print("scientific_result_interpretation_authorized=false")
print("scientific_freeze_authorized=false")
print("manuscript_integration_authorized=false")
print(f"report={report_path}")
print(f"report_sha256={sha(report_path)}")
print(f"surface={surface_path}")
print(f"surface_sha256={sha(surface_path)}")
print(f"next_stage={report['next_stage']}")
PY

echo
echo "=== 6. Validate readiness report ==="

jq -e '
  .status=="sa5_objective_count_stage10_post_merge_analysis_readiness_complete"
  and .source_commit=="0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .canonical_evidence.run_count==10
  and .canonical_evidence.instance_count==60
  and .canonical_evidence.functional_step_evaluation_count==1920
  and .canonical_evidence.canonical_run_file_count==280
  and .canonical_evidence.functional_completion_audited==true
  and .canonical_evidence.functional_evidence_committed==true
  and .structural_readiness.all_six_factor_levels_covered==true
  and .structural_readiness.all_ten_replications_covered==true
  and .structural_readiness.values_aggregated==false
  and .structural_readiness.timing_statistics_computed==false
  and .structural_readiness.precision_statistics_computed==false
  and .structural_readiness.bootstrap_computed==false
  and .tooling.controlled_sequence_precedent_confirmed==true
  and .sequence_decision.timing_preflight_is_next==true
  and .sequence_decision.precision_must_not_precede_timing_persistence==true
  and .sequence_decision.bootstrap_must_not_precede_precision_authorization==true
  and .sequence_decision.manuscript_integration_must_not_precede_scientific_freeze==true
  and .authorization.timing_preregistration_preflight_authorized==true
  and .authorization.timing_preregistration_authorized==false
  and .authorization.timing_input_materialization_authorized==false
  and .authorization.timing_execution_authorized==false
  and .authorization.precision_adapter_preregistration_authorized==false
  and .authorization.precision_analysis_authorized==false
  and .authorization.bootstrap_analysis_authorized==false
  and .authorization.scientific_result_interpretation_authorized==false
  and .authorization.scientific_freeze_authorized==false
  and .authorization.manuscript_integration_authorized==false
  and .scientific_controls.timing_execution_performed==false
  and .scientific_controls.precision_analysis_performed==false
  and .scientific_controls.bootstrap_analysis_performed==false
  and .scientific_controls.scientific_result_interpretation_performed==false
  and .scientific_controls.scientific_freeze_performed==false
  and .scientific_controls.manuscript_modified==false
  and .blocker_count==0
  and .readiness_complete==true
  and .next_stage=="preflight_sa5_objective_count_stage10_timing_preregistration"
' "$REPORT" >/dev/null

echo "analysis_readiness_report_validation=PASS"

echo
echo "=== 7. Repository and manuscript immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
verify_sha "$EVIDENCE_MANIFEST" "$EVIDENCE_MANIFEST_SHA"
verify_sha "$RUN_FILE_MANIFEST" "$RUN_FILE_MANIFEST_SHA"
sha256sum -c "$RUN_FILE_MANIFEST" >/dev/null
test ! -e "$TIMING_RUN_ROOT"
test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

echo "sa5_objective_count_stage10_post_merge_analysis_readiness=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$(sha256sum "$REPORT" | awk '{print $1}')"
echo "surface=$SURFACE"
echo "surface_sha256=$(sha256sum "$SURFACE" | awk '{print $1}')"
echo "schema_inventory=$SCHEMA_INVENTORY"
echo "schema_inventory_sha256=$(sha256sum "$SCHEMA_INVENTORY" | awk '{print $1}')"
echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"
echo "timing_preregistration_preflight_authorized=true"
echo "timing_preregistration_authorized=false"
echo "timing_execution_authorized=false"
echo "precision_adapter_preregistration_authorized=false"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"
echo "blocker_count=0"
echo "readiness_complete=true"
echo "next_stage=preflight_sa5_objective_count_stage10_timing_preregistration"

git status --short --branch
