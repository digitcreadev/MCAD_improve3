#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
BRANCH="paper/analyze-virtual-node-count-stage10-precision-20260802T175624Z"
EXPECTED_HEAD="f4b270c4092905d721476015f384c46b864d8182"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"

TIMING_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution/formal_timing_execution_report.json"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis"

OBSERVATIONS="$PRECISION_ROOT/stage10_measurement_observations.csv"
ADAPTER="$PRECISION_ROOT/analyzer_timing_report_adapter.json"
INPUT_MANIFEST="$PRECISION_ROOT/precision_input_manifest.json"

FAILED_LOG="$PRECISION_ROOT/analyzer_failed_schema.log"
ANALYZER_LOG="$PRECISION_ROOT/analyzer.log"

INTERVALS="$PRECISION_ROOT/clustered_precision_intervals.csv"
RAW_REPORT="$PRECISION_ROOT/raw_analyzer_report.json"
RAW_MD="$PRECISION_ROOT/raw_analyzer_report.md"

DECISION="$PRECISION_ROOT/stage10_precision_decision_report.json"
DECISION_MD="$PRECISION_ROOT/stage10_precision_decision_report.md"

trap 'echo "[ERROR] Precision recovery stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

git diff --quiet
git diff --cached --quiet

test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$PREREG"
test -f "$TIMING_REPORT"
test -f "$OBSERVATIONS"
test -f "$ADAPTER"
test -f "$INPUT_MANIFEST"
test -f "$ANALYZER_LOG"

test ! -e "$FAILED_LOG"
test ! -e "$INTERVALS"
test ! -e "$RAW_REPORT"
test ! -e "$RAW_MD"
test ! -e "$DECISION"
test ! -e "$DECISION_MD"

for FILE in \
  "$ADAPTER" \
  "$ANALYZER_LOG" \
  "$INPUT_MANIFEST" \
  "$OBSERVATIONS"
do
  test -f "$FILE"
  git check-ignore -q "$FILE"
done

echo "prepared_precision_inputs_exist=true"
echo "prepared_precision_inputs_are_ignored=true"

grep -q \
  "formal_replication_index" \
  "$ANALYZER_LOG"

echo "recovery_gate=PASS"
echo "previous_analyzer_attempt_successful=false"
echo "bootstrap_previously_performed=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"

echo
echo "=== 2. Preserve failed schema-validation log ==="

mv "$ANALYZER_LOG" "$FAILED_LOG"

test -f "$FAILED_LOG"
test ! -e "$ANALYZER_LOG"

echo "failed_schema_log_preserved=PASS"

echo
echo "=== 3. Repair formal observation schema ==="

REPAIRED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$OBSERVATIONS" \
  "$INPUT_MANIFEST" \
  "$TIMING_REPORT" \
  "$FAILED_LOG" \
  "$REPAIRED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
observations_path = root / sys.argv[2]
manifest_path = root / sys.argv[3]
timing_report_path = root / sys.argv[4]
failed_log_path = root / sys.argv[5]
repaired_utc = sys.argv[6]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


manifest = load_json(manifest_path)
timing_report = load_json(timing_report_path)

old_sha256 = sha256_file(observations_path)
recorded_sha256 = manifest["observations"]["sha256"]

if old_sha256 != recorded_sha256:
    raise SystemExit(
        "Prepared observation SHA-256 differs "
        "from the input manifest."
    )

with observations_path.open(
    "r",
    encoding="utf-8",
    newline="",
) as stream:
    reader = csv.DictReader(stream)
    original_fields = list(
        reader.fieldnames or ()
    )
    rows = list(reader)

if not original_fields:
    raise SystemExit(
        "Prepared observation CSV lacks a header."
    )

formal_fields = [
    "formal_replication_index",
    "formal_structural_seed",
    "formal_order_seed",
]

unexpected_existing = [
    field
    for field in formal_fields
    if field in original_fields
]

if unexpected_existing:
    raise SystemExit(
        "Formal fields already exist unexpectedly: "
        f"{unexpected_existing}"
    )

if len(rows) != 6000:
    raise SystemExit(
        f"Expected 6000 rows, got {len(rows)}."
    )

replication_reports = timing_report.get(
    "replications"
)

if not isinstance(replication_reports, list):
    raise SystemExit(
        "Timing report lacks replication records."
    )

if len(replication_reports) != 10:
    raise SystemExit(
        "Expected ten replication records."
    )

metadata_by_replication = {
    int(item["replication_index"]): {
        "structural_seed": int(
            item["structural_seed"]
        ),
        "order_seed": int(
            item["execution_order_seed"]
        ),
    }
    for item in replication_reports
}

if sorted(metadata_by_replication) != list(range(10)):
    raise SystemExit(
        "Timing-report replication matrix is incomplete."
    )

cell_counts: Counter[
    tuple[int, int, int]
] = Counter()

repaired_rows: list[dict[str, str]] = []

for csv_row_number, row in enumerate(
    rows,
    start=2,
):
    if row.get("phase") != "measurement":
        raise SystemExit(
            f"Non-measurement row at {csv_row_number}."
        )

    try:
        replication = int(
            row["replication_index"]
        )
        source_seed = int(row["seed"])
        level = int(row["factor_level"])
        step = int(row["step_index"])
        latency = float(row["wall_latency_ms"])
    except (
        KeyError,
        TypeError,
        ValueError,
    ) as exc:
        raise SystemExit(
            f"Invalid row {csv_row_number}: {exc}"
        ) from exc

    if replication not in metadata_by_replication:
        raise SystemExit(
            f"Unexpected replication {replication}."
        )

    metadata = metadata_by_replication[
        replication
    ]

    if source_seed != metadata["structural_seed"]:
        raise SystemExit(
            f"Replication {replication}: "
            "source seed differs from timing report."
        )

    if level not in {6, 12, 24}:
        raise SystemExit(
            f"Unexpected factor level {level}."
        )

    if step not in {1, 2}:
        raise SystemExit(
            f"Unexpected step index {step}."
        )

    if latency <= 0.0:
        raise SystemExit(
            f"Non-positive latency at row "
            f"{csv_row_number}."
        )

    repaired = {
        "formal_replication_index": str(
            replication
        ),
        "formal_structural_seed": str(
            metadata["structural_seed"]
        ),
        "formal_order_seed": str(
            metadata["order_seed"]
        ),
    }

    repaired.update(row)
    repaired_rows.append(repaired)

    cell_counts[
        (
            replication,
            level,
            step,
        )
    ] += 1

expected_cells = {
    (replication, level, step)
    for replication in range(10)
    for level in (6, 12, 24)
    for step in (1, 2)
}

if set(cell_counts) != expected_cells:
    raise SystemExit(
        "Repaired observation matrix is incomplete."
    )

invalid_counts = {
    cell: count
    for cell, count in cell_counts.items()
    if count != 100
}

if invalid_counts:
    raise SystemExit(
        f"Unbalanced cells: {invalid_counts}"
    )

new_fields = formal_fields + original_fields
temporary_path = observations_path.with_suffix(
    ".csv.repaired.tmp"
)

with temporary_path.open(
    "w",
    encoding="utf-8",
    newline="",
) as stream:
    writer = csv.DictWriter(
        stream,
        fieldnames=new_fields,
        lineterminator="\n",
    )

    writer.writeheader()
    writer.writerows(repaired_rows)

os.replace(
    temporary_path,
    observations_path,
)

new_sha256 = sha256_file(
    observations_path
)

if new_sha256 == old_sha256:
    raise SystemExit(
        "Schema repair did not change the CSV digest."
    )

manifest["schema_version"] = (
    "mcad-virtual-node-count-stage10-"
    "precision-input-manifest-v2"
)

manifest["observations"].update(
    {
        "sha256": new_sha256,
        "column_count": len(new_fields),
        "columns": new_fields,
        "formal_replication_column": (
            "formal_replication_index"
        ),
        "formal_structural_seed_column": (
            "formal_structural_seed"
        ),
        "formal_order_seed_column": (
            "formal_order_seed"
        ),
        "schema_matches_v2_analyzer": True,
    }
)

manifest["schema_repair"] = {
    "status": "pass",
    "repaired_utc": repaired_utc,
    "reason": (
        "The immutable v2 analyzer requires "
        "formal replication, structural-seed and "
        "order-seed columns matching the validated "
        "constraint-count aggregate precedent."
    ),
    "source_observations_sha256": old_sha256,
    "repaired_observations_sha256": new_sha256,
    "added_columns": formal_fields,
    "row_count": 6000,
    "cell_count": 60,
    "measurements_per_cluster_and_cell": 100,
    "failed_attempt_log_path": (
        failed_log_path
        .relative_to(root)
        .as_posix()
    ),
    "failed_attempt_log_sha256": sha256_file(
        failed_log_path
    ),
    "failed_attempt_reached_bootstrap": False,
}

manifest["execution_state"] = {
    "analyzer_invocation_attempt_count": 1,
    "successful_analyzer_invocation_count": 0,
    "bootstrap_execution_count": 0,
    "precision_analysis_performed": False,
    "functional_execution_rerun_performed": False,
    "timing_execution_rerun_performed": False,
}

write_json(manifest_path, manifest)

print("precision_input_schema_repair=PASS")
print(
    "added_columns="
    "formal_replication_index,"
    "formal_structural_seed,"
    "formal_order_seed"
)
print("measurement_observation_count=6000")
print("structural_replication_count=10")
print("precision_cell_count=6")
print("cluster_cell_count=60")
print("measurements_per_cluster_and_cell=100")
print("failed_attempt_reached_bootstrap=false")
print("precision_analysis_performed=false")
PY

echo
echo "=== 4. Execute preregistered analyzer ==="

if PYTHONPATH="$ROOT" \
  "$PYTHON" "$ANALYZER" \
    --stage-size 10 \
    --observations "$OBSERVATIONS" \
    --timing-report "$ADAPTER" \
    --intervals-csv "$INTERVALS" \
    --report-json "$RAW_REPORT" \
    --report-md "$RAW_MD" \
    --levels "6,12,24" \
    --steps "1,2" \
    --measurements-per-cluster 100 \
    --bootstrap-repetitions 10000 \
    --bootstrap-seed 20260728 \
    --confidence-level 0.95 \
    --median-target 0.10 \
    --p95-target 0.15 \
    >"$ANALYZER_LOG" 2>&1
then
  ANALYZER_STATUS=0
else
  ANALYZER_STATUS=$?
fi

cat "$ANALYZER_LOG"

echo "analyzer_exit_status=$ANALYZER_STATUS"

test "$ANALYZER_STATUS" -eq 0
test -f "$INTERVALS"
test -f "$RAW_REPORT"
test -f "$RAW_MD"

echo "clustered_precision_analyzer_execution=PASS"
echo "successful_bootstrap_execution_count=1"
echo "precision_analysis_performed=true"

echo
echo "=== 5. Validate precision result and create decision ==="

COMPLETED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

"$PYTHON" - \
  "$ROOT" \
  "$ANALYZER" \
  "$PREREG" \
  "$OBSERVATIONS" \
  "$ADAPTER" \
  "$INPUT_MANIFEST" \
  "$FAILED_LOG" \
  "$ANALYZER_LOG" \
  "$INTERVALS" \
  "$RAW_REPORT" \
  "$RAW_MD" \
  "$DECISION" \
  "$DECISION_MD" \
  "$BRANCH" \
  "$COMPLETED_UTC" <<'PY'
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
analyzer_path = root / sys.argv[2]
prereg_path = root / sys.argv[3]
observations_path = root / sys.argv[4]
adapter_path = root / sys.argv[5]
manifest_path = root / sys.argv[6]
failed_log_path = root / sys.argv[7]
analyzer_log_path = root / sys.argv[8]
intervals_path = root / sys.argv[9]
raw_report_path = root / sys.argv[10]
raw_md_path = root / sys.argv[11]
decision_path = root / sys.argv[12]
decision_md_path = root / sys.argv[13]
branch = sys.argv[14]
completed_utc = sys.argv[15]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


spec = importlib.util.spec_from_file_location(
    "mcad_precision_v2_validation",
    analyzer_path,
)

if spec is None or spec.loader is None:
    raise SystemExit(
        "Unable to import precision analyzer."
    )

module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

contract = module.stage_contract(10)

prereg = load_json(prereg_path)
manifest = load_json(manifest_path)
raw = load_json(raw_report_path)

precision_protocol = prereg[
    "precision_protocol"
]

analyzer_sha256 = sha256_file(
    analyzer_path
)

if (
    analyzer_sha256
    != precision_protocol["analyzer_sha256"]
):
    raise SystemExit(
        "Analyzer SHA-256 differs from preregistration."
    )

if raw.get("stage_size") != 10:
    raise SystemExit(
        "Expected Stage-10 analyzer output."
    )

if raw.get("structural_seed_count") != 10:
    raise SystemExit(
        "Expected ten structural-seed clusters."
    )

if raw.get("scientific_freeze") is not False:
    raise SystemExit(
        "Scientific freeze must remain false."
    )

if raw.get(
    "latency_claim_authorized"
) is not False:
    raise SystemExit(
        "Latency claims must remain unauthorized."
    )

bootstrap = raw.get(
    "bootstrap_contract",
    {},
)

expected_bootstrap = {
    "unit_of_resampling": (
        "structural seed cluster"
    ),
    "within_cluster_measurements": (
        "retained together"
    ),
    "bootstrap_repetitions": 10000,
    "bootstrap_seed": 20260728,
    "confidence_level": 0.95,
    "median_relative_half_width_target": 0.10,
    "p95_relative_half_width_target": 0.15,
}

for key, expected_value in expected_bootstrap.items():
    actual = bootstrap.get(key)

    if actual != expected_value:
        raise SystemExit(
            f"Bootstrap {key}: expected "
            f"{expected_value!r}, got {actual!r}"
        )

inputs = raw.get("inputs", {})

if inputs.get("observation_count") != 6000:
    raise SystemExit(
        "Analyzer did not consume 6000 observations."
    )

if (
    inputs.get("observations_sha256")
    != sha256_file(observations_path)
):
    raise SystemExit(
        "Observation SHA-256 mismatch."
    )

if (
    inputs.get("timing_report_sha256")
    != sha256_file(adapter_path)
):
    raise SystemExit(
        "Adapter SHA-256 mismatch."
    )

cells = raw.get("cell_results")

if not isinstance(cells, list):
    raise SystemExit(
        "Analyzer output lacks cell results."
    )

if len(cells) != 6:
    raise SystemExit(
        f"Expected six precision cells, "
        f"got {len(cells)}."
    )

expected_cells = {
    (level, step)
    for level in (6, 12, 24)
    for step in (1, 2)
}

observed_cells = {
    (
        int(row["factor_level"]),
        int(row["step_index"]),
    )
    for row in cells
}

if observed_cells != expected_cells:
    raise SystemExit(
        f"Unexpected precision cells: "
        f"{observed_cells}"
    )

with intervals_path.open(
    "r",
    encoding="utf-8",
    newline="",
) as stream:
    interval_rows = list(
        csv.DictReader(stream)
    )

if len(interval_rows) != 6:
    raise SystemExit(
        f"Expected six interval rows, "
        f"got {len(interval_rows)}."
    )

all_targets = raw.get(
    "all_precision_targets_met"
)

sufficient = raw.get(
    contract["sufficient_key"]
)

extension_required = raw.get(
    contract["extension_key"]
)

for label, value in (
    ("all targets", all_targets),
    ("Stage-10 sufficiency", sufficient),
    ("extension decision", extension_required),
):
    if not isinstance(value, bool):
        raise SystemExit(
            f"Missing boolean {label}."
        )

if sufficient != all_targets:
    raise SystemExit(
        "Stage sufficiency differs from "
        "the all-target result."
    )

if extension_required == sufficient:
    raise SystemExit(
        "Invalid sufficiency/extension relation."
    )

expected_status = (
    contract["success_status"]
    if sufficient
    else contract["failure_status"]
)

if raw.get("status") != expected_status:
    raise SystemExit(
        "Analyzer status differs from gate result."
    )

failing_cell_count = int(
    raw["failing_cell_count"]
)

if sufficient and failing_cell_count != 0:
    raise SystemExit(
        "Sufficient Stage-10 has failing cells."
    )

if (
    not sufficient
    and failing_cell_count <= 0
):
    raise SystemExit(
        "Insufficient Stage-10 lacks failing cells."
    )

if sufficient:
    campaign_gate = (
        "stage10_precision_sufficient"
    )
    next_stage = (
        "prepare_virtual_node_count_stage10_freeze"
    )
else:
    campaign_gate = (
        "stage10_precision_insufficient"
    )
    next_stage = (
        "prepare_virtual_node_count_stage20_authorization"
    )

decision = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "precision-decision-v1"
    ),
    "status": "pass",
    "campaign_id": (
        "virtual_node_count_stage10_c4"
    ),
    "factor": "virtual_node_count",
    "analysis_branch": branch,
    "completed_utc": completed_utc,
    "analysis": {
        "performed": True,
        "successful_bootstrap_execution_count": 1,
        "analyzer_path": (
            analyzer_path
            .relative_to(root)
            .as_posix()
        ),
        "analyzer_sha256": analyzer_sha256,
        "analyzer_sha256_matches_preregistration": (
            True
        ),
        "observations_path": (
            observations_path
            .relative_to(root)
            .as_posix()
        ),
        "observations_sha256": sha256_file(
            observations_path
        ),
        "raw_report_path": (
            raw_report_path
            .relative_to(root)
            .as_posix()
        ),
        "raw_report_sha256": sha256_file(
            raw_report_path
        ),
        "intervals_csv_path": (
            intervals_path
            .relative_to(root)
            .as_posix()
        ),
        "intervals_csv_sha256": sha256_file(
            intervals_path
        ),
        "analyzer_log_path": (
            analyzer_log_path
            .relative_to(root)
            .as_posix()
        ),
        "analyzer_log_sha256": sha256_file(
            analyzer_log_path
        ),
        "failed_schema_attempt_log_path": (
            failed_log_path
            .relative_to(root)
            .as_posix()
        ),
        "failed_schema_attempt_log_sha256": (
            sha256_file(failed_log_path)
        ),
        "failed_schema_attempt_reached_bootstrap": (
            False
        ),
    },
    "bootstrap_contract": bootstrap,
    "replication_count": 10,
    "structural_seed_count": 10,
    "timing_cell_count": 60,
    "precision_cell_count": 6,
    "measurement_observation_count": 6000,
    "all_median_targets_met": raw[
        "all_median_targets_met"
    ],
    "all_p95_targets_met": raw[
        "all_p95_targets_met"
    ],
    "all_precision_targets_met": all_targets,
    "failing_cell_count": failing_cell_count,
    "failing_cells": raw["failing_cells"],
    "stage10_sufficient": sufficient,
    "stage20_extension_required": (
        extension_required
    ),
    "campaign_gate": campaign_gate,
    "raw_analyzer_next_stage": raw[
        "next_stage"
    ],
    "scientific_constraints": {
        "functional_execution_rerun_performed": False,
        "timing_execution_rerun_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze_authorized": False,
    },
    "next_stage": next_stage,
}

write_json(decision_path, decision)

markdown_lines = [
    (
        "# Virtual-node-count Stage-10 "
        "precision analysis"
    ),
    "",
    "- Status: `PASS`",
    "- Structural-seed clusters: `10`",
    "- Measurement observations: `6000`",
    "- Bootstrap repetitions: `10000`",
    "- Confidence level: `95%`",
    (
        "- All precision targets met: "
        f"`{str(all_targets).lower()}`"
    ),
    (
        "- Failing precision cells: "
        f"`{failing_cell_count}`"
    ),
    (
        "- Stage-10 sufficient: "
        f"`{str(sufficient).lower()}`"
    ),
    (
        "- Stage-20 extension required: "
        f"`{str(extension_required).lower()}`"
    ),
    "- Stage-20 execution authorized: `false`",
    "- Latency claims authorized: `false`",
    "- Scientific freeze authorized: `false`",
    "",
    (
        "| Level | Step | Median RHW | "
        "p95 RHW | Pass |"
    ),
    "|---:|---:|---:|---:|---|",
]

for row in sorted(
    cells,
    key=lambda item: (
        int(item["factor_level"]),
        int(item["step_index"]),
    ),
):
    markdown_lines.append(
        f"| {row['factor_level']} "
        f"| {row['step_index']} "
        f"| "
        f"{float(row['median_relative_half_width']):.2%} "
        f"| "
        f"{float(row['p95_relative_half_width']):.2%} "
        f"| {row['all_cell_targets_met']} |"
    )

markdown_lines.extend(
    [
        "",
        "## Next stage",
        "",
        f"`{next_stage}`",
        "",
    ]
)

decision_md_path.write_text(
    "\n".join(markdown_lines),
    encoding="utf-8",
)

manifest["execution_state"] = {
    "analyzer_invocation_attempt_count": 2,
    "successful_analyzer_invocation_count": 1,
    "bootstrap_execution_count": 1,
    "precision_analysis_performed": True,
    "functional_execution_rerun_performed": False,
    "timing_execution_rerun_performed": False,
}

manifest["analysis_outputs"] = {
    "analyzer_log_path": (
        analyzer_log_path
        .relative_to(root)
        .as_posix()
    ),
    "analyzer_log_sha256": sha256_file(
        analyzer_log_path
    ),
    "intervals_csv_path": (
        intervals_path
        .relative_to(root)
        .as_posix()
    ),
    "intervals_csv_sha256": sha256_file(
        intervals_path
    ),
    "raw_report_path": (
        raw_report_path
        .relative_to(root)
        .as_posix()
    ),
    "raw_report_sha256": sha256_file(
        raw_report_path
    ),
    "raw_markdown_path": (
        raw_md_path
        .relative_to(root)
        .as_posix()
    ),
    "raw_markdown_sha256": sha256_file(
        raw_md_path
    ),
    "decision_report_path": (
        decision_path
        .relative_to(root)
        .as_posix()
    ),
    "decision_report_sha256": sha256_file(
        decision_path
    ),
}

write_json(manifest_path, manifest)

print("stage10_precision_analysis_validation=PASS")
print("structural_seed_count=10")
print("precision_cell_count=6")
print("measurement_observation_count=6000")
print("bootstrap_repetitions=10000")
print(
    "all_median_targets_met="
    f"{str(raw['all_median_targets_met']).lower()}"
)
print(
    "all_p95_targets_met="
    f"{str(raw['all_p95_targets_met']).lower()}"
)
print(
    "all_precision_targets_met="
    f"{str(all_targets).lower()}"
)
print(
    f"failing_cell_count={failing_cell_count}"
)
print(
    "stage10_sufficient="
    f"{str(sufficient).lower()}"
)
print(
    "stage20_extension_required="
    f"{str(extension_required).lower()}"
)
print("stage20_execution_authorized=false")
print("latency_claim_authorized=false")
print("scientific_freeze_authorized=false")
print("successful_bootstrap_execution_count=1")
print("functional_execution_rerun_performed=false")
print("timing_execution_rerun_performed=false")
print("precision_analysis_performed=true")
print(f"next_stage={next_stage}")
PY

echo
echo "=== 6. Commit precision evidence ==="

git add -f "$PRECISION_ROOT"

git diff --cached --check -- \
  . \
  ":(exclude)$INTERVALS"

echo "non_generated_csv_diff_check=PASS"

git diff --cached --stat

git commit \
  -m "evidence(experiments): analyze virtual-node-count Stage-10 precision"

COMMIT="$(git rev-parse HEAD)"

echo "commit=$COMMIT"
echo "commit=PASS"

echo
echo "=== 7. Push precision branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

ALL_TARGETS="$(
  jq -r \
    '.all_precision_targets_met' \
    "$DECISION"
)"

STAGE10_SUFFICIENT="$(
  jq -r \
    '.stage10_sufficient' \
    "$DECISION"
)"

EXTENSION_REQUIRED="$(
  jq -r \
    '.stage20_extension_required' \
    "$DECISION"
)"

FAILING_CELL_COUNT="$(
  jq -r \
    '.failing_cell_count' \
    "$DECISION"
)"

NEXT_STAGE="$(
  jq -r \
    '.next_stage' \
    "$DECISION"
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Analyze virtual-node-count Stage-10 timing precision" \
    --body "$(cat <<EOF
## Scope

- repairs the formal aggregate schema using the validated timing precedent;
- preserves the failed pre-bootstrap schema-validation log;
- consolidates 6000 formal measurement observations;
- executes the preregistered structural-seed cluster bootstrap;
- uses 10000 bootstrap repetitions and a 95% confidence level;
- evaluates all six virtual-node-count level-step cells;
- performs no functional or timing rerun.

## Precision result

- all targets met: \`$ALL_TARGETS\`;
- failing cells: \`$FAILING_CELL_COUNT\`;
- Stage-10 sufficient: \`$STAGE10_SUFFICIENT\`;
- Stage-20 extension required: \`$EXTENSION_REQUIRED\`;
- Stage-20 execution authorized: \`false\`;
- latency claims authorized: \`false\`;
- scientific freeze authorized: \`false\`.

## Next stage

\`$NEXT_STAGE\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

echo "virtual_node_count_stage10_precision_analysis=PASS"
echo "commit=$COMMIT"
echo "measurement_observation_count=6000"
echo "precision_cell_count=6"
echo "all_precision_targets_met=$ALL_TARGETS"
echo "failing_cell_count=$FAILING_CELL_COUNT"
echo "stage10_sufficient=$STAGE10_SUFFICIENT"
echo "stage20_extension_required=$EXTENSION_REQUIRED"
echo "stage20_execution_authorized=false"
echo "successful_bootstrap_execution_count=1"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_performed=true"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_precision_analysis"

git status --short --branch
git log --oneline --decorate -4
