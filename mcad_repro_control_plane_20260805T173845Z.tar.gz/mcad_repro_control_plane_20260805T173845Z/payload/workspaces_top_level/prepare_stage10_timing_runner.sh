#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="f2942f1c895c7643332f89490e68bd17ea88f9b2"
REPO="digitcreadev/MCAD_improve3"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TOOL="backend/harness/sensitivity_execution/tools/prepare_virtual_node_count_stage10_timing_plan.py"
TEST="backend/harness/sensitivity_execution/tests/test_virtual_node_count_stage10_timing_plan.py"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_preregistration.json"
AUTH="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_authorization.json"
FUNCTIONAL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/functional_completion/combined_60_functional_steps_audit.json"

PLAN="reports/article_experiments/sensitivity/e3_controlled_execution/planning/virtual_node_count_stage10_timing_execution_plan.json"

AUDIT_DIR="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_preparation"
AUDIT_JSON="$AUDIT_DIR/timing_runner_validation.json"
AUDIT_MD="$AUDIT_DIR/timing_runner_validation.md"

trap 'echo "[ERROR] Timing-runner preparation stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PREREG"
test -f "$AUTH"
test -f "$FUNCTIONAL"
test ! -e "$PLAN"

echo "branch=$BASE"
echo "head=$EXPECTED_HEAD"
echo "repository_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"

echo
echo "=== 2. Create preparation branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
BRANCH="paper/prepare-virtual-node-count-stage10-timing-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Create timing-plan preparer ==="

mkdir -p "$(dirname "$TOOL")"
mkdir -p "$(dirname "$TEST")"

cat > "$TOOL" <<'PY'
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[4]

E3 = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution"
)

PREREGISTRATION = (
    E3
    / "planning"
    / "virtual_node_count_stage10_preregistration.json"
)

AUTHORIZATION = (
    E3
    / "planning"
    / "virtual_node_count_stage10_timing_authorization.json"
)

FUNCTIONAL_AUDIT = (
    E3
    / "audits"
    / "virtual_node_count_stage10"
    / "functional_completion"
    / "combined_60_functional_steps_audit.json"
)

PLAN = (
    E3
    / "planning"
    / "virtual_node_count_stage10_timing_execution_plan.json"
)

VALIDATION_JSON = (
    E3
    / "audits"
    / "virtual_node_count_stage10"
    / "timing_preparation"
    / "timing_runner_validation.json"
)

VALIDATION_MD = (
    E3
    / "audits"
    / "virtual_node_count_stage10"
    / "timing_preparation"
    / "timing_runner_validation.md"
)


def load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise SystemExit(
            f"[ERROR] Missing JSON artifact: {path}"
        )

    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"[ERROR] Expected JSON object: {path}"
        )

    return payload


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(
        text.encode("utf-8")
    ).hexdigest()


def require(
    condition: bool,
    message: str,
) -> None:
    if not condition:
        raise SystemExit(f"[ERROR] {message}")


def expected_run_stem(
    replication_index: int,
) -> str:
    if replication_index < 2:
        return (
            "virtual_node_count_"
            f"rep_{replication_index:03d}_strict_common"
        )

    return (
        "virtual_node_count_stage10_"
        f"rep_{replication_index:03d}_strict_common"
    )


def main() -> int:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--repo-root",
        type=Path,
        default=ROOT,
    )

    parser.add_argument(
        "--created-utc",
        required=True,
    )

    args = parser.parse_args()
    root = args.repo_root.resolve()

    preregistration = load_json(
        root / PREREGISTRATION
    )
    authorization = load_json(
        root / AUTHORIZATION
    )
    functional = load_json(
        root / FUNCTIONAL_AUDIT
    )

    campaign = preregistration.get(
        "campaign_contract",
        {},
    )
    timing = preregistration.get(
        "timing_protocol",
        {},
    )
    precision = preregistration.get(
        "precision_protocol",
        {},
    )

    runner_relative = Path(
        timing.get("runner_path", "")
    )
    analyzer_relative = Path(
        precision.get("analyzer_path", "")
    )

    runner_path = root / runner_relative
    analyzer_path = root / analyzer_relative

    require(
        runner_path.is_file(),
        f"Missing timing runner: {runner_path}",
    )
    require(
        analyzer_path.is_file(),
        f"Missing precision analyzer: {analyzer_path}",
    )

    runner_sha256 = sha256_file(runner_path)
    analyzer_sha256 = sha256_file(analyzer_path)

    require(
        runner_sha256
        == timing.get("runner_sha256"),
        "Timing runner SHA-256 differs from preregistration.",
    )
    require(
        analyzer_sha256
        == precision.get("analyzer_sha256"),
        "Precision analyzer SHA-256 differs from preregistration.",
    )

    help_result = subprocess.run(
        [
            sys.executable,
            str(runner_path),
            "--help",
        ],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
    )

    require(
        help_result.returncode == 0,
        (
            "Timing runner --help failed:\n"
            + help_result.stderr
        ),
    )

    cli_options = sorted(
        set(
            re.findall(
                r"--[a-zA-Z0-9][a-zA-Z0-9_-]*",
                help_result.stdout,
            )
        )
    )

    require(
        bool(cli_options),
        "No CLI options discovered in runner help.",
    )

    expected_campaign = (
        "virtual_node_count_stage10_c4"
    )

    require(
        campaign.get("campaign_id")
        == expected_campaign,
        "Unexpected campaign identifier.",
    )
    require(
        campaign.get("levels") == [6, 12, 24],
        "Unexpected virtual-node-count levels.",
    )
    require(
        campaign.get("stage10_replication_count")
        == 10,
        "Expected 10 Stage-10 replications.",
    )

    seeds = campaign.get("stage10_seeds")

    require(
        isinstance(seeds, list)
        and len(seeds) == 10,
        "Expected 10 Stage-10 structural seeds.",
    )

    require(
        timing.get("warmups_per_cell") == 10,
        "Expected 10 warmups per cell.",
    )
    require(
        timing.get("measurements_per_cell") == 100,
        "Expected 100 measurements per cell.",
    )
    require(
        timing.get("expected_cell_count") == 60,
        "Expected 60 timing cells.",
    )
    require(
        timing.get(
            "expected_warmup_observation_count"
        )
        == 600,
        "Expected 600 warmup observations.",
    )
    require(
        timing.get(
            "expected_measurement_observation_count"
        )
        == 6000,
        "Expected 6000 measurement observations.",
    )
    require(
        timing.get("order_seed_base") == 20260728,
        "Unexpected timing-order seed base.",
    )
    require(
        timing.get("reuse_successful") is True,
        "Successful-output reuse must be enabled.",
    )
    require(
        timing.get("fresh_ckg_state_required")
        is True,
        "Fresh CKG state must be required.",
    )
    require(
        timing.get(
            "functional_digest_check_required"
        )
        is True,
        "Functional digest check must be required.",
    )

    require(
        authorization.get("status")
        == "authorized",
        "Formal timing authorization is absent.",
    )
    require(
        authorization.get("campaign_id")
        == expected_campaign,
        "Authorization campaign mismatch.",
    )

    scope = authorization.get("scope", {})
    execution_state = authorization.get(
        "execution_state",
        {},
    )
    prohibitions = authorization.get(
        "prohibitions",
        {},
    )

    expected_scope = {
        "replication_count": 10,
        "timing_cell_count": 60,
        "warmup_runs_per_cell": 10,
        "measurement_runs_per_cell": 100,
        "expected_warmup_count": 600,
        "expected_measurement_count": 6000,
    }

    for key, expected_value in expected_scope.items():
        require(
            scope.get(key) == expected_value,
            (
                f"Authorization {key}: expected "
                f"{expected_value!r}, got "
                f"{scope.get(key)!r}."
            ),
        )

    require(
        execution_state
        == {
            "timing_execution_performed": False,
            "warmup_count_observed": 0,
            "measurement_count_observed": 0,
        },
        "Timing authorization execution state is not pristine.",
    )

    for field in (
        "functional_execution_rerun_authorized",
        "historical_prefix_rerun_authorized",
        "stage20_execution_authorized",
        "latency_claim_authorized",
        "scientific_freeze_authorized",
    ):
        require(
            prohibitions.get(field) is False,
            f"{field} must remain false.",
        )

    require(
        functional.get("status") == "pass",
        "Functional completion audit is not passing.",
    )
    require(
        functional.get("replication_count") == 10,
        "Expected 10 functional replications.",
    )
    require(
        functional.get("instance_count") == 30,
        "Expected 30 functional instances.",
    )
    require(
        functional.get("functional_step_count")
        == 60,
        "Expected 60 functional steps.",
    )
    require(
        functional.get(
            "all_replications_passed"
        )
        is True,
        "Not all functional replications passed.",
    )
    require(
        functional.get(
            "timing_execution_performed"
        )
        is False,
        "Functional audit already records timing execution.",
    )

    functional_runs = functional.get("runs")

    require(
        isinstance(functional_runs, list)
        and len(functional_runs) == 10,
        "Expected 10 functional run records.",
    )

    functional_by_replication = {
        int(item["replication_index"]): item
        for item in functional_runs
    }

    authorization_replications = {
        int(item["replication_index"]): item
        for item in authorization.get(
            "replications",
            []
        )
    }

    require(
        sorted(functional_by_replication)
        == list(range(10)),
        "Functional replication matrix is incomplete.",
    )
    require(
        sorted(authorization_replications)
        == list(range(10)),
        "Authorization replication matrix is incomplete.",
    )

    plan_replications: list[dict[str, Any]] = []

    for replication_index in range(10):
        functional_run = (
            functional_by_replication[
                replication_index
            ]
        )
        authorized_replication = (
            authorization_replications[
                replication_index
            ]
        )

        seed = int(seeds[replication_index])
        expected_stem = expected_run_stem(
            replication_index
        )

        source_run_path = Path(
            functional_run["run_path"]
        )

        require(
            source_run_path.name == expected_stem,
            (
                "Unexpected run path for replication "
                f"{replication_index}: {source_run_path}"
            ),
        )
        require(
            (root / source_run_path).is_dir(),
            f"Missing functional run: {source_run_path}",
        )
        require(
            functional_run.get("status") == "pass",
            (
                "Functional run is not passing: "
                f"replication {replication_index}"
            ),
        )
        require(
            functional_run.get(
                "selected_instance_count"
            )
            == 3,
            (
                "Expected 3 instances for replication "
                f"{replication_index}."
            ),
        )
        require(
            functional_run.get(
                "functional_step_count"
            )
            == 6,
            (
                "Expected 6 functional steps for "
                f"replication {replication_index}."
            ),
        )
        require(
            functional_run.get(
                "timing_artifact_count"
            )
            == 0,
            (
                "Unexpected pre-existing timing artifacts "
                f"for replication {replication_index}."
            ),
        )

        require(
            int(
                authorized_replication[
                    "structural_seed"
                ]
            )
            == seed,
            (
                "Authorization seed mismatch for "
                f"replication {replication_index}."
            ),
        )

        expected_order_seed = (
            20260728 + replication_index
        )

        require(
            int(
                authorized_replication[
                    "execution_order_seed"
                ]
            )
            == expected_order_seed,
            (
                "Execution-order seed mismatch for "
                f"replication {replication_index}."
            ),
        )

        digest = functional_run.get(
            "deterministic_execution_digest"
        )

        require(
            isinstance(digest, str)
            and bool(digest),
            (
                "Missing functional digest for "
                f"replication {replication_index}."
            ),
        )

        plan_replications.append(
            {
                "replication_index": (
                    replication_index
                ),
                "structural_seed": seed,
                "source_evidence_class": (
                    functional_run[
                        "evidence_class"
                    ]
                ),
                "source_functional_run_path": (
                    source_run_path.as_posix()
                ),
                "source_functional_digest": digest,
                "functional_digest_check_required": (
                    True
                ),
                "fresh_ckg_state_required": True,
                "reuse_successful": True,
                "factor_levels": [6, 12, 24],
                "steps_per_instance": 2,
                "timing_cell_count": 6,
                "warmups_per_cell": 10,
                "measurements_per_cell": 100,
                "expected_warmup_count": 60,
                "expected_measurement_count": 600,
                "execution_order_seed": (
                    expected_order_seed
                ),
                "logical_status": "ready",
                "runner_invocation_performed": False,
            }
        )

    source_commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=root,
        text=True,
    ).strip()

    plan = {
        "schema_version": (
            "mcad-virtual-node-count-stage10-"
            "timing-execution-plan-v1"
        ),
        "status": "prepared",
        "created_utc": args.created_utc,
        "source_commit": source_commit,
        "campaign_id": expected_campaign,
        "factor": "virtual_node_count",
        "runner": {
            "path": runner_relative.as_posix(),
            "sha256": runner_sha256,
            "preregistered_sha256": (
                timing["runner_sha256"]
            ),
            "sha256_matches_preregistration": True,
            "help_exit_status": 0,
            "help_sha256": sha256_text(
                help_result.stdout
            ),
            "discovered_cli_options": cli_options,
        },
        "precision_analyzer": {
            "path": analyzer_relative.as_posix(),
            "sha256": analyzer_sha256,
            "preregistered_sha256": (
                precision["analyzer_sha256"]
            ),
            "sha256_matches_preregistration": True,
        },
        "scope": {
            "replication_count": 10,
            "factor_levels": [6, 12, 24],
            "steps_per_instance": 2,
            "timing_cell_count": 60,
            "warmups_per_cell": 10,
            "measurements_per_cell": 100,
            "expected_warmup_count": 600,
            "expected_measurement_count": 6000,
        },
        "protocol": {
            "fresh_ckg_state_required": True,
            "functional_digest_check_required": True,
            "reuse_successful": True,
            "reuse_successful_scope": (
                timing[
                    "reuse_successful_scope"
                ]
            ),
            "order_seed_base": 20260728,
            "order_seed_policy": (
                timing["order_seed_policy"]
            ),
        },
        "precision_protocol": {
            "analyzer_version": "v2",
            "cluster_unit": (
                precision["cluster_unit"]
            ),
            "bootstrap_repetitions": 10000,
            "bootstrap_seed_base": 20260728,
            "confidence_level": 0.95,
            "median_relative_half_width_target": (
                0.10
            ),
            "p95_relative_half_width_target": (
                0.15
            ),
            "all_cells_must_pass": True,
        },
        "replications": plan_replications,
        "execution_state": {
            "runner_invocation_performed": False,
            "timing_execution_performed": False,
            "warmup_count_observed": 0,
            "measurement_count_observed": 0,
            "timing_output_directories_created": False,
        },
        "prohibitions": {
            "functional_execution_rerun_authorized": (
                False
            ),
            "historical_prefix_rerun_authorized": (
                False
            ),
            "stage20_execution_authorized": False,
            "latency_claim_authorized": False,
            "scientific_freeze_authorized": False,
        },
        "next_stage": (
            "authorize_and_execute_stage10_formal_timing"
        ),
    }

    write_json(root / PLAN, plan)

    validation = {
        "schema_version": (
            "mcad-virtual-node-count-stage10-"
            "timing-runner-validation-v1"
        ),
        "status": "pass",
        "created_utc": args.created_utc,
        "source_commit": source_commit,
        "campaign_id": expected_campaign,
        "runner_path": runner_relative.as_posix(),
        "runner_sha256": runner_sha256,
        "runner_sha256_matches_preregistration": (
            True
        ),
        "runner_help_exit_status": 0,
        "runner_cli_option_count": len(
            cli_options
        ),
        "precision_analyzer_path": (
            analyzer_relative.as_posix()
        ),
        "precision_analyzer_sha256": (
            analyzer_sha256
        ),
        "precision_analyzer_sha256_matches_preregistration": (
            True
        ),
        "functional_audit_status": "pass",
        "replication_count": 10,
        "timing_cell_count": 60,
        "expected_warmup_count": 600,
        "expected_measurement_count": 6000,
        "functional_execution_rerun_performed": (
            False
        ),
        "timing_execution_performed": False,
        "timing_output_directories_created": False,
        "plan_path": PLAN.as_posix(),
        "plan_sha256": sha256_file(
            root / PLAN
        ),
        "next_stage": (
            "authorize_and_execute_stage10_formal_timing"
        ),
    }

    write_json(
        root / VALIDATION_JSON,
        validation,
    )

    summary = """# Virtual-node-count Stage-10 timing preparation

- Status: `PASS`
- Existing preregistered runner reused: `true`
- Runner SHA-256 matches preregistration: `true`
- Precision analyzer SHA-256 matches preregistration: `true`
- Replications prepared: `10`
- Timing cells prepared: `60`
- Expected warmups: `600`
- Expected measurements: `6000`
- Functional execution rerun: `false`
- Timing execution performed: `false`
- Timing output directories created: `false`

## Next stage

`authorize_and_execute_stage10_formal_timing`
"""

    summary_path = root / VALIDATION_MD
    summary_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    summary_path.write_text(
        summary,
        encoding="utf-8",
    )

    print(
        "stage10_timing_runner_validation=PASS"
    )
    print(
        "runner_sha256_matches_preregistration=true"
    )
    print(
        "analyzer_sha256_matches_preregistration=true"
    )
    print("replication_count=10")
    print("timing_cell_count=60")
    print("expected_warmup_count=600")
    print("expected_measurement_count=6000")
    print(
        "functional_execution_rerun_performed=false"
    )
    print("timing_execution_performed=false")
    print(
        "timing_output_directories_created=false"
    )
    print(
        "next_stage="
        "authorize_and_execute_stage10_formal_timing"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
PY

echo
echo "=== 4. Create focused plan tests ==="

cat > "$TEST" <<'PY'
from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]

E3 = (
    ROOT
    / "reports/article_experiments/sensitivity"
    / "e3_controlled_execution"
)

PLAN = (
    E3
    / "planning"
    / "virtual_node_count_stage10_timing_execution_plan.json"
)

VALIDATION = (
    E3
    / "audits"
    / "virtual_node_count_stage10"
    / "timing_preparation"
    / "timing_runner_validation.json"
)


def load_json(path: Path) -> dict:
    return json.loads(
        path.read_text(encoding="utf-8")
    )


def test_runner_and_analyzer_match_preregistration() -> None:
    plan = load_json(PLAN)
    validation = load_json(VALIDATION)

    assert plan["status"] == "prepared"
    assert validation["status"] == "pass"

    assert (
        plan["runner"][
            "sha256_matches_preregistration"
        ]
        is True
    )
    assert (
        plan["precision_analyzer"][
            "sha256_matches_preregistration"
        ]
        is True
    )

    assert (
        validation[
            "runner_sha256_matches_preregistration"
        ]
        is True
    )
    assert (
        validation[
            "precision_analyzer_sha256_matches_preregistration"
        ]
        is True
    )


def test_stage10_timing_plan_counts() -> None:
    plan = load_json(PLAN)
    scope = plan["scope"]

    assert scope["replication_count"] == 10
    assert scope["timing_cell_count"] == 60
    assert scope["warmups_per_cell"] == 10
    assert scope["measurements_per_cell"] == 100
    assert scope["expected_warmup_count"] == 600
    assert scope["expected_measurement_count"] == 6000

    assert len(plan["replications"]) == 10

    assert sum(
        item["timing_cell_count"]
        for item in plan["replications"]
    ) == 60

    assert sum(
        item["expected_warmup_count"]
        for item in plan["replications"]
    ) == 600

    assert sum(
        item["expected_measurement_count"]
        for item in plan["replications"]
    ) == 6000


def test_replication_matrix_and_seeds_are_complete() -> None:
    plan = load_json(PLAN)
    replications = plan["replications"]

    assert [
        item["replication_index"]
        for item in replications
    ] == list(range(10))

    assert [
        item["execution_order_seed"]
        for item in replications
    ] == [
        20260728 + index
        for index in range(10)
    ]

    for item in replications:
        assert item["factor_levels"] == [6, 12, 24]
        assert item["steps_per_instance"] == 2
        assert item["timing_cell_count"] == 6
        assert item["functional_digest_check_required"] is True
        assert item["fresh_ckg_state_required"] is True
        assert item["reuse_successful"] is True
        assert item["logical_status"] == "ready"
        assert item["runner_invocation_performed"] is False


def test_preparation_performed_no_execution() -> None:
    plan = load_json(PLAN)
    state = plan["execution_state"]
    prohibitions = plan["prohibitions"]

    assert state == {
        "runner_invocation_performed": False,
        "timing_execution_performed": False,
        "warmup_count_observed": 0,
        "measurement_count_observed": 0,
        "timing_output_directories_created": False,
    }

    assert (
        prohibitions[
            "functional_execution_rerun_authorized"
        ]
        is False
    )
    assert (
        prohibitions[
            "historical_prefix_rerun_authorized"
        ]
        is False
    )
    assert (
        prohibitions[
            "stage20_execution_authorized"
        ]
        is False
    )
    assert (
        prohibitions[
            "latency_claim_authorized"
        ]
        is False
    )
PY

echo
echo "=== 5. Generate and validate timing plan ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" -m py_compile \
    "$TOOL" \
    "$TEST"

PYTHONPATH="$ROOT" \
  "$PYTHON" "$TOOL" \
    --repo-root "$ROOT" \
    --created-utc "$CREATED_UTC"

echo
echo "=== 6. Run timing-component tests ==="

PYTHONPATH="$ROOT" \
  "$PYTHON" -m pytest \
    backend/harness/sensitivity_execution/tests/test_timing_repetitions.py \
    backend/harness/sensitivity_execution/tests/test_clustered_timing_precision_v2.py \
    "$TEST" \
    -q \
    -p no:cacheprovider

echo "timing_component_tests=PASS"

echo
echo "=== 7. Commit and push ==="

git add \
  "$TOOL" \
  "$TEST"

git add -f \
  "$PLAN" \
  "$AUDIT_JSON" \
  "$AUDIT_MD"

git diff --cached --check

git commit \
  -m "chore(experiments): prepare virtual-node-count Stage-10 timing runner"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Prepare virtual-node-count Stage-10 timing runner" \
    --body "$(cat <<'EOF'
## Scope

- reuses the preregistered timing runner;
- validates the runner and analyzer SHA-256 values;
- validates the runner CLI entry point;
- prepares the ten-replication timing plan;
- records 60 cells, 600 warmups and 6000 measurements;
- validates fresh-CKG and functional-digest requirements;
- performs no functional execution and no timing execution.

## Result

- runner hash: PASS;
- analyzer hash: PASS;
- replication plan: 10/10 ready;
- timing cells: 60;
- warmups planned: 600;
- measurements planned: 6000;
- timing execution performed: false.

## Next stage

Authorize and execute the formal Stage-10 timing campaign.
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

echo "stage10_timing_runner_preparation=PASS"
echo "commit=$COMMIT"
echo "replication_count=10"
echo "timing_cell_count=60"
echo "expected_warmup_count=600"
echo "expected_measurement_count=6000"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_timing_runner_preparation"

git status --short --branch
