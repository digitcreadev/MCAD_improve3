#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="729b73b7716a4c32c610241256b7e42dd9ba6bfc"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"
CONTROLLED_FAMILIES="backend/harness/sensitivity_generator/families/controlled_families.py"

DESIGN_DOC="backend/harness/sensitivity_design/SENSITIVITY_GENERATOR_DESIGN.md"
DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"
SEMANTIC_BINDING="backend/harness/sensitivity_design/semantic_binding/SEMANTIC_BINDING_E1_1.md"

WORKLOAD_VALIDATOR="backend/harness/sensitivity_execution/validate_workload_spec.py"
WORKLOAD_SCHEMA="backend/harness/sensitivity_execution/workload_spec.schema.json"

SA4_AUDITOR="backend/harness/sensitivity_execution/tools/audit_membership_density_common_workload.py"
SA4_AUDITOR_TEST="backend/harness/sensitivity_execution/tests/test_membership_density_common_workload_auditor.py"

SA4_ARCHIVE="experiments/article/frozen_campaigns/sa4_membership_density_stage10/archive/membership_density_stage10_canonical_20260804T161119Z.tar.gz"
EXPECTED_SA4_ARCHIVE_SHA="1729d7913e68407f754804c9d23468559e0eeefbf616e8f7ecc6be5fab940ffc"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_materialization_contract_${STAMP}"

REPORT_JSON="$AUDIT_ROOT/sa5_objective_count_materialization_contract.json"
SURFACE_TXT="$AUDIT_ROOT/sa5_objective_count_materialization_surface.txt"

trap 'echo "[ERROR] Materialization-contract projection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$CONTROLLED_FAMILIES" \
  "$DESIGN_DOC" \
  "$DESIGN_MATRIX" \
  "$SEMANTIC_BINDING" \
  "$WORKLOAD_VALIDATOR" \
  "$WORKLOAD_SCHEMA" \
  "$SA4_AUDITOR" \
  "$SA4_AUDITOR_TEST" \
  "$SA4_ARCHIVE"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$SA4_ARCHIVE" |
    awk '{print $1}'
)" = "$EXPECTED_SA4_ARCHIVE_SHA"

echo "repository_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "sa4_archive_sha256=$EXPECTED_SA4_ARCHIVE_SHA"
echo "repository_modified=false"

echo
echo "=== 2. Revalidate materialization eligibility ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-campaign-preregistration-v1"
  and .preregistration_id
    == "sa5_objective_count_stage10_c8_nv32"
  and .status
    == "preregistered_not_materialized"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .factor_contract.factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .factor_contract.selected_objective_index == 0
  and .factor_contract.constraints_per_objective == 8
  and .factor_contract.virtual_nodes_per_objective == 32
  and .factor_contract.workload_length == 40
  and .factor_contract.noise_ratio == 0.25
  and .replication_contract.replication_count == 10
  and .replication_contract.expected_instance_count == 60
  and .authorization.campaign_materialization_authorized_now
    == false
  and .authorization.campaign_materialization_authorized_after_preregistration_merge
    == true
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .authorization.precision_analysis_authorized
    == false
  and .authorization.bootstrap_execution_authorized
    == false
  and .authorization.stage20_execution_authorized
    == false
  and .authorization.manuscript_integration_authorized
    == false
  and .authorization.global_scientific_freeze
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .next_stage
    == "materialize_sa5_objective_count_stage10_structure_and_common_workloads"
' "$PREREG" >/dev/null

echo "materialization_eligibility_gate=PASS"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "selected_objective_index=0"
echo "workload_length=40"
echo "noise_ratio=0.25"
echo "functional_execution_authorized=false"

echo
echo "=== 3. Initialize detached audit output ==="

mkdir -p "$AUDIT_ROOT"

echo "audit_root=$AUDIT_ROOT"

export ROOT
export EXPECTED_HEAD
export PREREG
export OBJECTIVE_GENERATOR
export OBJECTIVE_FAMILY
export CONTROLLED_FAMILIES
export DESIGN_DOC
export DESIGN_MATRIX
export SEMANTIC_BINDING
export WORKLOAD_VALIDATOR
export WORKLOAD_SCHEMA
export SA4_AUDITOR
export SA4_AUDITOR_TEST
export SA4_ARCHIVE
export REPORT_JSON
export SURFACE_TXT

python3 - <<'PY'
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import tarfile
from collections import Counter
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
expected_head = os.environ["EXPECTED_HEAD"]

paths = {
    "preregistration": Path(os.environ["PREREG"]),
    "objective_generator": Path(os.environ["OBJECTIVE_GENERATOR"]),
    "objective_family": Path(os.environ["OBJECTIVE_FAMILY"]),
    "controlled_families": Path(os.environ["CONTROLLED_FAMILIES"]),
    "design_document": Path(os.environ["DESIGN_DOC"]),
    "design_matrix": Path(os.environ["DESIGN_MATRIX"]),
    "semantic_binding": Path(os.environ["SEMANTIC_BINDING"]),
    "workload_validator": Path(os.environ["WORKLOAD_VALIDATOR"]),
    "workload_schema": Path(os.environ["WORKLOAD_SCHEMA"]),
    "sa4_auditor": Path(os.environ["SA4_AUDITOR"]),
    "sa4_auditor_test": Path(os.environ["SA4_AUDITOR_TEST"]),
    "sa4_archive": Path(os.environ["SA4_ARCHIVE"]),
}

report_path = Path(os.environ["REPORT_JSON"])
surface_path = Path(os.environ["SURFACE_TXT"])


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def digest(value: Any) -> str:
    return hashlib.sha256(
        canonical_json(value).encode("utf-8")
    ).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AssertionError(f"Expected object in {path}")
    return value


def source_nodes(
    relative_path: Path,
    patterns: tuple[str, ...],
) -> list[dict[str, Any]]:
    source = relative_path.read_text(encoding="utf-8")
    lines = source.splitlines()
    tree = ast.parse(source)

    selected: list[dict[str, Any]] = []

    for node in tree.body:
        name: str | None = None

        if isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        ):
            name = node.name
        elif isinstance(node, ast.Assign):
            targets = [
                target.id
                for target in node.targets
                if isinstance(target, ast.Name)
            ]
            name = ",".join(targets) if targets else None
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name):
                name = node.target.id

        if not name:
            continue

        if not any(
            re.search(pattern, name, re.IGNORECASE)
            for pattern in patterns
        ):
            continue

        start = int(getattr(node, "lineno", 1))
        end = int(getattr(node, "end_lineno", start))

        selected.append(
            {
                "kind": type(node).__name__,
                "name": name,
                "start_line": start,
                "end_line": end,
                "source": "\n".join(lines[start - 1 : end]),
            }
        )

    return selected


def markdown_section(
    path: Path,
    start_pattern: str,
    end_pattern: str,
) -> dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()

    start = next(
        (
            index
            for index, line in enumerate(lines)
            if re.search(start_pattern, line, re.IGNORECASE)
        ),
        None,
    )

    if start is None:
        return {
            "found": False,
            "start_line": None,
            "end_line": None,
            "text": "",
        }

    end = next(
        (
            index
            for index in range(start + 1, len(lines))
            if re.search(end_pattern, lines[index], re.IGNORECASE)
        ),
        len(lines),
    )

    return {
        "found": True,
        "start_line": start + 1,
        "end_line": end,
        "text": "\n".join(lines[start:end]),
    }


preregistration = read_json(paths["preregistration"])
design_matrix = yaml.safe_load(
    paths["design_matrix"].read_text(encoding="utf-8")
)
workload_schema = read_json(paths["workload_schema"])

if not isinstance(design_matrix, dict):
    raise AssertionError("design_matrix must be a mapping")

objective_axis = (
    design_matrix
    .get("axes", {})
    .get("objective_count", {})
)

baseline = design_matrix.get("baseline", {})

design_sections = {
    "experimental_unit_and_objective_count": markdown_section(
        paths["design_document"],
        r"^## 5\.",
        r"^### F2|^## 6\.",
    ),
    "contribution_support_density": markdown_section(
        paths["design_document"],
        r"^### F4",
        r"^### F5",
    ),
    "non_contributive_workload_noise": markdown_section(
        paths["design_document"],
        r"^### F5",
        r"^## 7\.",
    ),
    "controlled_variables": markdown_section(
        paths["design_document"],
        r"^## 7\.",
        r"^## 8\.",
    ),
    "required_outputs": markdown_section(
        paths["design_document"],
        r"required manifest|^## 9\.",
        r"^## 10\.",
    ),
}

for label, section in design_sections.items():
    if not section["found"]:
        raise AssertionError(
            f"Required design section not found: {label}"
        )

source_projection = {
    "objective_generator": source_nodes(
        paths["objective_generator"],
        (
            r"VERSION",
            r"Config",
            r"Manifest",
            r"objective",
            r"generate",
            r"count",
            r"digest",
            r"write",
            r"validate",
        ),
    ),
    "objective_family": source_nodes(
        paths["objective_family"],
        (
            r"VERSION",
            r"Spec",
            r"Manifest",
            r"Instance",
            r"generate",
            r"build",
            r"validate",
            r"write",
            r"objective",
            r"normal",
        ),
    ),
    "controlled_families": source_nodes(
        paths["controlled_families"],
        (
            r"SUPPORTED_FACTORS",
            r"ControlledFamilySpec",
            r"generate_controlled_family",
        ),
    ),
    "workload_validator": source_nodes(
        paths["workload_validator"],
        (
            r"SCHEMA_VERSION",
            r"validate_query_spec",
            r"validate_workload_spec",
            r"load_workload_spec",
        ),
    ),
    "sa4_common_workload_auditor": source_nodes(
        paths["sa4_auditor"],
        (
            r"VERSION",
            r"normal",
            r"canonical",
            r"digest",
            r"query",
            r"workload",
            r"audit",
            r"main",
        ),
    ),
    "sa4_common_workload_tests": source_nodes(
        paths["sa4_auditor_test"],
        (
            r"workload",
            r"normal",
            r"common",
            r"audit",
            r"query",
        ),
    ),
}

if not source_projection["objective_generator"]:
    raise AssertionError(
        "No objective-count generator definitions projected"
    )

if not source_projection["objective_family"]:
    raise AssertionError(
        "No objective-count family definitions projected"
    )

archive_members: list[str] = []
archive_workload_members: list[str] = []
archive_python_candidates: list[str] = []
archive_json_evidence: list[dict[str, Any]] = []
archive_workload_shapes: list[dict[str, Any]] = []
noise_value_counter: Counter[str] = Counter()
query_key_counter: Counter[str] = Counter()

interesting_key_pattern = re.compile(
    r"("
    r"workload|common_query|noise|non_contributive|"
    r"contribution_density|useful_virtual|irrelevant_virtual|"
    r"realised_density|oracle|class_count"
    r")",
    re.IGNORECASE,
)


def walk_interesting(
    value: Any,
    prefix: str = "",
) -> list[tuple[str, Any]]:
    found: list[tuple[str, Any]] = []

    if isinstance(value, dict):
        for key, item in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)

            if interesting_key_pattern.search(str(key)):
                if isinstance(item, (str, int, float, bool)) or item is None:
                    found.append((path, item))
                elif isinstance(item, list) and len(item) <= 20:
                    found.append((path, item))
                elif isinstance(item, dict) and len(item) <= 20:
                    found.append((path, item))

            found.extend(walk_interesting(item, path))

    elif isinstance(value, list):
        for index, item in enumerate(value[:200]):
            found.extend(
                walk_interesting(
                    item,
                    f"{prefix}[{index}]",
                )
            )

    return found


with tarfile.open(paths["sa4_archive"], mode="r:gz") as archive:
    regular_members = [
        member
        for member in archive.getmembers()
        if member.isfile()
    ]

    archive_members = sorted(
        member.name for member in regular_members
    )

    for member in regular_members:
        name = member.name
        lowered = name.lower()

        if "workload" in lowered:
            archive_workload_members.append(name)

        if (
            name.endswith(".py")
            and any(
                token in lowered
                for token in (
                    "prepare",
                    "material",
                    "workload",
                    "audit",
                )
            )
        ):
            archive_python_candidates.append(name)

        if not name.endswith(".json"):
            continue

        extracted = archive.extractfile(member)

        if extracted is None:
            continue

        raw = extracted.read()

        try:
            value = json.loads(raw.decode("utf-8"))
        except Exception:
            continue

        if not isinstance(value, dict):
            continue

        interesting = walk_interesting(value)

        if interesting:
            archive_json_evidence.append(
                {
                    "member": name,
                    "interesting_values": [
                        {
                            "path": key,
                            "value": item,
                        }
                        for key, item in interesting[:100]
                    ],
                }
            )

        if {
            "workload_id",
            "objective_id",
            "session_id",
            "steps",
        }.issubset(value):
            steps = value.get("steps")

            if not isinstance(steps, list):
                continue

            query_keys: set[str] = set()
            class_values: set[str] = set()

            for step in steps:
                if not isinstance(step, dict):
                    continue

                query = step.get("query_spec")

                if isinstance(query, dict):
                    query_keys.update(str(key) for key in query)
                    query_key_counter.update(
                        str(key) for key in query
                    )

                    for key, item in walk_interesting(query):
                        if isinstance(item, str):
                            class_values.add(item)
                            noise_value_counter[item] += 1

                for key, item in walk_interesting(step):
                    if isinstance(item, str):
                        class_values.add(item)
                        noise_value_counter[item] += 1

            archive_workload_shapes.append(
                {
                    "member": name,
                    "workload_id": value.get("workload_id"),
                    "objective_id": value.get("objective_id"),
                    "session_id": value.get("session_id"),
                    "step_count": len(steps),
                    "query_spec_keys": sorted(query_keys),
                    "class_or_noise_values": sorted(class_values),
                    "canonical_sha256": digest(value),
                }
            )

archive_workload_members = sorted(set(archive_workload_members))
archive_python_candidates = sorted(
    set(archive_python_candidates)
)

repo_preparation_candidates = sorted(
    str(path.relative_to(root))
    for path in root.rglob("*.py")
    if ".git" not in path.parts
    and any(
        token in path.name.lower()
        for token in (
            "prepare",
            "material",
            "workload",
        )
    )
    and (
        "sensitivity" in str(path).lower()
        or "article_experiments" in str(path).lower()
    )
)

noise_classes = [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

design_noise_distribution = baseline.get(
    "noise_distribution",
    {},
)

if sorted(design_noise_distribution) != sorted(noise_classes):
    raise AssertionError(
        "Design noise classes differ from the expected eight-class set"
    )

if baseline.get("workload_length") != 40:
    raise AssertionError("Unexpected baseline workload length")

if baseline.get("noise_ratio") != 0.25:
    raise AssertionError("Unexpected baseline noise ratio")

if objective_axis.get("levels") != [1, 2, 5, 10, 20, 50]:
    raise AssertionError("Unexpected objective-count levels")

fixed = objective_axis.get("fixed", {})

if fixed.get("constraints_per_objective") != 8:
    raise AssertionError(
        "Unexpected constraints-per-objective control"
    )

if fixed.get("virtual_nodes_per_objective") != 32:
    raise AssertionError(
        "Unexpected virtual-nodes-per-objective control"
    )

if fixed.get("contribution_density") != 0.50:
    raise AssertionError(
        "Unexpected contribution-density control"
    )

if fixed.get("workload_length") != 40:
    raise AssertionError(
        "Unexpected objective-axis workload length"
    )

if fixed.get("noise_ratio") != 0.25:
    raise AssertionError(
        "Unexpected objective-axis noise ratio"
    )

schema_required = workload_schema.get("required")

if schema_required != [
    "contract_version",
    "workload_id",
    "objective_id",
    "session_id",
    "steps",
]:
    raise AssertionError(
        "Unexpected workload top-level required fields"
    )

report = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "materialization-contract-projection-v1"
    ),
    "source_commit": expected_head,
    "read_only": True,
    "scientific_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "canonical_campaign_generated": False,
    "preregistration": {
        "path": str(paths["preregistration"]),
        "sha256": sha256_file(paths["preregistration"]),
        "value": preregistration,
    },
    "source_hashes": {
        label: sha256_file(path)
        for label, path in paths.items()
    },
    "design_projection": {
        "baseline": baseline,
        "objective_count_axis": objective_axis,
        "sections": design_sections,
    },
    "workload_schema_projection": {
        "required": schema_required,
        "contract_version": (
            workload_schema
            .get("properties", {})
            .get("contract_version", {})
            .get("const")
        ),
        "steps_schema": (
            workload_schema
            .get("properties", {})
            .get("steps", {})
        ),
    },
    "source_projection": source_projection,
    "precedent_projection": {
        "archive_member_count": len(archive_members),
        "workload_named_member_count": len(
            archive_workload_members
        ),
        "workload_named_members": archive_workload_members,
        "workload_spec_count": len(archive_workload_shapes),
        "workload_shapes": archive_workload_shapes,
        "python_candidate_count": len(
            archive_python_candidates
        ),
        "python_candidates": archive_python_candidates,
        "json_evidence_count": len(archive_json_evidence),
        "json_evidence": archive_json_evidence,
        "query_spec_key_frequency": dict(
            query_key_counter.most_common()
        ),
        "noise_or_class_value_frequency": dict(
            noise_value_counter.most_common()
        ),
    },
    "repository_preparation_candidates": (
        repo_preparation_candidates
    ),
    "resolved_controls": {
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "replication_count": 10,
        "expected_instance_count": 60,
        "selected_objective_index": 0,
        "constraints_per_objective": 8,
        "virtual_nodes_per_objective": 32,
        "requested_contribution_density": 0.50,
        "workload_length": 40,
        "noise_ratio": 0.25,
        "expected_non_contributive_query_count": 10,
        "noise_classes": noise_classes,
        "noise_class_weights": design_noise_distribution,
    },
    "authorization": {
        "campaign_materialization_eligible": True,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "stage20_execution_authorized": False,
        "manuscript_integration_authorized": False,
        "global_scientific_freeze": False,
    },
    "next_stage": (
        "author_and_execute_sa5_objective_count_"
        "stage10_materialization"
    ),
}

report_path.write_text(
    json.dumps(
        report,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface: list[str] = []

surface.append(
    "SA5 OBJECTIVE-COUNT STAGE-10 "
    "MATERIALIZATION CONTRACT SURFACE"
)
surface.append("=" * 78)
surface.append(f"source_commit={expected_head}")
surface.append("read_only=true")
surface.append("canonical_campaign_generated=false")
surface.append("scientific_execution_performed=false")
surface.append("")

surface.append("=== RESOLVED CONTROLS ===")
for key, value in report["resolved_controls"].items():
    surface.append(f"{key}={value}")
surface.append("")

surface.append("=== DESIGN SECTIONS ===")
for label, section in design_sections.items():
    surface.append("")
    surface.append(
        f"--- {label} "
        f"[{section['start_line']}-{section['end_line']}] ---"
    )
    surface.append(section["text"])
surface.append("")

surface.append("=== CURRENT SOURCE DEFINITIONS ===")
for label, definitions in source_projection.items():
    surface.append("")
    surface.append(f"## {label}")

    for definition in definitions:
        surface.append(
            f"\n### {definition['kind']} "
            f"{definition['name']} "
            f"[{definition['start_line']}-"
            f"{definition['end_line']}]"
        )
        surface.append(definition["source"])
surface.append("")

surface.append("=== SA4 FROZEN WORKLOAD PRECEDENT ===")
surface.append(
    "archive_member_count="
    f"{len(archive_members)}"
)
surface.append(
    "workload_named_member_count="
    f"{len(archive_workload_members)}"
)
surface.append(
    "workload_spec_count="
    f"{len(archive_workload_shapes)}"
)
surface.append(
    "python_candidate_count="
    f"{len(archive_python_candidates)}"
)
surface.append("")

surface.append("--- Workload-named archive members ---")
surface.extend(archive_workload_members)
surface.append("")

surface.append("--- Workload shapes ---")
for shape in archive_workload_shapes:
    surface.append(canonical_json(shape))
surface.append("")

surface.append("--- Archive Python candidates ---")
surface.extend(archive_python_candidates)
surface.append("")

surface.append("--- Repository preparation candidates ---")
surface.extend(repo_preparation_candidates)
surface.append("")

surface.append("--- Relevant archived JSON values ---")
for evidence in archive_json_evidence:
    surface.append(f"\nMEMBER={evidence['member']}")

    for item in evidence["interesting_values"]:
        surface.append(
            f"{item['path']}="
            f"{canonical_json(item['value'])}"
        )

surface_path.write_text(
    "\n".join(surface) + "\n",
    encoding="utf-8",
)

print(
    "materialization_contract_report="
    f"{report_path}"
)
print(
    "materialization_surface="
    f"{surface_path}"
)
print(
    "materialization_contract_report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "materialization_surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(
    "archive_member_count="
    f"{len(archive_members)}"
)
print(
    "archive_workload_named_member_count="
    f"{len(archive_workload_members)}"
)
print(
    "archive_workload_spec_count="
    f"{len(archive_workload_shapes)}"
)
print(
    "archive_python_candidate_count="
    f"{len(archive_python_candidates)}"
)
print(
    "repository_preparation_candidate_count="
    f"{len(repo_preparation_candidates)}"
)
print(
    "objective_generator_definition_count="
    f"{len(source_projection['objective_generator'])}"
)
print(
    "objective_family_definition_count="
    f"{len(source_projection['objective_family'])}"
)
print(
    "sa4_auditor_definition_count="
    f"{len(source_projection['sa4_common_workload_auditor'])}"
)
PY

echo "detached_contract_projection=PASS"

echo
echo "=== 4. Show compact projected contract ==="

jq '{
  schema_version,
  source_commit,
  read_only,
  resolved_controls,
  authorization,
  precedent_projection: {
    archive_member_count:
      .precedent_projection.archive_member_count,
    workload_named_member_count:
      .precedent_projection.workload_named_member_count,
    workload_spec_count:
      .precedent_projection.workload_spec_count,
    python_candidate_count:
      .precedent_projection.python_candidate_count,
    query_spec_key_frequency:
      .precedent_projection.query_spec_key_frequency,
    noise_or_class_value_frequency:
      .precedent_projection.noise_or_class_value_frequency
  },
  repository_preparation_candidates,
  next_stage
}' "$REPORT_JSON"

echo
echo "=== 5. Show exact high-value surface excerpts ==="

grep -nE \
  '^(### F1|### F4|### F5|density =|noise_ratio =|Noise must|Requested density|A sensitivity point|workload_spec_count=|MEMBER=|workload_id=|common_query|realised_noise|non_contributive|useful_virtual|irrelevant_virtual|class_count)' \
  "$SURFACE_TXT" \
  | head -n 320 || true

echo
echo "=== 6. Repository immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"

echo
echo "=== 7. Final state ==="

echo "sa5_objective_count_materialization_contract_projection=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "audit_root=$AUDIT_ROOT"
echo "materialization_contract_report=$REPORT_JSON"
echo "materialization_surface=$SURFACE_TXT"
echo "factor_levels=1,2,5,10,20,50"
echo "replication_count=10"
echo "expected_instance_count=60"
echo "workload_count=10"
echo "workload_length=40"
echo "expected_non_contributive_query_count=10"
echo "campaign_materialization_eligible=true"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=author_and_execute_sa5_objective_count_stage10_materialization"

git status --short --branch
