#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BRANCH="paper/execute-membership-density-timing-stage10-20260803T111214Z"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

LEDGER="$RUN_ROOT/stage10_execution_ledger.json"
AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

EXPECTED_LEDGER_SHA="27e7c716e51eb7cff7fcc17ad506495f0cd4f128f4be9a2b81c5185d190d2d8f"

trap 'echo "[ERROR] Persistence resume stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Resume gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

test -f "$LEDGER"
test -f "$AUDIT"

test "$(
  sha256sum "$LEDGER" | awk '{print $1}'
)" = "$EXPECTED_LEDGER_SHA"

# Aucun changement non indexé ni fichier non suivi.
test -z "$(git diff --name-only)"
test -z "$(git ls-files --others --exclude-standard)"

STAGED_FILE_COUNT="$(
  git diff --cached --name-only | wc -l
)"

CSV_COUNT="$(
  git diff --cached --name-only |
    awk '/\/timing_observations\.csv$/ {count++}
         END {print count + 0}'
)"

NON_CSV_COUNT="$(
  git diff --cached --name-only |
    awk '!/\/timing_observations\.csv$/ {count++}
         END {print count + 0}'
)"

NON_ADDED_COUNT="$(
  git diff --cached --name-status |
    awk '$1 != "A" {count++}
         END {print count + 0}'
)"

test "$STAGED_FILE_COUNT" -eq 44
test "$CSV_COUNT" -eq 10
test "$NON_CSV_COUNT" -eq 34
test "$NON_ADDED_COUNT" -eq 0

echo "resume_gate=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"
echo "staged_csv_count=$CSV_COUNT"
echo "staged_non_csv_count=$NON_CSV_COUNT"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Verify immutable CSV evidence ==="

python - \
  "$LEDGER" \
  "$AUDIT" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

ledger_path = Path(sys.argv[1])
audit_path = Path(sys.argv[2])


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


ledger = load_object(ledger_path)
audit = load_object(audit_path)

if ledger.get("status") != (
    "membership_density_stage10_timing_execution_complete"
):
    raise SystemExit("Execution ledger status mismatch.")

if audit.get("status") != (
    "membership_density_stage10_output_audit_complete"
):
    raise SystemExit("Output audit status mismatch.")

replications = ledger.get("replications")

if not isinstance(replications, list) or len(replications) != 10:
    raise SystemExit("Expected ten ledger replications.")

verified_csv_count = 0
measurement_total = 0

for expected_replication, record in enumerate(replications):
    if record.get("replication_index") != expected_replication:
        raise SystemExit("Replication sequence mismatch.")

    declaration = record["files"]["timing_observations"]
    csv_path = Path(declaration["path"])

    if not csv_path.is_file():
        raise SystemExit(f"Missing timing CSV: {csv_path}")

    actual_sha = sha256(csv_path)

    if actual_sha != declaration["sha256"]:
        raise SystemExit(
            f"Replication {expected_replication}: "
            "timing CSV SHA mismatch."
        )

    verified_csv_count += 1
    measurement_total += int(
        record["measurement_observation_count"]
    )

if verified_csv_count != 10:
    raise SystemExit("Expected ten verified timing CSVs.")

if measurement_total != 92000:
    raise SystemExit(
        f"Expected 92,000 measurements, got {measurement_total}."
    )

source_ledger_sha = (
    audit.get("source_artifacts", {})
    .get("execution_ledger", {})
    .get("sha256")
)

if source_ledger_sha != sha256(ledger_path):
    raise SystemExit(
        "Audit does not reference the current execution ledger."
    )

execution_results = audit.get("execution_results", {})

if (
    execution_results.get("measurement_observation_count")
    != 92000
):
    raise SystemExit("Audit measurement total mismatch.")

if (
    audit.get("audit_decision", {})
    .get("stage10_timing_execution_accepted")
    is not True
):
    raise SystemExit("Stage-10 execution is not accepted.")

if (
    audit.get("scientific_controls", {})
    .get("precision_analysis_performed")
    is not False
):
    raise SystemExit("Unexpected precision analysis state.")

print("immutable_csv_evidence_gate=PASS")
print("verified_timing_csv_count=10")
print("verified_measurement_observation_count=92000")
print("timing_csv_content_modified=false")
print("execution_ledger_integrity=PASS")
print("output_audit_integrity=PASS")
PY

echo
echo "=== 3. Check non-CSV staged files only ==="

mapfile -t CHECK_FILES < <(
  git diff --cached --name-only |
    awk '!/\/timing_observations\.csv$/'
)

test "${#CHECK_FILES[@]}" -eq 34

git diff --cached --check -- "${CHECK_FILES[@]}"

echo "non_csv_whitespace_check=PASS"
echo "timing_csv_whitespace_check=NOT_APPLICABLE"
echo "timing_csv_files_remain_staged=true"
echo "timing_csv_files_modified=false"

echo
echo "=== 4. Commit canonical evidence ==="

AUDIT_SHA="$(
  sha256sum "$AUDIT" | awk '{print $1}'
)"

git commit \
  -m "evidence(experiments): persist membership-density Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

COMMITTED_FILE_COUNT="$(
  git show \
    --format='' \
    --name-only \
    "$COMMIT" |
    sed '/^$/d' |
    wc -l
)"

test "$COMMITTED_FILE_COUNT" -eq 44

echo "commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=$COMMITTED_FILE_COUNT"

echo
echo "=== 5. Push execution branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 6. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Persist membership-density Stage-10 timing evidence" \
    --body "$(cat <<EOF
## Timing execution

- successful replications: \`10/10\`;
- raw timing cells: \`920\`;
- warmups: \`9,200\`;
- measurements: \`92,000\`;
- total observations: \`101,200\`;
- functional mismatches: \`0\`;
- timing re-execution: \`false\`.

## Balance audit

The runner field \`all_cells_exactly_balanced=false\`
concerns order-position coverage, not per-cell observation
counts.

- measurement rounds: \`100\`;
- order positions: \`92\`;
- quotient: \`1\`;
- remainder: \`8\`;
- direct measurements per cell: exactly \`100\`;
- scientific defect: \`false\`;
- timing rerun required: \`false\`.

## Integrity

- execution ledger SHA-256:
  \`$EXPECTED_LEDGER_SHA\`;
- output audit SHA-256:
  \`$AUDIT_SHA\`;
- canonical timing CSVs: \`10\`;
- canonical evidence files: \`44\`;
- precision analysis performed: \`false\`;
- latency claims authorized: \`false\`.

## Next stage

\`prepare_membership_density_portfolio_analysis_adapter\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 7. Final state ==="

test -z "$(git status --porcelain)"

echo "membership_density_stage10_timing_evidence_persistence=PASS"
echo "commit=$COMMIT"
echo "execution_ledger_sha256=$EXPECTED_LEDGER_SHA"
echo "output_audit_sha256=$AUDIT_SHA"
echo "committed_file_count=44"
echo "timing_csv_count=10"
echo "measurement_observation_count=92000"
echo "timing_reexecution_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_stage10_timing_evidence"

git status --short --branch
git log --oneline --decorate -4
