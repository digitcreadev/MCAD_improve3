#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="13be44a20db08589b8c452ea8299bbfc61adf164"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

PREFLIGHT="$REPORTS/planning/sa4_membership_density_timing_preregistration_preflight.json"
EXECUTION_PLAN="$REPORTS/audits/membership_density/by_replication/replication_execution_plan.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"
RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

OUTPUT_JSON="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"
OUTPUT_MD="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.md"

EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

trap 'echo "[ERROR] Preregistration stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$PREFLIGHT" \
  "$EXECUTION_PLAN" \
  "$ANALYZER" \
  "$RUNNER"
do
  test -f "$FILE"
done

test -x "$PYTHON"
test ! -e "$OUTPUT_JSON"
test ! -e "$OUTPUT_MD"

test "$(sha256sum "$ANALYZER" | awk '{print $1}')" = "$EXPECTED_ANALYZER_SHA"
test "$(sha256sum "$RUNNER" | awk '{print $1}')" = "$EXPECTED_RUNNER_SHA"

echo "repository_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Create preregistration branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-membership-density-portfolio-timing-${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "created_utc=$CREATED_UTC"

echo
echo "=== 3. Formalize portfolio-level contract ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREFLIGHT" \
  "$EXECUTION_PLAN" \
  "$ANALYZER" \
  "$RUNNER" \
  "$OUTPUT_JSON" \
  "$OUTPUT_MD" \
  "$EXPECTED_HEAD" \
  "$CREATED_UTC" \
  "$EXPECTED_ANALYZER_SHA" \
  "$EXPECTED_RUNNER_SHA" <<'PY'
from __future__ import annotations

import hashlib
import itertools
import json
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
preflight_path = root / sys.argv[2]
execution_plan_path = root / sys.argv[3]
analyzer_path = root / sys.argv[4]
runner_path = root / sys.argv[5]
output_json = root / sys.argv[6]
output_md = root / sys.argv[7]
source_commit = sys.argv[8]
created_utc = sys.argv[9]
expected_analyzer_sha = sys.argv[10]
expected_runner_sha = sys.argv[11]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


preflight = load_json(preflight_path)
execution_plan = load_json(execution_plan_path)

if preflight.get("status") != (
    "membership_density_timing_"
    "preregistration_preflight_complete"
):
    raise SystemExit("Merged timing preflight is not complete.")

if preflight.get("source_commit") != (
    "bbe66c639c729322aeacb5f269e8e78ef3a3e42c"
):
    raise SystemExit("Unexpected preflight source commit.")

structural = preflight.get("structural_contract", {})
balance = preflight.get("workload_balance_audit", {})
timing = preflight.get("proposed_timing_protocol", {})
controls = preflight.get("scientific_controls", {})

levels = structural.get("levels")
seeds = structural.get("seeds")

expected_levels = [25, 50, 75, 100]
expected_seeds = [
    101,
    202,
    1198202409,
    796786883,
    1126922093,
    809989256,
    618554674,
    1363159082,
    874332939,
    1767972531,
]

if levels != expected_levels:
    raise SystemExit(f"Unexpected density levels: {levels}")

if seeds != expected_seeds:
    raise SystemExit(f"Unexpected structural seeds: {seeds}")

if balance.get("balanced_local_step_indexes") != list(range(1, 24)):
    raise SystemExit("Expected balanced local positions 1..23.")

if balance.get("available_step_count_histogram") != {
    "23": 2,
    "24": 8,
}:
    raise SystemExit("Unexpected workload-length histogram.")

if balance.get("global_query_digest_intersection_count") != 0:
    raise SystemExit("Expected no globally common query digest.")

if balance.get(
    "cross_replication_query_digest_identity_required"
) is not False:
    raise SystemExit(
        "Cross-replication query identity must not be assumed."
    )

if timing.get("timing_cluster_cell_count") != 920:
    raise SystemExit("Expected 920 raw timing cells.")

if timing.get("measurement_observation_count") != 92000:
    raise SystemExit("Expected 92,000 measurements.")

if controls.get("timing_execution_authorized") is not False:
    raise SystemExit("Timing is unexpectedly authorized.")

if controls.get("timing_execution_performed") is not False:
    raise SystemExit("Timing was unexpectedly performed.")

if sha256_file(analyzer_path) != expected_analyzer_sha:
    raise SystemExit("Analyzer SHA-256 mismatch.")

if sha256_file(runner_path) != expected_runner_sha:
    raise SystemExit("Runner SHA-256 mismatch.")

analyzer_source = analyzer_path.read_text(encoding="utf-8")

required_analyzer_fragments = (
    'row["formal_replication_index"]',
    'row["formal_structural_seed"]',
    'row["factor_level"]',
    'row["step_index"]',
    'row["wall_latency_ms"]',
    '"--levels"',
    '"--steps"',
    '"--measurements-per-cluster"',
)

for fragment in required_analyzer_fragments:
    if fragment not in analyzer_source:
        raise SystemExit(
            f"Analyzer contract fragment absent: {fragment}"
        )

partitions = execution_plan.get("partitions")

if not isinstance(partitions, list) or len(partitions) != 10:
    raise SystemExit("Expected ten execution-plan partitions.")

selected_steps = list(range(1, 24))
by_replication: dict[int, dict[int, str]] = {}

for partition in partitions:
    replication = int(partition["replication_index"])
    equivalence = partition.get("equivalence_metadata")

    if not isinstance(equivalence, list):
        raise SystemExit(
            f"Replication {replication} lacks equivalence metadata."
        )

    digest_by_step = {
        int(item["step_index"]): str(item["query_spec_digest"])
        for item in equivalence
        if int(item["step_index"]) in selected_steps
    }

    if sorted(digest_by_step) != selected_steps:
        raise SystemExit(
            f"Replication {replication} lacks positions 1..23."
        )

    by_replication[replication] = digest_by_step

if sorted(by_replication) != list(range(10)):
    raise SystemExit("Replication index set is incomplete.")

digest_support: Counter[str] = Counter()

for digest_by_step in by_replication.values():
    digest_support.update(set(digest_by_step.values()))

support_histogram = Counter(digest_support.values())

expected_histogram = {
    1: 189,
    2: 14,
    3: 3,
    4: 1,
}

if dict(sorted(support_histogram.items())) != expected_histogram:
    raise SystemExit(
        "Semantic-support histogram differs from audited result: "
        f"{dict(sorted(support_histogram.items()))}"
    )

globally_supported = [
    digest
    for digest, support in digest_support.items()
    if support == 10
]

if globally_supported:
    raise SystemExit("Unexpected globally supported digest.")

aligned_positions = [
    step
    for step in selected_steps
    if len({
        by_replication[replication][step]
        for replication in range(10)
    }) == 1
]

if aligned_positions:
    raise SystemExit("Unexpected globally aligned position.")

replication_digest_sets = {
    replication: set(mapping.values())
    for replication, mapping in by_replication.items()
}

pairwise_overlaps: list[int] = []
pairwise_jaccards: list[float] = []

for left, right in itertools.combinations(range(10), 2):
    left_set = replication_digest_sets[left]
    right_set = replication_digest_sets[right]

    intersection = left_set & right_set
    union = left_set | right_set

    pairwise_overlaps.append(len(intersection))
    pairwise_jaccards.append(
        len(intersection) / len(union) if union else 0.0
    )

raw_steps_per_cluster = 23
measurements_per_raw_cell = 100
measurements_per_portfolio_cluster = (
    raw_steps_per_cluster * measurements_per_raw_cell
)

if measurements_per_portfolio_cluster != 2300:
    raise SystemExit("Portfolio cluster size calculation failed.")

preregistration = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "portfolio-timing-preregistration-v1"
    ),
    "status": (
        "membership_density_portfolio_"
        "timing_preregistration_complete"
    ),
    "stage": (
        "SA4_membership_density_"
        "portfolio_timing_preregistration"
    ),
    "created_utc": created_utc,
    "source_commit": source_commit,
    "campaign_id": "membership_density_stage10_c4_nv24",
    "factor": "membership_density",
    "preregistration_scope": "stage10_temporal_precision",
    "preflight_revision": {
        "preflight_path": preflight_path.relative_to(root).as_posix(),
        "preflight_sha256": sha256_file(preflight_path),
        "preflight_precision_cell_count": 92,
        "formal_precision_cell_count": 4,
        "supersedes_preflight_precision_cell_definition": True,
        "reason": (
            "No query digest or local query position is "
            "semantically aligned across all ten structural "
            "seed clusters. Per-position cross-seed inference "
            "would therefore lack a stable query estimand."
        ),
        "raw_timing_dimensions_unchanged": True,
    },
    "structural_contract": {
        "stage_size": 10,
        "replication_count": 10,
        "structural_seed_count": 10,
        "levels": expected_levels,
        "level_count": 4,
        "seeds": expected_seeds,
        "fixed_constraint_count": 4,
        "fixed_virtual_node_count": 24,
    },
    "semantic_support_audit": {
        "selected_local_step_indexes": selected_steps,
        "selected_local_step_count": 23,
        "query_digest_occurrence_count": 230,
        "distinct_query_digest_count": len(digest_support),
        "digest_support_histogram": {
            str(key): value
            for key, value in sorted(support_histogram.items())
        },
        "globally_supported_digest_count": 0,
        "globally_aligned_local_position_count": 0,
        "pairwise_digest_overlap": {
            "minimum": min(pairwise_overlaps),
            "median": statistics.median(pairwise_overlaps),
            "maximum": max(pairwise_overlaps),
        },
        "pairwise_jaccard": {
            "minimum": min(pairwise_jaccards),
            "median": statistics.median(pairwise_jaccards),
            "maximum": max(pairwise_jaccards),
        },
        "cross_replication_query_identity_assumed": False,
        "within_replication_cross_level_equivalence_required": True,
    },
    "primary_estimand": {
        "name": (
            "density_level_latency_distribution_over_"
            "seed_specific_23_query_portfolios"
        ),
        "inferential_cell": "density_level",
        "inferential_cell_count": 4,
        "resampling_cluster": "structural_seed",
        "cluster_count_per_density_level": 10,
        "within_cluster_observations": (
            "All 23 seed-specific canonical queries and "
            "all 100 retained measurements per query."
        ),
        "within_cluster_observation_count": 2300,
        "cluster_weighting": (
            "Equal cluster sizes; each structural seed "
            "contributes exactly 2,300 observations."
        ),
        "cross_seed_query_identity_required": False,
        "interpretation": (
            "Precision of the latency distribution for a "
            "density level over the preregistered population "
            "of seed-specific canonical query portfolios."
        ),
        "unsupported_estimand": (
            "Latency precision for a semantically identical "
            "local query position across structural seeds."
        ),
    },
    "raw_timing_protocol": {
        "replication_count": 10,
        "density_level_count": 4,
        "local_step_count": 23,
        "raw_timing_cell_count": 920,
        "warmups_per_raw_cell": 10,
        "measurements_per_raw_cell": 100,
        "warmup_observation_count": 9200,
        "measurement_observation_count": 92000,
        "order_seed_base": 20260728,
        "order_seed_rule": "20260728 + replication_index",
        "fresh_state_required": True,
        "semantic_match_required": True,
        "reuse_successful": True,
    },
    "derived_analysis_adapter": {
        "required": True,
        "raw_timing_csv_modification_allowed": False,
        "derived_observation_count": 92000,
        "analyzer_factor_level": (
            "Preserve original density level."
        ),
        "analyzer_step_index": 0,
        "analyzer_levels_argument": "25,50,75,100",
        "analyzer_steps_argument": "0",
        "analyzer_measurements_per_cluster_argument": 2300,
        "preserved_analyzer_columns": [
            "formal_replication_index",
            "formal_structural_seed",
            "formal_order_seed",
            "factor_level",
            "wall_latency_ms",
        ],
        "required_provenance_columns": [
            "source_step_index",
            "source_step_id",
            "source_query_spec_digest",
            "source_timing_csv",
            "source_row_number",
        ],
        "query_digest_join_source": (
            execution_plan_path.relative_to(root).as_posix()
        ),
        "adapter_validation_requirements": {
            "exactly_four_factor_level_step_cells": True,
            "exactly_ten_clusters_per_cell": True,
            "exactly_2300_measurements_per_cluster": True,
            "all_92000_source_rows_accounted_for": True,
            "raw_source_hashes_preserved": True,
        },
    },
    "precision_protocol": {
        "analyzer": analyzer_path.relative_to(root).as_posix(),
        "analyzer_sha256": expected_analyzer_sha,
        "stage_size": 10,
        "levels": expected_levels,
        "steps": [0],
        "precision_cell_count": 4,
        "measurements_per_cluster": 2300,
        "bootstrap_repetitions": 10000,
        "bootstrap_seed": 20260728,
        "confidence_level": 0.95,
        "median_relative_half_width_target": 0.10,
        "p95_relative_half_width_target": 0.15,
        "gate_rule": (
            "All four density-level portfolio cells must "
            "meet both relative-half-width targets."
        ),
        "stage20_extension_only_if_stage10_fails": True,
        "stage20_execution_authorized": False,
    },
    "implementation_identities": {
        "timing_runner": runner_path.relative_to(root).as_posix(),
        "timing_runner_sha256": expected_runner_sha,
        "precision_analyzer": analyzer_path.relative_to(root).as_posix(),
        "precision_analyzer_sha256": expected_analyzer_sha,
    },
    "source_artifacts": {
        "timing_preflight": {
            "path": preflight_path.relative_to(root).as_posix(),
            "sha256": sha256_file(preflight_path),
        },
        "replication_execution_plan": {
            "path": execution_plan_path.relative_to(root).as_posix(),
            "sha256": sha256_file(execution_plan_path),
        },
    },
    "scientific_controls": {
        "functional_execution_rerun_required": False,
        "functional_execution_rerun_performed": False,
        "timing_input_materialization_authorized": True,
        "timing_input_materialization_performed": False,
        "timing_execution_authorized": False,
        "timing_execution_performed": False,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "preregistration_decision": {
        "portfolio_level_estimand_accepted": True,
        "formal_timing_preregistration_complete": True,
        "timing_input_materialization_ready": True,
        "timing_execution_ready": False,
    },
    "next_stage": (
        "prepare_membership_density_timing_inputs"
    ),
}

write_json(output_json, preregistration)

output_md.write_text(
    "\n".join([
        "# SA4 membership-density portfolio timing preregistration",
        "",
        "- Status: `PASS`",
        "- Structural seed clusters: `10`",
        "- Density levels: `25, 50, 75, 100`",
        "- Raw local positions per cluster: `23`",
        "- Raw timing cells: `920`",
        "- Formal measurements: `92,000`",
        "- Portfolio measurements per cluster: `2,300`",
        "- Inferential precision cells: `4`",
        "- Bootstrap repetitions: `10,000`",
        "- Median RHW target: `10%`",
        "- p95 RHW target: `15%`",
        "- Timing execution authorized: `false`",
        "",
        "## Estimand",
        "",
        (
            "Density-level latency distribution over "
            "seed-specific canonical 23-query portfolios."
        ),
        "",
        (
            "Local query positions are not interpreted as "
            "semantically identical across structural seeds."
        ),
        "",
        "## Analysis adapter",
        "",
        (
            "The immutable raw timing rows are copied into "
            "a derived analysis CSV. The original local step "
            "and query digest are retained as provenance, "
            "while the analyzer-facing `step_index` is set "
            "to the synthetic portfolio value `0`."
        ),
        "",
        "- Analyzer levels: `25,50,75,100`",
        "- Analyzer steps: `0`",
        "- Measurements per cluster: `2300`",
        "",
        "## Next stage",
        "",
        "`prepare_membership_density_timing_inputs`",
        "",
    ]),
    encoding="utf-8",
)

print(
    "membership_density_portfolio_"
    "timing_preregistration=PASS"
)
print("raw_timing_cell_count=920")
print("raw_measurement_observation_count=92000")
print("portfolio_measurements_per_cluster=2300")
print("formal_precision_cell_count=4")
print("globally_supported_digest_count=0")
print("globally_aligned_local_position_count=0")
print("cross_replication_query_identity_assumed=false")
print("timing_input_materialization_authorized=true")
print("timing_execution_authorized=false")
print("precision_analysis_authorized=false")
print(
    "next_stage="
    "prepare_membership_density_timing_inputs"
)
PY

echo
echo "=== 4. Validate preregistration ==="

jq -e '
  .status
    == "membership_density_portfolio_timing_preregistration_complete"
  and .raw_timing_protocol.raw_timing_cell_count == 920
  and .raw_timing_protocol.measurement_observation_count == 92000
  and .semantic_support_audit.distinct_query_digest_count == 207
  and .semantic_support_audit.globally_supported_digest_count == 0
  and .semantic_support_audit.globally_aligned_local_position_count == 0
  and .primary_estimand.inferential_cell_count == 4
  and .primary_estimand.within_cluster_observation_count == 2300
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .derived_analysis_adapter.analyzer_measurements_per_cluster_argument
      == 2300
  and .precision_protocol.precision_cell_count == 4
  and .precision_protocol.bootstrap_repetitions == 10000
  and .scientific_controls.timing_input_materialization_authorized == true
  and .scientific_controls.timing_execution_authorized == false
  and .scientific_controls.precision_analysis_authorized == false
  and .preregistration_decision.formal_timing_preregistration_complete
      == true
  and .preregistration_decision.timing_input_materialization_ready
      == true
  and .preregistration_decision.timing_execution_ready == false
  and .next_stage == "prepare_membership_density_timing_inputs"
' "$OUTPUT_JSON" >/dev/null

echo "formal_preregistration_validation=PASS"

echo
echo "=== 5. Commit and push ==="

git add -f "$OUTPUT_JSON" "$OUTPUT_MD"

git diff --cached --check
git diff --cached --stat

git commit \
  -m "chore(experiments): preregister membership-density portfolio timing"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 6. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister membership-density portfolio timing" \
    --body "$(cat <<'EOF'
## Formal timing contract

- raw timing cells: `920`;
- measurements: `92,000`;
- structural seed clusters: `10`;
- density levels: `4`;
- seed-specific queries per cluster: `23`;
- observations per portfolio cluster: `2,300`;
- formal precision cells: `4`.

## Estimand correction

No query digest or local query position is common to all ten structural
seeds. Formal inference is therefore defined at density-portfolio level,
not at local step-position level.

## Derived analysis adapter

- raw timing CSV files remain immutable;
- original step indexes and query digests are retained as provenance;
- analyzer-facing `step_index` is the synthetic portfolio value `0`;
- analyzer `--measurements-per-cluster` is fixed to `2300`.

## Controls

- functional rerun: `false`;
- timing-input preparation authorized: `true`;
- timing execution authorized: `false`;
- precision analysis authorized: `false`;
- latency claims authorized: `false`.

## Next stage

`prepare_membership_density_timing_inputs`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 7. Final state ==="

echo "membership_density_portfolio_timing_preregistration=PASS"
echo "commit=$COMMIT"
echo "raw_timing_cell_count=920"
echo "measurement_observation_count=92000"
echo "portfolio_measurements_per_cluster=2300"
echo "formal_precision_cell_count=4"
echo "timing_input_materialization_authorized=true"
echo "timing_execution_authorized=false"
echo "precision_analysis_authorized=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_membership_density_portfolio_preregistration"

git status --short --branch
git log --oneline --decorate -4
