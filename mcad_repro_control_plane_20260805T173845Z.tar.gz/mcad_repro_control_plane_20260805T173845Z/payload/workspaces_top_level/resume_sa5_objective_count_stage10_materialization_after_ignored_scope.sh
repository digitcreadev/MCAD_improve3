#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-20260805T104339Z"

EXPECTED_BASE_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_PATCH_SHA="85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

READINESS_ROOT="/workspaces/sa5_objective_count_v2_post_merge_materialization_readiness_20260805T102938Z"
READINESS_REPORT="$READINESS_ROOT/sa5_objective_count_v2_post_merge_materialization_readiness.json"
EXPECTED_READINESS_REPORT_SHA="2acc274086cf0ff8187132596c5177b350c87e774f4be3597782c9f23341f472"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/$CAMPAIGN_ID"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/$CAMPAIGN_ID"
STRUCTURE_AUDIT="$AUDIT_ROOT/structure_audit.json"
WORKLOAD_AUDIT="$AUDIT_ROOT/common_workload_audit.json"
CAMPAIGN_FILE_MANIFEST="$AUDIT_ROOT/canonical_campaign_file_manifest.sha256"

MATERIALIZATION_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MATERIALIZATION_SUMMARY="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d4d253da2bf739d65763fa2c44d0e7df15f352bd8b48ce7e96930c4ff93e3705"

EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

TMP_ROOT="$(mktemp -d /workspaces/sa5_materialization_resume.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 materialization recovery stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact stopped-state recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"
test -z "$(git diff --name-only)"
test -z "$(git diff --cached --name-only)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"

test -d "$CAMPAIGN_ROOT"
test -d "$AUDIT_ROOT"
test -f "$MATERIALIZATION_REPORT"
test -f "$MATERIALIZATION_SUMMARY"

verify_sha \
  "$READINESS_REPORT" \
  "$EXPECTED_READINESS_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "stopped_state_gate=PASS"
echo "branch=$BRANCH"
echo "head=$EXPECTED_BASE_HEAD"
echo "tracked_repository_changes=false"
echo "materialization_outputs_present=true"

echo
echo "=== 2. Reconstruct exact generated scope ==="

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/campaign_files.txt" \
  "$TMP_ROOT/audit_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_generated_files.txt"

test "$(
  wc -l < "$TMP_ROOT/campaign_files.txt"
)" -eq 134

test "$(
  wc -l < "$TMP_ROOT/audit_files.txt"
)" -eq 3

test "$(
  wc -l < "$TMP_ROOT/planning_files.txt"
)" -eq 2

test "$(
  wc -l < "$TMP_ROOT/expected_generated_files.txt"
)" -eq 139

test "$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name manifest.json |
    wc -l
)" -eq 60

test "$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name objectives.yaml |
    wc -l
)" -eq 60

test "$(
  find "$WORKLOAD_ROOT" \
    -maxdepth 1 \
    -type f \
    -name 'replication_*_seed_*.json' |
    wc -l
)" -eq 10

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

echo "generated_scope_reconstruction=PASS"
echo "canonical_campaign_file_count=134"
echo "audit_file_count=3"
echo "planning_file_count=2"
echo "total_generated_file_count=139"

echo
echo "=== 3. Diagnose ignored-output behavior ==="

while IFS= read -r FILE; do
  git check-ignore -q "$FILE"
done < "$TMP_ROOT/expected_generated_files.txt"

git status \
  --ignored \
  --short \
  -- \
  "$CAMPAIGN_ROOT" \
  "$AUDIT_ROOT" \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" \
  > "$TMP_ROOT/ignored_status.txt"

test -s "$TMP_ROOT/ignored_status.txt"

IGNORED_PATH_COUNT="$(
  grep -c '^!! ' "$TMP_ROOT/ignored_status.txt"
)"

test "$IGNORED_PATH_COUNT" -gt 0

echo "ignored_output_diagnosis=PASS"
echo "all_generated_files_ignored=true"
echo "ordinary_git_status_visible_file_count=0"
echo "ignored_status_entry_count=$IGNORED_PATH_COUNT"
echo "recovery_action=force_stage_exact_139_file_scope"

echo
echo "=== 4. Validate materialization reports before staging ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_structure_and_common_workloads_materialized"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .implementation_patch_sha256
    == "85473b11110b8a02e609e12fae2bd19fc55c2ff63aad32eacb9d142dd407f115"

  and .canonical_campaign.expected_instance_count
    == 60
  and .canonical_campaign.realised_instance_count
    == 60
  and .canonical_campaign.campaign_file_count
    == 134
  and .canonical_campaign.instance_manifest_count
    == 60
  and .canonical_campaign.objectives_file_count
    == 60

  and .common_workloads.workload_count
    == 10
  and .common_workloads.workload_length
    == 32
  and .common_workloads.contributive_query_count_per_workload
    == 24
  and .common_workloads.non_contributive_query_count_per_workload
    == 8

  and .audits.structure.status == "PASS"
  and .audits.structure.failure_count == 0
  and .audits.common_workloads.status == "PASS"
  and .audits.common_workloads.failure_count == 0
  and .audits.common_workloads.operator_oracle_mismatch_count
    == 0

  and .scientific_controls.canonical_campaign_generated
    == true
  and .scientific_controls.canonical_campaign_materialization_performed
    == true
  and .scientific_controls.canonical_stage10_functional_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false

  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

echo "materialization_report_gate=PASS"

echo
echo "=== 5. Force-stage exact ignored materialization scope ==="

mapfile -t GENERATED_FILES \
  < "$TMP_ROOT/expected_generated_files.txt"

git add \
  -f \
  -- \
  "${GENERATED_FILES[@]}"

git diff \
  --cached \
  --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/staged_files.txt"

STAGED_FILE_COUNT="$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)"

test "$STAGED_FILE_COUNT" -eq 139

test -z "$(git diff --name-only)"

echo "force_stage_gate=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"

echo
echo "=== 6. Revalidate staged bytes and scientific controls ==="

git diff \
  --cached \
  --check

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "staged_integrity_gate=PASS"
echo "canonical_campaign_generated=true"
echo "canonical_materialization_audit_evaluator_probe_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Commit canonical materialization ==="

git commit \
  -m "chore(experiments): materialize SA5 objective-count Stage-10 inputs"

COMMIT="$(
  git rev-parse HEAD
)"

test "$COMMIT" != "$EXPECTED_BASE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

echo "materialization_commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 8. Push materialization branch ==="

git push \
  -u \
  origin \
  "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "materialization_push=PASS"

echo
echo "=== 9. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Materialize SA5 objective-count Stage-10 inputs" \
    --body-file - <<EOF
## Scope

Materialize the preregistered SA5 objective-count Stage-10 canonical inputs from merged commit \`$EXPECTED_BASE_HEAD\`.

- 6 objective-count levels
- 10 fixed replications
- 60 canonical structural instances
- 10 common workloads
- 32 steps per workload
- 24 contributive and 8 non-contributive steps
- one occurrence of every registered noise class per replication

## Validation

- structure audit: PASS
- common-workload audit: PASS
- operator-oracle mismatches: 0
- canonical campaign files: 134
- total committed files: 139
- implementation patch SHA-256: \`$EXPECTED_PATCH_SHA\`
- readiness report SHA-256: \`$EXPECTED_READINESS_REPORT_SHA\`
- canonical campaign file-manifest SHA-256: \`$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA\`

## Scientific control

This PR materializes canonical inputs only. Formal Stage-10 functional execution, timing, bootstrap, precision analysis, and manuscript integration have not been performed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 10. Verify PR identity and exact scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,isDraft,headRefOid,headRefName,baseRefName,title,files
)"

jq -e \
  --arg commit "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $commit
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
    and (.files | length) == 139
  ' <<<"$PR_DATA" >/dev/null

jq -r '.files[].path' <<<"$PR_DATA" |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 11. Final state ==="

echo "sa5_objective_count_stage10_materialization_resume=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "canonical_campaign_file_count=134"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"
echo "total_generated_file_count=139"

echo "materialization_report_sha256=$EXPECTED_MATERIALIZATION_REPORT_SHA"
echo "materialization_summary_sha256=$EXPECTED_MATERIALIZATION_SUMMARY_SHA"
echo "canonical_campaign_file_manifest_sha256=$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

echo "operator_oracle_mismatch_count=0"
echo "structure_failure_count=0"
echo "workload_failure_count=0"
echo "blocker_count=0"
echo "materialization_complete=true"

echo "canonical_campaign_generated=true"
echo "canonical_campaign_materialization_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_materialization"

git status --short --branch
git log --oneline --decorate -5
