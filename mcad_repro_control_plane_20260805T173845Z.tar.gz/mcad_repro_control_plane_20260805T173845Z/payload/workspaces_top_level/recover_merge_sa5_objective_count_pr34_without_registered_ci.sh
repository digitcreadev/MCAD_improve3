#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=34

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-20260805T104339Z"

EXPECTED_BASE_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_FEATURE_HEAD="c92e90afcfb81e31c372f829a87a69d78eb9817f"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/$CAMPAIGN_ID"
INSTANCES_CSV="$CAMPAIGN_ROOT/instances.csv"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

AUDIT_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/$CAMPAIGN_ID"
STRUCTURE_AUDIT="$AUDIT_ROOT/structure_audit.json"
WORKLOAD_AUDIT="$AUDIT_ROOT/common_workload_audit.json"
CAMPAIGN_FILE_MANIFEST="$AUDIT_ROOT/canonical_campaign_file_manifest.sha256"

MATERIALIZATION_REPORT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MATERIALIZATION_SUMMARY="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d4d253da2bf739d65763fa2c44d0e7df15f352bd8b48ce7e96930c4ff93e3705"

EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
NO_CI_AUDIT_ROOT="/workspaces/sa5_objective_count_pr34_no_ci_registration_audit_${STAMP}"
NO_CI_REPORT="$NO_CI_AUDIT_ROOT/sa5_objective_count_pr34_no_ci_registration_audit.json"
NO_CI_SURFACE="$NO_CI_AUDIT_ROOT/sa5_objective_count_pr34_no_ci_registration_audit.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_pr34_no_ci_merge.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #34 no-CI recovery/merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact stopped merge state ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .isDraft == false
    and .headRefOid == $feature
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
  ' <<<"$PR_DATA" >/dev/null

echo "stopped_merge_state_gate=PASS"
echo "pull_request=$PR"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "feature_head=$EXPECTED_FEATURE_HEAD"
echo "repository_clean=true"

echo
echo "=== 2. Reconstruct and verify exact PR scope ==="

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/campaign_files.txt" \
  "$TMP_ROOT/audit_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/campaign_files.txt")" -eq 134
test "$(wc -l < "$TMP_ROOT/audit_files.txt")" -eq 3
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 139

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/feature_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/feature_files.txt"

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 139

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

echo "exact_materialization_scope_gate=PASS"
echo "canonical_campaign_file_count=134"
echo "total_pr_file_count=139"

echo
echo "=== 3. Confirm absence of registered CI objects ==="

PR_CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

if ! jq -e 'type == "array"' >/dev/null <<<"$PR_CHECKS"; then
  PR_CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$PR_CHECKS"
)"

ACTIONS_RUNS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
)"

ACTIONS_RUN_COUNT="$(
  jq '.total_count' <<<"$ACTIONS_RUNS"
)"

CHECK_RUNS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
)"

CHECK_RUN_COUNT="$(
  jq '.total_count' <<<"$CHECK_RUNS"
)"

COMBINED_STATUS="$(
  gh api \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
)"

LEGACY_STATUS_COUNT="$(
  jq '.statuses | length' <<<"$COMBINED_STATUS"
)"

test "$CHECK_COUNT" -eq 0
test "$ACTIONS_RUN_COUNT" -eq 0
test "$CHECK_RUN_COUNT" -eq 0
test "$LEGACY_STATUS_COUNT" -eq 0

echo "no_registered_ci_objects_gate=PASS"
echo "pr_check_count=0"
echo "actions_run_count=0"
echo "check_run_count=0"
echo "legacy_status_count=0"
echo "ci_failure_count=0"

echo
echo "=== 4. Audit workflow trigger eligibility against 139 changed files ==="

mkdir -p "$NO_CI_AUDIT_ROOT"

export ROOT
export BASE
export EXPECTED_BASE_HEAD
export EXPECTED_FEATURE_HEAD
export PR
export REPO
export NO_CI_REPORT
export NO_CI_SURFACE
export EXPECTED_FILES_PATH="$TMP_ROOT/expected_files.txt"

"$PYTHON" - <<'PY'
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
base_branch = os.environ["BASE"]
base_head = os.environ["EXPECTED_BASE_HEAD"]
feature_head = os.environ["EXPECTED_FEATURE_HEAD"]
pr_number = int(os.environ["PR"])
repo = os.environ["REPO"]

report_path = Path(os.environ["NO_CI_REPORT"])
surface_path = Path(os.environ["NO_CI_SURFACE"])
changed_files = Path(
    os.environ["EXPECTED_FILES_PATH"]
).read_text(encoding="utf-8").splitlines()

workflow_root = root / ".github" / "workflows"
workflow_files = sorted(
    [
        *workflow_root.glob("*.yml"),
        *workflow_root.glob("*.yaml"),
    ]
)

assert workflow_files, "No workflow files found."


def as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def github_match(value: str, pattern: str) -> bool:
    # GitHub workflow patterns are shell-style. For the repository's
    # current patterns, fnmatch is a conservative evaluator: a possible
    # match keeps a workflow eligible and therefore prevents an unsafe
    # no-CI merge.
    return fnmatch.fnmatchcase(value, pattern)


def ordered_inclusion(value: str, patterns: list[str]) -> bool:
    included = False

    for raw in patterns:
        negated = raw.startswith("!")
        pattern = raw[1:] if negated else raw

        if github_match(value, pattern):
            included = not negated

    return included


def ignored(value: str, patterns: list[str]) -> bool:
    return any(
        github_match(value, pattern)
        for pattern in patterns
    )


def event_config(on_value: Any, name: str) -> tuple[bool, Any]:
    if isinstance(on_value, str):
        return on_value == name, None

    if isinstance(on_value, list):
        return name in [str(item) for item in on_value], None

    if isinstance(on_value, dict):
        return name in on_value, on_value.get(name)

    return False, None


results: list[dict[str, Any]] = []

for workflow_path in workflow_files:
    document = yaml.load(
        workflow_path.read_text(encoding="utf-8"),
        Loader=yaml.BaseLoader,
    )

    if not isinstance(document, dict):
        raise TypeError(
            f"Workflow root must be a mapping: {workflow_path}"
        )

    on_value = document.get("on")
    relative_path = workflow_path.relative_to(root).as_posix()

    event_results: list[dict[str, Any]] = []

    for event_name in ("pull_request", "pull_request_target"):
        present, config = event_config(on_value, event_name)

        if not present:
            continue

        if not isinstance(config, dict):
            config = {}

        branches = as_list(config.get("branches"))
        branches_ignore = as_list(
            config.get("branches-ignore")
        )
        paths = as_list(config.get("paths"))
        paths_ignore = as_list(
            config.get("paths-ignore")
        )

        branch_eligible = True
        branch_reason = "no_branch_filter"

        if branches:
            branch_eligible = ordered_inclusion(
                base_branch,
                branches,
            )
            branch_reason = (
                "branch_included"
                if branch_eligible
                else "branch_not_included"
            )
        elif branches_ignore:
            branch_eligible = not ignored(
                base_branch,
                branches_ignore,
            )
            branch_reason = (
                "branch_not_ignored"
                if branch_eligible
                else "branch_ignored"
            )

        matched_files: list[str] = []
        path_eligible = True
        path_reason = "no_path_filter"

        if paths:
            matched_files = [
                path
                for path in changed_files
                if ordered_inclusion(path, paths)
            ]
            path_eligible = bool(matched_files)
            path_reason = (
                "paths_match"
                if path_eligible
                else "paths_no_match"
            )
        elif paths_ignore:
            non_ignored_files = [
                path
                for path in changed_files
                if not ignored(path, paths_ignore)
            ]
            matched_files = non_ignored_files
            path_eligible = bool(non_ignored_files)
            path_reason = (
                "at_least_one_path_not_ignored"
                if path_eligible
                else "all_paths_ignored"
            )

        eligible = branch_eligible and path_eligible

        event_results.append(
            {
                "event": event_name,
                "eligible": eligible,
                "branch_eligible": branch_eligible,
                "branch_reason": branch_reason,
                "path_eligible": path_eligible,
                "path_reason": path_reason,
                "branches": branches,
                "branches_ignore": branches_ignore,
                "paths": paths,
                "paths_ignore": paths_ignore,
                "matched_file_count": len(matched_files),
                "matched_files": matched_files,
            }
        )

    results.append(
        {
            "workflow": relative_path,
            "name": document.get("name"),
            "pull_request_events": event_results,
            "has_pull_request_event": bool(event_results),
            "eligible": any(
                item["eligible"]
                for item in event_results
            ),
        }
    )


eligible_workflows = [
    item
    for item in results
    if item["eligible"]
]

pr_workflows = [
    item
    for item in results
    if item["has_pull_request_event"]
]

phase3 = [
    item
    for item in results
    if item["workflow"]
    == ".github/workflows/phase3-regression.yml"
]

assert len(changed_files) == 139
assert pr_workflows, (
    "No pull-request workflow exists; this requires separate review."
)
assert len(phase3) == 1
assert phase3[0]["has_pull_request_event"]
assert not phase3[0]["eligible"]
assert not eligible_workflows, (
    "At least one pull-request workflow is eligible for this PR; "
    "absence of CI registration is therefore not explained by "
    "workflow filters."
)

phase3_events = phase3[0]["pull_request_events"]
assert phase3_events
assert all(
    not event["eligible"]
    for event in phase3_events
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-pr34-"
        "no-ci-registration-audit-v1"
    ),
    "status": (
        "no_ci_registration_expected_from_"
        "workflow_trigger_filters"
    ),
    "repository": repo,
    "pull_request": pr_number,
    "base_branch": base_branch,
    "base_head": base_head,
    "feature_head": feature_head,
    "changed_file_count": len(changed_files),
    "changed_files": changed_files,
    "workflow_file_count": len(results),
    "pull_request_workflow_count": len(pr_workflows),
    "eligible_pull_request_workflow_count": (
        len(eligible_workflows)
    ),
    "phase3_regression_workflow_eligible": False,
    "workflow_results": results,
    "registered_ci": {
        "pr_check_count": 0,
        "actions_run_count": 0,
        "check_run_count": 0,
        "legacy_status_count": 0,
        "failure_count": 0,
    },
    "decision": {
        "ci_absence_is_expected": True,
        "ci_waiver_is_not_being_invented": True,
        "reason": (
            "No pull-request workflow is eligible for the exact "
            "139-file materialization-only diff under the checked "
            "workflow branch/path filters."
        ),
        "merge_requires_local_regression": True,
        "merge_requires_exact_scope_and_hash_validation": True,
        "merge_requires_mergeable_clean": True,
    },
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT PR #34 NO-CI REGISTRATION AUDIT",
    "=" * 88,
    f"repository={repo}",
    f"pull_request={pr_number}",
    f"base_branch={base_branch}",
    f"base_head={base_head}",
    f"feature_head={feature_head}",
    f"changed_file_count={len(changed_files)}",
    f"workflow_file_count={len(results)}",
    f"pull_request_workflow_count={len(pr_workflows)}",
    "eligible_pull_request_workflow_count=0",
    "phase3_regression_workflow_eligible=false",
    "pr_check_count=0",
    "actions_run_count=0",
    "check_run_count=0",
    "legacy_status_count=0",
    "ci_failure_count=0",
    "ci_absence_is_expected=true",
    "blocker_count=0",
    "audit_complete=true",
    "",
    "WORKFLOW DECISIONS",
    "-" * 88,
]

for workflow in results:
    surface_lines.append(
        f"{workflow['workflow']}: "
        f"has_pull_request_event="
        f"{str(workflow['has_pull_request_event']).lower()} "
        f"eligible={str(workflow['eligible']).lower()}"
    )

    for event in workflow["pull_request_events"]:
        surface_lines.append(
            "  "
            f"event={event['event']} "
            f"branch_reason={event['branch_reason']} "
            f"path_reason={event['path_reason']} "
            f"matched_file_count={event['matched_file_count']} "
            f"eligible={str(event['eligible']).lower()}"
        )

surface_path.write_text(
    "\n".join(surface_lines) + "\n",
    encoding="utf-8",
)

print("workflow_trigger_eligibility_audit=PASS")
print(f"workflow_file_count={len(results)}")
print(f"pull_request_workflow_count={len(pr_workflows)}")
print("eligible_pull_request_workflow_count=0")
print("phase3_regression_workflow_eligible=false")
print("ci_absence_is_expected=true")
print("blocker_count=0")
print(f"no_ci_report={report_path}")
print(
    "no_ci_report_sha256="
    + hashlib.sha256(report_path.read_bytes()).hexdigest()
)
print(f"no_ci_surface={surface_path}")
print(
    "no_ci_surface_sha256="
    + hashlib.sha256(surface_path.read_bytes()).hexdigest()
)
PY

jq -e '
  .status
    == "no_ci_registration_expected_from_workflow_trigger_filters"
  and .pull_request == 34
  and .base_head
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .feature_head
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"
  and .changed_file_count == 139
  and .pull_request_workflow_count > 0
  and .eligible_pull_request_workflow_count == 0
  and .phase3_regression_workflow_eligible == false
  and .registered_ci.pr_check_count == 0
  and .registered_ci.actions_run_count == 0
  and .registered_ci.check_run_count == 0
  and .registered_ci.legacy_status_count == 0
  and .registered_ci.failure_count == 0
  and .decision.ci_absence_is_expected == true
  and .decision.merge_requires_local_regression == true
  and .decision.merge_requires_exact_scope_and_hash_validation == true
  and .decision.merge_requires_mergeable_clean == true
  and .blocker_count == 0
  and .audit_complete == true
' "$NO_CI_REPORT" >/dev/null

echo "no_ci_registration_explanation_gate=PASS"

echo
echo "=== 5. Full local regression substitute for ineligible CI ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -z "$(git status --porcelain)"

echo "full_local_regression_gate=PASS"
echo "ci_substitution_reason=workflow_ineligible_for_exact_materialization_diff"

echo
echo "=== 6. CRLF and scientific-control gate ==="

export INSTANCES_CSV

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import io
import os
import re
from pathlib import Path


path = Path(os.environ["INSTANCES_CSV"])
payload = path.read_bytes()

assert payload.endswith(b"\r\n")
assert payload.count(b"\r\n") == 61
assert payload.count(b"\n") == 61
assert payload.count(b"\r") == 61
assert not re.search(rb"[ \t]+\r\n", payload)

rows = list(
    csv.reader(
        io.StringIO(
            payload.decode("utf-8"),
            newline="",
        )
    )
)

assert len(rows) == 61
assert len(rows[1:]) == 60
assert all(
    len(row) == len(rows[0])
    for row in rows[1:]
)

print("instances_csv_crlf_gate=PASS")
print("instances_csv_record_count=61")
print("instances_csv_instance_count=60")
print("actual_trailing_space_or_tab_count=0")
PY

jq -e '
  .scientific_controls.canonical_campaign_generated
    == true
  and .scientific_controls.canonical_campaign_materialization_performed
    == true
  and .scientific_controls.canonical_stage10_functional_execution_performed
    == false
  and .scientific_controls.timing_execution_performed
    == false
  and .scientific_controls.precision_analysis_performed
    == false
  and .scientific_controls.bootstrap_execution_performed
    == false
  and .scientific_controls.scientific_execution_performed
    == false
  and .scientific_controls.manuscript_modified
    == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "scientific_control_gate=PASS"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Mergeability gate without registered CI ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"
echo "registered_ci_required_for_this_diff=false"
echo "basis=audited_workflow_trigger_ineligibility"

echo
echo "=== 8. Merge exact PR head through GitHub API ==="

MERGE_RESULT="$(
  gh api \
    --method PUT \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/pulls/$PR/merge" \
    -f merge_method=merge \
    -f sha="$EXPECTED_FEATURE_HEAD"
)"

jq -e '.merged == true' <<<"$MERGE_RESULT" >/dev/null

REMOTE_MERGE_COMMIT="$(
  jq -r '.sha' <<<"$MERGE_RESULT"
)"

test -n "$REMOTE_MERGE_COMMIT"
test "$REMOTE_MERGE_COMMIT" != "null"

echo "merge_command=PASS"
echo "remote_merge_commit=$REMOTE_MERGE_COMMIT"

echo
echo "=== 9. Delete remote materialization branch ==="

git fetch origin --prune

if [ -n "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)" ]; then
  git push \
    origin \
    --delete \
    "$BRANCH"
fi

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

echo "remote_branch_cleanup=PASS"

echo
echo "=== 10. Update and validate base lineage ==="

git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull \
  --ff-only \
  origin \
  "$BASE"

BASE_HEAD="$(
  git rev-parse HEAD
)"

test "$BASE_HEAD" = "$REMOTE_MERGE_COMMIT"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 11. Post-merge exact materialization integrity ==="

while IFS= read -r FILE; do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" \
    >/dev/null
done < "$TMP_ROOT/expected_files.txt"

find "$CAMPAIGN_ROOT" \
  -type f |
  sort > "$TMP_ROOT/post_merge_campaign_files.txt"

find "$AUDIT_ROOT" \
  -type f |
  sort > "$TMP_ROOT/post_merge_audit_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/post_merge_planning_files.txt"

cat \
  "$TMP_ROOT/post_merge_campaign_files.txt" \
  "$TMP_ROOT/post_merge_audit_files.txt" \
  "$TMP_ROOT/post_merge_planning_files.txt" |
  sort > "$TMP_ROOT/post_merge_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/post_merge_files.txt"

test "$(wc -l < "$TMP_ROOT/post_merge_files.txt")" -eq 139

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test -z "$(git status --porcelain)"

echo "post_merge_materialization_integrity_gate=PASS"
echo "canonical_campaign_file_count=134"
echo "total_materialization_file_count=139"

echo
echo "=== 12. Post-merge full regression ==="

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"

echo "post_merge_full_regression_gate=PASS"

echo
echo "=== 13. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 14. Cleanup local materialization branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch \
    -d \
    "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo "local_branch_cleanup=PASS"

echo
echo "=== 15. Final state ==="

NO_CI_REPORT_SHA="$(
  sha256sum "$NO_CI_REPORT" |
    awk '{print $1}'
)"

NO_CI_SURFACE_SHA="$(
  sha256sum "$NO_CI_SURFACE" |
    awk '{print $1}'
)"

echo "sa5_objective_count_stage10_materialization_no_ci_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "pull_request=$PR"

echo "no_ci_report=$NO_CI_REPORT"
echo "no_ci_report_sha256=$NO_CI_REPORT_SHA"
echo "no_ci_surface=$NO_CI_SURFACE"
echo "no_ci_surface_sha256=$NO_CI_SURFACE_SHA"

echo "eligible_pull_request_workflow_count=0"
echo "registered_ci_object_count=0"
echo "ci_failure_count=0"
echo "ci_absence_is_expected=true"

echo "full_local_regression_pre_merge=PASS"
echo "full_local_regression_post_merge=PASS"

echo "canonical_campaign_file_count=134"
echo "total_materialization_file_count=139"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"

echo "canonical_campaign_generated=true"
echo "canonical_campaign_materialization_performed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "functional_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "functional_execution_readiness_audit_eligible=true"
echo "next_stage=audit_sa5_objective_count_stage10_functional_execution_readiness"

git status --short --branch
git log --oneline --decorate -6
