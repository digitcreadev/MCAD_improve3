#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=23

BASE="paper/phase3-controlled-execution"
BRANCH="paper/analyze-membership-density-portfolio-precision-20260804T155547Z"

EXPECTED_HEAD="5e364e1242b58cd3ba5862af012ff86591cf5522"
EXPECTED_BASE_HEAD="c056ea76176f6a06d2a5012ddd37e043ca4324a4"

PRECISION_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/membership_density/timing_stage10/precision_analysis"

RAW_LOG="$PRECISION_ROOT/analyzer.log"
RAW_INTERVALS="$PRECISION_ROOT/raw_analyzer_intervals.csv"
RAW_REPORT_JSON="$PRECISION_ROOT/raw_analyzer_report.json"
RAW_REPORT_MD="$PRECISION_ROOT/raw_analyzer_report.md"
DECISION_JSON="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.json"
DECISION_MD="$PRECISION_ROOT/stage10_portfolio_precision_decision_report.md"

EXPECTED_RAW_LOG_SHA="019472284afb9cdca6bd24b0f0b77df85e50a2806a2169d50dc4e2392e8b0f88"
EXPECTED_RAW_INTERVALS_SHA="d3824d3b1ace93f907a40b0f643a6eaca9f35ef7ad00be743c3aba7696184ee3"
EXPECTED_RAW_REPORT_SHA="a58361d1927c771bd98c6428d013b91d46f1cc731795136c9ca122be9e7a6240"
EXPECTED_RAW_REPORT_MD_SHA="0f518becd88581cf171e6c3250d5d8a7d5850aeda41d983bb93ac7a8f42a0626"
EXPECTED_DECISION_SHA="92a9307a89e92c5e849b0e058f5e0a3c89633f6f8cd39f98ec9a2b9392cc88a4"

trap 'echo "[ERROR] PR #23 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local precision-evidence gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"
do
  test -s "$FILE"
done

test "$(sha256sum "$RAW_LOG" | awk '{print $1}')" \
  = "$EXPECTED_RAW_LOG_SHA"

test "$(sha256sum "$RAW_INTERVALS" | awk '{print $1}')" \
  = "$EXPECTED_RAW_INTERVALS_SHA"

test "$(sha256sum "$RAW_REPORT_JSON" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_SHA"

test "$(sha256sum "$RAW_REPORT_MD" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_MD_SHA"

test "$(sha256sum "$DECISION_JSON" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

CHANGED_FILES="$(
  git diff --name-only "$EXPECTED_BASE_HEAD..$EXPECTED_HEAD"
)"

CHANGED_FILE_COUNT="$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 6

for FILE in \
  "$RAW_LOG" \
  "$RAW_INTERVALS" \
  "$RAW_REPORT_JSON" \
  "$RAW_REPORT_MD" \
  "$DECISION_JSON" \
  "$DECISION_MD"
do
  test "$(
    printf '%s\n' "$CHANGED_FILES" |
      grep -Fx "$FILE" |
      wc -l
  )" -eq 1
done

grep -Fx \
  "status=stage10_precision_targets_met" \
  "$RAW_LOG" >/dev/null

grep -Fx \
  "all_precision_targets_met=true" \
  "$RAW_LOG" >/dev/null

grep -Fx \
  "failing_cell_count=0" \
  "$RAW_LOG" >/dev/null

jq -e '
  .status == "stage10_precision_targets_met"
  and (.cell_results | length) == 4
  and ([.cell_results[].factor] | unique)
      == ["constraint_count"]
  and ([.cell_results[].factor_level] | sort)
      == [25, 50, 75, 100]
  and ([.cell_results[].step_index] | unique)
      == [0]
' "$RAW_REPORT_JSON" >/dev/null

jq -e '
  .schema_version
    == "mcad-sa4-membership-density-stage10-portfolio-precision-decision-v1"
  and .status == "pass"
  and .factor == "membership_density"
  and .stage == 10
  and .analysis_execution.authorized_execution_count == 1
  and .analysis_execution.successful_bootstrap_execution_count == 1
  and .analysis_execution.precision_analysis_authorized == true
  and .analysis_execution.precision_analysis_performed == true
  and .analysis_execution.adapter_rematerialization_performed == false
  and .analysis_execution.timing_reexecution_performed == false
  and .analysis_contract.factor_levels == [25, 50, 75, 100]
  and .analysis_contract.synthetic_step_indexes == [0]
  and .analysis_contract.inferential_cell_count == 4
  and .analysis_contract.structural_seed_count == 10
  and .analysis_contract.measurements_per_cluster == 2300
  and .analysis_contract.measurements_per_inferential_cell == 23000
  and .analysis_contract.measurement_observation_count == 92000
  and .analysis_contract.bootstrap_repetitions == 10000
  and .analysis_contract.bootstrap_seed == 20260728
  and .analysis_contract.confidence_level == 0.95
  and .analysis_contract.median_relative_half_width_target == 0.10
  and .analysis_contract.p95_relative_half_width_target == 0.15
  and .raw_analyzer_interpretation.raw_factor_values
      == ["constraint_count"]
  and .raw_analyzer_interpretation.raw_factor_label_authoritative
      == false
  and .raw_analyzer_interpretation.raw_next_stage_authoritative
      == false
  and .raw_analyzer_interpretation.canonical_factor
      == "membership_density"
  and (.cell_results | length) == 4
  and ([.cell_results[].factor_level] | sort)
      == [25, 50, 75, 100]
  and ([.cell_results[].step_index] | unique) == [0]
  and ([.cell_results[].median_target_met] | all)
  and ([.cell_results[].p95_target_met] | all)
  and ([.cell_results[].all_cell_targets_met] | all)
  and .precision_decision.all_median_targets_met == true
  and .precision_decision.all_p95_targets_met == true
  and .precision_decision.all_precision_targets_met == true
  and .precision_decision.failing_cell_count == 0
  and .precision_decision.stage10_sufficient == true
  and .precision_decision.stage20_extension_required == false
  and .precision_decision.stage20_execution_authorized == false
  and .scientific_controls.successful_bootstrap_execution_count == 1
  and .scientific_controls.precision_analysis_performed == true
  and .scientific_controls.stage20_execution_authorized == false
  and .scientific_controls.latency_claim_authorized == false
  and .scientific_controls.scientific_freeze == false
  and .next_stage
      == "prepare_membership_density_stage10_freeze"
' "$DECISION_JSON" >/dev/null

echo "local_precision_evidence_gate=PASS"
echo "changed_file_count=$CHANGED_FILE_COUNT"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=true"
echo "failing_cell_count=0"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' >/dev/null 2>&1 <<<"$CHECKS"; then
  CHECKS='[]'
fi

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "precision_analysis_ci=PASS"
else
  echo "precision_analysis_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #23 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "precision_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged precision evidence ==="

test "$(sha256sum "$RAW_LOG" | awk '{print $1}')" \
  = "$EXPECTED_RAW_LOG_SHA"

test "$(sha256sum "$RAW_INTERVALS" | awk '{print $1}')" \
  = "$EXPECTED_RAW_INTERVALS_SHA"

test "$(sha256sum "$RAW_REPORT_JSON" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_SHA"

test "$(sha256sum "$RAW_REPORT_MD" | awk '{print $1}')" \
  = "$EXPECTED_RAW_REPORT_MD_SHA"

test "$(sha256sum "$DECISION_JSON" | awk '{print $1}')" \
  = "$EXPECTED_DECISION_SHA"

jq -e '
  .status == "pass"
  and .factor == "membership_density"
  and .analysis_execution.authorized_execution_count == 1
  and .analysis_execution.successful_bootstrap_execution_count == 1
  and .precision_decision.all_precision_targets_met == true
  and .precision_decision.failing_cell_count == 0
  and .precision_decision.stage10_sufficient == true
  and .precision_decision.stage20_extension_required == false
  and .precision_decision.stage20_execution_authorized == false
  and .scientific_controls.precision_analysis_performed == true
  and .scientific_controls.successful_bootstrap_execution_count == 1
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "prepare_membership_density_stage10_freeze"
' "$DECISION_JSON" >/dev/null

echo "merged_precision_analysis_evidence=PASS"
echo "raw_analyzer_log_sha256=$EXPECTED_RAW_LOG_SHA"
echo "raw_intervals_sha256=$EXPECTED_RAW_INTERVALS_SHA"
echo "raw_report_sha256=$EXPECTED_RAW_REPORT_SHA"
echo "canonical_decision_sha256=$EXPECTED_DECISION_SHA"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=true"
echo "stage10_sufficient=true"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

test -z "$(git status --porcelain)"

echo "membership_density_precision_analysis_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "authorized_execution_count=1"
echo "successful_bootstrap_execution_count=1"
echo "precision_analysis_performed=true"
echo "all_precision_targets_met=true"
echo "failing_cell_count=0"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "next_stage=prepare_membership_density_stage10_freeze"

git status --short --branch
git log --oneline --decorate -5
