#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=34

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6c4dac8312f4798fd0f1ede499cba58f57ab8368"
EXPECTED_PREVIOUS_HEAD="548df8f2f389508f29dbde24dcddec6724adbccc"
EXPECTED_MATERIALIZATION_COMMIT="c92e90afcfb81e31c372f829a87a69d78eb9817f"

CAMPAIGN_ID="objective_count_stage10_c8_nv32"

E3_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ROOT="$E3_ROOT/campaigns/$CAMPAIGN_ID"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"
EXECUTION_SPEC_TARGET_DIR="$E3_ROOT/execution_specs"
RUN_TARGET_DIR="$E3_ROOT/runs"

CAMPAIGN_FILE_MANIFEST="$E3_ROOT/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

MATERIALIZATION_REPORT="$E3_ROOT/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MATERIALIZATION_SUMMARY="$E3_ROOT/planning/sa5_objective_count_stage10_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d4d253da2bf739d65763fa2c44d0e7df15f352bd8b48ce7e96930c4ff93e3705"

NO_CI_ROOT="/workspaces/sa5_objective_count_pr34_no_ci_registration_audit_20260805T112617Z"
NO_CI_REPORT="$NO_CI_ROOT/sa5_objective_count_pr34_no_ci_registration_audit.json"
EXPECTED_NO_CI_REPORT_SHA="ce3d7627e37390f1ecd7a6cf8fbefd18f67dd6467bd9f581a470ee153e6d2eb4"
NO_CI_SURFACE="$NO_CI_ROOT/sa5_objective_count_pr34_no_ci_registration_audit.txt"
EXPECTED_NO_CI_SURFACE_SHA="d12d4c3d5c0f64b4f04ecdf4e8eafeab9a7306898015d5c0a8698f4da9806b29"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
AUDIT_ROOT="/workspaces/sa5_objective_count_stage10_functional_execution_readiness_${STAMP}"
REPORT="$AUDIT_ROOT/sa5_objective_count_stage10_functional_execution_readiness.json"
SURFACE="$AUDIT_ROOT/sa5_objective_count_stage10_functional_execution_readiness.txt"

MIRROR_A="$AUDIT_ROOT/candidate_a/reports/article_experiments/sensitivity/e3_controlled_execution"
MIRROR_B="$AUDIT_ROOT/candidate_b/reports/article_experiments/sensitivity/e3_controlled_execution"

TMP_ROOT="$(mktemp -d /workspaces/sa5_objective_count_functional_readiness.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 objective-count functional-readiness audit stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact post-materialization merge gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$EXPECTED_HEAD"
  )"

test "$MERGE_COMMIT" = "$EXPECTED_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_PREVIOUS_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_MATERIALIZATION_COMMIT"
test -z "${EXTRA_PARENT:-}"

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,mergeCommit,headRefOid,baseRefName,title
)"

jq -e \
  --arg merge "$EXPECTED_HEAD" \
  --arg feature "$EXPECTED_MATERIALIZATION_COMMIT" \
  --arg base "$BASE" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge
    and .headRefOid == $feature
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 inputs"
  ' <<<"$PR_DATA" >/dev/null

verify_sha \
  "$NO_CI_REPORT" \
  "$EXPECTED_NO_CI_REPORT_SHA"

verify_sha \
  "$NO_CI_SURFACE" \
  "$EXPECTED_NO_CI_SURFACE_SHA"

jq -e '
  .status
    == "no_ci_registration_expected_from_workflow_trigger_filters"
  and .pull_request == 34
  and .feature_head
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"
  and .changed_file_count == 139
  and .eligible_pull_request_workflow_count == 0
  and .registered_ci.failure_count == 0
  and .decision.ci_absence_is_expected == true
  and .blocker_count == 0
  and .audit_complete == true
' "$NO_CI_REPORT" >/dev/null

echo "post_materialization_merge_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "materialization_commit=$EXPECTED_MATERIALIZATION_COMMIT"
echo "pull_request=34"
echo "no_ci_merge_evidence=PASS"

echo
echo "=== 2. Canonical materialization integrity gate ==="

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -f "$CAMPAIGN_ROOT/campaign_manifest.json"
test -f "$CAMPAIGN_ROOT/campaign_spec.json"
test -f "$CAMPAIGN_ROOT/instances.csv"
test -f "$WORKLOAD_ROOT/common_workloads_manifest.json"

test "$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name manifest.json |
    wc -l
)" -eq 60

test "$(
  find "$CAMPAIGN_ROOT/instances" \
    -type f \
    -name objectives.yaml |
    wc -l
)" -eq 60

test "$(
  find "$WORKLOAD_ROOT" \
    -maxdepth 1 \
    -type f \
    -name 'replication_*_seed_*.json' |
    wc -l
)" -eq 10

jq -e '
  .status
    == "sa5_objective_count_stage10_structure_and_common_workloads_materialized"
  and .source_commit
    == "548df8f2f389508f29dbde24dcddec6724adbccc"
  and .canonical_campaign.expected_instance_count == 60
  and .canonical_campaign.realised_instance_count == 60
  and .canonical_campaign.campaign_file_count == 134
  and .common_workloads.workload_count == 10
  and .common_workloads.workload_length == 32
  and .common_workloads.contributive_query_count_per_workload == 24
  and .common_workloads.non_contributive_query_count_per_workload == 8
  and .audits.structure.status == "PASS"
  and .audits.structure.failure_count == 0
  and .audits.common_workloads.status == "PASS"
  and .audits.common_workloads.failure_count == 0
  and .audits.common_workloads.operator_oracle_mismatch_count == 0
  and .scientific_controls.canonical_campaign_generated == true
  and .scientific_controls.canonical_campaign_materialization_performed == true
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

EXISTING_SPEC_COUNT="$({
  find "$EXECUTION_SPEC_TARGET_DIR" \
    -maxdepth 1 \
    -type f \
    -name 'objective_count_stage10_rep_*_canonical.json' \
    2>/dev/null || true
} | wc -l)"

EXISTING_RUN_COUNT="$({
  find "$RUN_TARGET_DIR" \
    -maxdepth 1 \
    -type d \
    -name 'objective_count_stage10_rep_*_canonical' \
    2>/dev/null || true
} | wc -l)"

test "$EXISTING_SPEC_COUNT" -eq 0
test "$EXISTING_RUN_COUNT" -eq 0

echo "canonical_materialization_integrity_gate=PASS"
echo "canonical_instance_count=60"
echo "canonical_common_workload_count=10"
echo "existing_canonical_execution_spec_count=0"
echo "existing_canonical_run_count=0"
echo "canonical_functional_execution_performed=false"

echo
echo "=== 3. Targeted contract regression gate ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests/test_objective_count_generator_v2.py \
  backend/harness/sensitivity_generator/tests/test_objective_count_family_v2.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operators_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_session_support_policy_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_structure_auditor_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_common_workloads_v2.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py \
  backend/harness/sensitivity_execution/tests/test_workload_spec.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_workload_contribution_capacity_amendment.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_noise_operator_and_redundancy_ordering_amendment.py \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"

echo "targeted_contract_regression_gate=PASS"

echo
echo "=== 4. Build deterministic detached execution-spec candidates ==="

rm -rf "$AUDIT_ROOT"

for MIRROR in "$MIRROR_A" "$MIRROR_B"; do
  mkdir -p \
    "$MIRROR/execution_specs" \
    "$MIRROR/runs"

  ln -s \
    "$ROOT/$E3_ROOT/campaigns" \
    "$MIRROR/campaigns"
done

export AUDIT_ROOT
export MIRROR_A
export MIRROR_B
export REPORT
export SURFACE
export ROOT
export CAMPAIGN_ROOT_ABS="$ROOT/$CAMPAIGN_ROOT"
export WORKLOAD_ROOT_ABS="$ROOT/$WORKLOAD_ROOT"
export EXPECTED_HEAD
export EXPECTED_MATERIALIZATION_COMMIT
export EXPECTED_MATERIALIZATION_REPORT_SHA
export EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import inspect
import json
import os
import shutil
from collections import defaultdict
from pathlib import Path
from typing import Any

from backend.ckg.ckg_updater import CKGGraph
from backend.harness.sensitivity_execution.execute_controlled_family import (
    E3_EXECUTOR_VERSION,
    _build_instance_ckg,
    _execute_instance,
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    SCHEMA_VERSION as EXECUTION_SCHEMA_VERSION,
    validate_execution_spec,
)
from backend.harness.sensitivity_execution.validate_workload_spec import (
    validate_workload_spec,
)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


audit_root = Path(os.environ["AUDIT_ROOT"])
mirror_a = Path(os.environ["MIRROR_A"])
mirror_b = Path(os.environ["MIRROR_B"])
report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])

campaign_root = Path(os.environ["CAMPAIGN_ROOT_ABS"])
workload_root = Path(os.environ["WORKLOAD_ROOT_ABS"])

campaign_manifest = read_json(
    campaign_root / "campaign_manifest.json"
)
common_manifest = read_json(
    workload_root / "common_workloads_manifest.json"
)

assert campaign_manifest["campaign_id"] == (
    "objective_count_stage10_c8_nv32"
)
assert campaign_manifest["factor"] == "objective_count"
assert campaign_manifest["levels"] == [1, 2, 5, 10, 20, 50]
assert len(campaign_manifest["seeds"]) == 10
assert campaign_manifest["expected_instance_count"] == 60
assert campaign_manifest["realised_instance_count"] == 60
assert campaign_manifest["session_support_policy"] == (
    "union_requirement_sets"
)
assert campaign_manifest["campaign_generator_version"] == (
    "mcad-sensitivity-e2.2-objective-count-v2"
)
assert campaign_manifest["structural_generator_version"] == (
    "mcad-sensitivity-e2.1-objective-count-v2"
)

assert common_manifest["workload_count"] == 10
assert common_manifest["workload_length"] == 32
assert common_manifest[
    "contributive_query_count_per_workload"
] == 24
assert common_manifest[
    "non_contributive_query_count_per_workload"
] == 8
assert len(common_manifest["entries"]) == 10

with (campaign_root / "instances.csv").open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    rows = [dict(row) for row in csv.DictReader(handle)]

assert len(rows) == 60

rows_by_replication: dict[int, list[dict[str, str]]] = defaultdict(list)
for row in rows:
    rows_by_replication[int(row["replication_index"])].append(row)

entries_by_replication = {
    int(entry["replication_index"]): entry
    for entry in common_manifest["entries"]
}

assert set(rows_by_replication) == set(range(10))
assert set(entries_by_replication) == set(range(10))


def candidate_payload(
    replication_index: int,
    entry: dict[str, Any],
    selected_rows: list[dict[str, str]],
) -> dict[str, Any]:
    seed = int(entry["seed"])
    token = f"rep_{replication_index:03d}"

    return {
        "contract_version": EXECUTION_SCHEMA_VERSION,
        "execution_id": (
            "sa5-objective-count-stage10-"
            f"{token}-canonical-v1"
        ),
        "campaign_dir": (
            "../campaigns/"
            "objective_count_stage10_c8_nv32"
        ),
        "workload_path": (
            "../campaigns/"
            "objective_count_stage10_c8_nv32/"
            "common_workloads/"
            f"replication_{replication_index:03d}_"
            f"seed_{seed}.json"
        ),
        "output_dir": (
            "../runs/"
            "objective_count_stage10_"
            f"rep_{replication_index:03d}_canonical"
        ),
        "instance_selection": {
            "instance_ids": [
                row["relative_instance_dir"]
                for row in selected_rows
            ]
        },
        "continue_on_instance_failure": False,
    }


def build_candidates(mirror_root: Path) -> dict[str, Any]:
    spec_dir = mirror_root / "execution_specs"
    entries: list[dict[str, Any]] = []
    selected_ids: list[str] = []

    for replication_index in range(10):
        entry = entries_by_replication[replication_index]
        seed = int(entry["seed"])

        selected_rows = sorted(
            rows_by_replication[replication_index],
            key=lambda row: int(row["factor_level"]),
        )

        assert len(selected_rows) == 6
        assert [
            int(row["factor_level"])
            for row in selected_rows
        ] == [1, 2, 5, 10, 20, 50]
        assert {
            int(row["seed"])
            for row in selected_rows
        } == {seed}

        workload_filename = str(entry["workload_path"])
        expected_filename = (
            f"replication_{replication_index:03d}_"
            f"seed_{seed}.json"
        )
        assert workload_filename == expected_filename

        workload_path = workload_root / workload_filename
        workload = read_json(workload_path)
        validate_workload_spec(workload)

        assert len(workload["steps"]) == 32
        assert workload["workload_id"] == (
            "sa5-objective-count-stage10-"
            f"rep-{replication_index:03d}-seed-{seed}"
        )

        representative = selected_rows[0]
        assert int(representative["factor_level"]) == 1
        assert workload["objective_id"] == representative["objective_id"]

        payload = candidate_payload(
            replication_index,
            entry,
            selected_rows,
        )
        validate_execution_spec(payload)

        filename = (
            "objective_count_stage10_"
            f"rep_{replication_index:03d}_canonical.json"
        )
        spec_path = spec_dir / filename
        write_json(spec_path, payload)

        inputs = load_execution_inputs(spec_path)

        assert len(inputs.instances) == 6
        assert [
            instance.factor_level
            for instance in inputs.instances
        ] == [1, 2, 5, 10, 20, 50]
        assert {
            instance.replication_index
            for instance in inputs.instances
        } == {replication_index}
        assert {instance.seed for instance in inputs.instances} == {seed}
        assert inputs.workload_path.resolve() == workload_path.resolve()
        assert inputs.campaign_dir.resolve() == campaign_root.resolve()
        assert inputs.output_dir == (
            mirror_root
            / "runs"
            / (
                "objective_count_stage10_"
                f"rep_{replication_index:03d}_canonical"
            )
        ).resolve()

        ids = [
            instance.canonical_instance_id
            for instance in inputs.instances
        ]
        selected_ids.extend(ids)

        entries.append(
            {
                "replication_index": replication_index,
                "seed": seed,
                "filename": filename,
                "execution_id": payload["execution_id"],
                "file_sha256": sha256_file(spec_path),
                "semantic_sha256": stable_json_sha256(payload),
                "selected_instance_count": 6,
                "selected_factor_levels": [1, 2, 5, 10, 20, 50],
                "selected_instance_ids": ids,
                "workload_path": payload["workload_path"],
                "workload_file_sha256": sha256_file(workload_path),
                "workload_semantic_digest": entry[
                    "semantic_workload_digest"
                ],
                "output_dir": payload["output_dir"],
                "portable_relative_paths": True,
                "load_execution_inputs_status": "PASS",
            }
        )

    assert len(entries) == 10
    assert len(selected_ids) == 60
    assert len(set(selected_ids)) == 60

    manifest = {
        "schema_version": (
            "mcad-sa5-objective-count-stage10-"
            "execution-spec-candidate-manifest-v1"
        ),
        "campaign_id": campaign_manifest["campaign_id"],
        "source_commit": os.environ["EXPECTED_HEAD"],
        "materialization_commit": os.environ[
            "EXPECTED_MATERIALIZATION_COMMIT"
        ],
        "execution_schema_version": EXECUTION_SCHEMA_VERSION,
        "executor_version": E3_EXECUTOR_VERSION,
        "execution_spec_count": 10,
        "selected_instances_per_spec": 6,
        "total_selected_instance_count": 60,
        "unique_selected_instance_count": 60,
        "portable_relative_paths": True,
        "entries": entries,
    }

    write_json(
        mirror_root / "execution_spec_candidate_manifest.json",
        manifest,
    )

    return manifest


manifest_a = build_candidates(mirror_a)
manifest_b = build_candidates(mirror_b)

spec_files_a = sorted((mirror_a / "execution_specs").glob("*.json"))
spec_files_b = sorted((mirror_b / "execution_specs").glob("*.json"))

assert len(spec_files_a) == 10
assert len(spec_files_b) == 10
assert [path.name for path in spec_files_a] == [
    path.name for path in spec_files_b
]

for path_a, path_b in zip(spec_files_a, spec_files_b):
    assert path_a.read_bytes() == path_b.read_bytes()

assert manifest_a == manifest_b

candidate_manifest_a = (
    mirror_a / "execution_spec_candidate_manifest.json"
)
candidate_manifest_b = (
    mirror_b / "execution_spec_candidate_manifest.json"
)

assert candidate_manifest_a.read_bytes() == candidate_manifest_b.read_bytes()

# Verify the production executor's objective rebinding contract by source
# structure without running any workload step.
execute_source = inspect.getsource(_execute_instance)
assert '"objective_id": instance.objective_id' in execute_source
assert 'ckg.evaluate_step' in execute_source
assert 'ckg.update_from_step' in execute_source

# Stratified readiness-only bootstrap: every factor level is covered by
# replication 0, and every replication is covered at level 1. The evaluator
# is monkeypatched to fail if any workload step is accidentally executed.
all_inputs = [
    load_execution_inputs(path)
    for path in spec_files_a
]

bootstrap_instances = []
for inputs in all_inputs:
    for instance in inputs.instances:
        if (
            instance.replication_index == 0
            or instance.factor_level == 1
        ):
            bootstrap_instances.append(instance)

unique_bootstrap = {
    instance.canonical_instance_id: instance
    for instance in bootstrap_instances
}
bootstrap_instances = [
    unique_bootstrap[key]
    for key in sorted(unique_bootstrap)
]

assert len(bootstrap_instances) == 15
assert {
    instance.factor_level
    for instance in bootstrap_instances
} == {1, 2, 5, 10, 20, 50}
assert {
    instance.replication_index
    for instance in bootstrap_instances
} == set(range(10))

bootstrap_root = audit_root / "readiness_bootstrap_runtime"
bootstrap_rows: list[dict[str, Any]] = []
evaluator_call_count = 0

original_evaluate_step = CKGGraph.evaluate_step


def forbidden_evaluate_step(*args: Any, **kwargs: Any) -> Any:
    raise AssertionError(
        "Functional evaluator execution is forbidden during "
        "the readiness-only bootstrap probe."
    )

CKGGraph.evaluate_step = forbidden_evaluate_step

try:
    for instance in bootstrap_instances:
        runtime_dir = bootstrap_root / instance.canonical_instance_id
        ckg = _build_instance_ckg(
            instance=instance,
            runtime_output_dir=runtime_dir,
        )

        assert instance.objective_id in ckg.objectives
        assert len(ckg.objectives) == instance.factor_level
        assert len(ckg.G) > 0
        assert not ckg.history
        assert not ckg.session_coverage
        assert not ckg.session_weighted_coverage
        assert not ckg.session_resource_coverage

        bootstrap_rows.append(
            {
                "canonical_instance_id": instance.canonical_instance_id,
                "factor_level": instance.factor_level,
                "replication_index": instance.replication_index,
                "seed": instance.seed,
                "objective_count": len(ckg.objectives),
                "graph_node_count": len(ckg.G),
                "graph_edge_count": ckg.G.number_of_edges(),
                "selected_objective_present": True,
                "fresh_history": True,
                "fresh_session_state": True,
            }
        )
finally:
    CKGGraph.evaluate_step = original_evaluate_step

assert evaluator_call_count == 0
assert len(bootstrap_rows) == 15

shutil.rmtree(bootstrap_root)
assert not bootstrap_root.exists()

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "functional-execution-readiness-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "execution_spec_materialization_ready"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "materialization_commit": os.environ[
        "EXPECTED_MATERIALIZATION_COMMIT"
    ],
    "materialization_report_sha256": os.environ[
        "EXPECTED_MATERIALIZATION_REPORT_SHA"
    ],
    "canonical_campaign_file_manifest_sha256": os.environ[
        "EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"
    ],
    "campaign": {
        "campaign_id": campaign_manifest["campaign_id"],
        "campaign_digest": campaign_manifest["campaign_digest"],
        "campaign_spec_digest": campaign_manifest[
            "campaign_spec_digest"
        ],
        "levels": campaign_manifest["levels"],
        "seeds": campaign_manifest["seeds"],
        "instance_count": 60,
        "common_workload_count": 10,
        "workload_length": 32,
        "contributive_steps_per_workload": 24,
        "non_contributive_steps_per_workload": 8,
    },
    "execution_spec_candidates": {
        "candidate_root": str(mirror_a / "execution_specs"),
        "candidate_manifest": str(candidate_manifest_a),
        "candidate_manifest_sha256": sha256_file(candidate_manifest_a),
        "execution_schema_version": EXECUTION_SCHEMA_VERSION,
        "executor_version": E3_EXECUTOR_VERSION,
        "execution_spec_count": 10,
        "selected_instances_per_spec": 6,
        "total_selected_instance_count": 60,
        "unique_selected_instance_count": 60,
        "portable_relative_paths": True,
        "deterministic_candidate_replay": True,
        "all_validate_execution_spec": True,
        "all_load_execution_inputs": True,
        "runtime_objective_rebinding_confirmed": True,
        "entries": manifest_a["entries"],
    },
    "readiness_bootstrap_probe": {
        "performed": True,
        "formal_campaign_execution": False,
        "workload_step_execution_performed": False,
        "evaluator_call_count": 0,
        "instance_count": 15,
        "covered_factor_levels": [1, 2, 5, 10, 20, 50],
        "covered_replication_indices": list(range(10)),
        "runtime_cleaned": True,
        "instances": bootstrap_rows,
    },
    "authorization": {
        "execution_spec_materialization_authorized": True,
        "canonical_functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_execution_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": True,
        "canonical_campaign_materialization_performed": True,
        "canonical_execution_specs_committed": False,
        "canonical_stage10_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "readiness_complete": True,
    "next_stage": (
        "materialize_sa5_objective_count_"
        "stage10_execution_specs"
    ),
}

write_json(report_path, report)

surface_lines = [
    "SA5 OBJECTIVE-COUNT STAGE-10 FUNCTIONAL-EXECUTION READINESS",
    "=" * 92,
    f"source_commit={report['source_commit']}",
    f"materialization_commit={report['materialization_commit']}",
    f"status={report['status']}",
    "",
    "=== CANONICAL INPUTS ===",
    "canonical_instance_count=60",
    "canonical_common_workload_count=10",
    "workload_length=32",
    "contributive_steps_per_workload=24",
    "non_contributive_steps_per_workload=8",
    "",
    "=== EXECUTION-SPEC CANDIDATES ===",
    "execution_spec_count=10",
    "selected_instances_per_spec=6",
    "total_selected_instance_count=60",
    "unique_selected_instance_count=60",
    "portable_relative_paths=true",
    "deterministic_candidate_replay=PASS",
    "all_validate_execution_spec=PASS",
    "all_load_execution_inputs=PASS",
    "runtime_objective_rebinding_confirmed=true",
    "",
    "=== READINESS-ONLY BOOTSTRAP PROBE ===",
    "bootstrap_probe_instance_count=15",
    "covered_factor_levels=1,2,5,10,20,50",
    "covered_replication_indices=0,1,2,3,4,5,6,7,8,9",
    "workload_step_execution_performed=false",
    "evaluator_call_count=0",
    "bootstrap_runtime_cleaned=true",
    "",
    "=== AUTHORIZATION ===",
    "execution_spec_materialization_authorized=true",
    "canonical_functional_execution_authorized=false",
    "timing_execution_authorized=false",
    "scientific_execution_authorized=false",
    "manuscript_integration_authorized=false",
    "",
    "canonical_execution_specs_committed=false",
    "canonical_stage10_functional_execution_performed=false",
    "scientific_execution_performed=false",
    "manuscript_modified=false",
    "blocker_count=0",
    "readiness_complete=true",
    f"next_stage={report['next_stage']}",
    "",
]

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("execution_spec_candidate_generation=PASS")
print("execution_spec_candidate_count=10")
print("candidate_selected_instances_per_spec=6")
print("candidate_total_selected_instance_count=60")
print("candidate_unique_selected_instance_count=60")
print("portable_relative_paths=true")
print("deterministic_candidate_replay=PASS")
print("candidate_validation=PASS")
print("candidate_input_discovery=PASS")
print("runtime_objective_rebinding_confirmed=true")
print("readiness_bootstrap_probe=PASS")
print("bootstrap_probe_instance_count=15")
print("bootstrap_probe_factor_level_coverage=PASS")
print("bootstrap_probe_replication_coverage=PASS")
print("workload_step_execution_performed=false")
print("evaluator_call_count=0")
print("bootstrap_runtime_cleaned=true")
print("execution_spec_materialization_authorized=true")
print("canonical_functional_execution_authorized=false")
print(f"candidate_manifest={candidate_manifest_a}")
print(f"candidate_manifest_sha256={sha256_file(candidate_manifest_a)}")
print(f"report={report_path}")
print(f"report_sha256={sha256_file(report_path)}")
print(f"surface={surface_path}")
print(f"surface_sha256={sha256_file(surface_path)}")
print(f"next_stage={report['next_stage']}")
PY

echo
echo "=== 5. Validate functional-readiness decision ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-functional-execution-readiness-v1"
  and .status
    == "sa5_objective_count_stage10_execution_spec_materialization_ready"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .materialization_commit
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"

  and .campaign.instance_count == 60
  and .campaign.common_workload_count == 10
  and .campaign.workload_length == 32
  and .campaign.contributive_steps_per_workload == 24
  and .campaign.non_contributive_steps_per_workload == 8

  and .execution_spec_candidates.execution_spec_count == 10
  and .execution_spec_candidates.selected_instances_per_spec == 6
  and .execution_spec_candidates.total_selected_instance_count == 60
  and .execution_spec_candidates.unique_selected_instance_count == 60
  and .execution_spec_candidates.portable_relative_paths == true
  and .execution_spec_candidates.deterministic_candidate_replay == true
  and .execution_spec_candidates.all_validate_execution_spec == true
  and .execution_spec_candidates.all_load_execution_inputs == true
  and .execution_spec_candidates.runtime_objective_rebinding_confirmed == true
  and (
    .execution_spec_candidates.entries
    | length
  ) == 10

  and .readiness_bootstrap_probe.performed == true
  and .readiness_bootstrap_probe.formal_campaign_execution == false
  and .readiness_bootstrap_probe.workload_step_execution_performed == false
  and .readiness_bootstrap_probe.evaluator_call_count == 0
  and .readiness_bootstrap_probe.instance_count == 15
  and .readiness_bootstrap_probe.covered_factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .readiness_bootstrap_probe.covered_replication_indices
    == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
  and .readiness_bootstrap_probe.runtime_cleaned == true

  and .authorization.execution_spec_materialization_authorized == true
  and .authorization.canonical_functional_execution_authorized == false
  and .authorization.timing_execution_authorized == false
  and .authorization.scientific_execution_authorized == false
  and .authorization.manuscript_integration_authorized == false

  and .scientific_controls.canonical_campaign_generated == true
  and .scientific_controls.canonical_campaign_materialization_performed == true
  and .scientific_controls.canonical_execution_specs_committed == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false

  and .blocker_count == 0
  and .readiness_complete == true
  and .next_stage
    == "materialize_sa5_objective_count_stage10_execution_specs"
' "$REPORT" >/dev/null

echo "functional_execution_readiness_report_validation=PASS"

echo
echo "=== 6. Repository and formal-execution immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$({
  find "$EXECUTION_SPEC_TARGET_DIR" \
    -maxdepth 1 \
    -type f \
    -name 'objective_count_stage10_rep_*_canonical.json' \
    2>/dev/null || true
} | wc -l)" -eq 0

test "$({
  find "$RUN_TARGET_DIR" \
    -maxdepth 1 \
    -type d \
    -name 'objective_count_stage10_rep_*_canonical' \
    2>/dev/null || true
} | wc -l)" -eq 0

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "detached_execution_spec_candidates_generated=true"
echo "canonical_execution_specs_committed=false"
echo "readiness_bootstrap_probe_performed=true"
echo "workload_step_execution_performed=false"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

CANDIDATE_MANIFEST="$MIRROR_A/execution_spec_candidate_manifest.json"
CANDIDATE_MANIFEST_SHA="$(
  sha256sum "$CANDIDATE_MANIFEST" |
    awk '{print $1}'
)"

echo "sa5_objective_count_stage10_functional_execution_readiness=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "materialization_commit=$EXPECTED_MATERIALIZATION_COMMIT"

echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"
echo "candidate_manifest=$CANDIDATE_MANIFEST"
echo "candidate_manifest_sha256=$CANDIDATE_MANIFEST_SHA"

echo "execution_spec_candidate_count=10"
echo "candidate_selected_instances_per_spec=6"
echo "candidate_total_selected_instance_count=60"
echo "candidate_unique_selected_instance_count=60"
echo "portable_relative_paths=true"
echo "deterministic_candidate_replay=PASS"

echo "readiness_bootstrap_probe=PASS"
echo "bootstrap_probe_instance_count=15"
echo "workload_step_execution_performed=false"
echo "evaluator_call_count=0"

echo "blocker_count=0"
echo "readiness_complete=true"

echo "execution_spec_materialization_authorized=true"
echo "canonical_functional_execution_authorized=false"
echo "canonical_execution_specs_committed=false"
echo "canonical_stage10_functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=materialize_sa5_objective_count_stage10_execution_specs"

git status --short --branch
