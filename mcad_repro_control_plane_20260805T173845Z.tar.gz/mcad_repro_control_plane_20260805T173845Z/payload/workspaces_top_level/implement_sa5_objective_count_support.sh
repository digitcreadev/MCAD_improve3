#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"

CONTROLLED="backend/harness/sensitivity_generator/families/controlled_families.py"
OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"

CONTROLLED_TEST="backend/harness/sensitivity_generator/tests/test_controlled_families.py"
OBJECTIVE_FAMILY_TEST="backend/harness/sensitivity_generator/tests/test_objective_count_family.py"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"
E3_CONTRACT="backend/harness/sensitivity_execution/e3_contract.yaml"

COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py"
OBJECTIVE_COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"
E3_CONTRACT_TEST="backend/harness/sensitivity_execution/tests/test_e3_contract.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

EXPECTED_CONTROLLED_SHA="541ad65aea8a714af1aaca979c58ba5b983fd415f799c6fb7f4e0ddf41f264de"
EXPECTED_EXECUTOR_SHA="aac9adad0dbabdb90b2ca43e81f9426924343b425156abfc37cf61c096eb4a6c"
EXPECTED_VALIDATOR_SHA="b5cbe65d72aa45aaa8697152adaadbce637a5d42dd2d7cbe49401f95ed05df2c"
EXPECTED_CONTROLLED_TEST_SHA="0bfa32b0b237b66927d65ea470dd98b44121f9db1b93b82f91c162123f3a685e"
EXPECTED_COMPATIBILITY_TEST_SHA="af88f3ae6e9b43b069ee8507e61d241433efc748c7392c2634c5ceac3f1e2474"
EXPECTED_E3_CONTRACT_TEST_SHA="238ce658ae654b015ad141055470ef3d040f0827458de4a9dc1476c4e078b6b0"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

trap 'echo "[ERROR] SA5 implementation stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Implementation gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$CONTROLLED" \
  "$CONTROLLED_TEST" \
  "$EXECUTOR" \
  "$VALIDATOR" \
  "$E3_CONTRACT" \
  "$COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

for FILE in \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST"
do
  test ! -e "$FILE"
done

test "$(sha256sum "$CONTROLLED" | awk '{print $1}')" \
  = "$EXPECTED_CONTROLLED_SHA"

test "$(sha256sum "$EXECUTOR" | awk '{print $1}')" \
  = "$EXPECTED_EXECUTOR_SHA"

test "$(sha256sum "$VALIDATOR" | awk '{print $1}')" \
  = "$EXPECTED_VALIDATOR_SHA"

test "$(sha256sum "$CONTROLLED_TEST" | awk '{print $1}')" \
  = "$EXPECTED_CONTROLLED_TEST_SHA"

test "$(sha256sum "$COMPATIBILITY_TEST" | awk '{print $1}')" \
  = "$EXPECTED_COMPATIBILITY_TEST_SHA"

test "$(sha256sum "$E3_CONTRACT_TEST" | awk '{print $1}')" \
  = "$EXPECTED_E3_CONTRACT_TEST_SHA"

! grep -F \
  'factor_generator_profiles:' \
  "$E3_CONTRACT" >/dev/null

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "implementation_gate=PASS"
echo "source_commit=$EXPECTED_HEAD"
echo "campaign_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Create implementation branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/implement-sa5-objective-count-${STAMP}"
SMOKE_ROOT="/workspaces/sa5_objective_count_implementation_smoke_${STAMP}"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

rm -rf "$SMOKE_ROOT"
mkdir -p "$SMOKE_ROOT"

echo "branch=$BRANCH"
echo "smoke_root=$SMOKE_ROOT"

echo
echo "=== 3. Author objective-count implementation ==="

"$PYTHON" - \
  "$ROOT" \
  "$CONTROLLED" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$CONTROLLED_TEST" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$EXECUTOR" \
  "$VALIDATOR" \
  "$E3_CONTRACT" \
  "$COMPATIBILITY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()

controlled = root / sys.argv[2]
objective_generator = root / sys.argv[3]
objective_family = root / sys.argv[4]
controlled_test = root / sys.argv[5]
objective_family_test = root / sys.argv[6]
executor = root / sys.argv[7]
validator = root / sys.argv[8]
e3_contract = root / sys.argv[9]
compatibility_test = root / sys.argv[10]
objective_compatibility_test = root / sys.argv[11]
e3_contract_test = root / sys.argv[12]


def replace_once(
    path: Path,
    old: str,
    new: str,
) -> None:
    text = path.read_text(encoding="utf-8")

    count = text.count(old)

    if count != 1:
        raise SystemExit(
            f"Expected one patch anchor in {path}, "
            f"found {count}."
        )

    path.write_text(
        text.replace(old, new, 1),
        encoding="utf-8",
    )


def append_text(
    path: Path,
    addition: str,
) -> None:
    text = path.read_text(encoding="utf-8")

    path.write_text(
        text.rstrip() + "\n\n" + addition.rstrip() + "\n",
        encoding="utf-8",
    )


def write_new(
    path: Path,
    content: str,
) -> None:
    if path.exists():
        raise SystemExit(f"Refusing to replace existing file: {path}")

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    path.write_text(
        content.rstrip() + "\n",
        encoding="utf-8",
    )


write_new(
    objective_generator,
    r'''
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from backend.ckg.ckg_updater import CKGGraph
from backend.harness.sensitivity_generator.structural_generator import (
    StructuralConfig,
    build_objectives_document,
    count_structure,
    sha256_digest,
    validate_graph_projection,
    validate_reference_integrity,
    write_yaml,
)

GENERATOR_VERSION = "mcad-sensitivity-e2.1-objective-count-v1"


@dataclass(frozen=True)
class ObjectiveCountConfig:
    instance_id: str
    objective_count: int
    selected_objective_index: int
    constraints_per_objective: int
    virtual_nodes_per_objective: int
    seed: int
    output_dir: str


@dataclass(frozen=True)
class ObjectiveCountStructuralManifest:
    generator_version: str
    objective_id: str
    selected_objective_id: str
    selected_objective_index: int
    objective_ids: tuple[str, ...]
    requested_objective_count: int
    realised_objective_count: int
    requested_constraint_count: int
    realised_constraint_count: int
    requested_virtual_node_count: int
    realised_virtual_node_count: int
    total_constraint_count: int
    total_virtual_node_count: int
    requirement_set_count: int
    requirement_membership_link_count: int
    membership_density: float
    graph_node_count: int
    graph_edge_count: int
    seed: int
    selected_objective_shape_digest: str
    configuration_digest: str
    instance_digest: str


def _identifier(value: str) -> str:
    cleaned = re.sub(
        r"[^A-Za-z0-9_]+",
        "_",
        value.strip(),
    )
    cleaned = re.sub(
        r"_+",
        "_",
        cleaned,
    ).strip("_")

    if not cleaned:
        raise ValueError(
            "instance_id must contain an "
            "alphanumeric character."
        )

    return cleaned


def _positive(
    name: str,
    value: int,
) -> None:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or value <= 0
    ):
        raise ValueError(
            f"{name} must be a strictly positive integer."
        )


def _validate(
    config: ObjectiveCountConfig,
) -> None:
    _identifier(config.instance_id)
    _positive(
        "objective_count",
        config.objective_count,
    )
    _positive(
        "constraints_per_objective",
        config.constraints_per_objective,
    )
    _positive(
        "virtual_nodes_per_objective",
        config.virtual_nodes_per_objective,
    )
    _positive("seed", config.seed)

    if (
        isinstance(
            config.selected_objective_index,
            bool,
        )
        or not isinstance(
            config.selected_objective_index,
            int,
        )
        or not (
            0
            <= config.selected_objective_index
            < config.objective_count
        )
    ):
        raise ValueError(
            "selected_objective_index must identify "
            "one generated objective."
        )

    if (
        config.virtual_nodes_per_objective
        < config.constraints_per_objective
    ):
        raise ValueError(
            "virtual_nodes_per_objective must be "
            "at least constraints_per_objective."
        )

    if not str(config.output_dir).strip():
        raise ValueError(
            "output_dir must not be empty."
        )


def _objective_id(
    config: ObjectiveCountConfig,
    index: int,
) -> str:
    return (
        f"O_{_identifier(config.instance_id).upper()}_"
        f"OBJ{index + 1:04d}"
    )


def _normalise_ids(
    value: Any,
    objective_id: str,
) -> Any:
    if isinstance(value, dict):
        return {
            key: _normalise_ids(
                item,
                objective_id,
            )
            for key, item in value.items()
        }

    if isinstance(value, list):
        return [
            _normalise_ids(
                item,
                objective_id,
            )
            for item in value
        ]

    if isinstance(value, str):
        return value.replace(
            objective_id,
            "<SELECTED_OBJECTIVE>",
        )

    return value


def _prepare_output(
    output_dir: Path,
) -> None:
    if output_dir.exists():
        if any(output_dir.iterdir()):
            raise ValueError(
                "Objective-count structural output "
                "directory must be absent or empty: "
                f"{output_dir}"
            )
    else:
        output_dir.mkdir(
            parents=True,
            exist_ok=False,
        )


def _build_document(
    config: ObjectiveCountConfig,
) -> dict[str, Any]:
    objectives: list[dict[str, Any]] = []

    for index in range(
        config.objective_count
    ):
        objective_id = _objective_id(
            config,
            index,
        )

        generated = build_objectives_document(
            StructuralConfig(
                objective_id=objective_id,
                n_constraints=(
                    config.constraints_per_objective
                ),
                n_virtual_nodes=(
                    config.virtual_nodes_per_objective
                ),
                seed=(
                    config.seed
                    + index * 1_000_003
                ),
                output_dir="<not-written>",
            )
        ).get("objectives")

        if (
            not isinstance(generated, list)
            or len(generated) != 1
            or not isinstance(generated[0], dict)
        ):
            raise ValueError(
                "Legacy structural generator did not "
                "return exactly one objective."
            )

        objectives.append(generated[0])

    return {"objectives": objectives}


def generate_objective_count_instance(
    config: ObjectiveCountConfig,
) -> ObjectiveCountStructuralManifest:
    _validate(config)

    output_dir = Path(config.output_dir)
    _prepare_output(output_dir)

    document = _build_document(config)

    objective_ids = tuple(
        str(item["id"])
        for item in document["objectives"]
    )

    selected_id = objective_ids[
        config.selected_objective_index
    ]

    objectives_path = (
        output_dir / "objectives.yaml"
    )

    write_yaml(
        objectives_path,
        document,
    )

    ckg = CKGGraph(
        output_dir=str(
            output_dir / "ckg_runtime"
        )
    )

    ckg.G.clear()
    ckg.objectives.clear()
    ckg.history.clear()
    ckg.session_coverage.clear()
    ckg.session_weighted_coverage.clear()
    ckg.session_resource_coverage.clear()

    ckg.bootstrap_objectives(
        str(objectives_path)
    )

    if set(ckg.objectives) != set(objective_ids):
        raise ValueError(
            "Realised objective identifiers differ "
            "from the generated set."
        )

    counts_by_objective: dict[
        str,
        dict[str, int | float],
    ] = {}

    maximum_membership_count = 0

    for objective_id in objective_ids:
        validate_reference_integrity(
            ckg,
            objective_id,
        )
        validate_graph_projection(
            ckg,
            objective_id,
        )

        counts = count_structure(
            ckg,
            objective_id,
        )

        counts_by_objective[
            objective_id
        ] = counts

        if (
            counts["constraint_count"]
            != config.constraints_per_objective
        ):
            raise ValueError(
                "Per-objective constraint baseline changed."
            )

        if (
            counts["virtual_node_count"]
            != config.virtual_nodes_per_objective
        ):
            raise ValueError(
                "Per-objective virtual-node baseline changed."
            )

        for constraint in (
            ckg.objectives[
                objective_id
            ].get("constraints") or {}
        ).values():
            maximum_membership_count += (
                len(
                    constraint.get(
                        "requirement_sets"
                    ) or []
                )
                * len(
                    constraint.get(
                        "virtual_nodes"
                    ) or []
                )
            )

    selected_counts = counts_by_objective[
        selected_id
    ]

    total_constraints = sum(
        int(item["constraint_count"])
        for item in counts_by_objective.values()
    )

    total_virtual_nodes = sum(
        int(item["virtual_node_count"])
        for item in counts_by_objective.values()
    )

    requirement_sets = sum(
        int(item["requirement_set_count"])
        for item in counts_by_objective.values()
    )

    memberships = sum(
        int(item["membership_count"])
        for item in counts_by_objective.values()
    )

    density = (
        memberships / maximum_membership_count
        if maximum_membership_count
        else 0.0
    )

    configuration = asdict(config)
    configuration["output_dir"] = "<excluded>"

    configuration_digest = sha256_digest(
        configuration
    )

    selected_objective = document[
        "objectives"
    ][config.selected_objective_index]

    selected_shape_digest = sha256_digest(
        _normalise_ids(
            selected_objective,
            selected_id,
        )
    )

    instance_digest = sha256_digest(
        {
            "document": document,
            "configuration_digest": (
                configuration_digest
            ),
            "selected_objective_shape_digest": (
                selected_shape_digest
            ),
            "total_constraint_count": (
                total_constraints
            ),
            "total_virtual_node_count": (
                total_virtual_nodes
            ),
            "requirement_set_count": (
                requirement_sets
            ),
            "membership_count": memberships,
            "membership_density": round(
                density,
                6,
            ),
        }
    )

    manifest = ObjectiveCountStructuralManifest(
        generator_version=GENERATOR_VERSION,
        objective_id=selected_id,
        selected_objective_id=selected_id,
        selected_objective_index=(
            config.selected_objective_index
        ),
        objective_ids=objective_ids,
        requested_objective_count=(
            config.objective_count
        ),
        realised_objective_count=len(
            ckg.objectives
        ),
        requested_constraint_count=(
            config.constraints_per_objective
        ),
        realised_constraint_count=int(
            selected_counts["constraint_count"]
        ),
        requested_virtual_node_count=(
            config.virtual_nodes_per_objective
        ),
        realised_virtual_node_count=int(
            selected_counts["virtual_node_count"]
        ),
        total_constraint_count=(
            total_constraints
        ),
        total_virtual_node_count=(
            total_virtual_nodes
        ),
        requirement_set_count=(
            requirement_sets
        ),
        requirement_membership_link_count=(
            memberships
        ),
        membership_density=round(
            density,
            6,
        ),
        graph_node_count=(
            ckg.G.number_of_nodes()
        ),
        graph_edge_count=(
            ckg.G.number_of_edges()
        ),
        seed=config.seed,
        selected_objective_shape_digest=(
            selected_shape_digest
        ),
        configuration_digest=(
            configuration_digest
        ),
        instance_digest=instance_digest,
    )

    (
        output_dir / "manifest.json"
    ).write_text(
        json.dumps(
            asdict(manifest),
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )

    return manifest
''',
)

write_new(
    objective_family,
    r'''
from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

from backend.harness.sensitivity_generator.families.controlled_families import (
    ensure_positive_integer,
    normalise_identifier,
    prepare_output_directory,
    relative_instance_directory,
    sha256_payload,
    validate_unique_positive_values,
    write_json,
)
from backend.harness.sensitivity_generator.objective_count_generator import (
    GENERATOR_VERSION as STRUCTURAL_GENERATOR_VERSION,
)
from backend.harness.sensitivity_generator.objective_count_generator import (
    ObjectiveCountConfig,
    ObjectiveCountStructuralManifest,
    generate_objective_count_instance,
)

CAMPAIGN_GENERATOR_VERSION = (
    "mcad-sensitivity-e2.2-objective-count-v1"
)
FACTOR = "objective_count"


@dataclass(frozen=True)
class ObjectiveCountFamilySpec:
    campaign_id: str
    levels: tuple[int, ...]
    seeds: tuple[int, ...]
    baseline_constraints_per_objective: int
    baseline_virtual_nodes_per_objective: int
    selected_objective_index: int
    output_dir: str


@dataclass(frozen=True)
class ObjectiveCountInstanceRecord:
    campaign_id: str
    factor: str
    factor_level: int
    replication_index: int
    seed: int
    objective_id: str
    relative_instance_dir: str
    requested_constraint_count: int
    realised_constraint_count: int
    requested_virtual_node_count: int
    realised_virtual_node_count: int
    configuration_digest: str
    instance_digest: str
    generator_version: str
    requested_objective_count: int
    realised_objective_count: int
    selected_objective_index: int
    selected_objective_shape_digest: str
    total_constraint_count: int
    total_virtual_node_count: int
    requirement_set_count: int
    requirement_membership_link_count: int
    membership_density: float
    graph_node_count: int
    graph_edge_count: int


@dataclass(frozen=True)
class ObjectiveCountFamilyManifest:
    campaign_generator_version: str
    structural_generator_version: str
    campaign_id: str
    factor: str
    levels: tuple[int, ...]
    seeds: tuple[int, ...]
    baseline_constraints_per_objective: int
    baseline_virtual_nodes_per_objective: int
    selected_objective_index: int
    level_count: int
    replication_count: int
    expected_instance_count: int
    realised_instance_count: int
    campaign_spec_digest: str
    campaign_digest: str


def validate_spec(
    spec: ObjectiveCountFamilySpec,
) -> None:
    normalise_identifier(spec.campaign_id)

    validate_unique_positive_values(
        "levels",
        spec.levels,
    )
    validate_unique_positive_values(
        "seeds",
        spec.seeds,
    )

    ensure_positive_integer(
        "baseline_constraints_per_objective",
        spec.baseline_constraints_per_objective,
    )
    ensure_positive_integer(
        "baseline_virtual_nodes_per_objective",
        spec.baseline_virtual_nodes_per_objective,
    )

    if (
        spec.baseline_virtual_nodes_per_objective
        < spec.baseline_constraints_per_objective
    ):
        raise ValueError(
            "baseline_virtual_nodes_per_objective "
            "must be at least "
            "baseline_constraints_per_objective."
        )

    if (
        isinstance(
            spec.selected_objective_index,
            bool,
        )
        or not isinstance(
            spec.selected_objective_index,
            int,
        )
        or spec.selected_objective_index < 0
        or (
            spec.selected_objective_index
            >= min(spec.levels)
        )
    ):
        raise ValueError(
            "selected_objective_index must exist "
            "at every objective-count level."
        )

    if not str(spec.output_dir).strip():
        raise ValueError(
            "output_dir must not be empty."
        )


def stable_spec_payload(
    spec: ObjectiveCountFamilySpec,
) -> dict[str, object]:
    return {
        "campaign_generator_version": (
            CAMPAIGN_GENERATOR_VERSION
        ),
        "structural_generator_version": (
            STRUCTURAL_GENERATOR_VERSION
        ),
        "campaign_id": spec.campaign_id,
        "factor": FACTOR,
        "levels": list(spec.levels),
        "seeds": list(spec.seeds),
        "baseline_constraints_per_objective": (
            spec.baseline_constraints_per_objective
        ),
        "baseline_virtual_nodes_per_objective": (
            spec.baseline_virtual_nodes_per_objective
        ),
        "selected_objective_index": (
            spec.selected_objective_index
        ),
    }


def _instance_id(
    spec: ObjectiveCountFamilySpec,
    level: int,
    replication_index: int,
) -> str:
    return (
        f"{normalise_identifier(spec.campaign_id).upper()}"
        "_OBJECTIVE_COUNT_"
        f"L{level}_R{replication_index:03d}"
    )


def _record(
    spec: ObjectiveCountFamilySpec,
    level: int,
    replication_index: int,
    seed: int,
    relative_dir: Path,
    manifest: ObjectiveCountStructuralManifest,
) -> ObjectiveCountInstanceRecord:
    if (
        manifest.generator_version
        != STRUCTURAL_GENERATOR_VERSION
    ):
        raise ValueError(
            "Unexpected objective-count structural "
            "generator version."
        )

    if (
        manifest.requested_objective_count
        != level
    ):
        raise ValueError(
            "Objective-count factor level was not applied."
        )

    if (
        manifest.realised_objective_count
        != level
    ):
        raise ValueError(
            "Realised objective count differs "
            "from the factor level."
        )

    if (
        manifest.requested_constraint_count
        != spec.baseline_constraints_per_objective
    ):
        raise ValueError(
            "Selected-objective constraint "
            "baseline changed."
        )

    if (
        manifest.requested_virtual_node_count
        != spec.baseline_virtual_nodes_per_objective
    ):
        raise ValueError(
            "Selected-objective virtual-node "
            "baseline changed."
        )

    return ObjectiveCountInstanceRecord(
        campaign_id=spec.campaign_id,
        factor=FACTOR,
        factor_level=level,
        replication_index=replication_index,
        seed=seed,
        objective_id=manifest.objective_id,
        relative_instance_dir=(
            relative_dir.as_posix()
        ),
        requested_constraint_count=(
            manifest.requested_constraint_count
        ),
        realised_constraint_count=(
            manifest.realised_constraint_count
        ),
        requested_virtual_node_count=(
            manifest.requested_virtual_node_count
        ),
        realised_virtual_node_count=(
            manifest.realised_virtual_node_count
        ),
        configuration_digest=(
            manifest.configuration_digest
        ),
        instance_digest=(
            manifest.instance_digest
        ),
        generator_version=(
            manifest.generator_version
        ),
        requested_objective_count=(
            manifest.requested_objective_count
        ),
        realised_objective_count=(
            manifest.realised_objective_count
        ),
        selected_objective_index=(
            manifest.selected_objective_index
        ),
        selected_objective_shape_digest=(
            manifest.selected_objective_shape_digest
        ),
        total_constraint_count=(
            manifest.total_constraint_count
        ),
        total_virtual_node_count=(
            manifest.total_virtual_node_count
        ),
        requirement_set_count=(
            manifest.requirement_set_count
        ),
        requirement_membership_link_count=(
            manifest.requirement_membership_link_count
        ),
        membership_density=(
            manifest.membership_density
        ),
        graph_node_count=(
            manifest.graph_node_count
        ),
        graph_edge_count=(
            manifest.graph_edge_count
        ),
    )


def _validate_matrix(
    spec: ObjectiveCountFamilySpec,
    records: Sequence[
        ObjectiveCountInstanceRecord
    ],
) -> None:
    expected = {
        (
            level,
            replication_index,
            seed,
        )
        for level in spec.levels
        for replication_index, seed in enumerate(
            spec.seeds
        )
    }

    realised = {
        (
            record.factor_level,
            record.replication_index,
            record.seed,
        )
        for record in records
    }

    if (
        realised != expected
        or len(records) != len(expected)
    ):
        raise ValueError(
            "Incomplete or duplicated "
            "objective-count matrix."
        )


def _validate_ofat(
    spec: ObjectiveCountFamilySpec,
    records: Sequence[
        ObjectiveCountInstanceRecord
    ],
) -> None:
    selected_shapes: dict[
        tuple[int, int],
        set[str],
    ] = {}

    for record in records:
        if record.factor != FACTOR:
            raise ValueError(
                "Instance factor differs "
                "from objective_count."
            )

        if (
            record.generator_version
            != STRUCTURAL_GENERATOR_VERSION
        ):
            raise ValueError(
                "Objective-count structural "
                "binding changed."
            )

        if (
            record.realised_objective_count
            != record.factor_level
        ):
            raise ValueError(
                "Objective-count factor level "
                "was not realised."
            )

        if (
            record.requested_constraint_count
            != spec.baseline_constraints_per_objective
            or record.realised_constraint_count
            != spec.baseline_constraints_per_objective
        ):
            raise ValueError(
                "Selected-objective constraint "
                "baseline changed."
            )

        if (
            record.requested_virtual_node_count
            != spec.baseline_virtual_nodes_per_objective
            or record.realised_virtual_node_count
            != spec.baseline_virtual_nodes_per_objective
        ):
            raise ValueError(
                "Selected-objective virtual-node "
                "baseline changed."
            )

        if (
            record.total_constraint_count
            != (
                record.factor_level
                * spec.baseline_constraints_per_objective
            )
        ):
            raise ValueError(
                "Total constraint count "
                "is inconsistent."
            )

        if (
            record.total_virtual_node_count
            != (
                record.factor_level
                * spec.baseline_virtual_nodes_per_objective
            )
        ):
            raise ValueError(
                "Total virtual-node count "
                "is inconsistent."
            )

        if record.membership_density != 1.0:
            raise ValueError(
                "Objective-count v1 requires "
                "density 1.0."
            )

        selected_shapes.setdefault(
            (
                record.replication_index,
                record.seed,
            ),
            set(),
        ).add(
            record.selected_objective_shape_digest
        )

    if any(
        len(digests) != 1
        for digests in selected_shapes.values()
    ):
        raise ValueError(
            "Selected-objective structure changed "
            "across objective-count levels."
        )


def _write_csv(
    path: Path,
    records: Sequence[
        ObjectiveCountInstanceRecord
    ],
) -> None:
    rows = [
        asdict(record)
        for record in records
    ]

    if not rows:
        raise ValueError(
            "Cannot write an empty objective-count "
            "instances.csv."
        )

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=list(rows[0]),
        )
        writer.writeheader()
        writer.writerows(rows)


def generate_objective_count_family(
    spec: ObjectiveCountFamilySpec,
) -> ObjectiveCountFamilyManifest:
    validate_spec(spec)

    output_dir = Path(spec.output_dir)
    prepare_output_directory(output_dir)

    stable_spec = stable_spec_payload(spec)
    spec_digest = sha256_payload(stable_spec)

    write_json(
        output_dir / "campaign_spec.json",
        {
            **stable_spec,
            "campaign_spec_digest": spec_digest,
        },
    )

    records: list[
        ObjectiveCountInstanceRecord
    ] = []

    for level in spec.levels:
        for replication_index, seed in enumerate(
            spec.seeds
        ):
            relative_dir = (
                relative_instance_directory(
                    level,
                    replication_index,
                    seed,
                )
            )

            structural = (
                generate_objective_count_instance(
                    ObjectiveCountConfig(
                        instance_id=_instance_id(
                            spec,
                            level,
                            replication_index,
                        ),
                        objective_count=level,
                        selected_objective_index=(
                            spec.selected_objective_index
                        ),
                        constraints_per_objective=(
                            spec.baseline_constraints_per_objective
                        ),
                        virtual_nodes_per_objective=(
                            spec.baseline_virtual_nodes_per_objective
                        ),
                        seed=seed,
                        output_dir=str(
                            output_dir / relative_dir
                        ),
                    )
                )
            )

            records.append(
                _record(
                    spec,
                    level,
                    replication_index,
                    seed,
                    relative_dir,
                    structural,
                )
            )

    _validate_matrix(
        spec,
        records,
    )
    _validate_ofat(
        spec,
        records,
    )

    for record in records:
        instance_dir = (
            output_dir
            / record.relative_instance_dir
        )

        if not (
            instance_dir / "manifest.json"
        ).is_file():
            raise ValueError(
                f"Missing manifest: {instance_dir}"
            )

        if not (
            instance_dir / "objectives.yaml"
        ).is_file():
            raise ValueError(
                f"Missing objectives: {instance_dir}"
            )

    payloads = [
        asdict(record)
        for record in records
    ]

    campaign_digest = sha256_payload(
        {
            "campaign_spec_digest": spec_digest,
            "instances": payloads,
        }
    )

    expected_count = (
        len(spec.levels)
        * len(spec.seeds)
    )

    manifest = ObjectiveCountFamilyManifest(
        campaign_generator_version=(
            CAMPAIGN_GENERATOR_VERSION
        ),
        structural_generator_version=(
            STRUCTURAL_GENERATOR_VERSION
        ),
        campaign_id=spec.campaign_id,
        factor=FACTOR,
        levels=spec.levels,
        seeds=spec.seeds,
        baseline_constraints_per_objective=(
            spec.baseline_constraints_per_objective
        ),
        baseline_virtual_nodes_per_objective=(
            spec.baseline_virtual_nodes_per_objective
        ),
        selected_objective_index=(
            spec.selected_objective_index
        ),
        level_count=len(spec.levels),
        replication_count=len(spec.seeds),
        expected_instance_count=expected_count,
        realised_instance_count=len(records),
        campaign_spec_digest=spec_digest,
        campaign_digest=campaign_digest,
    )

    _write_csv(
        output_dir / "instances.csv",
        records,
    )

    write_json(
        output_dir / "campaign_manifest.json",
        asdict(manifest),
    )

    return manifest
''',
)

write_new(
    objective_family_test,
    r'''
from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path

import pytest
import yaml

from backend.harness.sensitivity_generator.families.objective_count_family import (
    CAMPAIGN_GENERATOR_VERSION,
    STRUCTURAL_GENERATOR_VERSION,
    ObjectiveCountFamilySpec,
    generate_objective_count_family,
)
from backend.harness.sensitivity_generator.objective_count_generator import (
    ObjectiveCountConfig,
    generate_objective_count_instance,
)


def _rows(
    path: Path,
) -> list[dict[str, str]]:
    with path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        return list(
            csv.DictReader(handle)
        )


def _spec(
    output_dir: Path,
) -> ObjectiveCountFamilySpec:
    return ObjectiveCountFamilySpec(
        campaign_id=(
            "objective_count_family_test"
        ),
        levels=(1, 2, 5),
        seeds=(101, 202),
        baseline_constraints_per_objective=2,
        baseline_virtual_nodes_per_objective=6,
        selected_objective_index=0,
        output_dir=str(output_dir),
    )


def test_structural_generator_realises_exact_objective_count(
    tmp_path: Path,
) -> None:
    output_dir = tmp_path / "structural"

    manifest = (
        generate_objective_count_instance(
            ObjectiveCountConfig(
                instance_id=(
                    "objective_count_structural_test"
                ),
                objective_count=5,
                selected_objective_index=0,
                constraints_per_objective=2,
                virtual_nodes_per_objective=6,
                seed=20260723,
                output_dir=str(output_dir),
            )
        )
    )

    assert (
        manifest.requested_objective_count
        == 5
    )
    assert (
        manifest.realised_objective_count
        == 5
    )
    assert manifest.total_constraint_count == 10
    assert manifest.total_virtual_node_count == 30
    assert manifest.membership_density == 1.0

    document = yaml.safe_load(
        (
            output_dir / "objectives.yaml"
        ).read_text(encoding="utf-8")
    )

    assert len(document["objectives"]) == 5
    assert all(
        len(item["constraints"]) == 2
        for item in document["objectives"]
    )

    stored = json.loads(
        (
            output_dir / "manifest.json"
        ).read_text(encoding="utf-8")
    )

    expected = asdict(manifest)
    expected["objective_ids"] = list(
        expected["objective_ids"]
    )

    assert stored == expected


def test_selected_objective_shape_is_level_invariant(
    tmp_path: Path,
) -> None:
    one = generate_objective_count_instance(
        ObjectiveCountConfig(
            instance_id="campaign_l1_r000",
            objective_count=1,
            selected_objective_index=0,
            constraints_per_objective=2,
            virtual_nodes_per_objective=6,
            seed=901,
            output_dir=str(
                tmp_path / "one"
            ),
        )
    )

    five = generate_objective_count_instance(
        ObjectiveCountConfig(
            instance_id="campaign_l5_r000",
            objective_count=5,
            selected_objective_index=0,
            constraints_per_objective=2,
            virtual_nodes_per_objective=6,
            seed=901,
            output_dir=str(
                tmp_path / "five"
            ),
        )
    )

    assert (
        one.selected_objective_shape_digest
        == five.selected_objective_shape_digest
    )


def test_family_matrix_and_ofat_invariants(
    tmp_path: Path,
) -> None:
    output_dir = tmp_path / "family"

    manifest = generate_objective_count_family(
        _spec(output_dir)
    )

    assert (
        manifest.campaign_generator_version
        == CAMPAIGN_GENERATOR_VERSION
    )
    assert (
        manifest.structural_generator_version
        == STRUCTURAL_GENERATOR_VERSION
    )
    assert manifest.factor == "objective_count"
    assert manifest.expected_instance_count == 6
    assert manifest.realised_instance_count == 6

    rows = _rows(
        output_dir / "instances.csv"
    )

    assert len(rows) == 6

    assert {
        int(row["factor_level"])
        for row in rows
    } == {1, 2, 5}

    shapes: dict[
        tuple[int, int],
        set[str],
    ] = {}

    for row in rows:
        level = int(row["factor_level"])

        assert row["factor"] == "objective_count"
        assert int(
            row["realised_objective_count"]
        ) == level
        assert int(
            row["requested_constraint_count"]
        ) == 2
        assert int(
            row["realised_constraint_count"]
        ) == 2
        assert int(
            row["requested_virtual_node_count"]
        ) == 6
        assert int(
            row["realised_virtual_node_count"]
        ) == 6
        assert int(
            row["total_constraint_count"]
        ) == level * 2
        assert int(
            row["total_virtual_node_count"]
        ) == level * 6
        assert float(
            row["membership_density"]
        ) == 1.0

        key = (
            int(row["replication_index"]),
            int(row["seed"]),
        )

        shapes.setdefault(
            key,
            set(),
        ).add(
            row[
                "selected_objective_shape_digest"
            ]
        )

        document = yaml.safe_load(
            (
                output_dir
                / row["relative_instance_dir"]
                / "objectives.yaml"
            ).read_text(encoding="utf-8")
        )

        assert (
            len(document["objectives"])
            == level
        )

    assert all(
        len(digests) == 1
        for digests in shapes.values()
    )


def test_family_is_deterministic_across_directories(
    tmp_path: Path,
) -> None:
    first_spec = _spec(
        tmp_path / "first"
    )

    second_spec = ObjectiveCountFamilySpec(
        **{
            **asdict(first_spec),
            "output_dir": str(
                tmp_path / "second"
            ),
        }
    )

    first = generate_objective_count_family(
        first_spec
    )
    second = generate_objective_count_family(
        second_spec
    )

    assert (
        first.campaign_spec_digest
        == second.campaign_spec_digest
    )
    assert (
        first.campaign_digest
        == second.campaign_digest
    )
    assert _rows(
        tmp_path / "first" / "instances.csv"
    ) == _rows(
        tmp_path / "second" / "instances.csv"
    )


@pytest.mark.parametrize(
    (
        "levels",
        "selected_index",
    ),
    (
        ((), 0),
        ((0,), 0),
        ((1,), -1),
        ((1,), 1),
    ),
)
def test_invalid_family_spec_is_rejected(
    tmp_path: Path,
    levels: tuple[int, ...],
    selected_index: int,
) -> None:
    with pytest.raises(ValueError):
        generate_objective_count_family(
            ObjectiveCountFamilySpec(
                campaign_id="invalid",
                levels=levels,
                seeds=(101,),
                baseline_constraints_per_objective=2,
                baseline_virtual_nodes_per_objective=6,
                selected_objective_index=(
                    selected_index
                ),
                output_dir=str(
                    tmp_path
                    / (
                        f"invalid_{len(levels)}_"
                        f"{selected_index}"
                    )
                ),
            )
        )
''',
)

write_new(
    objective_compatibility_test,
    r'''
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

import backend.harness.sensitivity_execution.execute_controlled_family as executor
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)


def _read_json(
    path: Path,
) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    assert isinstance(value, dict)

    return value


def _generate_campaign(
    output_dir: Path,
) -> dict[str, Any]:
    generate_controlled_family(
        ControlledFamilySpec(
            campaign_id=(
                "e3_objective_count_profile_test"
            ),
            factor="objective_count",
            levels=(2,),
            seeds=(101,),
            baseline_constraint_count=2,
            baseline_virtual_node_count=6,
            output_dir=str(output_dir),
        )
    )

    return _read_json(
        output_dir / "campaign_manifest.json"
    )


def test_objective_count_campaign_is_accepted(
    tmp_path: Path,
) -> None:
    campaign_dir = (
        tmp_path / "objective_count"
    )

    manifest = _generate_campaign(
        campaign_dir
    )

    instances = executor._discover_all_instances(
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
    )

    assert len(instances) == 1

    instance = instances[0]

    assert instance.factor == "objective_count"
    assert instance.factor_level == 2
    assert instance.generator_version == (
        "mcad-sensitivity-e2.1-"
        "objective-count-v1"
    )

    instance_manifest = _read_json(
        instance.manifest_path
    )

    assert (
        instance_manifest[
            "realised_objective_count"
        ]
        == 2
    )
    assert (
        instance_manifest[
            "selected_objective_id"
        ]
        == instance.objective_id
    )


def test_objective_count_cross_profile_is_rejected(
    tmp_path: Path,
) -> None:
    campaign_dir = (
        tmp_path / "cross_profile"
    )

    manifest = _generate_campaign(
        campaign_dir
    )

    manifest["factor"] = "constraint_count"

    with pytest.raises(
        executor.E3ExecutionError,
        match=(
            "Unsupported E2.2 campaign "
            "generator version"
        ),
    ):
        executor._discover_all_instances(
            campaign_dir=campaign_dir,
            campaign_manifest=manifest,
        )


def test_objective_count_evidence_uses_exact_versions(
    tmp_path: Path,
) -> None:
    campaign_dir = tmp_path / "evidence"

    manifest = _generate_campaign(
        campaign_dir
    )

    instances = executor._discover_all_instances(
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
    )

    instance = instances[0]

    inputs = executor.ExecutionInputs(
        execution_spec_path=(
            tmp_path / "execution_spec.json"
        ),
        execution_spec={
            "execution_id": (
                "objective-count-evidence-test"
            ),
        },
        workload_path=(
            tmp_path / "workload.json"
        ),
        workload={
            "workload_id": (
                "objective-count-workload"
            ),
            "objective_id": (
                instance.objective_id
            ),
        },
        campaign_dir=campaign_dir,
        campaign_manifest=manifest,
        output_dir=tmp_path / "output",
        instances=instances,
    )

    evidence = executor._base_instance_manifest(
        inputs=inputs,
        instance=instance,
        session_id=(
            "objective-count-session"
        ),
    )

    assert evidence[
        "campaign_generator_version"
    ] == (
        "mcad-sensitivity-e2.2-"
        "objective-count-v1"
    )

    assert evidence[
        "structural_generator_version"
    ] == (
        "mcad-sensitivity-e2.1-"
        "objective-count-v1"
    )
''',
)

replace_once(
    controlled,
    '''SUPPORTED_FACTORS = {
    "constraint_count",
    "virtual_node_count",
}
''',
    '''SUPPORTED_FACTORS = {
    "constraint_count",
    "virtual_node_count",
    "objective_count",
}
''',
)

replace_once(
    controlled,
    '''def generate_controlled_family(
    spec: ControlledFamilySpec,
) -> ControlledFamilyManifest:
    validate_spec(spec)
''',
    '''def generate_controlled_family(
    spec: ControlledFamilySpec,
) -> ControlledFamilyManifest:
    if spec.factor == "objective_count":
        from backend.harness.sensitivity_generator.families.objective_count_family import (
            ObjectiveCountFamilySpec,
            generate_objective_count_family,
        )

        return generate_objective_count_family(
            ObjectiveCountFamilySpec(
                campaign_id=spec.campaign_id,
                levels=spec.levels,
                seeds=spec.seeds,
                baseline_constraints_per_objective=(
                    spec.baseline_constraint_count
                ),
                baseline_virtual_nodes_per_objective=(
                    spec.baseline_virtual_node_count
                ),
                selected_objective_index=0,
                output_dir=spec.output_dir,
            )
        )

    validate_spec(spec)
''',
)

append_text(
    controlled_test,
    r'''
def test_objective_count_dispatch_uses_dedicated_profile(
    tmp_path: Path,
) -> None:
    output_dir = tmp_path / "objective_count_dispatch"

    manifest = generate_controlled_family(
        make_spec(
            output_dir,
            factor="objective_count",
            levels=(1, 2),
            seeds=(101,),
            baseline_constraint_count=2,
            baseline_virtual_node_count=6,
        )
    )

    assert manifest.factor == "objective_count"
    assert manifest.campaign_generator_version == (
        "mcad-sensitivity-e2.2-objective-count-v1"
    )
    assert manifest.structural_generator_version == (
        "mcad-sensitivity-e2.1-objective-count-v1"
    )

    rows = read_csv(
        output_dir / "instances.csv"
    )

    assert len(rows) == 2

    assert {
        int(row["realised_objective_count"])
        for row in rows
    } == {1, 2}
''',
)

replace_once(
    executor,
    '''MEMBERSHIP_DENSITY_E21_VERSION = (
    "mcad-sensitivity-e2.1-membership-density-v1"
)
''',
    '''MEMBERSHIP_DENSITY_E21_VERSION = (
    "mcad-sensitivity-e2.1-membership-density-v1"
)

OBJECTIVE_COUNT_E22_VERSION = (
    "mcad-sensitivity-e2.2-objective-count-v1"
)

OBJECTIVE_COUNT_E21_VERSION = (
    "mcad-sensitivity-e2.1-objective-count-v1"
)
''',
)

replace_once(
    executor,
    '''    "membership_density": (
        MEMBERSHIP_DENSITY_E22_VERSION,
        MEMBERSHIP_DENSITY_E21_VERSION,
    ),
}
''',
    '''    "membership_density": (
        MEMBERSHIP_DENSITY_E22_VERSION,
        MEMBERSHIP_DENSITY_E21_VERSION,
    ),
    "objective_count": (
        OBJECTIVE_COUNT_E22_VERSION,
        OBJECTIVE_COUNT_E21_VERSION,
    ),
}
''',
)

replace_once(
    compatibility_test,
    '''            "membership_density": (
                "mcad-sensitivity-e2.2-"
                "membership-density-v1",
                "mcad-sensitivity-e2.1-"
                "membership-density-v1",
            ),
        }
''',
    '''            "membership_density": (
                "mcad-sensitivity-e2.2-"
                "membership-density-v1",
                "mcad-sensitivity-e2.1-"
                "membership-density-v1",
            ),
            "objective_count": (
                "mcad-sensitivity-e2.2-"
                "objective-count-v1",
                "mcad-sensitivity-e2.1-"
                "objective-count-v1",
            ),
        }
''',
)

replace_once(
    validator,
    '\ndef fail(message: str) -> None:\n',
    '''
SUPPORTED_FACTOR_GENERATOR_PROFILES = {
    "constraint_count": (
        "mcad-sensitivity-e2.2-v1",
        "mcad-sensitivity-e2.1-v1",
    ),
    "virtual_node_count": (
        "mcad-sensitivity-e2.2-v1",
        "mcad-sensitivity-e2.1-v1",
    ),
    "membership_density": (
        "mcad-sensitivity-e2.2-membership-density-v1",
        "mcad-sensitivity-e2.1-membership-density-v1",
    ),
    "objective_count": (
        "mcad-sensitivity-e2.2-objective-count-v1",
        "mcad-sensitivity-e2.1-objective-count-v1",
    ),
}


def fail(message: str) -> None:
''',
)

replace_once(
    validator,
    '''    require_equal(
        e2_2.get("generator_version"),
        "mcad-sensitivity-e2.2-v1",
        "E2.2 generator version",
    )

    evaluator = require_mapping(
''',
    '''    require_equal(
        e2_2.get("generator_version"),
        "mcad-sensitivity-e2.2-v1",
        "E2.2 generator version",
    )

    profiles = require_mapping(
        contract.get(
            "factor_generator_profiles"
        ),
        "factor_generator_profiles",
    )

    require_equal(
        set(profiles),
        set(
            SUPPORTED_FACTOR_GENERATOR_PROFILES
        ),
        "factor_generator_profiles keys",
    )

    for factor, expected_versions in (
        SUPPORTED_FACTOR_GENERATOR_PROFILES.items()
    ):
        profile = require_mapping(
            profiles.get(factor),
            (
                "factor_generator_profiles."
                f"{factor}"
            ),
        )

        require_equal(
            profile.get(
                "campaign_generator_version"
            ),
            expected_versions[0],
            (
                f"{factor} campaign "
                "generator version"
            ),
        )

        require_equal(
            profile.get(
                "structural_generator_version"
            ),
            expected_versions[1],
            (
                f"{factor} structural "
                "generator version"
            ),
        )

    evaluator = require_mapping(
''',
)

append_text(
    e3_contract,
    r'''
factor_generator_profiles:
  constraint_count:
    campaign_generator_version: mcad-sensitivity-e2.2-v1
    structural_generator_version: mcad-sensitivity-e2.1-v1
  virtual_node_count:
    campaign_generator_version: mcad-sensitivity-e2.2-v1
    structural_generator_version: mcad-sensitivity-e2.1-v1
  membership_density:
    campaign_generator_version: mcad-sensitivity-e2.2-membership-density-v1
    structural_generator_version: mcad-sensitivity-e2.1-membership-density-v1
  objective_count:
    campaign_generator_version: mcad-sensitivity-e2.2-objective-count-v1
    structural_generator_version: mcad-sensitivity-e2.1-objective-count-v1
''',
)

append_text(
    e3_contract_test,
    r'''
def test_contract_registers_factor_generator_profiles() -> None:
    contract = load_contract()

    profiles = contract[
        "factor_generator_profiles"
    ]

    assert profiles["objective_count"] == {
        "campaign_generator_version": (
            "mcad-sensitivity-e2.2-"
            "objective-count-v1"
        ),
        "structural_generator_version": (
            "mcad-sensitivity-e2.1-"
            "objective-count-v1"
        ),
    }


def test_validator_rejects_missing_objective_count_profile() -> None:
    contract = deepcopy(load_contract())

    del contract[
        "factor_generator_profiles"
    ]["objective_count"]

    with pytest.raises(
        AssertionError,
        match="factor_generator_profiles keys",
    ):
        validate_contract(contract)
''',
)

print("objective_count_source_authoring=PASS")
print("new_source_file_count=4")
print("modified_source_file_count=7")
print("campaign_execution_authorized=false")
PY

echo
echo "=== 4. Compile implementation ==="

"$PYTHON" -m py_compile \
  "$CONTROLLED" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$EXECUTOR" \
  "$VALIDATOR" \
  "$CONTROLLED_TEST" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$COMPATIBILITY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST"

echo "objective_count_compile=PASS"

echo
echo "=== 5. Validate E3 contract ==="

"$PYTHON" "$VALIDATOR"

echo "e3_contract_validation=PASS"

echo
echo "=== 6. Run targeted implementation tests ==="

"$PYTHON" -m pytest \
  "$CONTROLLED_TEST" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$COMPATIBILITY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST" \
  -q \
  -p no:cacheprovider

echo "targeted_objective_count_tests=PASS"

echo
echo "=== 7. Run complete generator and E3 regressions ==="

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

echo "complete_sensitivity_regression=PASS"

echo
echo "=== 8. Non-canonical implementation smoke ==="

"$PYTHON" - \
  "$SMOKE_ROOT" <<'PY'
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import backend.harness.sensitivity_execution.execute_controlled_family as executor
from backend.harness.sensitivity_generator.families.controlled_families import (
    ControlledFamilySpec,
    generate_controlled_family,
)

output_dir = Path(sys.argv[1]).resolve()

manifest = generate_controlled_family(
    ControlledFamilySpec(
        campaign_id=(
            "sa5_objective_count_implementation_smoke"
        ),
        factor="objective_count",
        levels=(1, 2),
        seeds=(20260723,),
        baseline_constraint_count=2,
        baseline_virtual_node_count=6,
        output_dir=str(output_dir),
    )
)

stored_manifest = json.loads(
    (
        output_dir
        / "campaign_manifest.json"
    ).read_text(encoding="utf-8")
)

instances = executor._discover_all_instances(
    campaign_dir=output_dir,
    campaign_manifest=stored_manifest,
)

with (
    output_dir / "instances.csv"
).open(
    "r",
    encoding="utf-8",
    newline="",
) as handle:
    rows = list(csv.DictReader(handle))

assert manifest.factor == "objective_count"
assert manifest.expected_instance_count == 2
assert manifest.realised_instance_count == 2
assert len(rows) == 2
assert len(instances) == 2

assert [
    instance.factor_level
    for instance in instances
] == [1, 2]

assert {
    int(row["realised_objective_count"])
    for row in rows
} == {1, 2}

assert {
    int(row["requested_constraint_count"])
    for row in rows
} == {2}

assert {
    int(row["requested_virtual_node_count"])
    for row in rows
} == {6}

print("objective_count_implementation_smoke=PASS")
print("smoke_instance_count=2")
print("smoke_levels=1,2")
print("selected_objective_index=0")
print("campaign_generator_version="
      + stored_manifest["campaign_generator_version"])
print("structural_generator_version="
      + stored_manifest["structural_generator_version"])
print("canonical_campaign_generated=false")
print("scientific_execution_performed=false")
PY

echo
echo "=== 9. Validate implementation capability ==="

grep -F \
  '"objective_count"' \
  "$CONTROLLED" >/dev/null

grep -F \
  'objective_count_dispatch' \
  "$CONTROLLED_TEST" >/dev/null

grep -F \
  '"objective_count": (' \
  "$EXECUTOR" >/dev/null

grep -F \
  '"objective_count": (' \
  "$VALIDATOR" >/dev/null

grep -F \
  'objective_count:' \
  "$E3_CONTRACT" >/dev/null

"$PYTHON" - <<'PY'
from backend.harness.sensitivity_execution.execute_controlled_family import (
    SUPPORTED_GENERATOR_VERSION_PAIRS,
)
from backend.harness.sensitivity_generator.families.controlled_families import (
    SUPPORTED_FACTORS,
)

assert "objective_count" in SUPPORTED_FACTORS

assert (
    SUPPORTED_GENERATOR_VERSION_PAIRS[
        "objective_count"
    ]
    == (
        "mcad-sensitivity-e2.2-objective-count-v1",
        "mcad-sensitivity-e2.1-objective-count-v1",
    )
)

print("objective_count_capability_validation=PASS")
print("controlled_generator_ready=true")
print("executor_ready=true")
print("e3_contract_ready=true")
print("direct_preregistration_ready=true")
PY

echo
echo "=== 10. Repository-scope validation ==="

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

CHANGED_FILES="$(
  git status --short |
    sed -E 's/^.. //'
)"

CHANGED_FILE_COUNT="$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 11

for FILE in \
  "$CONTROLLED" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$CONTROLLED_TEST" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$EXECUTOR" \
  "$VALIDATOR" \
  "$E3_CONTRACT" \
  "$COMPATIBILITY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST"
do
  test "$(
    printf '%s\n' "$CHANGED_FILES" |
      grep -Fx "$FILE" |
      wc -l
  )" -eq 1
done

git diff --check

echo "implementation_scope_validation=PASS"
echo "changed_file_count=$CHANGED_FILE_COUNT"
echo "manuscript_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"

echo
echo "=== 11. Stage implementation ==="

git add \
  "$CONTROLLED" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$CONTROLLED_TEST" \
  "$OBJECTIVE_FAMILY_TEST" \
  "$EXECUTOR" \
  "$VALIDATOR" \
  "$E3_CONTRACT" \
  "$COMPATIBILITY_TEST" \
  "$OBJECTIVE_COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST"

STAGED_FILE_COUNT="$(
  git diff --cached --name-only |
    wc -l
)"

test "$STAGED_FILE_COUNT" -eq 11

git diff --cached --check

echo "implementation_stage=PASS"
echo "staged_file_count=$STAGED_FILE_COUNT"

echo
echo "=== 12. Commit implementation ==="

git commit \
  -m "feat(sensitivity): implement SA5 objective-count support"

COMMIT="$(git rev-parse HEAD)"

echo "commit=PASS"
echo "commit=$COMMIT"

echo
echo "=== 13. Push implementation branch ==="

git push -u origin "$BRANCH"

echo "push=PASS"

echo
echo "=== 14. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Implement SA5 objective-count controlled family" \
    --body "$(cat <<'EOF'
## SA5 implementation

Adds dedicated, factor-isolated support for `objective_count`.

### Generator contract

- dedicated E2.1 version:
  `mcad-sensitivity-e2.1-objective-count-v1`;
- dedicated E2.2 version:
  `mcad-sensitivity-e2.2-objective-count-v1`;
- fixed constraints per objective;
- fixed virtual nodes per objective;
- selected objective index fixed to `0` at the implementation layer;
- selected-objective structural shape verified invariant across factor
  levels;
- total constraints and virtual nodes scale exactly with objective count.

### E3 compatibility

- explicit generator-version profile;
- campaign and instance discovery supported;
- cross-factor profile mismatches rejected;
- exact generator versions preserved in execution evidence;
- E3 contract records all supported factor profiles.

### Compatibility

Historical `constraint_count`, `virtual_node_count`, and
`membership_density` profiles remain registered and covered by the full
regression suites.

### Scientific controls

- canonical SA5 campaign generated: `false`;
- campaign execution authorized: `false`;
- timing execution performed: `false`;
- bootstrap execution performed: `false`;
- manuscript modified: `false`.

The implementation smoke uses only levels `1` and `2` outside the
repository and is not a scientific campaign.

## Next stage

`preregister_sa5_objective_count_campaign`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 15. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_implementation=PASS"
echo "commit=$COMMIT"
echo "changed_file_count=11"
echo "controlled_generator_ready=true"
echo "executor_ready=true"
echo "e3_contract_ready=true"
echo "direct_preregistration_ready=true"
echo "selected_objective_index=0"
echo "canonical_campaign_generated=false"
echo "campaign_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "manuscript_modified=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_implementation"

git status --short --branch
git log --oneline --decorate -4
