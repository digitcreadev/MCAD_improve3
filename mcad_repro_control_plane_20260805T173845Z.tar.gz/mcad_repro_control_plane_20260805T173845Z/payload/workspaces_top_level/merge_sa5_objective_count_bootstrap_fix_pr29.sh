#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

PR=29

BASE="paper/phase3-controlled-execution"
BRANCH="paper/fix-sa5-objective-count-bootstrap-20260804T201003Z"

EXPECTED_BASE_HEAD="729b73b7716a4c32c610241256b7e42dd9ba6bfc"
EXPECTED_FEATURE_HEAD="37289429bd39c7487007cda1157ba7f8502eeb3d"

EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
OBJECTIVE_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_compatibility.py"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

TMP_ROOT="$(mktemp -d /workspaces/merge_sa5_bootstrap_pr29.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #29 merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

printf '%s\n' \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

echo "=== 1. Local corrective-branch gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test -z "$(git status --porcelain)"

test -f "$EXECUTOR"
test -f "$OBJECTIVE_TEST"
test -f "$PREREG"
test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort \
  > "$TMP_ROOT/actual_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/actual_files.txt"

test "$(
  wc -l < "$TMP_ROOT/actual_files.txt"
)" -eq 2

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_correction_gate=PASS"
echo "changed_file_count=2"
echo "canonical_campaign_generated=false"
echo "functional_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Exact correction-content gate ==="

grep -F \
  'def _expected_bootstrap_objective_ids(' \
  "$EXECUTOR" >/dev/null

grep -F \
  'if instance.factor != "objective_count":' \
  "$EXECUTOR" >/dev/null

grep -F \
  'raw_objective_ids = manifest.get(' \
  "$EXECUTOR" >/dev/null

grep -F \
  '"requested_objective_count"' \
  "$EXECUTOR" >/dev/null

grep -F \
  '"realised_objective_count"' \
  "$EXECUTOR" >/dev/null

grep -F \
  '"selected_objective_id"' \
  "$EXECUTOR" >/dev/null

grep -F \
  'expected_objective_ids = (' \
  "$EXECUTOR" >/dev/null

grep -F \
  'if objective_ids != expected_objective_ids:' \
  "$EXECUTOR" >/dev/null

grep -F \
  'def test_objective_count_bootstrap_loads_complete_catalogue(' \
  "$OBJECTIVE_TEST" >/dev/null

grep -F \
  'def test_objective_count_bootstrap_rejects_catalogue_cardinality_mismatch(' \
  "$OBJECTIVE_TEST" >/dev/null

grep -F \
  'def test_objective_count_bootstrap_rejects_selected_objective_mismatch(' \
  "$OBJECTIVE_TEST" >/dev/null

grep -F \
  'assert not ckg.history' \
  "$OBJECTIVE_TEST" >/dev/null

! grep -F \
  'assert ckg.history == {}' \
  "$OBJECTIVE_TEST" >/dev/null

echo "correction_content_gate=PASS"
echo "historical_single_objective_contract_preserved=true"
echo "objective_count_multi_objective_contract_supported=true"
echo "runtime_state_empty_contract=true"

echo
echo "=== 3. Pre-merge regression gate ==="

"$PYTHON" -m py_compile \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

echo "python_compile=PASS"

"$PYTHON" -m pytest \
  "$OBJECTIVE_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  -q \
  -p no:cacheprovider

echo "targeted_objective_count_tests=PASS"

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

echo "complete_sensitivity_regression=PASS"

echo
echo "=== 4. Remote lineage gate ==="

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_BASE_HEAD"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$EXPECTED_FEATURE_HEAD"

echo "remote_lineage_gate=PASS"
echo "remote_base_head=$EXPECTED_BASE_HEAD"
echo "remote_feature_head=$EXPECTED_FEATURE_HEAD"

echo
echo "=== 5. Pull-request identity and scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Fix SA5 objective-count multi-objective bootstrap"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 6. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' \
  >/dev/null 2>&1 \
  <<<"$CHECKS"
then
  CHECKS='[]'
fi

CHECK_COUNT="$(
  jq 'length' <<<"$CHECKS"
)"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '
      [
        .[]
        | select(.bucket != "pass")
      ]
      | length
    ' <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "sa5_bootstrap_fix_ci=PASS"
else
  echo "sa5_bootstrap_fix_ci=NOT_APPLICABLE"
fi

echo
echo "=== 7. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 8. Merge PR #29 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 9. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_FEATURE_HEAD" \
  "$BASE_HEAD"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 10. Post-merge corrective validation ==="

test -f "$EXECUTOR"
test -f "$OBJECTIVE_TEST"

grep -F \
  'def _expected_bootstrap_objective_ids(' \
  "$EXECUTOR" >/dev/null

grep -F \
  'if objective_ids != expected_objective_ids:' \
  "$EXECUTOR" >/dev/null

"$PYTHON" -m py_compile \
  "$EXECUTOR" \
  "$OBJECTIVE_TEST"

"$PYTHON" -m pytest \
  "$OBJECTIVE_TEST" \
  backend/harness/sensitivity_generator/tests/test_objective_count_family.py \
  backend/harness/sensitivity_generator/tests/test_controlled_families.py \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  -q \
  -p no:cacheprovider

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$CAMPAIGN_ROOT"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "post_merge_bootstrap_fix_validation=PASS"
echo "historical_single_objective_contract_preserved=true"
echo "objective_count_multi_objective_contract_supported=true"
echo "canonical_campaign_generated=false"
echo "functional_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 11. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 12. Cleanup local corrective branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo
echo "=== 13. Final state ==="

echo "sa5_objective_count_bootstrap_fix_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "changed_file_count=2"
echo "historical_single_objective_contract_preserved=true"
echo "objective_count_multi_objective_contract_supported=true"
echo "runtime_state_empty_contract=true"
echo "canonical_campaign_generated=false"
echo "canonical_stage10_bootstrap_performed=false"
echo "functional_execution_authorized=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "campaign_materialization_eligible=true"
echo "next_stage=author_sa5_objective_count_stage10_materializer_and_auditor"

git status --short --branch
git log --oneline --decorate -5
