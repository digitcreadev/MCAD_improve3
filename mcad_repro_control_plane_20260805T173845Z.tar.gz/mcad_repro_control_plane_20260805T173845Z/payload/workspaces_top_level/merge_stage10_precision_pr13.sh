#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=13

BASE="paper/phase3-controlled-execution"
BRANCH="paper/analyze-virtual-node-count-stage10-precision-20260802T175624Z"
EXPECTED_HEAD="d290722446bda78fe2128ce56e40d625e3fdb709"

DECISION="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis/stage10_precision_decision_report.json"

cd "$ROOT"

echo "=== 1. Local gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -f "$DECISION"

echo "local_gate=PASS"
echo "precision_analysis_rerun_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || printf '[]'
)"

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASSING="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASSING" -eq 0
  echo "precision_analysis_ci=PASS"
else
  echo "precision_analysis_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,baseRefName,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #13 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base ==="

git fetch origin --prune
git switch "$BASE"
git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "precision_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged decision ==="

jq -e '
  .status == "pass"
  and .measurement_observation_count == 6000
  and .precision_cell_count == 6
  and .all_median_targets_met == true
  and .all_p95_targets_met == true
  and .all_precision_targets_met == true
  and .failing_cell_count == 0
  and .stage10_sufficient == true
  and .stage20_extension_required == false
  and .analysis.successful_bootstrap_execution_count == 1
  and .scientific_constraints.functional_execution_rerun_performed == false
  and .scientific_constraints.timing_execution_rerun_performed == false
  and .scientific_constraints.stage20_execution_authorized == false
  and .scientific_constraints.latency_claim_authorized == false
  and .scientific_constraints.scientific_freeze_authorized == false
  and .next_stage == "prepare_virtual_node_count_stage10_freeze"
' "$DECISION" >/dev/null

echo "merged_precision_decision=PASS"
echo "all_precision_targets_met=true"
echo "failing_cell_count=0"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"
echo "successful_bootstrap_execution_count=1"

echo
echo "=== 8. Cleanup ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

echo "stage10_precision_analysis_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "precision_analysis_rerun_performed=false"
echo "stage20_execution_authorized=false"
echo "latency_claim_authorized=false"
echo "scientific_freeze_authorized=false"
echo "next_stage=prepare_virtual_node_count_stage10_freeze"

git status --short --branch
git log --oneline --decorate -5
