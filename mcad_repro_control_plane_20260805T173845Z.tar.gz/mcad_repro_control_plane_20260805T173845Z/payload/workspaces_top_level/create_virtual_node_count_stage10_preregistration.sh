#!/usr/bin/env bash
set -Eeuo pipefail

HIST="/workspaces/MCAD_improve3"
BASE_BRANCH="paper/phase3-controlled-execution"
EXPECTED_HEAD="6132923eb211b14109e2bda851948da7ddbe2220"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

PREFLIGHT_ROOT="/workspaces/virtual_node_count_stage10_preregistration_preflight_20260802T091721Z"
PREFLIGHT_JSON="$PREFLIGHT_ROOT/virtual_node_count_stage10_preregistration_preflight.json"
PREFLIGHT_MD="$PREFLIGHT_ROOT/virtual_node_count_stage10_preregistration_preflight.md"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/preregister-virtual-node-count-stage10-${STAMP}"
WORKTREE="/workspaces/MCAD_virtual_node_count_preregistration_${STAMP}"

fail() {
  echo "[ERROR] $*" >&2
  exit 1
}

echo "=== 1. Minimal gate ==="

test "$(git -C "$HIST" branch --show-current)" = "$BASE_BRANCH" ||
  fail "Unexpected active branch."

test "$(git -C "$HIST" rev-parse HEAD)" = "$EXPECTED_HEAD" ||
  fail "Unexpected repository HEAD."

test -z "$(git -C "$HIST" status --porcelain)" ||
  fail "Historical worktree is not clean."

test -x "$PYTHON" ||
  fail "Validation Python is unavailable."

test -f "$PREFLIGHT_JSON" ||
  fail "Preflight JSON is missing."

test -f "$PREFLIGHT_MD" ||
  fail "Preflight Markdown is missing."

echo "branch=$BASE_BRANCH"
echo "head=$EXPECTED_HEAD"

echo
echo "=== 2. Validate external preflight ==="

PYTHONPATH="$HIST" "$PYTHON" - "$PREFLIGHT_JSON" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
data = json.loads(path.read_text(encoding="utf-8"))

assert data["status"] == (
    "preflight_complete_parameter_freeze_pending"
)
assert data["source_commit"] == (
    "6132923eb211b14109e2bda851948da7ddbe2220"
)
assert data["historical_campaign"]["prefix_valid"] is True
assert data["historical_campaign"]["rerun_required"] is False
assert data["unresolved_required_parameters"] == []

contract = data["proposed_stage10_contract"]

assert contract["factor"] == "virtual_node_count"
assert contract["levels"] == [6, 12, 24]
assert contract["fixed_constraint_count"] == 4
assert contract["replication_count"] == 10
assert contract["historical_functional_prefix"]["valid"] is True
assert contract["historical_functional_prefix"]["rerun_required"] is False
assert contract["new_functional_replications"] == list(range(2, 10))
assert contract["formal_timing_replications"] == list(range(10))

decisions = data["decisions"]

assert decisions["historical_functional_prefix_reuse"] is True
assert decisions["historical_functional_rerun_authorized"] is False
assert decisions["new_functional_execution_authorized"] is False
assert decisions["formal_timing_execution_authorized"] is False
assert decisions["stage20_execution_authorized"] is False

print("external_preflight_validation=PASS")
print("historical_prefix_rerun_required=false")
print("experimental_execution_performed=false")
PY

echo
echo "=== 3. Create dedicated preregistration worktree ==="

git -C "$HIST" worktree add \
  -b "$BRANCH" \
  "$WORKTREE" \
  "$EXPECTED_HEAD"

SEED_SCHEDULE_REL="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa3_preregistered_seed_schedule.json"
SEED_SCHEDULE_SOURCE="$HIST/$SEED_SCHEDULE_REL"
SEED_SCHEDULE_DEST="$WORKTREE/$SEED_SCHEDULE_REL"

test -f "$SEED_SCHEDULE_SOURCE" ||
  fail "Historical seed schedule is missing."

if [ ! -f "$SEED_SCHEDULE_DEST" ]; then
  mkdir -p "$(dirname "$SEED_SCHEDULE_DEST")"

  cp "$SEED_SCHEDULE_SOURCE" "$SEED_SCHEDULE_DEST"

  echo "seed_schedule_copied_into_worktree=true"
  echo "seed_schedule_sha256=$(sha256sum "$SEED_SCHEDULE_DEST" | awk '{print $1}')"
else
  echo "seed_schedule_already_present_in_worktree=true"
fi

PLANNING_REL="reports/article_experiments/sensitivity/e3_controlled_execution/planning"
PLANNING="$WORKTREE/$PLANNING_REL"

VALIDATOR_REL="backend/harness/sensitivity_execution/tools/validate_virtual_node_count_stage10_preregistration.py"
VALIDATOR="$WORKTREE/$VALIDATOR_REL"

TEST_REL="backend/harness/sensitivity_execution/tests/test_virtual_node_count_stage10_preregistration.py"
TEST="$WORKTREE/$TEST_REL"

mkdir -p \
  "$PLANNING" \
  "$(dirname "$VALIDATOR")" \
  "$(dirname "$TEST")"

cp "$PREFLIGHT_JSON" \
  "$PLANNING/virtual_node_count_stage10_preregistration_preflight.json"

cp "$PREFLIGHT_MD" \
  "$PLANNING/virtual_node_count_stage10_preregistration_preflight.md"

echo
echo "=== 4. Create versioned preregistration contract ==="

PYTHONPATH="$WORKTREE" \
"$PYTHON" - "$WORKTREE" "$STAMP" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

repo = Path(sys.argv[1]).resolve()
stamp = sys.argv[2]

planning = (
    repo
    / "reports/article_experiments/sensitivity"
    / "e3_controlled_execution/planning"
)

preflight_path = (
    planning
    / "virtual_node_count_stage10_"
      "preregistration_preflight.json"
)

seed_schedule_path = (
    planning
    / "sa3_preregistered_seed_schedule.json"
)

historical_spec_path = (
    repo
    / "reports/article_experiments/sensitivity"
    / "e2_2_controlled_families/campaigns"
    / "virtual_node_count/campaign_spec.json"
)

historical_manifest_path = (
    repo
    / "reports/article_experiments/sensitivity"
    / "e2_2_controlled_families/campaigns"
    / "virtual_node_count/campaign_manifest.json"
)

timing_runner_path = (
    repo
    / "backend/harness/sensitivity_execution"
    / "run_timing_repetitions.py"
)

precision_analyzer_path = (
    repo
    / "backend/harness/sensitivity_execution"
    / "analyze_clustered_timing_precision_v2.py"
)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(
            lambda: stream.read(1024 * 1024),
            b"",
        ):
            digest.update(block)

    return digest.hexdigest()


for required in (
    preflight_path,
    seed_schedule_path,
    historical_spec_path,
    historical_manifest_path,
    timing_runner_path,
    precision_analyzer_path,
):
    if not required.is_file():
        raise SystemExit(f"Missing required file: {required}")

preflight = load_json(preflight_path)
schedule = load_json(seed_schedule_path)
historical_spec = load_json(historical_spec_path)
historical_manifest = load_json(historical_manifest_path)

stage10_seeds = schedule["stages"]["stage_10"]
stage20_seeds = schedule["stages"]["stage_20"]

assert len(stage10_seeds) == 10
assert len(stage20_seeds) == 20
assert stage20_seeds[:10] == stage10_seeds
assert stage10_seeds[:2] == [101, 202]

assert historical_spec["levels"] == [6, 12, 24]
assert historical_spec["seeds"] == [101, 202]
assert historical_spec["baseline_constraint_count"] == 4
assert historical_manifest["realised_instance_count"] == 6

levels = [6, 12, 24]
steps_per_instance = 2
stage10_replication_count = 10

stage10_cell_count = (
    len(levels)
    * steps_per_instance
    * stage10_replication_count
)

contract = {
    "schema_version": (
        "mcad-virtual-node-count-"
        "stage10-preregistration-v1"
    ),
    "status": "preregistered",
    "created_utc": datetime.now(
        timezone.utc
    ).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "creation_stamp": stamp,
    "source_branch": "paper/phase3-controlled-execution",
    "source_commit": (
        "6132923eb211b14109e2bda851948da7ddbe2220"
    ),
    "scientific_scope": {
        "factor": "virtual_node_count",
        "design": "one_factor_at_a_time",
        "scientific_question": (
            "Evaluate the effect of the number of virtual "
            "nodes while holding the strategic constraint "
            "count and all other declared factors constant."
        ),
        "latency_claim_authorized_before_execution": False,
        "scientific_freeze_before_execution": False,
    },
    "source_evidence": {
        "preflight_path": preflight_path.relative_to(
            repo
        ).as_posix(),
        "preflight_sha256": sha256(preflight_path),
        "seed_schedule_path": seed_schedule_path.relative_to(
            repo
        ).as_posix(),
        "seed_schedule_sha256": sha256(seed_schedule_path),
        "historical_campaign_spec_path": (
            historical_spec_path.relative_to(repo).as_posix()
        ),
        "historical_campaign_spec_sha256": sha256(
            historical_spec_path
        ),
        "historical_campaign_manifest_path": (
            historical_manifest_path.relative_to(repo).as_posix()
        ),
        "historical_campaign_manifest_sha256": sha256(
            historical_manifest_path
        ),
    },
    "campaign_contract": {
        "campaign_id": "virtual_node_count_stage10_c4",
        "factor": "virtual_node_count",
        "levels": levels,
        "fixed_constraint_count": 4,
        "baseline_virtual_node_count": 12,
        "structural_generator_version": (
            historical_spec["structural_generator_version"]
        ),
        "campaign_generator_version": (
            historical_spec["campaign_generator_version"]
        ),
        "stage10_replication_count": 10,
        "stage10_seeds": stage10_seeds,
        "expected_stage10_instance_count": 30,
        "steps_per_instance": steps_per_instance,
        "expected_stage10_functional_step_count": 60,
    },
    "historical_functional_prefix": {
        "replications": [0, 1],
        "seeds": [101, 202],
        "instance_count": 6,
        "functional_step_count": 12,
        "validation_status": "valid",
        "reuse_required": True,
        "rerun_authorized": False,
        "rerun_required": False,
    },
    "stage10_functional_plan": {
        "combined_replications": list(range(10)),
        "reused_replications": [0, 1],
        "new_replications": list(range(2, 10)),
        "new_seeds": stage10_seeds[2:],
        "new_instance_count": 24,
        "new_functional_step_count": 48,
        "combined_instance_count": 30,
        "combined_functional_step_count": 60,
        "new_execution_authorized_by_preregistration": False,
        "authorization_prerequisite": (
            "generated_campaign_and_common_workload_"
            "audits_pass"
        ),
    },
    "common_workload_contract": {
        "policy": (
            "one_workload_per_structural_seed_"
            "shared_across_virtual_node_levels"
        ),
        "comparison_scope": (
            "within_replication_across_levels"
        ),
        "cross_replication_workload_reuse": False,
        "expected_common_query_count_per_replication": 2,
        "semantic_digest_equality_required": True,
        "fully_nested_intersection_required": True,
    },
    "timing_protocol": {
        "runner_path": timing_runner_path.relative_to(
            repo
        ).as_posix(),
        "runner_sha256": sha256(timing_runner_path),
        "replications": list(range(10)),
        "warmups_per_cell": 10,
        "measurements_per_cell": 100,
        "order_seed_base": 20260728,
        "order_seed_policy": (
            "order_seed_base_plus_replication_index"
        ),
        "reuse_successful": True,
        "reuse_successful_scope": (
            "only_successful_outputs_from_the_same_"
            "preregistered_campaign"
        ),
        "fresh_ckg_state_required": True,
        "functional_digest_check_required": True,
        "expected_cell_count": stage10_cell_count,
        "expected_warmup_observation_count": (
            stage10_cell_count * 10
        ),
        "expected_measurement_observation_count": (
            stage10_cell_count * 100
        ),
        "execution_authorized": False,
        "authorization_prerequisite": (
            "functional_stage10_combined_audit_pass"
        ),
    },
    "precision_protocol": {
        "analyzer_path": precision_analyzer_path.relative_to(
            repo
        ).as_posix(),
        "analyzer_sha256": sha256(
            precision_analyzer_path
        ),
        "stage_size": 10,
        "measurements_per_cluster": 100,
        "cluster_unit": "structural_seed",
        "within_cluster_measurements": (
            "retained_together"
        ),
        "bootstrap_repetitions": 10000,
        "bootstrap_seed_base": 20260728,
        "bootstrap_cell_seed_policy": (
            "deterministic_derivation_by_versioned_analyzer"
        ),
        "confidence_level": 0.95,
        "median_relative_half_width_target": 0.10,
        "p95_relative_half_width_target": 0.15,
        "all_cells_must_pass": True,
    },
    "stage_extension_policy": {
        "stage10_to_stage20": (
            "extend_only_if_one_or_more_"
            "preregistered_precision_cells_fail"
        ),
        "stage20_seeds": stage20_seeds,
        "stage20_new_replications": list(range(10, 20)),
        "stage20_generation_authorized": False,
        "stage20_functional_execution_authorized": False,
        "stage20_timing_execution_authorized": False,
        "stage30_policy": (
            "not_authorized_requires_contract_amendment"
        ),
    },
    "authorization_gates": {
        "preregistration_contract_complete": True,
        "structural_stage10_generation_authorized": True,
        "historical_functional_prefix_reuse_authorized": True,
        "historical_functional_rerun_authorized": False,
        "new_functional_execution_authorized": False,
        "formal_timing_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
    },
    "next_stage": (
        "generate_and_audit_virtual_node_count_"
        "stage10_structure"
    ),
}

target = (
    planning
    / "virtual_node_count_stage10_preregistration.json"
)

if target.exists():
    raise SystemExit(
        f"Refusing to overwrite existing contract: {target}"
    )

target.write_text(
    json.dumps(
        contract,
        indent=2,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

markdown = f"""# Virtual-node-count Stage-10 preregistration

## Status

- Contract status: `preregistered`
- Source commit: `{contract["source_commit"]}`
- Factor: `virtual_node_count`
- Levels: `6`, `12`, `24`
- Fixed constraint count: `4`
- Stage-10 replications: `10`
- Expected structural instances: `30`

## Historical functional prefix

`rep_000` and `rep_001` are validated historical results.

- reuse required: `true`
- rerun required: `false`
- rerun authorized: `false`

Only `rep_002` through `rep_009` may eventually require new
functional execution, after generation and workload audits pass.

## Timing protocol

- warmups per cell: `10`
- measurements per cell: `100`
- order seed: `20260728 + replication_index`
- formal timing replications: `rep_000` through `rep_009`
- expected timing cells: `{stage10_cell_count}`
- expected warmup observations: `{stage10_cell_count * 10}`
- expected measurement observations: `{stage10_cell_count * 100}`
- reuse successful outputs: `true`

Timing execution is not authorized by this contract alone.

## Precision protocol

- bootstrap repetitions: `10000`
- bootstrap seed base: `20260728`
- confidence level: `0.95`
- median relative half-width target: `0.10`
- p95 relative half-width target: `0.15`
- bootstrap unit: structural seed cluster
- all cells must pass

## Extension rule

Stage 20 is permitted only if at least one preregistered Stage-10
precision cell fails. Stage 30 is outside this contract and requires
a formal amendment.

## Current authorization

- Stage-10 structural generation: `authorized`
- historical functional prefix reuse: `authorized`
- historical functional rerun: `not authorized`
- new functional execution: `not authorized`
- formal timing execution: `not authorized`
- Stage-20 execution: `not authorized`
- latency claim: `not authorized`

## Next stage

Generate and audit the Stage-10 structural campaign without executing
the new functional replications.
"""

(
    planning
    / "virtual_node_count_stage10_preregistration.md"
).write_text(
    markdown,
    encoding="utf-8",
)

print("preregistration_contract_creation=PASS")
print(f"stage10_seed_count={len(stage10_seeds)}")
print("stage10_instance_count=30")
print("stage10_timing_cell_count=60")
print("stage10_measurement_observation_count=6000")
print("historical_prefix_rerun_required=false")
print("new_functional_execution_authorized=false")
print("formal_timing_execution_authorized=false")
PY

echo
echo "=== 5. Create contract validator ==="

cat > "$VALIDATOR" <<'PY'
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


CONTRACT_RELATIVE_PATH = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution/planning/"
    "virtual_node_count_stage10_preregistration.json"
)

VALIDATION_JSON_RELATIVE_PATH = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution/planning/"
    "virtual_node_count_stage10_"
    "preregistration_validation.json"
)

VALIDATION_MD_RELATIVE_PATH = Path(
    "reports/article_experiments/sensitivity/"
    "e3_controlled_execution/planning/"
    "virtual_node_count_stage10_"
    "preregistration_validation.md"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(
            lambda: stream.read(1024 * 1024),
            b"",
        ):
            digest.update(block)

    return digest.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_contract(repo_root: Path) -> list[str]:
    errors: list[str] = []

    contract_path = repo_root / CONTRACT_RELATIVE_PATH

    if not contract_path.is_file():
        return [f"Missing contract: {contract_path}"]

    contract = load_json(contract_path)

    def require(condition: bool, message: str) -> None:
        if not condition:
            errors.append(message)

    require(
        contract.get("schema_version")
        == (
            "mcad-virtual-node-count-"
            "stage10-preregistration-v1"
        ),
        "Unexpected schema version.",
    )

    require(
        contract.get("status") == "preregistered",
        "Contract is not preregistered.",
    )

    campaign = contract.get("campaign_contract", {})

    require(
        campaign.get("factor") == "virtual_node_count",
        "Unexpected factor.",
    )
    require(
        campaign.get("levels") == [6, 12, 24],
        "Unexpected factor levels.",
    )
    require(
        campaign.get("fixed_constraint_count") == 4,
        "Constraint count is not fixed at four.",
    )
    require(
        campaign.get("stage10_replication_count") == 10,
        "Stage-10 replication count is not ten.",
    )

    seeds = campaign.get("stage10_seeds", [])

    require(len(seeds) == 10, "Expected ten Stage-10 seeds.")
    require(
        len(set(seeds)) == 10,
        "Stage-10 seeds are not unique.",
    )
    require(
        seeds[:2] == [101, 202],
        "Historical seed prefix changed.",
    )
    require(
        campaign.get("expected_stage10_instance_count") == 30,
        "Expected Stage-10 instance count is not 30.",
    )
    require(
        campaign.get("expected_stage10_functional_step_count")
        == 60,
        "Expected functional step count is not 60.",
    )

    prefix = contract.get(
        "historical_functional_prefix",
        {},
    )

    require(
        prefix.get("replications") == [0, 1],
        "Historical replication prefix changed.",
    )
    require(
        prefix.get("reuse_required") is True,
        "Historical prefix reuse is not required.",
    )
    require(
        prefix.get("rerun_required") is False,
        "Historical prefix is incorrectly marked for rerun.",
    )
    require(
        prefix.get("rerun_authorized") is False,
        "Historical prefix rerun is incorrectly authorized.",
    )

    functional = contract.get(
        "stage10_functional_plan",
        {},
    )

    require(
        functional.get("reused_replications") == [0, 1],
        "Unexpected reused replications.",
    )
    require(
        functional.get("new_replications")
        == list(range(2, 10)),
        "Unexpected new functional replications.",
    )
    require(
        functional.get("new_instance_count") == 24,
        "Expected 24 new instances.",
    )
    require(
        functional.get("new_functional_step_count") == 48,
        "Expected 48 new functional steps.",
    )
    require(
        functional.get("new_execution_authorized_by_preregistration")
        is False,
        "New execution must remain unauthorized.",
    )

    timing = contract.get("timing_protocol", {})

    require(
        timing.get("replications") == list(range(10)),
        "Unexpected timing replication set.",
    )
    require(
        timing.get("warmups_per_cell") == 10,
        "Unexpected warmup count.",
    )
    require(
        timing.get("measurements_per_cell") == 100,
        "Unexpected measurement count.",
    )
    require(
        timing.get("order_seed_base") == 20260728,
        "Unexpected order seed base.",
    )
    require(
        timing.get("reuse_successful") is True,
        "Successful-output reuse must be enabled.",
    )
    require(
        timing.get("expected_cell_count") == 60,
        "Expected 60 timing cells.",
    )
    require(
        timing.get("expected_warmup_observation_count") == 600,
        "Expected 600 warmup observations.",
    )
    require(
        timing.get("expected_measurement_observation_count") == 6000,
        "Expected 6000 measurement observations.",
    )
    require(
        timing.get("execution_authorized") is False,
        "Timing execution must remain unauthorized.",
    )

    precision = contract.get("precision_protocol", {})

    require(
        precision.get("stage_size") == 10,
        "Unexpected precision stage size.",
    )
    require(
        precision.get("measurements_per_cluster") == 100,
        "Unexpected cluster measurement count.",
    )
    require(
        precision.get("cluster_unit") == "structural_seed",
        "Bootstrap unit must be the structural seed.",
    )
    require(
        precision.get("bootstrap_repetitions") == 10000,
        "Unexpected bootstrap repetition count.",
    )
    require(
        precision.get("bootstrap_seed_base") == 20260728,
        "Unexpected bootstrap seed base.",
    )
    require(
        precision.get("confidence_level") == 0.95,
        "Unexpected confidence level.",
    )
    require(
        precision.get("median_relative_half_width_target")
        == 0.10,
        "Unexpected median target.",
    )
    require(
        precision.get("p95_relative_half_width_target")
        == 0.15,
        "Unexpected p95 target.",
    )
    require(
        precision.get("all_cells_must_pass") is True,
        "All precision cells must pass.",
    )

    extension = contract.get(
        "stage_extension_policy",
        {},
    )

    stage20_seeds = extension.get("stage20_seeds", [])

    require(
        len(stage20_seeds) == 20,
        "Expected 20 Stage-20 seeds.",
    )
    require(
        stage20_seeds[:10] == seeds,
        "Stage-20 does not preserve the Stage-10 prefix.",
    )
    require(
        extension.get("stage20_new_replications")
        == list(range(10, 20)),
        "Unexpected Stage-20 extension set.",
    )
    require(
        extension.get("stage20_generation_authorized") is False,
        "Stage-20 generation must remain unauthorized.",
    )
    require(
        extension.get("stage30_policy")
        == "not_authorized_requires_contract_amendment",
        "Stage-30 policy is not safely closed.",
    )

    gates = contract.get("authorization_gates", {})

    require(
        gates.get("preregistration_contract_complete") is True,
        "Contract-complete gate is false.",
    )
    require(
        gates.get("structural_stage10_generation_authorized")
        is True,
        "Stage-10 structural generation is not authorized.",
    )
    require(
        gates.get("historical_functional_rerun_authorized")
        is False,
        "Historical functional rerun is authorized.",
    )
    require(
        gates.get("new_functional_execution_authorized")
        is False,
        "New functional execution is authorized too early.",
    )
    require(
        gates.get("formal_timing_execution_authorized")
        is False,
        "Formal timing is authorized too early.",
    )
    require(
        gates.get("stage20_execution_authorized") is False,
        "Stage-20 execution is authorized too early.",
    )
    require(
        gates.get("latency_claim_authorized") is False,
        "Latency claim is authorized too early.",
    )

    source_evidence = contract.get("source_evidence", {})

    path_and_digest_fields = [
        (
            "preflight_path",
            "preflight_sha256",
        ),
        (
            "seed_schedule_path",
            "seed_schedule_sha256",
        ),
        (
            "historical_campaign_spec_path",
            "historical_campaign_spec_sha256",
        ),
        (
            "historical_campaign_manifest_path",
            "historical_campaign_manifest_sha256",
        ),
    ]

    for path_field, digest_field in path_and_digest_fields:
        relative = source_evidence.get(path_field)
        expected_digest = source_evidence.get(digest_field)

        if not relative:
            errors.append(f"Missing source path field: {path_field}")
            continue

        source_path = repo_root / relative

        if not source_path.is_file():
            errors.append(f"Missing source evidence: {source_path}")
            continue

        if sha256_file(source_path) != expected_digest:
            errors.append(
                f"Source digest mismatch: {source_path}"
            )

    for section_name, path_field, digest_field in (
        (
            "timing_protocol",
            "runner_path",
            "runner_sha256",
        ),
        (
            "precision_protocol",
            "analyzer_path",
            "analyzer_sha256",
        ),
    ):
        section = contract.get(section_name, {})
        relative = section.get(path_field)
        expected_digest = section.get(digest_field)

        if not relative:
            errors.append(
                f"Missing implementation path in {section_name}."
            )
            continue

        implementation_path = repo_root / relative

        if not implementation_path.is_file():
            errors.append(
                f"Missing implementation: {implementation_path}"
            )
            continue

        if sha256_file(implementation_path) != expected_digest:
            errors.append(
                f"Implementation digest mismatch: "
                f"{implementation_path}"
            )

    require(
        contract.get("next_stage")
        == (
            "generate_and_audit_virtual_node_count_"
            "stage10_structure"
        ),
        "Unexpected next stage.",
    )

    return errors


def write_validation_report(
    repo_root: Path,
    errors: list[str],
) -> None:
    contract_path = repo_root / CONTRACT_RELATIVE_PATH

    payload = {
        "schema_version": (
            "mcad-virtual-node-count-"
            "stage10-preregistration-validation-v1"
        ),
        "status": "pass" if not errors else "fail",
        "contract_path": CONTRACT_RELATIVE_PATH.as_posix(),
        "contract_sha256": (
            sha256_file(contract_path)
            if contract_path.is_file()
            else None
        ),
        "error_count": len(errors),
        "errors": errors,
        "experimental_execution_performed": False,
        "historical_prefix_rerun_required": False,
        "next_stage": (
            "generate_and_audit_virtual_node_count_"
            "stage10_structure"
            if not errors
            else "repair_preregistration_contract"
        ),
    }

    json_path = repo_root / VALIDATION_JSON_RELATIVE_PATH
    md_path = repo_root / VALIDATION_MD_RELATIVE_PATH

    json_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    lines = [
        "# Virtual-node-count Stage-10 "
        "preregistration validation",
        "",
        f"- Status: `{payload['status']}`",
        f"- Error count: `{len(errors)}`",
        "- Experimental execution performed: `false`",
        "- Historical prefix rerun required: `false`",
        f"- Next stage: `{payload['next_stage']}`",
        "",
    ]

    if errors:
        lines.extend(
            [
                "## Errors",
                "",
                *[f"- {error}" for error in errors],
                "",
            ]
        )

    md_path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo-root",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "--write-report",
        action="store_true",
    )

    args = parser.parse_args()
    repo_root = args.repo_root.resolve()

    errors = validate_contract(repo_root)

    if args.write_report:
        write_validation_report(repo_root, errors)

    if errors:
        for error in errors:
            print(f"[ERROR] {error}")

        print("preregistration_validation=FAIL")
        return 1

    print("preregistration_validation=PASS")
    print("historical_prefix_rerun_required=false")
    print("experimental_execution_performed=false")
    print(
        "next_stage="
        "generate_and_audit_virtual_node_count_"
        "stage10_structure"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
PY

echo
echo "=== 6. Create focused tests ==="

cat > "$TEST" <<'PY'
from pathlib import Path

from backend.harness.sensitivity_execution.tools.validate_virtual_node_count_stage10_preregistration import (
    validate_contract,
)


REPO_ROOT = Path(__file__).resolve().parents[4]


def test_virtual_node_count_stage10_preregistration_is_valid():
    assert validate_contract(REPO_ROOT) == []


def test_virtual_node_count_historical_prefix_is_not_rerun():
    import json

    contract_path = (
        REPO_ROOT
        / "reports/article_experiments/sensitivity"
        / "e3_controlled_execution/planning"
        / "virtual_node_count_stage10_preregistration.json"
    )

    contract = json.loads(
        contract_path.read_text(encoding="utf-8")
    )

    prefix = contract["historical_functional_prefix"]
    gates = contract["authorization_gates"]

    assert prefix["rerun_required"] is False
    assert prefix["rerun_authorized"] is False
    assert (
        gates["historical_functional_rerun_authorized"]
        is False
    )


def test_execution_remains_blocked_after_preregistration():
    import json

    contract_path = (
        REPO_ROOT
        / "reports/article_experiments/sensitivity"
        / "e3_controlled_execution/planning"
        / "virtual_node_count_stage10_preregistration.json"
    )

    contract = json.loads(
        contract_path.read_text(encoding="utf-8")
    )

    gates = contract["authorization_gates"]

    assert gates["structural_stage10_generation_authorized"] is True
    assert gates["new_functional_execution_authorized"] is False
    assert gates["formal_timing_execution_authorized"] is False
    assert gates["stage20_execution_authorized"] is False
    assert gates["latency_claim_authorized"] is False
PY

echo
echo "=== 7. Validate contract and run focused tests ==="

PYTHONPATH="$WORKTREE" \
"$PYTHON" -m py_compile \
  "$VALIDATOR" \
  "$TEST"

PYTHONPATH="$WORKTREE" \
"$PYTHON" "$VALIDATOR" \
  --repo-root "$WORKTREE" \
  --write-report

PYTHONPATH="$WORKTREE" \
"$PYTHON" -m pytest -q "$TEST"

echo
echo "=== 8. Commit and push preregistration ==="

git -C "$WORKTREE" add -f \
  "reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa3_preregistered_seed_schedule.json" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration.json" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration.md" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration_preflight.json" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration_preflight.md" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration_validation.json" \
  "$PLANNING_REL/virtual_node_count_stage10_preregistration_validation.md" \
  "$VALIDATOR_REL" \
  "$TEST_REL"

git -C "$WORKTREE" diff --cached --check

git -C "$WORKTREE" commit \
  -m "chore(experiments): preregister virtual-node-count Stage-10"

COMMIT="$(git -C "$WORKTREE" rev-parse HEAD)"

git -C "$WORKTREE" push -u origin "$BRANCH"

echo
echo "virtual_node_count_stage10_preregistration=PASS"
echo "preregistration_branch=$BRANCH"
echo "preregistration_commit=$COMMIT"
echo "preregistration_worktree=$WORKTREE"
echo "historical_prefix_rerun_required=false"
echo "experimental_execution_performed=false"
echo "new_functional_execution_authorized=false"
echo "formal_timing_execution_authorized=false"
echo "next_stage=create_virtual_node_count_preregistration_pr"
