#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="1685ee83afe14236f92e8ebbed09867fefee9d20"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"

AMENDMENT_TEST="backend/harness/sensitivity_execution/tests/test_objective_count_materialization_contract_amendment.py"

DESIGN_MATRIX="backend/harness/sensitivity_design/design_matrix.yaml"
SEMANTIC_BINDING="backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml"

OBJECTIVE_GENERATOR="backend/harness/sensitivity_generator/objective_count_generator.py"
OBJECTIVE_FAMILY="backend/harness/sensitivity_generator/families/objective_count_family.py"

CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

PREFLIGHT_REPORT_SHA="76598d6b0e56396aa8e0466907f11f0052d7e829ffd72f945eb6a57417b420b2"
PREFLIGHT_SURFACE_SHA="328ffe51332ac0132cb27ff11df06bee5dc169a8284e7795ed3c088c9288c943"

TARGET_E21_VERSION="mcad-sensitivity-e2.1-objective-count-v2"
TARGET_E22_VERSION="mcad-sensitivity-e2.2-objective-count-v2"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CREATED_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/preregister-sa5-objective-count-materialization-amendment-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_materialization_amendment.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 materialization-contract amendment stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Amendment preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$PREREG" \
  "$DESIGN_MATRIX" \
  "$SEMANTIC_BINDING" \
  "$OBJECTIVE_GENERATOR" \
  "$OBJECTIVE_FAMILY" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test ! -e "$AMENDMENT"
test ! -e "$AMENDMENT_TEST"
test ! -e "$CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

jq -e '
  .factor == "objective_count"
  and .stage == 10
  and .status == "preregistered_not_materialized"
  and .factor_contract.factor_levels
    == [1, 2, 5, 10, 20, 50]
  and .factor_contract.selected_objective_index == 0
  and .factor_contract.constraints_per_objective == 8
  and .factor_contract.virtual_nodes_per_objective == 32
  and .factor_contract.requirement_sets_per_constraint == 1
  and .factor_contract.membership_density == 1.0
  and .factor_contract.contribution_density == 0.5
  and .factor_contract.workload_length == 40
  and .factor_contract.noise_ratio == 0.25
  and .replication_contract.replication_count == 10
  and .replication_contract.expected_instance_count == 60
  and .authorization.functional_execution_authorized == false
' "$PREREG" >/dev/null

"$PYTHON" - \
  "$DESIGN_MATRIX" \
  "$SEMANTIC_BINDING" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

import yaml

design = yaml.safe_load(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

binding = yaml.safe_load(
    Path(sys.argv[2]).read_text(encoding="utf-8")
)

baseline = design["baseline"]
axis = design["axes"]["objective_count"]

assert baseline["useful_virtual_node_ratio"] == 0.75
assert baseline["contribution_density"] == 0.50

assert axis["levels"] == [1, 2, 5, 10, 20, 50]
assert axis["fixed"]["constraints_per_objective"] == 8
assert axis["fixed"]["virtual_nodes_per_objective"] == 32
assert axis["fixed"]["contribution_density"] == 0.50
assert axis["fixed"]["workload_length"] == 40
assert axis["fixed"]["noise_ratio"] == 0.25

density = binding["density"]

assert density["name"] == "membership_density"
assert density["numerator"] == (
    "requirement_membership_link_count"
)

assert (
    "number_of_requirement_sets_per_constraint"
    in density["denominator"]
)

assert (
    "declared_virtual_nodes_per_constraint"
    in density["denominator"]
)

print("design_and_binding_gate=PASS")
PY

echo "amendment_preflight_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "original_preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "preflight_report_sha256=$PREFLIGHT_REPORT_SHA"
echo "preflight_surface_sha256=$PREFLIGHT_SURFACE_SHA"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"

echo
echo "=== 2. Create amendment branch ==="

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"

echo
echo "=== 3. Author authoritative amendment ==="

"$PYTHON" - \
  "$ROOT" \
  "$PREREG" \
  "$AMENDMENT" \
  "$AMENDMENT_TEST" \
  "$CREATED_UTC" \
  "$EXPECTED_HEAD" \
  "$EXPECTED_PREREG_SHA" \
  "$PREFLIGHT_REPORT_SHA" \
  "$PREFLIGHT_SURFACE_SHA" \
  "$TARGET_E21_VERSION" \
  "$TARGET_E22_VERSION" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


root = Path(sys.argv[1]).resolve()

prereg_path = root / sys.argv[2]
amendment_path = root / sys.argv[3]
test_path = root / sys.argv[4]

created_utc = sys.argv[5]
source_commit = sys.argv[6]
original_prereg_sha = sys.argv[7]
preflight_report_sha = sys.argv[8]
preflight_surface_sha = sys.argv[9]
target_e21_version = sys.argv[10]
target_e22_version = sys.argv[11]

original = json.loads(
    prereg_path.read_text(encoding="utf-8")
)

levels = original[
    "factor_contract"
]["factor_levels"]

seeds = original[
    "replication_contract"
]["structural_seeds"]

noise_classes = [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]


def replication_class_counts(
    replication_index: int,
) -> dict[str, int]:
    counts = {
        noise_class: 1
        for noise_class in noise_classes
    }

    first_extra = (
        2 * replication_index
    ) % len(noise_classes)

    second_extra = (
        first_extra + 1
    ) % len(noise_classes)

    counts[
        noise_classes[first_extra]
    ] += 1

    counts[
        noise_classes[second_extra]
    ] += 1

    assert sum(counts.values()) == 10

    return counts


noise_counts_by_replication = [
    {
        "replication_index": replication_index,
        "seed": seed,
        "class_counts": replication_class_counts(
            replication_index
        ),
    }
    for replication_index, seed
    in enumerate(seeds)
]

stage10_class_totals = {
    noise_class: sum(
        row["class_counts"][noise_class]
        for row in noise_counts_by_replication
    )
    for noise_class in noise_classes
}

assert sorted(
    stage10_class_totals.values()
) == [12, 12, 12, 12, 13, 13, 13, 13]

structural_counts_by_level = []

for level in levels:
    structural_counts_by_level.append(
        {
            "objective_count": level,
            "constraint_count": 8 * level,
            "virtual_node_count": 32 * level,
            "useful_virtual_node_count": 24 * level,
            "irrelevant_virtual_node_count": 8 * level,
            "requirement_set_count": 16 * level,
            "requirement_membership_link_count": (
                32 * level
            ),
            "maximum_membership_link_count": (
                64 * level
            ),
            "realised_density": 0.5,
        }
    )

amendment: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "materialization-contract-amendment-v1"
    ),
    "amendment_id": (
        "sa5_objective_count_"
        "materialization_contract_amendment_001"
    ),
    "status": (
        "preregistered_implementation_required"
    ),
    "phase": "SA5",
    "factor": "objective_count",
    "stage": 10,
    "created_utc": created_utc,
    "source_repository": (
        "digitcreadev/MCAD_improve3"
    ),
    "source_branch": (
        "paper/phase3-controlled-execution"
    ),
    "source_commit": source_commit,
    "amends": {
        "artifact_path": str(
            prereg_path.relative_to(root)
        ),
        "artifact_sha256": (
            original_prereg_sha
        ),
        "amendment_precedence": (
            "This artifact is authoritative whenever "
            "its fields conflict with the original "
            "SA5 Stage-10 preregistration."
        ),
        "superseded_original_fields": [
            (
                "factor_contract."
                "requirement_sets_per_constraint"
            ),
            (
                "factor_contract."
                "membership_density"
            ),
            (
                "ofat_invariants: membership density "
                "remains equal to 1.0"
            ),
            (
                "implementation_binding generator "
                "versions for canonical materialization"
            ),
        ],
        "preserved_original_fields": [
            "factor levels",
            "structural seeds",
            "replication count",
            "selected objective index",
            "constraints per objective",
            "virtual nodes per objective",
            "workload length",
            "noise ratio",
            "common-workload sharing rule",
            "execution authorization prohibitions",
        ],
    },
    "preflight_provenance": {
        "classification": (
            "preregistration_amendment_required_"
            "before_materialization"
        ),
        "blockers": [
            (
                "noise_class_integer_"
                "allocation_rule_missing"
            ),
            (
                "useful_virtual_node_ratio_"
                "scope_unresolved_for_sa5"
            ),
            (
                "contribution_support_density_"
                "binding_unresolved"
            ),
        ],
        "preflight_report_sha256": (
            preflight_report_sha
        ),
        "preflight_surface_sha256": (
            preflight_surface_sha
        ),
    },
    "structural_control_contract": {
        "scope": (
            "Every generated objective, including the "
            "selected objective and all background "
            "objectives."
        ),
        "objective_count_levels": levels,
        "selected_objective_index": 0,
        "constraints_per_objective": 8,
        "virtual_nodes_per_objective": 32,
        "local_virtual_nodes_per_constraint": 4,
        "requirement_sets_per_constraint": 2,
        "local_virtual_node_indices": [
            0,
            1,
            2,
            3,
        ],
        "requirement_set_membership_indices": [
            [0, 1],
            [1, 2],
        ],
        "useful_local_virtual_node_indices": [
            0,
            1,
            2,
        ],
        "irrelevant_local_virtual_node_indices": [
            3,
        ],
        "useful_definition": (
            "A declared local virtual node is useful "
            "exactly when it appears in at least one "
            "requirement set of its owning constraint."
        ),
        "irrelevant_definition": (
            "A declared local virtual node is irrelevant "
            "exactly when it appears in no requirement "
            "set of its owning constraint."
        ),
        "useful_virtual_nodes_per_constraint": 3,
        "irrelevant_virtual_nodes_per_constraint": 1,
        "useful_virtual_nodes_per_objective": 24,
        "irrelevant_virtual_nodes_per_objective": 8,
        "useful_virtual_node_ratio": 0.75,
        "requirement_sets_per_objective": 16,
        "membership_links_per_constraint": 4,
        "maximum_membership_links_per_constraint": 8,
        "membership_links_per_objective": 32,
        "maximum_membership_links_per_objective": 64,
        "requested_contribution_density": 0.5,
        "density_name": "membership_density",
        "density_formula": (
            "requirement_membership_link_count / "
            "sum(requirement_set_count_per_constraint "
            "* declared_virtual_node_count_per_constraint)"
        ),
        "expected_realised_density": 0.5,
        "density_tolerance": 0.0,
        "counts_by_factor_level": (
            structural_counts_by_level
        ),
        "ofat_rule": (
            "Only total objective count may vary. "
            "The complete per-objective structural "
            "blueprint must remain byte-equivalent "
            "after objective-identifier normalization."
        ),
    },
    "workload_noise_contract": {
        "workload_length": 40,
        "requested_noise_ratio": 0.25,
        "non_contributive_query_count": 10,
        "oracle_contributive_query_count": 30,
        "noise_class_order": noise_classes,
        "requested_class_weights": {
            noise_class: 0.125
            for noise_class in noise_classes
        },
        "integer_allocation_method": (
            "base_one_per_class_plus_two_"
            "cyclic_extras_by_replication_index"
        ),
        "integer_allocation_formula": {
            "base_count_per_class": 1,
            "extra_count_per_replication": 2,
            "first_extra_class_index": (
                "(2 * replication_index) mod 8"
            ),
            "second_extra_class_index": (
                "(2 * replication_index + 1) mod 8"
            ),
        },
        "counts_by_replication": (
            noise_counts_by_replication
        ),
        "stage10_class_totals": (
            stage10_class_totals
        ),
        "stage10_total_noise_query_count": 100,
        "stage10_minimum_class_count": 12,
        "stage10_maximum_class_count": 13,
        "stage10_maximum_pairwise_class_imbalance": 1,
        "noise_position_selection": {
            "position_domain": "1..40",
            "selection_count": 10,
            "algorithm": (
                "Rank all positions by ascending SHA-256 "
                "of UTF-8 string "
                "'mcad-sa5-noise-position-v1|"
                "<seed>|<position>'; select the ten "
                "lowest digests; ties are resolved by "
                "ascending numeric position."
            ),
        },
        "class_to_position_assignment": {
            "algorithm": (
                "Expand the preregistered class multiset, "
                "rank each occurrence by ascending SHA-256 "
                "of UTF-8 string "
                "'mcad-sa5-noise-class-v1|<seed>|"
                "<class>|<occurrence-index>', then assign "
                "that order to the selected noise "
                "positions in ascending numeric order."
            ),
        },
        "oracle_rule": (
            "Every step must carry independent "
            "ground-truth oracle metadata. The realised "
            "non-contributive count, realised ratio, and "
            "realised class counts must equal this "
            "preregistered schedule before any functional "
            "execution is authorized."
        ),
        "common_workload_rule": (
            "For a structural seed, the exact ordered "
            "semantic workload and oracle labels are "
            "shared across all six objective-count "
            "levels. Only deterministic selected-"
            "objective identifier substitution is allowed."
        ),
    },
    "implementation_contract": {
        "implementation_required_before_materialization": True,
        "current_profiles_noncanonical_for_materialization": [
            (
                "mcad-sensitivity-e2.1-"
                "objective-count-v1"
            ),
            (
                "mcad-sensitivity-e2.2-"
                "objective-count-v1"
            ),
        ],
        "target_structural_generator_version": (
            target_e21_version
        ),
        "target_campaign_generator_version": (
            target_e22_version
        ),
        "required_structural_manifest_fields": [
            "objective_count",
            "selected_objective_id",
            "selected_objective_constraint_count",
            "total_constraint_count",
            "useful_virtual_node_count",
            "irrelevant_virtual_node_count",
            "total_virtual_node_count",
            "requirement_set_count",
            "requirement_membership_link_count",
            "maximum_membership_link_count",
            "realised_density",
            "graph_node_count",
            "graph_edge_count",
            "generator_version",
        ],
        "required_workload_audit_fields": [
            "workload_length",
            "non_contributive_query_count",
            "realised_noise_ratio",
            "realised_noise_class_counts",
            "oracle_contributive_query_count",
            "semantic_workload_digest",
            "objective_normalized_workload_digest",
        ],
        "required_new_components": [
            (
                "objective-count v2 structural "
                "generator support"
            ),
            (
                "objective-count v2 controlled-family "
                "support"
            ),
            (
                "independent structural contract auditor"
            ),
            (
                "deterministic Stage-10 workload "
                "materializer"
            ),
            (
                "independent workload and oracle auditor"
            ),
            (
                "factor-specific E3 v2 profile binding"
            ),
        ],
        "legacy_factor_behavior_must_remain_unchanged": True,
    },
    "materialization_acceptance_contract": {
        "required_instance_count": 60,
        "required_replication_count": 10,
        "required_level_count": 6,
        "required_workload_count": 10,
        "required_structural_mismatch_count": 0,
        "required_density_mismatch_count": 0,
        "required_useful_irrelevant_count_mismatch_count": 0,
        "required_workload_length_mismatch_count": 0,
        "required_noise_count_mismatch_count": 0,
        "required_noise_class_count_mismatch_count": 0,
        "required_cross_level_workload_mismatch_count": 0,
        "required_oracle_mismatch_count": 0,
        "required_duplicate_condition_count": 0,
        "required_missing_instance_count": 0,
    },
    "authorization": {
        "amendment_persistence_authorized": True,
        "v2_implementation_authorized_after_amendment_merge": True,
        "canonical_campaign_materialization_authorized": False,
        "functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_execution_authorized": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "manuscript_integration_authorized": False,
        "global_scientific_freeze": False,
    },
    "scientific_controls": {
        "canonical_campaign_generated": False,
        "canonical_stage10_bootstrap_performed": False,
        "functional_execution_performed": False,
        "timing_execution_performed": False,
        "bootstrap_execution_performed": False,
        "manuscript_modified": False,
    },
    "next_stage": (
        "implement_sa5_objective_count_"
        "materialization_contract_v2"
    ),
}

amendment_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

amendment_path.write_text(
    json.dumps(
        amendment,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
    )
    + "\n",
    encoding="utf-8",
)

test_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

test_path.write_text(
    r'''from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]

AMENDMENT_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_"
        "materialization_contract_amendment.json"
    )
)

ORIGINAL_PREREGISTRATION_PATH = (
    ROOT
    / "reports"
    / "article_experiments"
    / "sensitivity"
    / "e3_controlled_execution"
    / "planning"
    / (
        "sa5_objective_count_stage10_"
        "campaign_preregistration.json"
    )
)

EXPECTED_ORIGINAL_SHA = (
    "a92bb672c2c0ac61d3700ce49c9f3340"
    "ffe6b2f01f08b0f94dd354f96c8c8d5e"
)


def load_amendment() -> dict:
    value = json.loads(
        AMENDMENT_PATH.read_text(
            encoding="utf-8"
        )
    )

    assert isinstance(value, dict)

    return value


def test_original_preregistration_is_unchanged() -> None:
    digest = hashlib.sha256(
        ORIGINAL_PREREGISTRATION_PATH.read_bytes()
    ).hexdigest()

    assert digest == EXPECTED_ORIGINAL_SHA


def test_amendment_identity_and_precedence() -> None:
    amendment = load_amendment()

    assert amendment["schema_version"] == (
        "mcad-sa5-objective-count-"
        "materialization-contract-amendment-v1"
    )

    assert amendment["status"] == (
        "preregistered_implementation_required"
    )

    assert amendment["factor"] == "objective_count"
    assert amendment["stage"] == 10

    superseded = amendment[
        "amends"
    ]["superseded_original_fields"]

    assert (
        "factor_contract."
        "requirement_sets_per_constraint"
    ) in superseded

    assert (
        "factor_contract.membership_density"
    ) in superseded


def test_structural_micro_design_is_exact() -> None:
    contract = load_amendment()[
        "structural_control_contract"
    ]

    assert contract[
        "constraints_per_objective"
    ] == 8

    assert contract[
        "virtual_nodes_per_objective"
    ] == 32

    assert contract[
        "local_virtual_nodes_per_constraint"
    ] == 4

    assert contract[
        "requirement_sets_per_constraint"
    ] == 2

    assert contract[
        "requirement_set_membership_indices"
    ] == [
        [0, 1],
        [1, 2],
    ]

    assert contract[
        "useful_local_virtual_node_indices"
    ] == [0, 1, 2]

    assert contract[
        "irrelevant_local_virtual_node_indices"
    ] == [3]

    assert contract[
        "useful_virtual_nodes_per_objective"
    ] == 24

    assert contract[
        "irrelevant_virtual_nodes_per_objective"
    ] == 8

    assert contract[
        "useful_virtual_node_ratio"
    ] == 0.75

    assert contract[
        "membership_links_per_objective"
    ] == 32

    assert contract[
        "maximum_membership_links_per_objective"
    ] == 64

    assert contract[
        "expected_realised_density"
    ] == 0.5


def test_structural_counts_scale_only_with_objective_count() -> None:
    contract = load_amendment()[
        "structural_control_contract"
    ]

    rows = contract[
        "counts_by_factor_level"
    ]

    assert [
        row["objective_count"]
        for row in rows
    ] == [1, 2, 5, 10, 20, 50]

    for row in rows:
        level = row["objective_count"]

        assert row["constraint_count"] == 8 * level
        assert row["virtual_node_count"] == 32 * level

        assert (
            row["useful_virtual_node_count"]
            == 24 * level
        )

        assert (
            row["irrelevant_virtual_node_count"]
            == 8 * level
        )

        assert (
            row["requirement_set_count"]
            == 16 * level
        )

        assert (
            row[
                "requirement_membership_link_count"
            ]
            == 32 * level
        )

        assert (
            row["maximum_membership_link_count"]
            == 64 * level
        )

        assert row["realised_density"] == 0.5


def test_noise_integer_allocation_is_deterministic() -> None:
    contract = load_amendment()[
        "workload_noise_contract"
    ]

    classes = contract["noise_class_order"]
    rows = contract["counts_by_replication"]

    assert len(classes) == 8
    assert len(rows) == 10

    recomputed_totals = {
        noise_class: 0
        for noise_class in classes
    }

    for row in rows:
        replication_index = row[
            "replication_index"
        ]

        expected = {
            noise_class: 1
            for noise_class in classes
        }

        expected[
            classes[
                (2 * replication_index) % 8
            ]
        ] += 1

        expected[
            classes[
                (2 * replication_index + 1) % 8
            ]
        ] += 1

        assert row["class_counts"] == expected
        assert sum(expected.values()) == 10

        for noise_class, count in expected.items():
            recomputed_totals[noise_class] += count

    assert recomputed_totals == (
        contract["stage10_class_totals"]
    )

    assert sorted(
        recomputed_totals.values()
    ) == [
        12,
        12,
        12,
        12,
        13,
        13,
        13,
        13,
    ]

    assert contract[
        "stage10_total_noise_query_count"
    ] == 100


def test_materialization_remains_unauthorized() -> None:
    amendment = load_amendment()

    implementation = amendment[
        "implementation_contract"
    ]

    authorization = amendment[
        "authorization"
    ]

    controls = amendment[
        "scientific_controls"
    ]

    assert implementation[
        (
            "implementation_required_"
            "before_materialization"
        )
    ] is True

    assert implementation[
        "target_structural_generator_version"
    ] == (
        "mcad-sensitivity-e2.1-"
        "objective-count-v2"
    )

    assert implementation[
        "target_campaign_generator_version"
    ] == (
        "mcad-sensitivity-e2.2-"
        "objective-count-v2"
    )

    assert authorization[
        "canonical_campaign_materialization_authorized"
    ] is False

    assert authorization[
        "functional_execution_authorized"
    ] is False

    assert authorization[
        "timing_execution_authorized"
    ] is False

    assert authorization[
        "bootstrap_execution_authorized"
    ] is False

    assert controls[
        "canonical_campaign_generated"
    ] is False

    assert controls[
        "functional_execution_performed"
    ] is False

    assert amendment["next_stage"] == (
        "implement_sa5_objective_count_"
        "materialization_contract_v2"
    )
'''.rstrip()
    + "\n",
    encoding="utf-8",
)

print("materialization_contract_amendment_authoring=PASS")
print(f"amendment={amendment_path.relative_to(root)}")
print(f"test={test_path.relative_to(root)}")
print("structural_density=0.50")
print("useful_virtual_node_ratio=0.75")
print("noise_queries_per_replication=10")
print("canonical_campaign_materialization_authorized=false")
PY

echo
echo "=== 4. Validate amendment JSON ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-materialization-contract-amendment-v1"
  and .status
    == "preregistered_implementation_required"
  and .phase == "SA5"
  and .factor == "objective_count"
  and .stage == 10
  and .source_commit
    == "1685ee83afe14236f92e8ebbed09867fefee9d20"
  and .structural_control_contract.objective_count_levels
    == [1, 2, 5, 10, 20, 50]
  and .structural_control_contract.constraints_per_objective
    == 8
  and .structural_control_contract.virtual_nodes_per_objective
    == 32
  and .structural_control_contract.requirement_sets_per_constraint
    == 2
  and .structural_control_contract.requirement_set_membership_indices
    == [[0, 1], [1, 2]]
  and .structural_control_contract.useful_virtual_nodes_per_objective
    == 24
  and .structural_control_contract.irrelevant_virtual_nodes_per_objective
    == 8
  and .structural_control_contract.useful_virtual_node_ratio
    == 0.75
  and .structural_control_contract.expected_realised_density
    == 0.5
  and .workload_noise_contract.workload_length == 40
  and .workload_noise_contract.non_contributive_query_count
    == 10
  and .workload_noise_contract.stage10_total_noise_query_count
    == 100
  and (
    .workload_noise_contract.counts_by_replication
    | length
  ) == 10
  and .implementation_contract.implementation_required_before_materialization
    == true
  and .implementation_contract.target_structural_generator_version
    == "mcad-sensitivity-e2.1-objective-count-v2"
  and .implementation_contract.target_campaign_generator_version
    == "mcad-sensitivity-e2.2-objective-count-v2"
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
  and .authorization.timing_execution_authorized
    == false
  and .scientific_controls.canonical_campaign_generated
    == false
  and .next_stage
    == "implement_sa5_objective_count_materialization_contract_v2"
' "$AMENDMENT" >/dev/null

echo "amendment_json_validation=PASS"

echo
echo "=== 5. Compile and test amendment ==="

"$PYTHON" -m py_compile \
  "$AMENDMENT_TEST"

"$PYTHON" -m pytest \
  "$AMENDMENT_TEST" \
  backend/harness/sensitivity_execution/tests/test_objective_count_stage10_preregistration.py \
  -q \
  -p no:cacheprovider

echo "amendment_tests=PASS"

echo
echo "=== 6. Repository-scope gate ==="

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CAMPAIGN_ROOT"

test -f "$AMENDMENT"
test -f "$AMENDMENT_TEST"

test -n "$(
  git check-ignore -v "$AMENDMENT" || true
)"

test "$(
  git status --porcelain -- "$AMENDMENT_TEST"
)" = "?? $AMENDMENT_TEST"

test -z "$(git diff --name-only)"
test -z "$(git diff --cached --name-only)"

echo "repository_scope_gate=PASS"
echo "original_preregistration_modified=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Force-stage amendment ==="

git add -f "$AMENDMENT"
git add "$AMENDMENT_TEST"

printf '%s\n' \
  "$AMENDMENT_TEST" \
  "$AMENDMENT" |
  sort \
  > "$TMP_ROOT/expected_files.txt"

git diff --cached --name-only |
  sort \
  > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(
  wc -l < "$TMP_ROOT/staged_files.txt"
)" -eq 2

git diff --cached --check

echo "amendment_stage=PASS"
echo "staged_file_count=2"

echo
echo "=== 8. Commit amendment ==="

git commit \
  -m "chore(experiments): amend SA5 materialization contract"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"

AMENDMENT_SHA="$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)"

echo "commit=PASS"
echo "commit=$COMMIT"
echo "amendment_sha256=$AMENDMENT_SHA"

echo
echo "=== 9. Push amendment branch ==="

git push -u origin "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "push=PASS"

echo
echo "=== 10. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Preregister SA5 objective-count materialization amendment" \
    --body "$(cat <<EOF
## SA5 materialization-contract amendment

Resolves the three blockers identified by the read-only amendment
preflight.

### Structural contract

Per constraint:

- declared virtual nodes: \`4\`;
- requirement sets: \`[0,1]\` and \`[1,2]\`;
- useful virtual nodes: \`3\`;
- irrelevant virtual nodes: \`1\`;
- realised membership links: \`4\`;
- maximum membership links: \`8\`;
- realised density: \`0.50\`.

Per objective:

- constraints: \`8\`;
- virtual nodes: \`32\`;
- useful virtual nodes: \`24\`;
- irrelevant virtual nodes: \`8\`;
- useful ratio: \`0.75\`;
- requirement sets: \`16\`;
- membership links: \`32 / 64\`.

### Noise allocation

Each 40-step workload contains exactly 10 oracle-non-contributive
queries.

Each replication assigns one query to every noise class, then two
additional classes using:

\`(2r mod 8)\` and \`(2r + 1 mod 8)\`.

Across Stage-10, four classes occur 13 times and four occur 12 times,
which is the minimum possible integer imbalance around the requested
12.5 occurrences per class.

### Implementation consequence

The existing objective-count v1 profiles are non-canonical for
materialization. Required target profiles:

- \`mcad-sensitivity-e2.1-objective-count-v2\`;
- \`mcad-sensitivity-e2.2-objective-count-v2\`.

### Scientific controls

- canonical campaign generated: \`false\`;
- canonical materialization authorized: \`false\`;
- functional execution authorized: \`false\`;
- timing execution authorized: \`false\`;
- manuscript modified: \`false\`.

### Integrity

- amendment SHA-256: \`$AMENDMENT_SHA\`;
- original preregistration SHA-256: \`$EXPECTED_PREREG_SHA\`;
- preflight report SHA-256: \`$PREFLIGHT_REPORT_SHA\`;
- preflight surface SHA-256: \`$PREFLIGHT_SURFACE_SHA\`.

## Next stage

\`implement_sa5_objective_count_materialization_contract_v2\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 11. Verify PR scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,headRefOid,headRefName,baseRefName,isDraft,title,files
)"

jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
    and .title
      == "Preregister SA5 objective-count materialization amendment"
    and (.files | length) == 2
  ' <<<"$PR_DATA" >/dev/null

jq -r \
  '.files[].path' \
  <<<"$PR_DATA" |
  sort \
  > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"

echo
echo "=== 12. Final state ==="

test -z "$(git status --porcelain)"

echo "sa5_objective_count_materialization_contract_amendment=PASS"
echo "commit=$COMMIT"
echo "amendment=$AMENDMENT"
echo "amendment_sha256=$AMENDMENT_SHA"
echo "original_preregistration_sha256=$EXPECTED_PREREG_SHA"
echo "structural_density=0.50"
echo "useful_virtual_node_ratio=0.75"
echo "noise_queries_per_replication=10"
echo "stage10_noise_query_count=100"
echo "target_e21_version=$TARGET_E21_VERSION"
echo "target_e22_version=$TARGET_E22_VERSION"
echo "canonical_campaign_generated=false"
echo "canonical_campaign_materialization_authorized=false"
echo "functional_execution_authorized=false"
echo "timing_execution_authorized=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_sa5_materialization_contract_amendment"

git status --short --branch
git log --oneline --decorate -4
