#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="0c394d4fad12dfc450fd6ae984eafa217600b0b3"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
PLANNING="$E3/planning"
SPECS="$E3/execution_specs"
RUNS="$E3/runs"

READINESS_ROOT="/workspaces/sa5_objective_count_stage10_post_merge_analysis_readiness_20260805T150733Z"
READINESS_REPORT="$READINESS_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.json"
EXPECTED_READINESS_REPORT_SHA="95bc871859b3488f90ad04b16f206b108b4ac676c2c0aba64666db8157cf0898"
READINESS_SURFACE="$READINESS_ROOT/sa5_objective_count_stage10_post_merge_analysis_readiness.txt"
EXPECTED_READINESS_SURFACE_SHA="ae8c82eeeb5b61a1d59a749bacc12395d1670eae6e6dd338a5a3be61f1a62600"
SCHEMA_INVENTORY="$READINESS_ROOT/sa5_objective_count_stage10_functional_schema_inventory.json"
EXPECTED_SCHEMA_INVENTORY_SHA="97368226d59dfbea50e8206a53daa5b8b25db4b653072cc0dca295e232b31de4"

SPEC_MANIFEST="$SPECS/objective_count_stage10_execution_spec_manifest.json"
EXPECTED_SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

FUNCTIONAL_EVIDENCE_MANIFEST="$E3/audits/objective_count_stage10_c8_nv32/functional_execution/functional_execution_evidence_manifest.json"
EXPECTED_FUNCTIONAL_EVIDENCE_MANIFEST_SHA="d2b66ccf52bde34aee15596a898ddf7fa95cb51aad6ce6bd4b0fa14f59e37dbc"

TIMING_RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"
EXPECTED_TIMING_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

MEMBERSHIP_TIMING_ROOT="$E3/timing_runs/membership_density_stage10_portfolio"
MEMBERSHIP_PREFLIGHT="$PLANNING/sa4_membership_density_timing_preregistration_preflight.json"
MEMBERSHIP_PREREG="$PLANNING/sa4_membership_density_portfolio_timing_preregistration.json"
MEMBERSHIP_MATERIALIZATION="$PLANNING/sa4_membership_density_timing_input_materialization.json"
MEMBERSHIP_AUTHORIZATION="$PLANNING/sa4_membership_density_timing_execution_authorization.json"

SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_SPECS="$SETUP_ROOT/specs"
SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
SETUP_SHA_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"

PREFLIGHT_JSON="$PLANNING/sa5_objective_count_stage10_timing_preregistration_preflight.json"
PREFLIGHT_MD="$PLANNING/sa5_objective_count_stage10_timing_preregistration_preflight.md"
PREREG_JSON="$PLANNING/sa5_objective_count_stage10_portfolio_timing_preregistration.json"
PREREG_MD="$PLANNING/sa5_objective_count_stage10_portfolio_timing_preregistration.md"
MATERIALIZATION_JSON="$PLANNING/sa5_objective_count_stage10_timing_input_materialization.json"
MATERIALIZATION_MD="$PLANNING/sa5_objective_count_stage10_timing_input_materialization.md"
AUTHORIZATION_JSON="$PLANNING/sa5_objective_count_stage10_timing_execution_authorization.json"
AUTHORIZATION_MD="$PLANNING/sa5_objective_count_stage10_timing_execution_authorization.md"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/prepare-sa5-objective-count-stage10-timing-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_timing_setup.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 Timing Setup stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact readiness and repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha "$READINESS_REPORT" "$EXPECTED_READINESS_REPORT_SHA"
verify_sha "$READINESS_SURFACE" "$EXPECTED_READINESS_SURFACE_SHA"
verify_sha "$SCHEMA_INVENTORY" "$EXPECTED_SCHEMA_INVENTORY_SHA"
verify_sha "$SPEC_MANIFEST" "$EXPECTED_SPEC_MANIFEST_SHA"
verify_sha "$FUNCTIONAL_EVIDENCE_MANIFEST" "$EXPECTED_FUNCTIONAL_EVIDENCE_MANIFEST_SHA"
verify_sha "$TIMING_RUNNER" "$EXPECTED_TIMING_RUNNER_SHA"

jq -e '
  .status
    == "sa5_objective_count_stage10_post_merge_analysis_readiness_complete"
  and .source_commit
    == "0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .canonical_evidence.run_count == 10
  and .canonical_evidence.instance_count == 60
  and .canonical_evidence.functional_step_evaluation_count == 1920
  and .authorization.timing_preregistration_preflight_authorized == true
  and .authorization.timing_preregistration_authorized == false
  and .authorization.timing_execution_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .blocker_count == 0
  and .readiness_complete == true
  and .next_stage
    == "preflight_sa5_objective_count_stage10_timing_preregistration"
' "$READINESS_REPORT" >/dev/null

for FILE in \
  "$MEMBERSHIP_PREFLIGHT" \
  "$MEMBERSHIP_PREREG" \
  "$MEMBERSHIP_MATERIALIZATION" \
  "$MEMBERSHIP_AUTHORIZATION"
do
  test -f "$FILE"
done

test -d "$MEMBERSHIP_TIMING_ROOT"
test "$(find "$MEMBERSHIP_TIMING_ROOT" -mindepth 1 -maxdepth 1 -type d \
  -name 'membership_density_rep_*_portfolio_timing_stage10' | wc -l)" -eq 10

test ! -e "$SETUP_ROOT"
test ! -e "$PREFLIGHT_JSON"
test ! -e "$PREFLIGHT_MD"
test ! -e "$PREREG_JSON"
test ! -e "$PREREG_MD"
test ! -e "$MATERIALIZATION_JSON"
test ! -e "$MATERIALIZATION_MD"
test ! -e "$AUTHORIZATION_JSON"
test ! -e "$AUTHORIZATION_MD"

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "readiness_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "timing_preregistration_preflight_authorized=true"
echo "timing_execution_performed=false"

echo
echo "=== 2. Freeze historical timing-design precedent ==="

export ROOT E3 PLANNING SPECS RUNS
export SPEC_MANIFEST FUNCTIONAL_EVIDENCE_MANIFEST
export READINESS_REPORT SCHEMA_INVENTORY
export TIMING_RUNNER MEMBERSHIP_TIMING_ROOT
export MEMBERSHIP_PREFLIGHT MEMBERSHIP_PREREG
export MEMBERSHIP_MATERIALIZATION MEMBERSHIP_AUTHORIZATION
export SETUP_ROOT SETUP_SPECS SETUP_MANIFEST SETUP_SHA_MANIFEST
export PREFLIGHT_JSON PREFLIGHT_MD PREREG_JSON PREREG_MD
export MATERIALIZATION_JSON MATERIALIZATION_MD
export AUTHORIZATION_JSON AUTHORIZATION_MD
export EXPECTED_HEAD EXPECTED_TIMING_RUNNER_SHA

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import os
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(os.environ["ROOT"]).resolve()


def abs_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else ROOT / path


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        ) + "\n",
        encoding="utf-8",
    )


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scalar_paths(
    value: Any,
    prefix: str = "",
) -> list[tuple[str, Any]]:
    rows: list[tuple[str, Any]] = []

    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{prefix}.{key}" if prefix else str(key)
            rows.extend(scalar_paths(child, child_path))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(scalar_paths(child, f"{prefix}[{index}]"))
    elif isinstance(value, (str, int, float, bool)) or value is None:
        rows.append((prefix, value))

    return rows


def argparse_contract(path: Path) -> dict[str, Any]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    arguments: list[dict[str, Any]] = []

    def literal(node: ast.AST) -> Any:
        try:
            return ast.literal_eval(node)
        except Exception:
            return ast.unparse(node)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "add_argument"
        ):
            continue

        names = [
            arg.value
            for arg in node.args
            if isinstance(arg, ast.Constant)
            and isinstance(arg.value, str)
        ]

        arguments.append({
            "names": names,
            "keywords": {
                keyword.arg: literal(keyword.value)
                for keyword in node.keywords
                if keyword.arg is not None
            },
        })

    functions = sorted(
        node.name
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    )

    return {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": sha(path),
        "argument_count": len(arguments),
        "arguments": arguments,
        "function_count": len(functions),
        "functions": functions,
        "ast_parse": "PASS",
    }


spec_manifest_path = abs_path(os.environ["SPEC_MANIFEST"])
functional_evidence_path = abs_path(
    os.environ["FUNCTIONAL_EVIDENCE_MANIFEST"]
)
readiness_path = Path(os.environ["READINESS_REPORT"])
inventory_path = Path(os.environ["SCHEMA_INVENTORY"])
timing_runner_path = abs_path(os.environ["TIMING_RUNNER"])
membership_root = abs_path(os.environ["MEMBERSHIP_TIMING_ROOT"])

setup_root = abs_path(os.environ["SETUP_ROOT"])
setup_specs = abs_path(os.environ["SETUP_SPECS"])
setup_manifest_path = abs_path(os.environ["SETUP_MANIFEST"])
setup_sha_manifest_path = abs_path(os.environ["SETUP_SHA_MANIFEST"])

preflight_json = abs_path(os.environ["PREFLIGHT_JSON"])
preflight_md = abs_path(os.environ["PREFLIGHT_MD"])
prereg_json = abs_path(os.environ["PREREG_JSON"])
prereg_md = abs_path(os.environ["PREREG_MD"])
materialization_json = abs_path(os.environ["MATERIALIZATION_JSON"])
materialization_md = abs_path(os.environ["MATERIALIZATION_MD"])
authorization_json = abs_path(os.environ["AUTHORIZATION_JSON"])
authorization_md = abs_path(os.environ["AUTHORIZATION_MD"])

source_plans = {
    "preflight": abs_path(os.environ["MEMBERSHIP_PREFLIGHT"]),
    "preregistration": abs_path(os.environ["MEMBERSHIP_PREREG"]),
    "materialization": abs_path(os.environ["MEMBERSHIP_MATERIALIZATION"]),
    "authorization": abs_path(os.environ["MEMBERSHIP_AUTHORIZATION"]),
}

source_plan_inventory = {
    key: {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": sha(path),
        "top_level_keys": sorted(read_json(path)),
    }
    for key, path in source_plans.items()
}

spec_manifest = read_json(spec_manifest_path)
functional_evidence = read_json(functional_evidence_path)
readiness = read_json(readiness_path)
inventory = read_json(inventory_path)

assert spec_manifest["execution_spec_count"] == 10
assert len(spec_manifest["entries"]) == 10
assert functional_evidence["completion"]["canonical_run_count"] == 10
assert readiness["authorization"][
    "timing_preregistration_preflight_authorized"
] is True
assert readiness["scientific_controls"]["timing_execution_performed"] is False
assert inventory["run_count"] == 10
assert inventory["instance_count"] == 60

runner_contract = argparse_contract(timing_runner_path)
assert runner_contract["sha256"] == os.environ[
    "EXPECTED_TIMING_RUNNER_SHA"
]
assert runner_contract["argument_count"] > 0

membership_dirs = sorted(
    path
    for path in membership_root.glob(
        "membership_density_rep_*_portfolio_timing_stage10"
    )
    if path.is_dir()
)
assert len(membership_dirs) == 10

precedent_rows: list[dict[str, Any]] = []
manifest_scalars: defaultdict[str, list[Any]] = defaultdict(list)
csv_field_sets: list[list[str]] = []
rows_per_replication: list[int] = []
rows_per_level: list[int] = []
membership_levels_by_rep: list[list[int]] = []

for replication_index, timing_dir in enumerate(membership_dirs):
    manifest_path = timing_dir / "timing_manifest.json"
    observations_path = timing_dir / "timing_observations.csv"
    summary_path = timing_dir / "timing_summary.json"
    references_path = timing_dir / "functional_references.json"

    for path in (
        manifest_path,
        observations_path,
        summary_path,
        references_path,
    ):
        assert path.is_file()

    manifest = read_json(manifest_path)
    summary = read_json(summary_path)

    for key, value in scalar_paths(manifest):
        manifest_scalars[key].append(value)

    with observations_path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = list(reader.fieldnames or [])

    assert fields
    assert rows
    csv_field_sets.append(fields)
    rows_per_replication.append(len(rows))

    level_field = next(
        (
            field
            for field in fields
            if field.lower() in {
                "factor_level",
                "level",
                "density_level",
                "membership_density_level",
            }
        ),
        None,
    )
    assert level_field is not None

    levels = sorted({int(row[level_field]) for row in rows})
    assert len(levels) == 4
    membership_levels_by_rep.append(levels)

    counts = Counter(int(row[level_field]) for row in rows)
    assert len(set(counts.values())) == 1
    per_level = next(iter(counts.values()))
    rows_per_level.append(per_level)

    precedent_rows.append({
        "replication_index": replication_index,
        "timing_dir": timing_dir.relative_to(ROOT).as_posix(),
        "timing_manifest_sha256": sha(manifest_path),
        "timing_observations_sha256": sha(observations_path),
        "timing_summary_sha256": sha(summary_path),
        "functional_references_sha256": sha(references_path),
        "observation_row_count": len(rows),
        "observation_rows_per_factor_level": per_level,
        "factor_levels": levels,
        "csv_fields": fields,
        "manifest_top_level_keys": sorted(manifest),
        "summary_top_level_keys": sorted(summary),
    })

assert len(set(rows_per_replication)) == 1
assert len(set(rows_per_level)) == 1
assert all(levels == membership_levels_by_rep[0] for levels in membership_levels_by_rep)
assert all(fields == csv_field_sets[0] for fields in csv_field_sets)

measured_repetitions_per_level = rows_per_level[0]
precedent_rows_per_replication = rows_per_replication[0]
expected_rows_per_objective_replication = (
    measured_repetitions_per_level * 6
)
expected_total_rows = expected_rows_per_objective_replication * 10

candidate_scalar_fields = []
tokens = (
    "warmup",
    "repetition",
    "repeat",
    "clock",
    "timer",
    "shuffle",
    "order",
    "gc",
    "process",
)

for key, values in sorted(manifest_scalars.items()):
    if not any(token in key.lower() for token in tokens):
        continue
    unique = []
    for value in values:
        if value not in unique:
            unique.append(value)
    candidate_scalar_fields.append({
        "path": key,
        "observed_values": unique,
        "constant_across_precedent_runs": len(unique) == 1,
    })

setup_specs.mkdir(parents=True, exist_ok=False)

timing_specs: list[dict[str, Any]] = []
all_instance_ids: list[str] = []

for entry in spec_manifest["entries"]:
    replication_index = int(entry["replication_index"])
    token = f"{replication_index:03d}"
    seed = int(entry["seed"])

    functional_spec = (
        spec_manifest_path.parent / entry["filename"]
    )
    functional_spec_payload = read_json(functional_spec)

    selected_ids = list(entry["selected_instance_ids"])
    assert len(selected_ids) == 6
    all_instance_ids.extend(selected_ids)

    functional_run = (
        abs_path(os.environ["RUNS"])
        / f"objective_count_stage10_rep_{token}_canonical"
    )
    assert functional_run.is_dir()

    timing_output = (
        abs_path(os.environ["E3"])
        / "timing_runs"
        / "objective_count_stage10_portfolio"
        / f"objective_count_rep_{token}_portfolio_timing_stage10"
    )
    assert not timing_output.exists()

    timing_spec_path = (
        setup_specs
        / f"objective_count_rep_{token}_portfolio_timing_stage10.json"
    )

    timing_spec = {
        "schema_version": (
            "mcad-sa5-objective-count-stage10-timing-spec-v1"
        ),
        "timing_spec_id": (
            f"sa5-objective-count-rep_{token}-portfolio-timing-stage10-v1"
        ),
        "factor": "objective_count",
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "replication_index": replication_index,
        "seed": seed,
        "functional_execution_id": functional_spec_payload["execution_id"],
        "functional_execution_spec": (
            functional_spec.relative_to(ROOT).as_posix()
        ),
        "functional_execution_spec_sha256": sha(functional_spec),
        "functional_run_dir": functional_run.relative_to(ROOT).as_posix(),
        "selected_instance_ids": selected_ids,
        "selected_instance_count": 6,
        "workload_step_count_per_instance": 32,
        "measured_repetitions_per_factor_level": (
            measured_repetitions_per_level
        ),
        "expected_observation_rows": (
            expected_rows_per_objective_replication
        ),
        "timing_runner": runner_contract,
        "timing_output_dir": timing_output.relative_to(ROOT).as_posix(),
        "continue_on_instance_failure": False,
        "functional_result_reexecution_forbidden": True,
        "timing_execution_authorized": True,
        "timing_execution_performed": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "manuscript_integration_authorized": False,
    }

    write_json(timing_spec_path, timing_spec)

    timing_specs.append({
        "replication_index": replication_index,
        "seed": seed,
        "filename": timing_spec_path.name,
        "path": timing_spec_path.relative_to(ROOT).as_posix(),
        "sha256": sha(timing_spec_path),
        "selected_instance_count": 6,
        "expected_observation_rows": (
            expected_rows_per_objective_replication
        ),
        "timing_output_dir": timing_output.relative_to(ROOT).as_posix(),
    })

assert len(all_instance_ids) == 60
assert len(set(all_instance_ids)) == 60
assert len(timing_specs) == 10

setup_manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-timing-setup-manifest-v1"
    ),
    "status": "sa5_objective_count_stage10_timing_setup_complete",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "source_readiness": {
        "report_path": str(readiness_path),
        "report_sha256": sha(readiness_path),
        "schema_inventory_path": str(inventory_path),
        "schema_inventory_sha256": sha(inventory_path),
    },
    "canonical_functional_evidence": {
        "execution_spec_manifest_path": (
            spec_manifest_path.relative_to(ROOT).as_posix()
        ),
        "execution_spec_manifest_sha256": sha(spec_manifest_path),
        "functional_evidence_manifest_path": (
            functional_evidence_path.relative_to(ROOT).as_posix()
        ),
        "functional_evidence_manifest_sha256": sha(
            functional_evidence_path
        ),
        "functional_run_count": 10,
        "functional_instance_count": 60,
        "functional_step_evaluation_count": 1920,
    },
    "historical_timing_precedent": {
        "family": "membership_density",
        "source_planning_artifacts": source_plan_inventory,
        "precedent_run_count": 10,
        "precedent_factor_level_count": 4,
        "precedent_observation_rows_per_replication": (
            precedent_rows_per_replication
        ),
        "measured_repetitions_per_factor_level": (
            measured_repetitions_per_level
        ),
        "csv_fields": csv_field_sets[0],
        "candidate_constant_configuration_fields": (
            candidate_scalar_fields
        ),
        "runs": precedent_rows,
        "used_for_protocol_design_only": True,
        "objective_count_timing_values_observed": False,
    },
    "objective_count_timing_plan": {
        "factor": "objective_count",
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "replication_count": 10,
        "instance_count": 60,
        "workload_step_count_per_instance": 32,
        "measured_repetitions_per_factor_level": (
            measured_repetitions_per_level
        ),
        "expected_observation_rows_per_replication": (
            expected_rows_per_objective_replication
        ),
        "expected_total_observation_rows": expected_total_rows,
        "timing_spec_count": 10,
        "timing_specs": timing_specs,
        "timing_runner": runner_contract,
        "execution_order": list(range(10)),
        "continue_on_instance_failure": False,
        "resumable_by_replication": True,
    },
    "authorization": {
        "timing_preregistration_preflight_complete": True,
        "timing_preregistration_complete": True,
        "timing_inputs_materialized": True,
        "timing_execution_authorized": True,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "scientific_freeze_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "scientific_controls": {
        "functional_execution_performed": True,
        "functional_evidence_committed": True,
        "timing_execution_performed": False,
        "timing_analysis_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "scientific_freeze_performed": False,
        "manuscript_modified": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "setup_complete": True,
    "next_stage": (
        "wait_for_ci_then_merge_sa5_objective_count_stage10_timing_setup"
    ),
}

write_json(setup_manifest_path, setup_manifest)

common = {
    "source_commit": os.environ["EXPECTED_HEAD"],
    "readiness_report_sha256": sha(readiness_path),
    "schema_inventory_sha256": sha(inventory_path),
    "timing_runner_sha256": sha(timing_runner_path),
    "factor_levels": [1, 2, 5, 10, 20, 50],
    "replication_count": 10,
    "instance_count": 60,
    "workload_step_count_per_instance": 32,
    "measured_repetitions_per_factor_level": (
        measured_repetitions_per_level
    ),
    "expected_observation_rows_per_replication": (
        expected_rows_per_objective_replication
    ),
    "expected_total_observation_rows": expected_total_rows,
    "timing_spec_count": 10,
    "timing_execution_performed": False,
    "precision_analysis_performed": False,
    "bootstrap_analysis_performed": False,
    "scientific_result_interpretation_performed": False,
    "manuscript_modified": False,
}

preflight = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "timing-preregistration-preflight-v1"
    ),
    "status": "timing_preregistration_preflight_complete",
    **common,
    "precedent_family": "membership_density",
    "precedent_run_count": 10,
    "runner_contract": runner_contract,
    "preflight_complete": True,
    "timing_preregistration_authorized": True,
    "timing_execution_authorized": False,
}
write_json(preflight_json, preflight)

prereg = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "portfolio-timing-preregistration-v1"
    ),
    "status": "timing_preregistration_complete",
    **common,
    "primary_timing_unit": (
        "runner_emitted_unit_from_timing_observations_contract"
    ),
    "execution_order": list(range(10)),
    "resumption_unit": "replication",
    "continue_on_instance_failure": False,
    "functional_result_reexecution_forbidden": True,
    "precision_analysis_must_follow_timing_persistence": True,
    "timing_preregistration_complete": True,
    "timing_execution_authorized": False,
}
write_json(prereg_json, prereg)

materialization = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "timing-input-materialization-v1"
    ),
    "status": "timing_inputs_materialized",
    **common,
    "timing_setup_manifest": (
        setup_manifest_path.relative_to(ROOT).as_posix()
    ),
    "timing_setup_manifest_sha256": sha(setup_manifest_path),
    "timing_spec_directory": setup_specs.relative_to(ROOT).as_posix(),
    "timing_specs": timing_specs,
    "timing_inputs_materialized": True,
    "timing_execution_authorized": False,
}
write_json(materialization_json, materialization)

authorization = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "timing-execution-authorization-v1"
    ),
    "status": "timing_execution_authorized",
    **common,
    "timing_setup_manifest": (
        setup_manifest_path.relative_to(ROOT).as_posix()
    ),
    "timing_setup_manifest_sha256": sha(setup_manifest_path),
    "all_timing_specs_validated": True,
    "all_output_directories_absent": True,
    "timing_execution_authorized": True,
    "timing_execution_performed": False,
    "precision_analysis_authorized": False,
    "bootstrap_analysis_authorized": False,
    "scientific_result_interpretation_authorized": False,
    "scientific_freeze_authorized": False,
    "manuscript_integration_authorized": False,
    "blockers": [],
    "blocker_count": 0,
    "authorization_complete": True,
    "next_stage": (
        "execute_sa5_objective_count_stage10_timing_campaign"
    ),
}
write_json(authorization_json, authorization)

documents = [
    (
        preflight_md,
        "SA5 objective-count Stage-10 timing preregistration preflight",
        preflight,
    ),
    (
        prereg_md,
        "SA5 objective-count Stage-10 portfolio timing preregistration",
        prereg,
    ),
    (
        materialization_md,
        "SA5 objective-count Stage-10 timing input materialization",
        materialization,
    ),
    (
        authorization_md,
        "SA5 objective-count Stage-10 timing execution authorization",
        authorization,
    ),
]

for path, title, payload in documents:
    path.write_text(
        "\n".join([
            f"# {title}",
            "",
            f"- Source commit: `{payload['source_commit']}`",
            "- Factor levels: `1, 2, 5, 10, 20, 50`",
            "- Replications: `10`",
            "- Canonical instances: `60`",
            "- Workload steps per instance: `32`",
            (
                "- Measured repetitions per factor level: "
                f"`{measured_repetitions_per_level}`"
            ),
            (
                "- Expected observation rows per replication: "
                f"`{expected_rows_per_objective_replication}`"
            ),
            (
                "- Expected total observation rows: "
                f"`{expected_total_rows}`"
            ),
            "- Timing execution performed: `false`",
            "- Precision analysis performed: `false`",
            "- Bootstrap analysis performed: `false`",
            "- Manuscript modified: `false`",
            "",
        ]),
        encoding="utf-8",
    )

generated_without_hash_manifest = sorted([
    setup_manifest_path,
    *setup_specs.glob("*.json"),
    preflight_json,
    preflight_md,
    prereg_json,
    prereg_md,
    materialization_json,
    materialization_md,
    authorization_json,
    authorization_md,
])

assert len(generated_without_hash_manifest) == 19

setup_sha_manifest_path.write_text(
    "".join(
        f"{sha(path)}  {path.relative_to(ROOT).as_posix()}\n"
        for path in generated_without_hash_manifest
    ),
    encoding="utf-8",
)

print("historical_timing_precedent_freeze=PASS")
print("membership_precedent_run_count=10")
print(
    "membership_precedent_observation_rows_per_replication="
    f"{precedent_rows_per_replication}"
)
print(
    "measured_repetitions_per_factor_level="
    f"{measured_repetitions_per_level}"
)
print(
    "objective_count_expected_observation_rows_per_replication="
    f"{expected_rows_per_objective_replication}"
)
print(
    "objective_count_expected_total_observation_rows="
    f"{expected_total_rows}"
)
print("timing_runner_contract_ast=PASS")
print(f"timing_runner_argument_count={runner_contract['argument_count']}")
print("timing_spec_count=10")
print("timing_execution_performed=false")
print(f"setup_manifest_sha256={sha(setup_manifest_path)}")
print(f"setup_file_manifest_sha256={sha(setup_sha_manifest_path)}")
PY

echo "timing_design_and_input_generation=PASS"

echo
echo "=== 3. Validate complete setup and authorization ==="

test "$(find "$SETUP_SPECS" -maxdepth 1 -type f -name '*.json' | wc -l)" -eq 10
test "$(wc -l < "$SETUP_SHA_MANIFEST")" -eq 19
sha256sum -c "$SETUP_SHA_MANIFEST" >/dev/null

jq -e '
  .status == "sa5_objective_count_stage10_timing_setup_complete"
  and .source_commit
    == "0c394d4fad12dfc450fd6ae984eafa217600b0b3"
  and .objective_count_timing_plan.factor_levels
    == [1,2,5,10,20,50]
  and .objective_count_timing_plan.replication_count == 10
  and .objective_count_timing_plan.instance_count == 60
  and .objective_count_timing_plan.timing_spec_count == 10
  and .objective_count_timing_plan.workload_step_count_per_instance == 32
  and .historical_timing_precedent.precedent_run_count == 10
  and .historical_timing_precedent.used_for_protocol_design_only == true
  and .historical_timing_precedent.objective_count_timing_values_observed == false
  and .authorization.timing_preregistration_preflight_complete == true
  and .authorization.timing_preregistration_complete == true
  and .authorization.timing_inputs_materialized == true
  and .authorization.timing_execution_authorized == true
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.scientific_freeze_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .scientific_controls.timing_execution_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .setup_complete == true
' "$SETUP_MANIFEST" >/dev/null

jq -e '
  .status == "timing_execution_authorized"
  and .timing_spec_count == 10
  and .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .precision_analysis_authorized == false
  and .bootstrap_analysis_authorized == false
  and .scientific_result_interpretation_authorized == false
  and .manuscript_integration_authorized == false
  and .blocker_count == 0
  and .authorization_complete == true
  and .next_stage
    == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION_JSON" >/dev/null

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  SPEC="$SETUP_SPECS/objective_count_rep_${TOKEN}_portfolio_timing_stage10.json"
  test -f "$SPEC"

  OUTPUT_DIR="$(jq -r '.timing_output_dir' "$SPEC")"
  test ! -e "$OUTPUT_DIR"

  jq -e \
    --argjson index "$INDEX" \
    '
      .replication_index == $index
      and .factor == "objective_count"
      and .factor_levels == [1,2,5,10,20,50]
      and .selected_instance_count == 6
      and .workload_step_count_per_instance == 32
      and .continue_on_instance_failure == false
      and .functional_result_reexecution_forbidden == true
      and .timing_execution_authorized == true
      and .timing_execution_performed == false
      and .precision_analysis_authorized == false
    ' "$SPEC" >/dev/null
done

echo "timing_setup_validation=PASS"
echo "timing_preregistration_preflight_complete=true"
echo "timing_preregistration_complete=true"
echo "timing_inputs_materialized=true"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo
echo "=== 4. Repository and manuscript control gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

verify_sha "$READINESS_REPORT" "$EXPECTED_READINESS_REPORT_SHA"
verify_sha "$SPEC_MANIFEST" "$EXPECTED_SPEC_MANIFEST_SHA"
verify_sha "$FUNCTIONAL_EVIDENCE_MANIFEST" "$EXPECTED_FUNCTIONAL_EVIDENCE_MANIFEST_SHA"
verify_sha "$TIMING_RUNNER" "$EXPECTED_TIMING_RUNNER_SHA"

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

git status --porcelain --untracked-files=all |
  awk '{print $2}' |
  sort > "$TMP_ROOT/untracked_or_modified.txt"

{
  find "$SETUP_ROOT" -type f
  printf '%s\n' \
    "$PREFLIGHT_JSON" "$PREFLIGHT_MD" \
    "$PREREG_JSON" "$PREREG_MD" \
    "$MATERIALIZATION_JSON" "$MATERIALIZATION_MD" \
    "$AUTHORIZATION_JSON" "$AUTHORIZATION_MD"
} |
  sort > "$TMP_ROOT/expected_generated.txt"

diff -u \
  "$TMP_ROOT/expected_generated.txt" \
  "$TMP_ROOT/untracked_or_modified.txt"

test "$(wc -l < "$TMP_ROOT/expected_generated.txt")" -eq 20

echo "repository_scope_gate=PASS"
echo "generated_file_count=20"
echo "manuscript_modified=false"

echo
echo "=== 5. Create one accelerated Timing Setup branch ==="

git switch -c "$BRANCH"

mapfile -t GENERATED_FILES < "$TMP_ROOT/expected_generated.txt"
git add -f -- "${GENERATED_FILES[@]}"

git diff --cached --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 20

git commit \
  -m "chore(experiments): prepare SA5 objective-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "timing_setup_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=20"

echo
echo "=== 6. Push and create one Timing Setup PR ==="

git push -u origin "$BRANCH"

SETUP_MANIFEST_SHA="$(sha256sum "$SETUP_MANIFEST" | awk '{print $1}')"
SETUP_FILES_SHA="$(sha256sum "$SETUP_SHA_MANIFEST" | awk '{print $1}')"
AUTH_SHA="$(sha256sum "$AUTHORIZATION_JSON" | awk '{print $1}')"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Prepare SA5 objective-count Stage-10 timing" \
    --body-file - <<EOF
## Accelerated Timing Setup

This single setup PR combines the four non-execution stages:

1. timing preregistration preflight;
2. portfolio timing preregistration;
3. timing-input materialization;
4. timing-execution authorization.

## Frozen scope

- factor levels: 1, 2, 5, 10, 20, 50
- replications: 10
- canonical instances: 60
- workload steps per instance: 32
- timing specifications: 10
- timing execution performed: false
- precision analysis performed: false
- bootstrap analysis performed: false
- manuscript modified: false

## Provenance

- source commit: \`$EXPECTED_HEAD\`
- timing setup manifest SHA-256: \`$SETUP_MANIFEST_SHA\`
- timing setup file manifest SHA-256: \`$SETUP_FILES_SHA\`
- timing authorization SHA-256: \`$AUTH_SHA\`

The historical membership-density timing campaign is used only to freeze the measurement protocol. No SA5 objective-count timing value has been observed or analyzed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

gh pr view "$PR_NUMBER" \
  --repo "$REPO" \
  --json state,isDraft,headRefOid,headRefName,baseRefName,title |
jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .title == "Prepare SA5 objective-count Stage-10 timing"
  ' >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 20

echo "timing_setup_push=PASS"
echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"
echo "pr_file_count=20"

echo
echo "=== 7. Final state ==="

echo "sa5_objective_count_stage10_timing_setup=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"
echo "generated_file_count=20"
echo "timing_spec_count=10"
echo "canonical_instance_count=60"
echo "workload_step_count_per_instance=32"
echo "setup_manifest=$SETUP_MANIFEST"
echo "setup_manifest_sha256=$SETUP_MANIFEST_SHA"
echo "setup_file_manifest=$SETUP_SHA_MANIFEST"
echo "setup_file_manifest_sha256=$SETUP_FILES_SHA"
echo "authorization=$AUTHORIZATION_JSON"
echo "authorization_sha256=$AUTH_SHA"

echo "timing_preregistration_preflight_complete=true"
echo "timing_preregistration_complete=true"
echo "timing_inputs_materialized=true"
echo "timing_execution_authorized=true"
echo "timing_execution_performed=false"

echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_timing_setup"

git status --short --branch
git log --oneline --decorate -5
