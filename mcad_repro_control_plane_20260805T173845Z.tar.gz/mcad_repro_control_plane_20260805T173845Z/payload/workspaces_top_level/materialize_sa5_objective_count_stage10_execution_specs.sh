#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6c4dac8312f4798fd0f1ede499cba58f57ab8368"
EXPECTED_MATERIALIZATION_COMMIT="c92e90afcfb81e31c372f829a87a69d78eb9817f"

READINESS_ROOT="/workspaces/sa5_objective_count_stage10_functional_execution_readiness_20260805T114315Z"
READINESS_REPORT="$READINESS_ROOT/sa5_objective_count_stage10_functional_execution_readiness.json"
EXPECTED_READINESS_REPORT_SHA="ec84c769338f9c537c0e15166d844e218f4095029a4bf19126dfc3443cd4250a"

READINESS_SURFACE="$READINESS_ROOT/sa5_objective_count_stage10_functional_execution_readiness.txt"
EXPECTED_READINESS_SURFACE_SHA="625710c8772cc7d76b0ad87028947c91ad15d41d10fa10179f1383428a9a5f1f"

CANDIDATE_A_ROOT="$READINESS_ROOT/candidate_a/reports/article_experiments/sensitivity/e3_controlled_execution"
CANDIDATE_B_ROOT="$READINESS_ROOT/candidate_b/reports/article_experiments/sensitivity/e3_controlled_execution"

CANDIDATE_A_SPEC_DIR="$CANDIDATE_A_ROOT/execution_specs"
CANDIDATE_B_SPEC_DIR="$CANDIDATE_B_ROOT/execution_specs"

CANDIDATE_A_MANIFEST="$CANDIDATE_A_ROOT/execution_spec_candidate_manifest.json"
CANDIDATE_B_MANIFEST="$CANDIDATE_B_ROOT/execution_spec_candidate_manifest.json"
EXPECTED_CANDIDATE_MANIFEST_SHA="8ef2f0b23e81bd0a9fdd32393af2af8223a01fb435ff8851cf4294bbd588506f"

E3_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="$E3_ROOT/campaigns/$CAMPAIGN_ID"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"

CANONICAL_SPEC_DIR="$E3_ROOT/execution_specs"
CANONICAL_SPEC_MANIFEST="$CANONICAL_SPEC_DIR/objective_count_stage10_execution_spec_manifest.json"

PLANNING_ROOT="$E3_ROOT/planning"
MATERIALIZATION_REPORT="$PLANNING_ROOT/sa5_objective_count_stage10_execution_spec_materialization_report.json"
MATERIALIZATION_SUMMARY="$PLANNING_ROOT/sa5_objective_count_stage10_execution_spec_materialization_report.md"

CAMPAIGN_FILE_MANIFEST="$E3_ROOT/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

INPUT_MATERIALIZATION_REPORT="$PLANNING_ROOT/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

RUN_ROOT="$E3_ROOT/runs"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/materialize-sa5-objective-count-stage10-execution-specs-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_execution_spec_materialization.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 execution-spec materialization stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

echo "=== 1. Exact execution-spec materialization gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha \
  "$READINESS_REPORT" \
  "$EXPECTED_READINESS_REPORT_SHA"

verify_sha \
  "$READINESS_SURFACE" \
  "$EXPECTED_READINESS_SURFACE_SHA"

verify_sha \
  "$CANDIDATE_A_MANIFEST" \
  "$EXPECTED_CANDIDATE_MANIFEST_SHA"

verify_sha \
  "$CANDIDATE_B_MANIFEST" \
  "$EXPECTED_CANDIDATE_MANIFEST_SHA"

cmp \
  "$CANDIDATE_A_MANIFEST" \
  "$CANDIDATE_B_MANIFEST"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

verify_sha \
  "$INPUT_MATERIALIZATION_REPORT" \
  "$EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -f "$CAMPAIGN_ROOT/campaign_manifest.json"
test -f "$CAMPAIGN_ROOT/campaign_spec.json"
test -f "$CAMPAIGN_ROOT/instances.csv"
test -f "$WORKLOAD_ROOT/common_workloads_manifest.json"

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

jq -e '
  .status
    == "sa5_objective_count_stage10_execution_spec_materialization_ready"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .materialization_commit
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"

  and .campaign.instance_count == 60
  and .campaign.common_workload_count == 10
  and .campaign.workload_length == 32

  and .execution_spec_candidates.execution_spec_count == 10
  and .execution_spec_candidates.selected_instances_per_spec == 6
  and .execution_spec_candidates.total_selected_instance_count == 60
  and .execution_spec_candidates.unique_selected_instance_count == 60
  and .execution_spec_candidates.portable_relative_paths == true
  and .execution_spec_candidates.deterministic_candidate_replay == true
  and .execution_spec_candidates.all_validate_execution_spec == true
  and .execution_spec_candidates.all_load_execution_inputs == true
  and .execution_spec_candidates.runtime_objective_rebinding_confirmed == true

  and .readiness_bootstrap_probe.workload_step_execution_performed == false
  and .readiness_bootstrap_probe.evaluator_call_count == 0
  and .readiness_bootstrap_probe.runtime_cleaned == true

  and .authorization.execution_spec_materialization_authorized == true
  and .authorization.canonical_functional_execution_authorized == false
  and .authorization.scientific_execution_authorized == false

  and .scientific_controls.canonical_execution_specs_committed == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false

  and .blocker_count == 0
  and .readiness_complete == true
  and .next_stage
    == "materialize_sa5_objective_count_stage10_execution_specs"
' "$READINESS_REPORT" >/dev/null

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-execution-spec-candidate-manifest-v1"
  and .campaign_id
    == "objective_count_stage10_c8_nv32"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .materialization_commit
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"
  and .execution_spec_count == 10
  and .selected_instances_per_spec == 6
  and .total_selected_instance_count == 60
  and .unique_selected_instance_count == 60
  and .portable_relative_paths == true
  and (.entries | length) == 10
' "$CANDIDATE_A_MANIFEST" >/dev/null

for INDEX in $(seq 0 9); do
  FILE="$(
    printf \
      'objective_count_stage10_rep_%03d_canonical.json' \
      "$INDEX"
  )"

  test -f "$CANDIDATE_A_SPEC_DIR/$FILE"
  test -f "$CANDIDATE_B_SPEC_DIR/$FILE"

  cmp \
    "$CANDIDATE_A_SPEC_DIR/$FILE" \
    "$CANDIDATE_B_SPEC_DIR/$FILE"

  test ! -e "$CANONICAL_SPEC_DIR/$FILE"
done

test ! -e "$CANONICAL_SPEC_MANIFEST"
test ! -e "$MATERIALIZATION_REPORT"
test ! -e "$MATERIALIZATION_SUMMARY"

EXISTING_RUN_COUNT="$({
  find "$RUN_ROOT" \
    -maxdepth 1 \
    -type d \
    -name 'objective_count_stage10_rep_*_canonical' \
    2>/dev/null || true
} | wc -l)"

test "$EXISTING_RUN_COUNT" -eq 0

echo "execution_spec_materialization_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "readiness_report_sha256=$EXPECTED_READINESS_REPORT_SHA"
echo "candidate_manifest_sha256=$EXPECTED_CANDIDATE_MANIFEST_SHA"
echo "candidate_execution_spec_count=10"
echo "canonical_execution_spec_count_before=0"
echo "canonical_run_count_before=0"
echo "execution_spec_materialization_authorized=true"
echo "canonical_functional_execution_authorized=false"

echo
echo "=== 2. Revalidate candidate specs with production loaders ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

export CANDIDATE_A_SPEC_DIR
export CANDIDATE_A_MANIFEST
export CAMPAIGN_ROOT_ABS="$ROOT/$CAMPAIGN_ROOT"
export WORKLOAD_ROOT_ABS="$ROOT/$WORKLOAD_ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import json
import os
from pathlib import Path

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


spec_dir = Path(os.environ["CANDIDATE_A_SPEC_DIR"])
manifest_path = Path(os.environ["CANDIDATE_A_MANIFEST"])
campaign_root = Path(os.environ["CAMPAIGN_ROOT_ABS"]).resolve()
workload_root = Path(os.environ["WORKLOAD_ROOT_ABS"]).resolve()

manifest = json.loads(
    manifest_path.read_text(encoding="utf-8")
)

assert manifest["execution_spec_count"] == 10
assert len(manifest["entries"]) == 10

selected_ids: list[str] = []

for entry in manifest["entries"]:
    spec_path = spec_dir / entry["filename"]
    payload = json.loads(
        spec_path.read_text(encoding="utf-8")
    )

    validate_execution_spec(payload)

    inputs = load_execution_inputs(spec_path)

    assert inputs.campaign_dir.resolve() == campaign_root
    assert inputs.workload_path.parent.resolve() == workload_root
    assert len(inputs.instances) == 6
    assert [
        instance.factor_level
        for instance in inputs.instances
    ] == [1, 2, 5, 10, 20, 50]

    replication_index = int(entry["replication_index"])
    seed = int(entry["seed"])

    assert {
        instance.replication_index
        for instance in inputs.instances
    } == {replication_index}

    assert {
        instance.seed
        for instance in inputs.instances
    } == {seed}

    ids = [
        instance.canonical_instance_id
        for instance in inputs.instances
    ]

    assert ids == entry["selected_instance_ids"]
    selected_ids.extend(ids)

assert len(selected_ids) == 60
assert len(set(selected_ids)) == 60

print("candidate_revalidation=PASS")
print("candidate_validate_execution_spec_count=10")
print("candidate_load_execution_inputs_count=10")
print("candidate_selected_instance_count=60")
print("candidate_unique_selected_instance_count=60")
PY

echo "candidate_revalidation_gate=PASS"

echo
echo "=== 3. Create isolated execution-spec materialization branch ==="

git switch \
  -c \
  "$BRANCH"

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "execution_spec_branch_creation=PASS"
echo "branch=$BRANCH"

echo
echo "=== 4. Materialize exact canonical execution specs ==="

mkdir -p "$CANONICAL_SPEC_DIR"

for INDEX in $(seq 0 9); do
  FILE="$(
    printf \
      'objective_count_stage10_rep_%03d_canonical.json' \
      "$INDEX"
  )"

  cp \
    --preserve=mode,timestamps \
    "$CANDIDATE_A_SPEC_DIR/$FILE" \
    "$CANONICAL_SPEC_DIR/$FILE"

  cmp \
    "$CANDIDATE_A_SPEC_DIR/$FILE" \
    "$CANONICAL_SPEC_DIR/$FILE"
done

echo "canonical_execution_spec_copy=PASS"
echo "canonical_execution_spec_count=10"

echo
echo "=== 5. Write canonical execution-spec manifest and provenance ==="

export CANONICAL_SPEC_DIR
export CANONICAL_SPEC_MANIFEST
export MATERIALIZATION_REPORT
export MATERIALIZATION_SUMMARY
export READINESS_REPORT
export READINESS_SURFACE
export EXPECTED_READINESS_REPORT_SHA
export EXPECTED_READINESS_SURFACE_SHA
export EXPECTED_CANDIDATE_MANIFEST_SHA
export EXPECTED_HEAD
export EXPECTED_MATERIALIZATION_COMMIT
export EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA
export INPUT_MATERIALIZATION_REPORT
export EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA
export RUN_ROOT_ABS="$ROOT/$RUN_ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from backend.harness.sensitivity_execution.execute_controlled_family import (
    E3_EXECUTOR_VERSION,
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    SCHEMA_VERSION as EXECUTION_SCHEMA_VERSION,
    validate_execution_spec,
)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"Expected JSON object: {path}")
    return value


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_json_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n",
        encoding="utf-8",
    )


candidate_manifest_path = Path(
    os.environ["CANDIDATE_A_MANIFEST"]
)
candidate_manifest = read_json(candidate_manifest_path)

canonical_spec_dir = Path(
    os.environ["CANONICAL_SPEC_DIR"]
)
canonical_manifest_path = Path(
    os.environ["CANONICAL_SPEC_MANIFEST"]
)
report_path = Path(
    os.environ["MATERIALIZATION_REPORT"]
)
summary_path = Path(
    os.environ["MATERIALIZATION_SUMMARY"]
)
readiness_report_path = Path(
    os.environ["READINESS_REPORT"]
)
input_materialization_report_path = Path(
    os.environ["INPUT_MATERIALIZATION_REPORT"]
)
run_root = Path(os.environ["RUN_ROOT_ABS"]).resolve()

canonical_entries: list[dict[str, Any]] = []
selected_ids: list[str] = []

for candidate_entry in candidate_manifest["entries"]:
    filename = str(candidate_entry["filename"])
    spec_path = canonical_spec_dir / filename

    payload = read_json(spec_path)
    validate_execution_spec(payload)

    inputs = load_execution_inputs(spec_path)

    assert len(inputs.instances) == 6
    assert [
        instance.factor_level
        for instance in inputs.instances
    ] == [1, 2, 5, 10, 20, 50]

    replication_index = int(
        candidate_entry["replication_index"]
    )
    seed = int(candidate_entry["seed"])

    assert {
        instance.replication_index
        for instance in inputs.instances
    } == {replication_index}

    assert {
        instance.seed
        for instance in inputs.instances
    } == {seed}

    ids = [
        instance.canonical_instance_id
        for instance in inputs.instances
    ]

    assert ids == candidate_entry["selected_instance_ids"]

    expected_output = (
        run_root
        / (
            "objective_count_stage10_"
            f"rep_{replication_index:03d}_canonical"
        )
    ).resolve()

    assert inputs.output_dir == expected_output
    assert not expected_output.exists()

    selected_ids.extend(ids)

    canonical_entries.append(
        {
            "replication_index": replication_index,
            "seed": seed,
            "filename": filename,
            "path": spec_path.as_posix(),
            "execution_id": payload["execution_id"],
            "file_sha256": sha256_file(spec_path),
            "semantic_sha256": stable_json_sha256(payload),
            "selected_instance_count": 6,
            "selected_factor_levels": [1, 2, 5, 10, 20, 50],
            "selected_instance_ids": ids,
            "workload_path": payload["workload_path"],
            "workload_file_sha256": candidate_entry[
                "workload_file_sha256"
            ],
            "workload_semantic_digest": candidate_entry[
                "workload_semantic_digest"
            ],
            "output_dir": payload["output_dir"],
            "portable_relative_paths": True,
            "validate_execution_spec_status": "PASS",
            "load_execution_inputs_status": "PASS",
            "functional_execution_performed": False,
        }
    )

assert len(canonical_entries) == 10
assert len(selected_ids) == 60
assert len(set(selected_ids)) == 60

canonical_manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "execution-spec-manifest-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "execution_specs_materialized"
    ),
    "campaign_id": candidate_manifest["campaign_id"],
    "source_commit": os.environ["EXPECTED_HEAD"],
    "materialization_commit": os.environ[
        "EXPECTED_MATERIALIZATION_COMMIT"
    ],
    "execution_schema_version": EXECUTION_SCHEMA_VERSION,
    "executor_version": E3_EXECUTOR_VERSION,
    "readiness_report_sha256": os.environ[
        "EXPECTED_READINESS_REPORT_SHA"
    ],
    "candidate_manifest_sha256": os.environ[
        "EXPECTED_CANDIDATE_MANIFEST_SHA"
    ],
    "execution_spec_count": 10,
    "selected_instances_per_spec": 6,
    "total_selected_instance_count": 60,
    "unique_selected_instance_count": 60,
    "portable_relative_paths": True,
    "deterministic_candidate_replay_preserved": True,
    "entries": canonical_entries,
    "scientific_controls": {
        "canonical_execution_specs_materialized": True,
        "canonical_execution_specs_committed": False,
        "canonical_stage10_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
}

write_json(
    canonical_manifest_path,
    canonical_manifest,
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "execution-spec-materialization-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "execution_specs_materialized"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "materialization_commit": os.environ[
        "EXPECTED_MATERIALIZATION_COMMIT"
    ],
    "readiness_evidence": {
        "report_path": readiness_report_path.name,
        "report_sha256": os.environ[
            "EXPECTED_READINESS_REPORT_SHA"
        ],
        "surface_sha256": os.environ[
            "EXPECTED_READINESS_SURFACE_SHA"
        ],
        "candidate_manifest_sha256": os.environ[
            "EXPECTED_CANDIDATE_MANIFEST_SHA"
        ],
        "status": (
            "sa5_objective_count_stage10_"
            "execution_spec_materialization_ready"
        ),
    },
    "input_materialization_evidence": {
        "report_path": input_materialization_report_path.as_posix(),
        "report_sha256": os.environ[
            "EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA"
        ],
        "campaign_file_manifest_sha256": os.environ[
            "EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"
        ],
    },
    "canonical_execution_specs": {
        "directory": canonical_spec_dir.as_posix(),
        "manifest_path": canonical_manifest_path.as_posix(),
        "manifest_sha256": sha256_file(
            canonical_manifest_path
        ),
        "execution_schema_version": EXECUTION_SCHEMA_VERSION,
        "executor_version": E3_EXECUTOR_VERSION,
        "execution_spec_count": 10,
        "selected_instances_per_spec": 6,
        "total_selected_instance_count": 60,
        "unique_selected_instance_count": 60,
        "portable_relative_paths": True,
        "all_validate_execution_spec": True,
        "all_load_execution_inputs": True,
        "all_output_directories_absent": True,
        "entries": canonical_entries,
    },
    "scientific_controls": {
        "canonical_campaign_generated": True,
        "canonical_campaign_materialization_performed": True,
        "canonical_execution_specs_materialized": True,
        "canonical_execution_specs_committed": False,
        "canonical_stage10_functional_execution_performed": False,
        "timing_execution_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_execution_performed": False,
        "manuscript_modified": False,
    },
    "authorization": {
        "canonical_execution_spec_materialization_complete": True,
        "canonical_functional_execution_authorized": False,
        "timing_execution_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_execution_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "materialization_complete": True,
    "next_stage": (
        "review_and_merge_sa5_objective_count_"
        "stage10_execution_specs_then_audit_"
        "functional_execution_authorization"
    ),
}

write_json(report_path, report)

summary_lines = [
    "# SA5 objective-count Stage-10 execution-spec materialization",
    "",
    f"- Source commit: `{report['source_commit']}`",
    "- Canonical execution specifications: `10`",
    "- Selected instances per specification: `6`",
    "- Total selected instances: `60`",
    "- Unique selected instances: `60`",
    "- Factor levels per specification: `1, 2, 5, 10, 20, 50`",
    "- Relative paths: portable",
    "- `validate_execution_spec`: PASS for all specifications",
    "- `load_execution_inputs`: PASS for all specifications",
    "- Canonical output directories created: no",
    (
        "- Execution-spec manifest SHA-256: "
        f"`{report['canonical_execution_specs']['manifest_sha256']}`"
    ),
    "",
    "## Scientific control",
    "",
    "- Canonical execution specs: materialized",
    "- Formal Stage-10 functional execution: not performed",
    "- Timing execution: not performed",
    "- Bootstrap analysis: not performed",
    "- Precision analysis: not performed",
    "- Manuscript modification: not performed",
    "",
    (
        "Next stage: review and merge these specifications, "
        "then audit authorization for formal functional execution."
    ),
    "",
]

summary_path.write_text(
    "\n".join(summary_lines),
    encoding="utf-8",
)

print("canonical_execution_spec_manifest=PASS")
print(
    "canonical_execution_spec_manifest_sha256="
    + sha256_file(canonical_manifest_path)
)
print("canonical_execution_spec_materialization_report=PASS")
print(
    "materialization_report_sha256="
    + sha256_file(report_path)
)
print(
    "materialization_summary_sha256="
    + sha256_file(summary_path)
)
PY

echo "canonical_execution_spec_provenance=PASS"

echo
echo "=== 6. Validate canonical specs and materialization report ==="

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-execution-spec-manifest-v1"
  and .status
    == "sa5_objective_count_stage10_execution_specs_materialized"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .materialization_commit
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"
  and .execution_spec_count == 10
  and .selected_instances_per_spec == 6
  and .total_selected_instance_count == 60
  and .unique_selected_instance_count == 60
  and .portable_relative_paths == true
  and .deterministic_candidate_replay_preserved == true
  and (.entries | length) == 10
  and .scientific_controls.canonical_execution_specs_materialized == true
  and .scientific_controls.canonical_execution_specs_committed == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false
' "$CANONICAL_SPEC_MANIFEST" >/dev/null

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-stage10-execution-spec-materialization-v1"
  and .status
    == "sa5_objective_count_stage10_execution_specs_materialized"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .materialization_commit
    == "c92e90afcfb81e31c372f829a87a69d78eb9817f"

  and .canonical_execution_specs.execution_spec_count == 10
  and .canonical_execution_specs.selected_instances_per_spec == 6
  and .canonical_execution_specs.total_selected_instance_count == 60
  and .canonical_execution_specs.unique_selected_instance_count == 60
  and .canonical_execution_specs.portable_relative_paths == true
  and .canonical_execution_specs.all_validate_execution_spec == true
  and .canonical_execution_specs.all_load_execution_inputs == true
  and .canonical_execution_specs.all_output_directories_absent == true
  and (.canonical_execution_specs.entries | length) == 10

  and .scientific_controls.canonical_execution_specs_materialized == true
  and .scientific_controls.canonical_execution_specs_committed == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false

  and .authorization.canonical_execution_spec_materialization_complete == true
  and .authorization.canonical_functional_execution_authorized == false
  and .authorization.scientific_execution_authorized == false

  and .blocker_count == 0
  and .materialization_complete == true
  and .next_stage
    == "review_and_merge_sa5_objective_count_stage10_execution_specs_then_audit_functional_execution_authorization"
' "$MATERIALIZATION_REPORT" >/dev/null

export CANONICAL_SPEC_DIR
export CANONICAL_SPEC_MANIFEST
export RUN_ROOT_ABS="$ROOT/$RUN_ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import json
import os
from pathlib import Path

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


spec_dir = Path(os.environ["CANONICAL_SPEC_DIR"])
manifest = json.loads(
    Path(
        os.environ["CANONICAL_SPEC_MANIFEST"]
    ).read_text(encoding="utf-8")
)
run_root = Path(os.environ["RUN_ROOT_ABS"]).resolve()

spec_paths = sorted(
    spec_dir.glob(
        "objective_count_stage10_rep_*_canonical.json"
    )
)

assert len(spec_paths) == 10

selected_ids: list[str] = []

for entry, spec_path in zip(
    manifest["entries"],
    spec_paths,
):
    assert spec_path.name == entry["filename"]

    payload = json.loads(
        spec_path.read_text(encoding="utf-8")
    )

    validate_execution_spec(payload)

    inputs = load_execution_inputs(spec_path)

    assert len(inputs.instances) == 6
    assert [
        instance.factor_level
        for instance in inputs.instances
    ] == [1, 2, 5, 10, 20, 50]

    assert inputs.output_dir.parent == run_root
    assert not inputs.output_dir.exists()

    selected_ids.extend(
        instance.canonical_instance_id
        for instance in inputs.instances
    )

assert len(selected_ids) == 60
assert len(set(selected_ids)) == 60

print("canonical_execution_spec_validation=PASS")
print("canonical_validate_execution_spec_count=10")
print("canonical_load_execution_inputs_count=10")
print("canonical_selected_instance_count=60")
print("canonical_unique_selected_instance_count=60")
print("canonical_output_directory_count=0")
PY

echo "canonical_execution_spec_validation_gate=PASS"

echo
echo "=== 7. Exact generated scope gate ==="

find "$CANONICAL_SPEC_DIR" \
  -maxdepth 1 \
  -type f \
  -name 'objective_count_stage10_rep_*_canonical.json' |
  sort > "$TMP_ROOT/spec_files.txt"

printf '%s\n' \
  "$CANONICAL_SPEC_MANIFEST" \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/provenance_files.txt"

cat \
  "$TMP_ROOT/spec_files.txt" \
  "$TMP_ROOT/provenance_files.txt" |
  sort > "$TMP_ROOT/expected_generated_files.txt"

test "$(wc -l < "$TMP_ROOT/spec_files.txt")" -eq 10
test "$(wc -l < "$TMP_ROOT/provenance_files.txt")" -eq 3
test "$(wc -l < "$TMP_ROOT/expected_generated_files.txt")" -eq 13

test "$({
  find "$RUN_ROOT" \
    -maxdepth 1 \
    -type d \
    -name 'objective_count_stage10_rep_*_canonical' \
    2>/dev/null || true
} | wc -l)" -eq 0

echo "generated_scope_gate=PASS"
echo "canonical_execution_spec_file_count=10"
echo "provenance_file_count=3"
echo "total_generated_file_count=13"
echo "canonical_run_count=0"

echo
echo "=== 8. Repository and scientific-control gate before staging ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"

verify_sha \
  "$READINESS_REPORT" \
  "$EXPECTED_READINESS_REPORT_SHA"

verify_sha \
  "$READINESS_SURFACE" \
  "$EXPECTED_READINESS_SURFACE_SHA"

verify_sha \
  "$CANDIDATE_A_MANIFEST" \
  "$EXPECTED_CANDIDATE_MANIFEST_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test "$({
  find "$RUN_ROOT" \
    -maxdepth 1 \
    -type d \
    -name 'objective_count_stage10_rep_*_canonical' \
    2>/dev/null || true
} | wc -l)" -eq 0

echo "precommit_integrity_gate=PASS"
echo "canonical_execution_specs_materialized=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 9. Force-stage exact execution-spec materialization ==="

mapfile -t GENERATED_FILES \
  < "$TMP_ROOT/expected_generated_files.txt"

git add \
  -f \
  -- \
  "${GENERATED_FILES[@]}"

git diff \
  --cached \
  --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 13

git diff \
  --cached \
  --check

echo "execution_spec_stage=PASS"
echo "staged_file_count=13"

echo
echo "=== 10. Commit execution-spec materialization ==="

git commit \
  -m "chore(experiments): materialize SA5 objective-count Stage-10 execution specs"

COMMIT="$(
  git rev-parse HEAD
)"

test "$COMMIT" != "$EXPECTED_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git diff-tree \
  --no-commit-id \
  --name-only \
  -r \
  "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/committed_files.txt"

echo "execution_spec_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=13"

echo
echo "=== 11. Push execution-spec branch ==="

git push \
  -u \
  origin \
  "$BRANCH"

test "$(
  git rev-parse "origin/$BRANCH"
)" = "$COMMIT"

echo "execution_spec_push=PASS"

echo
echo "=== 12. Create pull request ==="

SPEC_MANIFEST_SHA="$(
  sha256sum "$CANONICAL_SPEC_MANIFEST" |
    awk '{print $1}'
)"

REPORT_SHA="$(
  sha256sum "$MATERIALIZATION_REPORT" |
    awk '{print $1}'
)"

SUMMARY_SHA="$(
  sha256sum "$MATERIALIZATION_SUMMARY" |
    awk '{print $1}'
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Materialize SA5 objective-count Stage-10 execution specs" \
    --body-file - <<EOF
## Scope

Materialize the 10 preregistered and readiness-audited SA5 objective-count Stage-10 execution specifications.

- one specification per fixed replication
- 6 factor levels per specification
- 60 canonical instances selected exactly once
- 10 common workloads
- portable relative paths
- no output run directory created

## Validation

- \`validate_execution_spec\`: PASS for all 10 specifications
- \`load_execution_inputs\`: PASS for all 10 specifications
- candidate deterministic replay: PASS
- candidate manifest SHA-256: \`$EXPECTED_CANDIDATE_MANIFEST_SHA\`
- canonical execution-spec manifest SHA-256: \`$SPEC_MANIFEST_SHA\`
- materialization report SHA-256: \`$REPORT_SHA\`
- materialization summary SHA-256: \`$SUMMARY_SHA\`

## Scientific control

This PR materializes execution specifications only. It does not perform the formal Stage-10 functional campaign, timing, bootstrap analysis, precision analysis, or manuscript integration.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 13. Verify PR identity and exact scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg commit "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $commit
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 execution specs"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_generated_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 13

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=13"

echo
echo "=== 14. Final state ==="

echo "sa5_objective_count_stage10_execution_spec_materialization=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "canonical_execution_spec_count=10"
echo "selected_instances_per_spec=6"
echo "total_selected_instance_count=60"
echo "unique_selected_instance_count=60"
echo "total_committed_file_count=13"

echo "canonical_execution_spec_manifest=$CANONICAL_SPEC_MANIFEST"
echo "canonical_execution_spec_manifest_sha256=$SPEC_MANIFEST_SHA"
echo "materialization_report=$MATERIALIZATION_REPORT"
echo "materialization_report_sha256=$REPORT_SHA"
echo "materialization_summary=$MATERIALIZATION_SUMMARY"
echo "materialization_summary_sha256=$SUMMARY_SHA"

echo "canonical_execution_specs_materialized=true"
echo "canonical_execution_specs_committed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "canonical_functional_execution_authorized=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_execution_specs"

git status --short --branch
git log --oneline --decorate -5
