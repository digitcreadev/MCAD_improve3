#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CORE_FILES=(
  "backend/harness/sensitivity_design/design_matrix.yaml"
  "backend/harness/sensitivity_design/SENSITIVITY_GENERATOR_DESIGN.md"
  "backend/harness/sensitivity_generator/structural_generator.py"
  "backend/harness/sensitivity_generator/families/controlled_families.py"
  "backend/harness/sensitivity_generator/families/CONTROLLED_FAMILIES_E2_2.md"
  "backend/harness/sensitivity_generator/tests/test_controlled_families.py"
  "backend/harness/sensitivity_execution/execute_controlled_family.py"
  "backend/harness/sensitivity_execution/validate_e3_contract.py"
)

OPTIONAL_FILES=(
  "backend/harness/sensitivity_design/semantic_binding/semantic_binding.yaml"
  "backend/harness/sensitivity_design/semantic_binding/SEMANTIC_BINDING_E1_1.md"
  "backend/harness/run_scalability_benchmark.py"
)

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="/workspaces/sa5_objective_count_implementation_surface_${STAMP}"

trap 'echo "[ERROR] SA5 implementation-surface inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only implementation preflight gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in "${CORE_FILES[@]}"; do
  if [ ! -f "$FILE" ]; then
    echo "[ERROR] Missing required core file: $FILE"
    exit 1
  fi
done

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" | awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}'
)"

echo "implementation_preflight_gate=PASS"
echo "repository_modified=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 2. Initialize detached inspection output ==="

rm -rf "$OUT"

mkdir -p \
  "$OUT/extracts" \
  "$OUT/discovery"

echo "inspection_root=$OUT"

echo
echo "=== 3. Discover actual relevant tests ==="

git ls-files \
  'backend/harness/sensitivity_generator/tests/*.py' \
  'backend/harness/sensitivity_execution/tests/*.py' \
  'backend/harness/tests/*.py' \
  > "$OUT/discovery/all_candidate_tests.txt"

: > "$OUT/discovery/relevant_tests.txt"

while IFS= read -r FILE; do
  test -f "$FILE" || continue

  if grep -Eqi \
    'objective_count|n_objectives|controlled_families|execute_controlled_family|validate_e3_contract|campaign_generator_version|structural_generator_version|generator_profile|factor_specific_generator_profiles|virtual_node_count|membership_density' \
    "$FILE"
  then
    printf '%s\n' "$FILE" \
      >> "$OUT/discovery/relevant_tests.txt"
  fi
done < "$OUT/discovery/all_candidate_tests.txt"

sort -u \
  "$OUT/discovery/relevant_tests.txt" \
  -o "$OUT/discovery/relevant_tests.txt"

RELEVANT_TEST_COUNT="$(
  sed '/^$/d' \
    "$OUT/discovery/relevant_tests.txt" |
    wc -l
)"

echo "relevant_test_count=$RELEVANT_TEST_COUNT"

echo
echo "--- Discovered relevant tests ---"

if [ "$RELEVANT_TEST_COUNT" -gt 0 ]; then
  cat "$OUT/discovery/relevant_tests.txt"
else
  echo "NONE"
fi

echo
echo "=== 4. Build exact selected-file inventory ==="

{
  printf '%s\n' "${CORE_FILES[@]}"

  for FILE in "${OPTIONAL_FILES[@]}"; do
    if [ -f "$FILE" ]; then
      printf '%s\n' "$FILE"
    fi
  done

  cat "$OUT/discovery/relevant_tests.txt"
} |
  sed '/^$/d' |
  awk '!seen[$0]++' |
  sort \
  > "$OUT/selected_files.txt"

SELECTED_FILE_COUNT="$(
  wc -l < "$OUT/selected_files.txt"
)"

test "$SELECTED_FILE_COUNT" -ge "${#CORE_FILES[@]}"

{
  printf 'sha256\tsize_bytes\tpath\n'

  while IFS= read -r FILE; do
    test -f "$FILE"

    printf '%s\t%s\t%s\n' \
      "$(sha256sum "$FILE" | awk '{print $1}')" \
      "$(stat -c '%s' "$FILE")" \
      "$FILE"
  done < "$OUT/selected_files.txt"
} > "$OUT/source_inventory.tsv"

echo "selected_file_count=$SELECTED_FILE_COUNT"

column -t -s $'\t' \
  "$OUT/source_inventory.tsv"

echo
echo "=== 5. Extract exact implementation and test surfaces ==="

python3 - \
  "$ROOT" \
  "$OUT" \
  "$OUT/selected_files.txt" <<'PY'
from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1]).resolve()
output_root = Path(sys.argv[2]).resolve()
selected_file_list = Path(sys.argv[3]).resolve()

relative_paths = [
    line.strip()
    for line in selected_file_list.read_text(
        encoding="utf-8"
    ).splitlines()
    if line.strip()
]

keyword_regex = re.compile(
    "|".join([
        r"\bobjective_count\b",
        r"\bn_objectives\b",
        r"\bconstraint_count\b",
        r"\bvirtual_node_count\b",
        r"\bmembership_density\b",
        r"\bcontribution_density\b",
        r"\bworkload_noise\b",
        r"\bprimary_factor\b",
        r"\bfactor\b",
        r"\bcampaign_generator_version\b",
        r"\bstructural_generator_version\b",
        r"\baccepted_profiles\b",
        r"\bgenerator_profile\b",
        r"\bfactor_specific_generator_profiles\b",
        r"\bcontrolled_famil",
        r"\bexecute_controlled_family\b",
    ]),
    flags=re.IGNORECASE,
)


def render_signature(node: ast.AST) -> str:
    if isinstance(
        node,
        (ast.FunctionDef, ast.AsyncFunctionDef),
    ):
        try:
            rendered_arguments = ast.unparse(node.args)
        except Exception:
            rendered_arguments = "..."

        prefix = (
            "async def"
            if isinstance(node, ast.AsyncFunctionDef)
            else "def"
        )

        return (
            f"{prefix} {node.name}"
            f"({rendered_arguments})"
        )

    if isinstance(node, ast.ClassDef):
        return f"class {node.name}"

    return type(node).__name__


def merge_ranges(
    line_numbers: list[int],
    *,
    radius: int,
    line_count: int,
) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []

    for line_number in sorted(set(line_numbers)):
        start = max(1, line_number - radius)
        end = min(line_count, line_number + radius)

        if ranges and start <= ranges[-1][1] + 1:
            previous_start, previous_end = ranges[-1]

            ranges[-1] = (
                previous_start,
                max(previous_end, end),
            )
        else:
            ranges.append((start, end))

    return ranges


report: dict[str, Any] = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "implementation-surface-v2"
    ),
    "selected_file_count": len(relative_paths),
    "files": {},
}

for relative_path in relative_paths:
    path = root / relative_path

    text = path.read_text(
        encoding="utf-8",
        errors="replace",
    )

    lines = text.splitlines()

    matching_line_numbers: list[int] = []
    matching_lines: list[dict[str, Any]] = []

    for line_number, line in enumerate(
        lines,
        start=1,
    ):
        if keyword_regex.search(line):
            matching_line_numbers.append(line_number)

            matching_lines.append({
                "line": line_number,
                "text": line[:1000],
            })

    record: dict[str, Any] = {
        "path": relative_path,
        "line_count": len(lines),
        "matching_lines": matching_lines,
        "relevant_definitions": [],
        "relevant_assignments": [],
    }

    extract_lines = [
        "=" * 100,
        f"FILE={relative_path}",
        f"LINE_COUNT={len(lines)}",
        "=" * 100,
    ]

    for start, end in merge_ranges(
        matching_line_numbers,
        radius=16,
        line_count=len(lines),
    ):
        extract_lines.extend([
            "",
            f"--- LINES {start}-{end} ---",
        ])

        for index in range(start - 1, end):
            extract_lines.append(
                f"{index + 1:05d}: {lines[index]}"
            )

    if path.suffix == ".py":
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            record["python_parse_error"] = str(exc)
        else:
            relevant_nodes: list[ast.AST] = []

            for node in ast.walk(tree):
                if not isinstance(
                    node,
                    (
                        ast.FunctionDef,
                        ast.AsyncFunctionDef,
                        ast.ClassDef,
                    ),
                ):
                    continue

                source = (
                    ast.get_source_segment(text, node)
                    or ""
                )

                if keyword_regex.search(source):
                    relevant_nodes.append(node)

                    record[
                        "relevant_definitions"
                    ].append({
                        "signature": render_signature(node),
                        "start_line": getattr(
                            node,
                            "lineno",
                            None,
                        ),
                        "end_line": getattr(
                            node,
                            "end_lineno",
                            None,
                        ),
                    })

            for node in tree.body:
                if not isinstance(
                    node,
                    (
                        ast.Assign,
                        ast.AnnAssign,
                    ),
                ):
                    continue

                source = (
                    ast.get_source_segment(text, node)
                    or ""
                )

                if keyword_regex.search(source):
                    record[
                        "relevant_assignments"
                    ].append({
                        "start_line": getattr(
                            node,
                            "lineno",
                            None,
                        ),
                        "end_line": getattr(
                            node,
                            "end_lineno",
                            None,
                        ),
                        "source": source,
                    })

            extract_lines.append(
                "\n--- COMPLETE RELEVANT PYTHON DEFINITIONS ---"
            )

            for node in sorted(
                relevant_nodes,
                key=lambda item: getattr(
                    item,
                    "lineno",
                    0,
                ),
            ):
                source = ast.get_source_segment(
                    text,
                    node,
                )

                if not source:
                    continue

                extract_lines.extend([
                    "",
                    (
                        f"### {render_signature(node)} "
                        f"[{node.lineno}-"
                        f"{getattr(node, 'end_lineno', node.lineno)}]"
                    ),
                    source,
                ])

            extract_lines.append(
                "\n--- RELEVANT MODULE ASSIGNMENTS ---"
            )

            for assignment in record[
                "relevant_assignments"
            ]:
                extract_lines.extend([
                    "",
                    assignment["source"],
                ])

    extract_name = (
        relative_path
        .replace("/", "__")
        .replace("\\", "__")
        + ".txt"
    )

    extract_path = (
        output_root
        / "extracts"
        / extract_name
    )

    extract_path.write_text(
        "\n".join(extract_lines) + "\n",
        encoding="utf-8",
    )

    record["extract_path"] = str(extract_path)
    report["files"][relative_path] = record

(output_root / "implementation_surface.json").write_text(
    json.dumps(
        report,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

print("implementation_surface_extraction=PASS")
print(f"selected_file_count={len(relative_paths)}")

for relative_path, record in report["files"].items():
    print(
        f"surface_file={relative_path} "
        f"matching_lines={len(record['matching_lines'])} "
        "relevant_definitions="
        f"{len(record['relevant_definitions'])} "
        "assignments="
        f"{len(record['relevant_assignments'])}"
    )
PY

echo
echo "=== 6. Show exact controlled-generator surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_generator__families__controlled_families.py.txt"

echo
echo "=== 7. Show discovered generator-test surfaces ==="

while IFS= read -r FILE; do
  case "$FILE" in
    backend/harness/sensitivity_generator/tests/*)
      EXTRACT="$OUT/extracts/${FILE//\//__}.txt"

      if [ -f "$EXTRACT" ]; then
        cat "$EXTRACT"
      fi
      ;;
  esac
done < "$OUT/discovery/relevant_tests.txt"

echo
echo "=== 8. Show exact E3 executor surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_execution__execute_controlled_family.py.txt"

echo
echo "=== 9. Show exact E3 validator surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_execution__validate_e3_contract.py.txt"

echo
echo "=== 10. Show discovered execution-test surfaces ==="

while IFS= read -r FILE; do
  case "$FILE" in
    backend/harness/sensitivity_execution/tests/*)
      EXTRACT="$OUT/extracts/${FILE//\//__}.txt"

      if [ -f "$EXTRACT" ]; then
        cat "$EXTRACT"
      fi
      ;;
  esac
done < "$OUT/discovery/relevant_tests.txt"

echo
echo "=== 11. Show structural-generator surface ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_generator__structural_generator.py.txt"

echo
echo "=== 12. Show exact design and semantic bindings ==="

cat \
  "$OUT/extracts/backend__harness__sensitivity_design__design_matrix.yaml.txt"

if [ -f \
  "$OUT/extracts/backend__harness__sensitivity_design__semantic_binding__semantic_binding.yaml.txt" ]
then
  cat \
    "$OUT/extracts/backend__harness__sensitivity_design__semantic_binding__semantic_binding.yaml.txt"
fi

echo
echo "=== 13. Compact implementation matrix ==="

python3 - \
  "$OUT/implementation_surface.json" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

report = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

for path, record in report["files"].items():
    definitions = record.get(
        "relevant_definitions",
        [],
    )

    assignments = record.get(
        "relevant_assignments",
        [],
    )

    if not definitions and not assignments:
        continue

    print(f"\nFILE={path}")

    for definition in definitions:
        print(
            "  DEF "
            f"{definition['signature']} "
            f"[{definition['start_line']}-"
            f"{definition['end_line']}]"
        )

    for assignment in assignments:
        first_line = (
            assignment["source"]
            .splitlines()[0]
            .strip()
        )

        print(
            "  ASSIGN "
            f"[{assignment['start_line']}-"
            f"{assignment['end_line']}] "
            f"{first_line}"
        )
PY

echo
echo "=== 14. Explicit objective-count readiness evidence ==="

grep -RInE \
  'objective_count|n_objectives' \
  "$OUT/extracts" \
  > "$OUT/objective_count_surface_hits.txt" \
  || true

OBJECTIVE_HIT_COUNT="$(
  wc -l < "$OUT/objective_count_surface_hits.txt"
)"

echo "objective_count_surface_hit_count=$OBJECTIVE_HIT_COUNT"

sed -n '1,260p' \
  "$OUT/objective_count_surface_hits.txt"

echo
echo "=== 15. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$MANUSCRIPT" | awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" | awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "sa5_objective_count_implementation_surface=PASS"
echo "repository_modified=false"
echo "manuscript_modified=false"
echo "scientific_execution_performed=false"
echo "campaign_execution_authorized=false"
echo "relevant_test_count=$RELEVANT_TEST_COUNT"
echo "selected_file_count=$SELECTED_FILE_COUNT"
echo "inspection_root=$OUT"
echo "implementation_surface_report=$OUT/implementation_surface.json"
echo "next_stage=implement_sa5_objective_count_controlled_family_and_e3_support"

git status --short --branch
