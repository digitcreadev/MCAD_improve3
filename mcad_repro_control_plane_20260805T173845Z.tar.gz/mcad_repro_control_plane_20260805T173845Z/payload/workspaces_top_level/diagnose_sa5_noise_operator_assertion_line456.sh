#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="34012c02b5784049ea25b8d0544f1f092896ae2a"

FAILED_SCRIPT="/workspaces/audit_sa5_objective_count_v2_noise_operator_feasibility.sh"

AMENDMENT_002="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_workload_contribution_capacity_amendment.json"
EXPECTED_AMENDMENT_002_SHA="32b3f28d0815fa3e0713f00bc0a418863e28089f00fe4079e20c7f257ac960dc"

SCOPE_REPORT="/workspaces/sa5_objective_count_v2_scope_reprojection_20260804T225944Z/sa5_objective_count_v2_scope_reprojection.json"
EXPECTED_SCOPE_REPORT_SHA="51dc1c626dd3a017587eb745f2fbc643c53a00eb6669dbfb789cd8788fcac9c3"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="/workspaces/sa5_noise_operator_line456_diagnosis_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_noise_operator_line456_diagnosis.json"
SURFACE="$OUTPUT_ROOT/sa5_noise_operator_line456_diagnosis.txt"

trap 'echo "[ERROR] SA5 line-456 diagnosis stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact read-only diagnosis gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$FAILED_SCRIPT" \
  "$AMENDMENT_002" \
  "$SCOPE_REPORT" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "diagnosis_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Confirm exact failed assertion ==="

export ROOT
export FAILED_SCRIPT
export AMENDMENT_002
export SCOPE_REPORT
export REPORT
export SURFACE
export EXPECTED_HEAD

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

python3 - <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
from pathlib import Path
from typing import Any


root = Path(os.environ["ROOT"]).resolve()
failed_script = Path(
    os.environ["FAILED_SCRIPT"]
).resolve()

amendment_path = (
    root / os.environ["AMENDMENT_002"]
)

scope_report_path = Path(
    os.environ["SCOPE_REPORT"]
).resolve()

report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])

source_commit = os.environ["EXPECTED_HEAD"]


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(value, dict):
        raise AssertionError(
            f"JSON root is not an object: {path}"
        )

    return value


script_text = failed_script.read_text(
    encoding="utf-8"
)

start_marker = '"$PYTHON" - <<\'PY\'\n'
end_marker = "\nPY\n"

start = script_text.find(start_marker)

if start < 0:
    raise AssertionError(
        "Embedded Python start marker not found."
    )

start += len(start_marker)

end = script_text.find(
    end_marker,
    start,
)

if end < 0:
    raise AssertionError(
        "Embedded Python end marker not found."
    )

python_block = script_text[start:end]
python_lines = python_block.splitlines()

assert len(python_lines) >= 456

failed_python_line = (
    python_lines[455].strip()
)

assert failed_python_line == (
    "assert production_operator_hits == []"
)

line_context_start = 443
line_context_end = 458

failed_line_context = "\n".join(
    (
        f"{number:4d}: "
        f"{python_lines[number - 1]}"
    )
    for number in range(
        line_context_start,
        line_context_end + 1,
    )
)

amendment = load_json(
    amendment_path
)

scope_report = load_json(
    scope_report_path
)

noise_classes = list(
    amendment[
        "revised_workload_contract"
    ]["noise_class_order"]
)

assert noise_classes == [
    "wrong_measure",
    "wrong_context",
    "insufficient_grain",
    "invalid_aggregation",
    "invalid_unit",
    "invalid_time_window",
    "missing_cube",
    "redundant_contribution",
]

assert scope_report[
    "final_scope"
]["total_patch_file_count"] == 21


tracked_output = subprocess.run(
    [
        "git",
        "-C",
        str(root),
        "ls-files",
        "-z",
    ],
    check=True,
    capture_output=True,
).stdout

tracked_files = [
    Path(item.decode("utf-8"))
    for item in tracked_output.split(b"\0")
    if item
]


def enclosing_owner(
    tree: ast.AST,
    line_number: int,
) -> dict[str, Any] | None:
    candidates: list[
        tuple[int, ast.AST]
    ] = []

    for node in ast.walk(tree):
        if not isinstance(
            node,
            (
                ast.ClassDef,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
            ),
        ):
            continue

        start_line = int(
            getattr(node, "lineno", 0)
        )

        end_line = int(
            getattr(
                node,
                "end_lineno",
                start_line,
            )
        )

        if (
            start_line
            <= line_number
            <= end_line
        ):
            candidates.append(
                (
                    end_line - start_line,
                    node,
                )
            )

    if not candidates:
        return None

    _, node = min(
        candidates,
        key=lambda item: item[0],
    )

    return {
        "kind": type(node).__name__,
        "name": getattr(
            node,
            "name",
            "<anonymous>",
        ),
        "start_line": int(node.lineno),
        "end_line": int(
            getattr(
                node,
                "end_lineno",
                node.lineno,
            )
        ),
    }


all_hits: list[dict[str, Any]] = []

for relative in tracked_files:
    path = root / relative

    if path.suffix != ".py":
        continue

    try:
        text = path.read_text(
            encoding="utf-8"
        )
    except (
        OSError,
        UnicodeDecodeError,
    ):
        continue

    matched_file_classes = [
        noise_class
        for noise_class in noise_classes
        if noise_class in text
    ]

    if not matched_file_classes:
        continue

    try:
        tree = ast.parse(
            text,
            filename=str(path),
        )
    except SyntaxError:
        tree = None

    lines = text.splitlines()

    for line_number, line in enumerate(
        lines,
        start=1,
    ):
        matched_classes = [
            noise_class
            for noise_class in noise_classes
            if noise_class in line
        ]

        if not matched_classes:
            continue

        start_line = max(
            1,
            line_number - 5,
        )

        end_line = min(
            len(lines),
            line_number + 5,
        )

        relative_text = (
            relative.as_posix()
        )

        excluded_by_original_filter = (
            "/tests/" in relative_text
            or relative_text.endswith(
                "validate_design.py"
            )
            or "/planning/" in relative_text
        )

        stripped = line.strip()

        if stripped.startswith("#"):
            lexical_role = "comment"
        elif stripped.startswith(
            ('"""', "'''")
        ):
            lexical_role = (
                "possible_docstring"
            )
        elif (
            "=" in stripped
            and any(
                quote in stripped
                for quote in ('"', "'")
            )
        ):
            lexical_role = (
                "assignment_or_mapping_literal"
            )
        elif stripped.startswith(
            ("def ", "class ")
        ):
            lexical_role = (
                "definition_header"
            )
        else:
            lexical_role = (
                "executable_or_reference_expression"
            )

        all_hits.append(
            {
                "path": relative_text,
                "file_sha256": (
                    sha256_file(path)
                ),
                "line": line_number,
                "classes": matched_classes,
                "text": line.rstrip(),
                "context_start_line": (
                    start_line
                ),
                "context_end_line": (
                    end_line
                ),
                "context": "\n".join(
                    (
                        f"{number:4d}: "
                        f"{lines[number - 1]}"
                    )
                    for number in range(
                        start_line,
                        end_line + 1,
                    )
                ),
                "excluded_by_original_filter": (
                    excluded_by_original_filter
                ),
                "lexical_role": lexical_role,
                "enclosing_owner": (
                    enclosing_owner(
                        tree,
                        line_number,
                    )
                    if tree is not None
                    else None
                ),
            }
        )


production_hits = [
    hit
    for hit in all_hits
    if not hit[
        "excluded_by_original_filter"
    ]
]

assert production_hits

production_hit_files = sorted(
    {
        hit["path"]
        for hit in production_hits
    }
)

owner_keys = sorted(
    {
        (
            hit["path"],
            (
                hit["enclosing_owner"][
                    "kind"
                ]
                if hit[
                    "enclosing_owner"
                ]
                else "<module>"
            ),
            (
                hit["enclosing_owner"][
                    "name"
                ]
                if hit[
                    "enclosing_owner"
                ]
                else "<module>"
            ),
        )
        for hit in production_hits
    }
)

lexical_role_counts: dict[str, int] = {}

for hit in production_hits:
    role = str(hit["lexical_role"])

    lexical_role_counts[role] = (
        lexical_role_counts.get(
            role,
            0,
        )
        + 1
    )


status = (
    "sa5_noise_operator_line456_"
    "production_hits_confirmed"
)

next_stage = (
    "classify_existing_noise_class_"
    "production_hits_before_operator_"
    "contract_decision"
)

report = {
    "schema_version": (
        "mcad-sa5-noise-operator-"
        "line456-diagnosis-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "failed_script": str(
        failed_script
    ),
    "failed_script_sha256": (
        sha256_file(failed_script)
    ),
    "embedded_python_line_count": (
        len(python_lines)
    ),
    "failed_python_line_number": 456,
    "failed_python_line": (
        failed_python_line
    ),
    "failed_line_context": (
        failed_line_context
    ),
    "confirmed_preceding_results": {
        "redundancy_schedule_assertions_reached": True,
        "session_semantics_assertions_reached": True,
        "artifact_operator_key_absence_assertion_reached": True,
        "production_hit_emptiness_assertion_failed": True,
    },
    "noise_classes": noise_classes,
    "tracked_file_count": len(
        tracked_files
    ),
    "all_repository_hit_count": len(
        all_hits
    ),
    "production_hit_count": len(
        production_hits
    ),
    "production_hit_file_count": len(
        production_hit_files
    ),
    "production_hit_files": (
        production_hit_files
    ),
    "production_owner_count": len(
        owner_keys
    ),
    "production_owners": [
        {
            "path": path,
            "kind": kind,
            "name": name,
        }
        for path, kind, name
        in owner_keys
    ],
    "production_lexical_role_counts": (
        lexical_role_counts
    ),
    "production_hits": (
        production_hits
    ),
    "all_hits": all_hits,
    "classification_complete": False,
    "authoritative_operator_definition_present": None,
    "production_operator_implementation_present": None,
    "v2_patch_authoring_authorized": False,
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 NOISE-OPERATOR ASSERTION LINE 456 DIAGNOSIS",
    "=" * 92,
    f"source_commit={source_commit}",
    f"status={status}",
    "",
    "=== FAILED ASSERTION ===",
    "failed_python_line_number=456",
    f"failed_python_line={failed_python_line}",
    "",
    failed_line_context,
    "",
    "=== HIT COUNTS ===",
    (
        "all_repository_hit_count="
        f"{len(all_hits)}"
    ),
    (
        "production_hit_count="
        f"{len(production_hits)}"
    ),
    (
        "production_hit_file_count="
        f"{len(production_hit_files)}"
    ),
    (
        "production_owner_count="
        f"{len(owner_keys)}"
    ),
    "",
    "=== PRODUCTION HIT FILES ===",
    *production_hit_files,
    "",
    "=== EXACT PRODUCTION HITS ===",
]

for hit in production_hits:
    owner = hit[
        "enclosing_owner"
    ]

    if owner is None:
        owner_text = "<module>"
    else:
        owner_text = (
            f"{owner['kind']} "
            f"{owner['name']} "
            f"[{owner['start_line']}-"
            f"{owner['end_line']}]"
        )

    surface_lines.extend(
        [
            "",
            "-" * 92,
            (
                f"FILE={hit['path']}"
            ),
            (
                f"LINE={hit['line']}"
            ),
            (
                "CLASSES="
                + json.dumps(
                    hit["classes"],
                    ensure_ascii=False,
                )
            ),
            (
                "LEXICAL_ROLE="
                f"{hit['lexical_role']}"
            ),
            (
                "OWNER="
                f"{owner_text}"
            ),
            (
                f"SHA256="
                f"{hit['file_sha256']}"
            ),
            "CONTEXT:",
            hit["context"],
        ]
    )

surface_lines.extend(
    [
        "",
        "=== DECISION STATE ===",
        "classification_complete=false",
        (
            "authoritative_operator_definition_"
            "present=unresolved"
        ),
        (
            "production_operator_implementation_"
            "present=unresolved"
        ),
        "v2_patch_authoring_authorized=false",
        (
            "canonical_campaign_materialization_"
            "authorized=false"
        ),
        "canonical_campaign_generated=false",
        "scientific_execution_performed=false",
        f"next_stage={next_stage}",
        "",
    ]
)

surface_path.write_text(
    "\n".join(surface_lines),
    encoding="utf-8",
)

print("failed_assertion_identification=PASS")
print("failed_python_line_number=456")
print(
    f"failed_python_line={failed_python_line}"
)
print(
    "production_hit_count="
    f"{len(production_hits)}"
)
print(
    "production_hit_file_count="
    f"{len(production_hit_files)}"
)
print(
    "production_owner_count="
    f"{len(owner_keys)}"
)
print(
    "classification_complete=false"
)
print(
    "production_operator_implementation_"
    "present=unresolved"
)
print(
    "v2_patch_authoring_authorized=false"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 3. Validate diagnosis report ==="

jq -e '
  .schema_version
    == "mcad-sa5-noise-operator-line456-diagnosis-v1"
  and .status
    == "sa5_noise_operator_line456_production_hits_confirmed"
  and .source_commit
    == "34012c02b5784049ea25b8d0544f1f092896ae2a"
  and .read_only == true
  and .failed_python_line_number == 456
  and .failed_python_line
    == "assert production_operator_hits == []"
  and .confirmed_preceding_results.production_hit_emptiness_assertion_failed
    == true
  and .production_hit_count >= 1
  and .production_hit_file_count >= 1
  and (
    .production_hits
    | length
  ) == .production_hit_count
  and .classification_complete == false
  and .authoritative_operator_definition_present == null
  and .production_operator_implementation_present == null
  and .v2_patch_authoring_authorized == false
  and .canonical_campaign_materialization_authorized == false
  and .canonical_campaign_generated == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false
  and .next_stage
    == "classify_existing_noise_class_production_hits_before_operator_contract_decision"
' "$REPORT" >/dev/null

echo "diagnosis_report_validation=PASS"

echo
echo "=== 4. Exact production-hit summary ==="

jq '{
  status,
  failed_python_line_number,
  failed_python_line,
  production_hit_count,
  production_hit_file_count,
  production_hit_files,
  production_owner_count,
  production_owners,
  production_lexical_role_counts,
  classification_complete,
  production_operator_implementation_present,
  next_stage
}' "$REPORT"

echo
echo "=== 5. Exact hit contexts ==="

cat "$SURFACE"

echo
echo "=== 6. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$AMENDMENT_002" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_002_SHA"

test "$(
  sha256sum "$SCOPE_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_SCOPE_REPORT_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_noise_operator_line456_diagnosis=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"
echo "classification_complete=false"
echo "production_operator_implementation_present=unresolved"
echo "v2_patch_authoring_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=classify_existing_noise_class_production_hits_before_operator_contract_decision"

git status --short --branch
