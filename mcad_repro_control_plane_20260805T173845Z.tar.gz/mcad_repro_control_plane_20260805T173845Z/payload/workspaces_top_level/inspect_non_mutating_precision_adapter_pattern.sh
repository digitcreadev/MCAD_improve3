#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6d244ec318cf3986900b3220924050974b141cd1"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

VNC_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis"

INPUT_MANIFEST="$VNC_ROOT/precision_input_manifest.json"
TIMING_ADAPTER="$VNC_ROOT/analyzer_timing_report_adapter.json"
RAW_REPORT="$VNC_ROOT/raw_analyzer_report.json"
DECISION_REPORT="$VNC_ROOT/stage10_precision_decision_report.json"

MD_PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa4_membership_density_portfolio_timing_preregistration.json"
MD_LEDGER="reports/article_experiments/sensitivity/e3_controlled_execution/timing_runs/membership_density_stage10_portfolio/stage10_execution_ledger.json"
MD_AUDIT="reports/article_experiments/sensitivity/e3_controlled_execution/audits/membership_density/timing_stage10/stage10_output_audit.json"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"
EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

trap 'echo "[ERROR] Adapter-pattern inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only pattern gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"

for FILE in \
  "$INPUT_MANIFEST" \
  "$TIMING_ADAPTER" \
  "$RAW_REPORT" \
  "$DECISION_REPORT" \
  "$MD_PREREG" \
  "$MD_LEDGER" \
  "$MD_AUDIT" \
  "$ANALYZER"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

echo "pattern_gate=PASS"
echo "adapter_materialization_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Inspect virtual-node-count non-mutating pattern ==="

"$PYTHON" - \
  "$ROOT" \
  "$INPUT_MANIFEST" \
  "$TIMING_ADAPTER" \
  "$RAW_REPORT" \
  "$DECISION_REPORT" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Iterator

root = Path(sys.argv[1]).resolve()

paths = {
    "input_manifest": (root / sys.argv[2]).resolve(),
    "timing_adapter": (root / sys.argv[3]).resolve(),
    "raw_report": (root / sys.argv[4]).resolve(),
    "decision_report": (root / sys.argv[5]).resolve(),
}


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def walk(
    value: Any,
    prefix: str = "$",
) -> Iterator[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from walk(child, f"{prefix}.{key}")

    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from walk(child, f"{prefix}[{index}]")

    else:
        yield prefix, value


documents = {
    name: load_object(path)
    for name, path in paths.items()
}

manifest = documents["input_manifest"]
timing_adapter = documents["timing_adapter"]
raw_report = documents["raw_report"]
decision = documents["decision_report"]

if manifest.get("factor") != "virtual_node_count":
    raise SystemExit("Unexpected precision-input factor.")

if timing_adapter.get("factor") != "virtual_node_count":
    raise SystemExit("Unexpected timing-adapter factor.")

if timing_adapter.get("status") != (
    "stage10_formal_timing_execution_success"
):
    raise SystemExit("Unexpected timing-adapter status.")

if decision.get("factor") != "virtual_node_count":
    raise SystemExit("Unexpected decision-report factor.")

cell_results = raw_report.get("cell_results")

if not isinstance(cell_results, list) or not cell_results:
    raise SystemExit("Raw analyzer cell results are absent.")

raw_factor_values = sorted({
    row.get("factor")
    for row in cell_results
})

if raw_factor_values != ["constraint_count"]:
    raise SystemExit(
        f"Unexpected raw factor values: {raw_factor_values}"
    )

if decision.get("status") != "pass":
    raise SystemExit("Virtual-node decision report is not PASS.")

print("virtual_node_pattern_gate=PASS")
print(f"raw_analyzer_cell_count={len(cell_results)}")
print(
    "raw_analyzer_factor_values="
    + json.dumps(raw_factor_values)
)
print("canonical_wrapper_factor=virtual_node_count")
print(
    "raw_analyzer_report_is_not_canonical_decision=true"
)

print()
print("artifact_sha256_values=")

for name, path in paths.items():
    print(f"{name}={sha256(path)}")

keywords = {
    "factor",
    "status",
    "observations",
    "timing_report",
    "measurement_observation_count",
    "cell_count",
    "structural_seed_count",
    "exactly_balanced_run_count",
    "analyzer",
    "raw_analyzer",
    "next_stage",
    "stage10_sufficient",
    "stage20",
    "sha256",
    "source",
}

for name, document in documents.items():
    print()
    print(f"--- {name} selected contract fields ---")

    for field, value in walk(document):
        if any(
            keyword in field.lower()
            for keyword in keywords
        ):
            rendered = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
            )
            print(f"{field}={rendered}")

print()
print("non_mutating_precision_pattern_inspection=PASS")
PY

echo
echo "=== 3. Locate pattern-producing implementation ==="

MATCHES="$(
  git grep -n \
    -e 'precision_input_manifest' \
    -e 'analyzer_timing_report_adapter' \
    -e 'stage10_precision_decision_report' \
    -- \
    '*.py' \
    '*.sh' \
    '*.md' \
    2>/dev/null || true
)"

if [ -n "$MATCHES" ]; then
  printf '%s\n' "$MATCHES" | head -200
  echo "pattern_implementation_references_found=true"
else
  echo "pattern_implementation_references_found=false"
fi

echo
echo "=== 4. Verify membership-density target contract ==="

jq -e '
  .factor == "membership_density"
  and .derived_analysis_adapter.required == true
  and .derived_analysis_adapter.analyzer_step_index == 0
  and .derived_analysis_adapter.analyzer_levels_argument
      == "25,50,75,100"
  and .derived_analysis_adapter.analyzer_steps_argument == "0"
  and .derived_analysis_adapter.analyzer_measurements_per_cluster_argument
      == 2300
  and .derived_analysis_adapter.derived_observation_count == 92000
  and .derived_analysis_adapter.raw_timing_csv_modification_allowed
      == false
  and .precision_protocol.bootstrap_repetitions == 10000
  and .precision_protocol.bootstrap_seed == 20260728
  and .precision_protocol.confidence_level == 0.95
  and .precision_protocol.median_relative_half_width_target == 0.10
  and .precision_protocol.p95_relative_half_width_target == 0.15
' "$MD_PREREG" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.measurement_observation_count == 92000
  and .scientific_controls.precision_analysis_performed == false
' "$MD_LEDGER" >/dev/null

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
' "$MD_AUDIT" >/dev/null

echo "membership_density_target_contract=PASS"
echo "canonical_factor=membership_density"
echo "raw_analyzer_factor_label_expected=constraint_count"
echo "canonical_wrapper_required=true"
echo "synthetic_step_index=0"
echo "analyzer_cell_count=40"
echo "inferential_density_cell_count=4"
echo "measurements_per_cluster=2300"
echo "measurement_observation_count=92000"

echo
echo "=== 5. Selected integration strategy ==="

echo "analyzer_source_modification_allowed=false"
echo "raw_timing_csv_modification_allowed=false"
echo "observation_adapter_required=true"
echo "timing_report_adapter_required=true"
echo "raw_analyzer_report_required=true"
echo "canonical_decision_wrapper_required=true"
echo "raw_analyzer_next_stage_authoritative=false"
echo "raw_analyzer_factor_authoritative=false"
echo "precision_analysis_authorized=false"

echo
echo "=== 6. Final read-only state ==="

test -z "$(git status --porcelain)"

echo "membership_density_non_mutating_adapter_strategy=PASS"
echo "source_files_modified=false"
echo "adapter_artifact_created=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "next_stage=preregister_membership_density_non_mutating_precision_adapter"

git status --short --branch
