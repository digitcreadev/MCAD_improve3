#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="5a25d5e5a90c0fd821d9c0c21dc539fcfb9e8766"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"
WORKLOADS="$REPORTS/workloads"
SPECS="$REPORTS/execution_specs"

PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"
RUNNER="backend/harness/sensitivity_execution/run_timing_repetitions.py"

cd "$ROOT"

echo "=== 1. Repository gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"
test -x "$PYTHON"
test -f "$PREREG"
test -f "$RUNNER"

jq -e '
  .status
    == "membership_density_portfolio_timing_preregistration_complete"
  and .scientific_controls.timing_input_materialization_authorized
      == true
  and .scientific_controls.timing_input_materialization_performed
      == false
  and .scientific_controls.timing_execution_authorized == false
  and .next_stage == "prepare_membership_density_timing_inputs"
' "$PREREG" >/dev/null

echo "repository_gate=PASS"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Workload and execution-spec schema ==="

"$PYTHON" - \
  "$ROOT" \
  "$WORKLOADS" \
  "$SPECS" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
workloads_root = root / sys.argv[2]
specs_root = root / sys.argv[3]


def load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


records: list[dict[str, Any]] = []

for replication in range(10):
    workload_path = (
        workloads_root
        / f"membership_density_rep_{replication:03d}_canonical.json"
    )

    spec_path = (
        specs_root
        / f"membership_density_rep_{replication:03d}_canonical.json"
    )

    if not workload_path.is_file():
        raise SystemExit(f"Missing workload: {workload_path}")

    if not spec_path.is_file():
        raise SystemExit(f"Missing execution spec: {spec_path}")

    workload = load(workload_path)
    spec = load(spec_path)

    steps = workload.get("steps")

    if not isinstance(steps, list):
        raise SystemExit(
            f"Replication {replication} has no steps list."
        )

    records.append(
        {
            "replication": replication,
            "step_count": len(steps),
            "workload_path": workload_path,
            "spec_path": spec_path,
            "workload": workload,
            "spec": spec,
        }
    )

histogram: dict[int, int] = {}

for record in records:
    count = int(record["step_count"])
    histogram[count] = histogram.get(count, 0) + 1

print(
    "step_count_histogram="
    + json.dumps(histogram, sort_keys=True)
)

if histogram != {23: 2, 24: 8}:
    raise SystemExit(
        f"Unexpected workload histogram: {histogram}"
    )

sample_23 = next(
    record
    for record in records
    if record["step_count"] == 23
)

sample_24 = next(
    record
    for record in records
    if record["step_count"] == 24
)

print(
    f"sample_23_replication="
    f"{sample_23['replication']}"
)

print(
    f"sample_24_replication="
    f"{sample_24['replication']}"
)


def scalar_fields(
    value: Any,
    prefix: str = "$",
) -> list[tuple[str, Any]]:
    rows: list[tuple[str, Any]] = []

    if isinstance(value, dict):
        for key, child in value.items():
            current = f"{prefix}.{key}"

            if isinstance(
                child,
                (str, int, float, bool),
            ) or child is None:
                rows.append((current, child))
            else:
                rows.extend(
                    scalar_fields(child, current)
                )

    elif isinstance(value, list):
        for index, child in enumerate(value):
            current = f"{prefix}[{index}]"

            if isinstance(
                child,
                (str, int, float, bool),
            ) or child is None:
                rows.append((current, child))
            elif index < 2:
                rows.extend(
                    scalar_fields(child, current)
                )

    return rows


terms = (
    "path",
    "root",
    "dir",
    "output",
    "run",
    "workload",
    "campaign",
    "replication",
    "seed",
    "timing",
    "result",
    "manifest",
)


for label, record in (
    ("sample_23", sample_23),
    ("sample_24", sample_24),
):
    workload_path = record["workload_path"]
    spec_path = record["spec_path"]
    workload = record["workload"]
    spec = record["spec"]

    print()
    print(f"--- {label} ---")
    print(f"replication={record['replication']}")
    print(f"step_count={record['step_count']}")
    print(
        "workload_sha256="
        f"{sha256(workload_path)}"
    )
    print(
        "execution_spec_sha256="
        f"{sha256(spec_path)}"
    )
    print(
        "workload_top_level_keys="
        + ",".join(sorted(workload))
    )
    print(
        "execution_spec_top_level_keys="
        + ",".join(sorted(spec))
    )

    print("workload_relevant_scalars:")

    for field, value in scalar_fields(workload):
        if any(term in field.lower() for term in terms):
            print(
                f"{field}="
                f"{json.dumps(value, sort_keys=True)}"
            )

    print("execution_spec_relevant_scalars:")

    for field, value in scalar_fields(spec):
        if any(term in field.lower() for term in terms):
            print(
                f"{field}="
                f"{json.dumps(value, sort_keys=True)}"
            )

print()
print("all_replications:")

for record in records:
    print(
        f"replication={record['replication']} "
        f"step_count={record['step_count']} "
        f"workload_sha256="
        f"{sha256(record['workload_path'])} "
        f"execution_spec_sha256="
        f"{sha256(record['spec_path'])}"
    )

print()
print("timing_input_source_schema_audit=PASS")
PY

echo
echo "=== 3. Runner input contract ==="

"$PYTHON" "$RUNNER" --help

echo
echo "=== 4. Runner path-handling source excerpts ==="

"$PYTHON" - "$RUNNER" <<'PY'
from __future__ import annotations

import sys
from pathlib import Path

path = Path(sys.argv[1])
lines = path.read_text(
    encoding="utf-8"
).splitlines()

terms = (
    "execution_spec",
    "workload_path",
    "output_root",
    "output_dir",
    "run_root",
    "timing_root",
    "observations",
    "timing_report",
)

selected: set[int] = set()

for index, line in enumerate(lines):
    if any(term in line for term in terms):
        for context in range(
            max(0, index - 3),
            min(len(lines), index + 4),
        ):
            selected.add(context)

previous = -2

for index in sorted(selected):
    if index > previous + 1:
        print("...")

    print(f"{index + 1}:{lines[index]}")
    previous = index
PY

echo
echo "=== 5. Final state ==="

echo "membership_density_timing_input_schema_inspection=PASS"
echo "timing_input_materialization_performed=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "timing_execution_authorized=false"
echo "next_stage=materialize_membership_density_timing_inputs"

git status --short --branch
