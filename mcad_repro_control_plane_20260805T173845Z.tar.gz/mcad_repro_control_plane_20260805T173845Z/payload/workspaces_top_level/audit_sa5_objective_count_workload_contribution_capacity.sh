#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ec4f22ae01fd16a74c4207146e7fb35c8acef946"

CLASSIFICATION_ROOT="/workspaces/sa5_objective_count_v2_binding_candidate_classification_20260804T223518Z"

CLASSIFICATION_REPORT="$CLASSIFICATION_ROOT/sa5_objective_count_v2_binding_candidate_classification.json"
EXPECTED_CLASSIFICATION_REPORT_SHA="7cbd688bfe149b2a21d8306ccadb4534da890f3d2608725f2c74e540a05cff36"

CLASSIFICATION_SURFACE="$CLASSIFICATION_ROOT/sa5_objective_count_v2_binding_candidate_classification.txt"
EXPECTED_CLASSIFICATION_SURFACE_SHA="351e4542eefdf2bea80e987ee5e1e48c95ea1b8c4ab7986e2fe8f061f4cb2ef9"

PREREG="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_campaign_preregistration.json"
EXPECTED_PREREG_SHA="a92bb672c2c0ac61d3700ce49c9f3340ffe6b2f01f08b0f94dd354f96c8c8d5e"

AMENDMENT="reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_materialization_contract_amendment.json"
EXPECTED_AMENDMENT_SHA="2e0ff32570d9e427e753fdda5bc816996d2608778879c1c4c5568fc47bf088e1"

CKG_SOURCE="backend/ckg/ckg_updater.py"
STRUCTURAL_SOURCE="backend/harness/sensitivity_generator/structural_generator.py"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CANONICAL_CAMPAIGN_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution/campaigns/objective_count_stage10_c8_nv32"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"

OUTPUT_ROOT="/workspaces/sa5_objective_count_workload_contribution_capacity_${STAMP}"

REPORT="$OUTPUT_ROOT/sa5_objective_count_workload_contribution_capacity.json"
SURFACE="$OUTPUT_ROOT/sa5_objective_count_workload_contribution_capacity.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_contribution_capacity_probe.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 contribution-capacity audit stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

echo "=== 1. Exact read-only audit gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(
  git rev-parse "origin/$BASE"
)" = "$EXPECTED_HEAD"

for FILE in \
  "$CLASSIFICATION_REPORT" \
  "$CLASSIFICATION_SURFACE" \
  "$PREREG" \
  "$AMENDMENT" \
  "$CKG_SOURCE" \
  "$STRUCTURAL_SOURCE" \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT"
do
  test -f "$FILE"
done

test "$(
  sha256sum "$CLASSIFICATION_REPORT" |
    awk '{print $1}'
)" = "$EXPECTED_CLASSIFICATION_REPORT_SHA"

test "$(
  sha256sum "$CLASSIFICATION_SURFACE" |
    awk '{print $1}'
)" = "$EXPECTED_CLASSIFICATION_SURFACE_SHA"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

jq -e '
  .status
    == "sa5_objective_count_v2_binding_candidate_classification_resolved"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .final_scope.new_file_count == 9
  and .final_scope.modified_file_count == 8
  and .final_scope.total_patch_file_count == 17
  and .scope_complete == true
  and .next_stage
    == "author_sa5_objective_count_materialization_contract_v2_patch_with_17_file_scope"
' "$CLASSIFICATION_REPORT" >/dev/null

grep -F \
  'def _constraint_support(' \
  "$CKG_SOURCE" >/dev/null

grep -F \
  'return list(sorted(requirement_sets, key=lambda r: (len(r), r))[0])' \
  "$CKG_SOURCE" >/dev/null

grep -F \
  'contributive = bool(gained_resource_ids)' \
  "$CKG_SOURCE" >/dev/null

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "audit_gate=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "classified_patch_file_count=17"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"

echo
echo "=== 2. Validate preregistered arithmetic ==="

jq -e '
  .structural_control_contract.constraints_per_objective
    == 8
  and .structural_control_contract.virtual_nodes_per_objective
    == 32
  and .structural_control_contract.requirement_sets_per_constraint
    == 2
  and .structural_control_contract.requirement_set_membership_indices
    == [[0, 1], [1, 2]]
  and .structural_control_contract.useful_virtual_nodes_per_constraint
    == 3
  and .structural_control_contract.useful_virtual_nodes_per_objective
    == 24
  and .structural_control_contract.irrelevant_virtual_nodes_per_objective
    == 8
  and .structural_control_contract.useful_virtual_node_ratio
    == 0.75
  and .workload_noise_contract.workload_length
    == 40
  and .workload_noise_contract.non_contributive_query_count
    == 10
  and .workload_noise_contract.oracle_contributive_query_count
    == 30
  and .workload_noise_contract.requested_noise_ratio
    == 0.25
  and .authorization.canonical_campaign_materialization_authorized
    == false
  and .authorization.functional_execution_authorized
    == false
' "$AMENDMENT" >/dev/null

WORKLOAD_LENGTH="$(
  jq -r \
    '.workload_noise_contract.workload_length' \
    "$AMENDMENT"
)"

NON_CONTRIBUTIVE_COUNT="$(
  jq -r \
    '.workload_noise_contract.non_contributive_query_count' \
    "$AMENDMENT"
)"

ORACLE_CONTRIBUTIVE_COUNT="$(
  jq -r \
    '.workload_noise_contract.oracle_contributive_query_count' \
    "$AMENDMENT"
)"

test "$(
  (
    echo "$WORKLOAD_LENGTH"
    echo "$NON_CONTRIBUTIVE_COUNT"
  ) |
    awk 'NR == 1 {a=$1} NR == 2 {b=$1} END {print a-b}'
)" -eq "$ORACLE_CONTRIBUTIVE_COUNT"

echo "preregistered_arithmetic_gate=PASS"
echo "workload_length=$WORKLOAD_LENGTH"
echo "non_contributive_query_count=$NON_CONTRIBUTIVE_COUNT"
echo "oracle_contributive_query_count=$ORACLE_CONTRIBUTIVE_COUNT"

echo
echo "=== 3. Run detached evaluator-capacity probe ==="

rm -rf "$OUTPUT_ROOT"
mkdir -p "$OUTPUT_ROOT"

export ROOT
export EXPECTED_HEAD
export AMENDMENT
export CKG_SOURCE
export STRUCTURAL_SOURCE
export TMP_ROOT
export REPORT
export SURFACE

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import inspect
import json
import os
from pathlib import Path
from typing import Any

from backend.ckg.ckg_updater import CKGGraph
from backend.harness.sensitivity_generator.structural_generator import (
    StructuralConfig,
    build_objectives_document,
    write_yaml,
)


root = Path(os.environ["ROOT"]).resolve()
source_commit = os.environ["EXPECTED_HEAD"]

amendment_path = root / os.environ["AMENDMENT"]
ckg_source_path = root / os.environ["CKG_SOURCE"]
structural_source_path = (
    root / os.environ["STRUCTURAL_SOURCE"]
)

tmp_root = Path(os.environ["TMP_ROOT"])
report_path = Path(os.environ["REPORT"])
surface_path = Path(os.environ["SURFACE"])


def sha256_file(path: Path) -> str:
    return hashlib.sha256(
        path.read_bytes()
    ).hexdigest()


amendment = json.loads(
    amendment_path.read_text(encoding="utf-8")
)

structural = amendment[
    "structural_control_contract"
]

workload = amendment[
    "workload_noise_contract"
]

constraints_per_objective = int(
    structural["constraints_per_objective"]
)

virtual_nodes_per_objective = int(
    structural["virtual_nodes_per_objective"]
)

membership_indices = structural[
    "requirement_set_membership_indices"
]

useful_per_constraint = int(
    structural[
        "useful_virtual_nodes_per_constraint"
    ]
)

useful_per_objective = int(
    structural[
        "useful_virtual_nodes_per_objective"
    ]
)

workload_length = int(
    workload["workload_length"]
)

non_contributive_count = int(
    workload["non_contributive_query_count"]
)

required_contributive_count = int(
    workload["oracle_contributive_query_count"]
)

assert workload_length == 40
assert non_contributive_count == 10
assert required_contributive_count == 30

assert constraints_per_objective == 8
assert virtual_nodes_per_objective == 32
assert membership_indices == [
    [0, 1],
    [1, 2],
]
assert useful_per_constraint == 3
assert useful_per_objective == 24


objective_id = (
    "O_SA5_OBJECTIVE_COUNT_"
    "CONTRIBUTION_CAPACITY_PROBE"
)

document = build_objectives_document(
    StructuralConfig(
        objective_id=objective_id,
        n_constraints=constraints_per_objective,
        n_virtual_nodes=virtual_nodes_per_objective,
        seed=101,
        output_dir="<detached-not-written>",
    )
)

objectives = document.get("objectives")

assert isinstance(objectives, list)
assert len(objectives) == 1

objective = objectives[0]
constraints = objective.get("constraints")

assert isinstance(constraints, list)
assert len(constraints) == constraints_per_objective

declared_ids_by_constraint: dict[
    str,
    list[str],
] = {}

useful_union_by_constraint: dict[
    str,
    list[str],
] = {}

for constraint in constraints:
    constraint_id = str(constraint["id"])

    raw_nodes = constraint.get("virtual_nodes")

    assert isinstance(raw_nodes, list)
    assert len(raw_nodes) == 4

    declared_ids = [
        str(node["id"])
        for node in raw_nodes
    ]

    requirement_sets = [
        [
            declared_ids[index]
            for index in index_set
        ]
        for index_set in membership_indices
    ]

    constraint[
        "requirement_sets"
    ] = requirement_sets

    useful_union = sorted(
        {
            member
            for requirement_set in requirement_sets
            for member in requirement_set
        }
    )

    assert len(useful_union) == 3

    declared_ids_by_constraint[
        constraint_id
    ] = declared_ids

    useful_union_by_constraint[
        constraint_id
    ] = useful_union


objective_path = (
    tmp_root / "objectives.yaml"
)

write_yaml(
    objective_path,
    document,
)

ckg = CKGGraph(
    output_dir=str(
        tmp_root / "runtime"
    )
)

for attribute_name in (
    "G",
    "objectives",
    "history",
    "session_coverage",
    "session_weighted_coverage",
    "session_resource_coverage",
):
    value = getattr(ckg, attribute_name)
    value.clear()

ckg.bootstrap_objectives(
    str(objective_path)
)

assert set(ckg.objectives) == {
    objective_id
}

loaded_constraints = (
    ckg.objectives[
        objective_id
    ]["constraints"]
)

assert len(loaded_constraints) == 8


evaluator_support_by_constraint: dict[
    str,
    list[str],
] = {}

for constraint_id in sorted(
    loaded_constraints
):
    support = ckg._constraint_support(
        objective_id,
        constraint_id,
    )

    evaluator_support_by_constraint[
        constraint_id
    ] = list(support)

    assert len(support) == 2

    assert set(support).issubset(
        set(
            useful_union_by_constraint[
                constraint_id
            ]
        )
    )


useful_union_capacity = sum(
    len(values)
    for values
    in useful_union_by_constraint.values()
)

evaluator_support_capacity = sum(
    len(values)
    for values
    in evaluator_support_by_constraint.values()
)

assert useful_union_capacity == 24
assert evaluator_support_capacity == 16


session_id = (
    "S_SA5_CONTRIBUTION_CAPACITY_PROBE"
)

singleton_contributive_count = 0
singleton_observations: list[
    dict[str, Any]
] = []

for constraint_id in sorted(
    declared_ids_by_constraint
):
    for virtual_node_id in (
        declared_ids_by_constraint[
            constraint_id
        ]
    ):
        observation = (
            ckg.classify_constraint_states(
                session_id,
                objective_id,
                {virtual_node_id},
            )
        )

        is_contributive = bool(
            observation[
                "is_session_contributive"
            ]
        )

        if is_contributive:
            singleton_contributive_count += 1

        singleton_observations.append(
            {
                "constraint_id": constraint_id,
                "virtual_node_id": (
                    virtual_node_id
                ),
                "is_session_contributive": (
                    is_contributive
                ),
                "gained_resource_ids": (
                    observation[
                        "gained_resource_ids"
                    ]
                ),
            }
        )


assert singleton_contributive_count == 16

repeat_contributive_count = 0

for constraint_id in sorted(
    declared_ids_by_constraint
):
    for virtual_node_id in (
        declared_ids_by_constraint[
            constraint_id
        ]
    ):
        observation = (
            ckg.classify_constraint_states(
                session_id,
                objective_id,
                {virtual_node_id},
            )
        )

        if observation[
            "is_session_contributive"
        ]:
            repeat_contributive_count += 1

assert repeat_contributive_count == 0


useful_union_deficit = (
    required_contributive_count
    - useful_union_capacity
)

evaluator_support_deficit = (
    required_contributive_count
    - evaluator_support_capacity
)

assert useful_union_deficit == 6
assert evaluator_support_deficit == 14

blockers = [
    (
        "oracle_contributive_count_exceeds_"
        "useful_virtual_node_union_capacity"
    ),
    (
        "oracle_contributive_count_exceeds_"
        "evaluator_session_support_capacity"
    ),
    (
        "workload_materialization_contract_"
        "requires_semantic_amendment"
    ),
]

status = (
    "sa5_objective_count_workload_"
    "contribution_capacity_incompatible"
)

next_stage = (
    "preregister_sa5_objective_count_"
    "workload_contribution_capacity_amendment"
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-workload-"
        "contribution-capacity-audit-v1"
    ),
    "status": status,
    "source_commit": source_commit,
    "read_only": True,
    "test_only_semantic_probe": True,
    "source_hashes": {
        "amendment": sha256_file(
            amendment_path
        ),
        "ckg_updater": sha256_file(
            ckg_source_path
        ),
        "structural_generator": sha256_file(
            structural_source_path
        ),
    },
    "preregistered_contract": {
        "workload_length": workload_length,
        "non_contributive_query_count": (
            non_contributive_count
        ),
        "oracle_contributive_query_count": (
            required_contributive_count
        ),
        "constraints_per_objective": (
            constraints_per_objective
        ),
        "virtual_nodes_per_objective": (
            virtual_nodes_per_objective
        ),
        "useful_virtual_nodes_per_constraint": (
            useful_per_constraint
        ),
        "useful_virtual_nodes_per_objective": (
            useful_per_objective
        ),
        "requirement_set_membership_indices": (
            membership_indices
        ),
    },
    "capacity_proof": {
        "useful_union_capacity": (
            useful_union_capacity
        ),
        "useful_union_deficit": (
            useful_union_deficit
        ),
        "evaluator_support_selection_rule": (
            "shortest_requirement_set_then_"
            "lexicographic_tie_break"
        ),
        "evaluator_support_resources_per_constraint": 2,
        "evaluator_support_capacity": (
            evaluator_support_capacity
        ),
        "evaluator_support_deficit": (
            evaluator_support_deficit
        ),
        "observed_singleton_contributive_count": (
            singleton_contributive_count
        ),
        "observed_repeat_contributive_count": (
            repeat_contributive_count
        ),
        "maximum_contributive_step_count_under_"
        "current_session_resource_semantics": (
            evaluator_support_capacity
        ),
        "required_contributive_step_count": (
            required_contributive_count
        ),
        "contract_feasible_under_useful_union_semantics": (
            required_contributive_count
            <= useful_union_capacity
        ),
        "contract_feasible_under_current_evaluator_semantics": (
            required_contributive_count
            <= evaluator_support_capacity
        ),
    },
    "evaluator_support_by_constraint": (
        evaluator_support_by_constraint
    ),
    "useful_union_by_constraint": (
        useful_union_by_constraint
    ),
    "singleton_observations": (
        singleton_observations
    ),
    "blockers": blockers,
    "blocker_count": len(blockers),
    "v2_patch_authoring_authorized": False,
    "canonical_campaign_materialization_authorized": False,
    "canonical_campaign_generated": False,
    "campaign_materialization_performed": False,
    "functional_execution_performed": False,
    "timing_execution_performed": False,
    "bootstrap_execution_performed": False,
    "scientific_execution_performed": False,
    "manuscript_modified": False,
    "next_stage": next_stage,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

support_source = inspect.getsource(
    CKGGraph._constraint_support
)

classification_source = inspect.getsource(
    CKGGraph.classify_constraint_states
)

surface = [
    "SA5 OBJECTIVE-COUNT WORKLOAD CONTRIBUTION-CAPACITY AUDIT",
    "=" * 88,
    f"source_commit={source_commit}",
    f"status={status}",
    "",
    "=== PREREGISTERED WORKLOAD ===",
    f"workload_length={workload_length}",
    (
        "non_contributive_query_count="
        f"{non_contributive_count}"
    ),
    (
        "oracle_contributive_query_count="
        f"{required_contributive_count}"
    ),
    "",
    "=== STRUCTURAL CAPACITY ===",
    (
        "useful_union_capacity="
        f"{useful_union_capacity}"
    ),
    (
        "useful_union_deficit="
        f"{useful_union_deficit}"
    ),
    (
        "evaluator_support_resources_per_constraint=2"
    ),
    (
        "evaluator_support_capacity="
        f"{evaluator_support_capacity}"
    ),
    (
        "evaluator_support_deficit="
        f"{evaluator_support_deficit}"
    ),
    (
        "observed_singleton_contributive_count="
        f"{singleton_contributive_count}"
    ),
    (
        "observed_repeat_contributive_count="
        f"{repeat_contributive_count}"
    ),
    (
        "contract_feasible_under_useful_union_semantics=false"
    ),
    (
        "contract_feasible_under_current_evaluator_semantics=false"
    ),
    "",
    "=== EXACT EVALUATOR SUPPORT FUNCTION ===",
    support_source.rstrip(),
    "",
    "=== EXACT SESSION CONTRIBUTION FUNCTION ===",
    classification_source.rstrip(),
    "",
    "=== BLOCKERS ===",
    *[
        f"blocker={blocker}"
        for blocker in blockers
    ],
    "",
    "v2_patch_authoring_authorized=false",
    "canonical_campaign_materialization_authorized=false",
    "canonical_campaign_generated=false",
    "campaign_materialization_performed=false",
    "functional_execution_performed=false",
    "timing_execution_performed=false",
    "bootstrap_execution_performed=false",
    "scientific_execution_performed=false",
    "manuscript_modified=false",
    f"next_stage={next_stage}",
    "",
]

surface_path.write_text(
    "\n".join(surface),
    encoding="utf-8",
)

print("contribution_capacity_probe=PASS")
print(f"status={status}")
print(
    "useful_union_capacity="
    f"{useful_union_capacity}"
)
print(
    "required_contributive_count="
    f"{required_contributive_count}"
)
print(
    "useful_union_deficit="
    f"{useful_union_deficit}"
)
print(
    "evaluator_support_capacity="
    f"{evaluator_support_capacity}"
)
print(
    "evaluator_support_deficit="
    f"{evaluator_support_deficit}"
)
print(
    "observed_singleton_contributive_count="
    f"{singleton_contributive_count}"
)
print(
    "observed_repeat_contributive_count="
    f"{repeat_contributive_count}"
)
print(
    "v2_patch_authoring_authorized=false"
)
print(f"report={report_path}")
print(f"surface={surface_path}")
print(
    "report_sha256="
    f"{sha256_file(report_path)}"
)
print(
    "surface_sha256="
    f"{sha256_file(surface_path)}"
)
print(f"next_stage={next_stage}")
PY

echo
echo "=== 4. Validate incompatibility report ==="

test -s "$REPORT"
test -s "$SURFACE"

jq -e '
  .schema_version
    == "mcad-sa5-objective-count-workload-contribution-capacity-audit-v1"
  and .status
    == "sa5_objective_count_workload_contribution_capacity_incompatible"
  and .source_commit
    == "ec4f22ae01fd16a74c4207146e7fb35c8acef946"
  and .read_only == true
  and .test_only_semantic_probe == true
  and .preregistered_contract.workload_length == 40
  and .preregistered_contract.non_contributive_query_count == 10
  and .preregistered_contract.oracle_contributive_query_count == 30
  and .preregistered_contract.useful_virtual_nodes_per_objective == 24
  and .capacity_proof.useful_union_capacity == 24
  and .capacity_proof.useful_union_deficit == 6
  and .capacity_proof.evaluator_support_resources_per_constraint == 2
  and .capacity_proof.evaluator_support_capacity == 16
  and .capacity_proof.evaluator_support_deficit == 14
  and .capacity_proof.observed_singleton_contributive_count == 16
  and .capacity_proof.observed_repeat_contributive_count == 0
  and .capacity_proof.contract_feasible_under_useful_union_semantics == false
  and .capacity_proof.contract_feasible_under_current_evaluator_semantics == false
  and .blocker_count == 3
  and .v2_patch_authoring_authorized == false
  and .canonical_campaign_materialization_authorized == false
  and .canonical_campaign_generated == false
  and .campaign_materialization_performed == false
  and .functional_execution_performed == false
  and .scientific_execution_performed == false
  and .manuscript_modified == false
  and .next_stage
    == "preregister_sa5_objective_count_workload_contribution_capacity_amendment"
' "$REPORT" >/dev/null

echo "contribution_capacity_report_validation=PASS"

echo
echo "=== 5. Compact capacity decision ==="

jq '{
  status,
  source_commit,
  preregistered_contract,
  capacity_proof,
  blockers,
  blocker_count,
  v2_patch_authoring_authorized,
  next_stage
}' "$REPORT"

echo
echo "=== 6. High-value capacity surface ==="

grep -nE \
  '^(status=|workload_length=|non_contributive|oracle_contributive|useful_union|evaluator_support|observed_|contract_feasible|blocker=|v2_patch|next_stage=)' \
  "$SURFACE" |
  head -n 300 || true

echo
echo "=== 7. Repository and scientific immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$PREREG" |
    awk '{print $1}'
)" = "$EXPECTED_PREREG_SHA"

test "$(
  sha256sum "$AMENDMENT" |
    awk '{print $1}'
)" = "$EXPECTED_AMENDMENT_SHA"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test ! -e "$CANONICAL_CAMPAIGN_ROOT"

echo "repository_immutability_gate=PASS"
echo "repository_modified=false"
echo "canonical_campaign_generated=false"
echo "campaign_materialization_performed=false"
echo "functional_execution_performed=false"
echo "timing_execution_performed=false"
echo "bootstrap_execution_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo
echo "=== 8. Final state ==="

REPORT_SHA="$(
  sha256sum "$REPORT" |
    awk '{print $1}'
)"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

echo "sa5_objective_count_workload_contribution_capacity_audit=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "report=$REPORT"
echo "report_sha256=$REPORT_SHA"
echo "surface=$SURFACE"
echo "surface_sha256=$SURFACE_SHA"
echo "required_contributive_count=30"
echo "useful_union_capacity=24"
echo "evaluator_support_capacity=16"
echo "v2_patch_authoring_authorized=false"
echo "canonical_campaign_generated=false"
echo "scientific_execution_performed=false"
echo "next_stage=preregister_sa5_objective_count_workload_contribution_capacity_amendment"

git status --short --branch
