#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BRANCH="paper/execute-membership-density-timing-stage10-20260803T111214Z"
EXPECTED_HEAD="57912c7e6459f4ffc3a7d53c28dd44fd84f7b8ac"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="$ROOT/reports/article_experiments/sensitivity/e3_controlled_execution"

AUTH="$REPORTS/planning/sa4_membership_density_timing_execution_authorization.json"

RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

LOG_ROOT="/workspaces/membership_density_timing_stage10_logs_20260803T111214Z"
MALFORMED_JSONL="$LOG_ROOT/replication_results.jsonl"

LEDGER_JSON="$RUN_ROOT/stage10_execution_ledger.json"
LEDGER_MD="$RUN_ROOT/stage10_execution_ledger.md"

EXPECTED_AUTH_SHA="dc9010e319e238f1419e4fdb4d52cd184fc9470d346cef8833ef0355ff0c4be0"

trap 'echo "[ERROR] Ledger recovery stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Recovery gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$AUTH"
test -d "$RUN_ROOT"
test -d "$LOG_ROOT"
test -f "$MALFORMED_JSONL"

test ! -e "$LEDGER_JSON"
test ! -e "$LEDGER_MD"

test "$(
  sha256sum "$AUTH" | awk '{print $1}'
)" = "$EXPECTED_AUTH_SHA"

RESULT_COUNT="$(
  find "$LOG_ROOT" \
    -maxdepth 1 \
    -type f \
    -name 'replication_[0-9].result.json' \
    | wc -l
)"

LOG_COUNT="$(
  find "$LOG_ROOT" \
    -maxdepth 1 \
    -type f \
    -name 'replication_[0-9].log' \
    | wc -l
)"

OUTPUT_DIR_COUNT="$(
  find "$RUN_ROOT" \
    -mindepth 1 \
    -maxdepth 1 \
    -type d \
    -name 'membership_density_rep_*_portfolio_timing_stage10' \
    | wc -l
)"

test "$RESULT_COUNT" -eq 10
test "$LOG_COUNT" -eq 10
test "$OUTPUT_DIR_COUNT" -eq 10

echo "recovery_gate=PASS"
echo "existing_result_json_count=$RESULT_COUNT"
echo "existing_replication_log_count=$LOG_COUNT"
echo "existing_timing_output_directory_count=$OUTPUT_DIR_COUNT"
echo "timing_reexecution_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Recover ledger from complete result files ==="

"$PYTHON" - \
  "$LOG_ROOT" \
  "$AUTH" \
  "$LEDGER_JSON" \
  "$LEDGER_MD" \
  "$BRANCH" \
  "$EXPECTED_HEAD" \
  "$MALFORMED_JSONL" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

log_root = Path(sys.argv[1]).resolve()
authorization_path = Path(sys.argv[2]).resolve()
ledger_json = Path(sys.argv[3]).resolve()
ledger_md = Path(sys.argv[4]).resolve()
branch = sys.argv[5]
source_commit = sys.argv[6]
malformed_jsonl = Path(sys.argv[7]).resolve()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


results: list[dict[str, Any]] = []

for replication in range(10):
    result_path = (
        log_root
        / f"replication_{replication}.result.json"
    )

    if not result_path.is_file():
        raise SystemExit(
            f"Missing replication result: {result_path}"
        )

    result = load_object(result_path)

    expected = {
        "replication_index": replication,
        "runner_exit_status": 0,
        "raw_timing_cell_count": 92,
        "warmup_observation_count": 920,
        "measurement_observation_count": 9200,
        "total_observation_count": 10120,
        "balanced_cell_counts": True,
        "functional_semantic_match": True,
    }

    for field, expected_value in expected.items():
        actual = result.get(field)

        if actual != expected_value:
            raise SystemExit(
                f"Replication {replication}: "
                f"{field} expected={expected_value!r}, "
                f"actual={actual!r}"
            )

    if result.get("order_seed") != 20260728 + replication:
        raise SystemExit(
            f"Replication {replication}: order-seed mismatch."
        )

    if result.get("density_levels") != [25, 50, 75, 100]:
        raise SystemExit(
            f"Replication {replication}: density levels differ."
        )

    if result.get("step_indexes") != list(range(1, 24)):
        raise SystemExit(
            f"Replication {replication}: step indexes differ."
        )

    files = result.get("files")

    if not isinstance(files, dict) or len(files) != 4:
        raise SystemExit(
            f"Replication {replication}: invalid output-file map."
        )

    for name, declaration in files.items():
        path = Path(declaration["path"])

        if not path.is_file():
            raise SystemExit(
                f"Replication {replication}: missing {name}: {path}"
            )

        actual_sha = sha256(path)

        if actual_sha != declaration["sha256"]:
            raise SystemExit(
                f"Replication {replication}: "
                f"SHA mismatch for {name}."
            )

    log_declaration = result.get("log", {})
    log_path = Path(log_declaration["path"])

    if not log_path.is_file():
        raise SystemExit(
            f"Replication {replication}: missing log."
        )

    if sha256(log_path) != log_declaration["sha256"]:
        raise SystemExit(
            f"Replication {replication}: log SHA mismatch."
        )

    results.append(result)

warmup_count = sum(
    result["warmup_observation_count"]
    for result in results
)

measurement_count = sum(
    result["measurement_observation_count"]
    for result in results
)

total_count = sum(
    result["total_observation_count"]
    for result in results
)

raw_cell_count = sum(
    result["raw_timing_cell_count"]
    for result in results
)

if warmup_count != 9200:
    raise SystemExit(
        f"Unexpected warmup total: {warmup_count}"
    )

if measurement_count != 92000:
    raise SystemExit(
        f"Unexpected measurement total: {measurement_count}"
    )

if total_count != 101200:
    raise SystemExit(
        f"Unexpected observation total: {total_count}"
    )

if raw_cell_count != 920:
    raise SystemExit(
        f"Unexpected timing-cell total: {raw_cell_count}"
    )

started_utc = min(
    result["started_utc"]
    for result in results
)

completed_utc = max(
    result["completed_utc"]
    for result in results
)

ledger = {
    "schema_version": (
        "mcad-sa4-membership-density-"
        "stage10-timing-execution-ledger-v1"
    ),
    "status": (
        "membership_density_stage10_"
        "timing_execution_complete"
    ),
    "execution_branch": branch,
    "source_commit": source_commit,
    "started_utc": started_utc,
    "completed_utc": completed_utc,
    "authorization": {
        "path": str(authorization_path),
        "sha256": sha256(authorization_path),
    },
    "execution_contract": {
        "replication_count": 10,
        "execution_order": list(range(10)),
        "maximum_parallel_replications": 1,
        "density_levels": [25, 50, 75, 100],
        "step_indexes": list(range(1, 24)),
        "warmups_per_raw_cell": 10,
        "measurements_per_raw_cell": 100,
        "reuse_successful": True,
        "stop_on_first_failure": True,
    },
    "execution_totals": {
        "successful_replication_count": 10,
        "failed_replication_count": 0,
        "raw_timing_cell_count": raw_cell_count,
        "warmup_observation_count": warmup_count,
        "measurement_observation_count": measurement_count,
        "total_observation_count": total_count,
    },
    "replications": results,
    "external_log_root": str(log_root),
    "ledger_recovery": {
        "required": True,
        "reason": (
            "The original ledger builder treated each line "
            "of pretty-printed JSON as a complete JSON object."
        ),
        "malformed_jsonl_preserved": True,
        "malformed_jsonl_path": str(malformed_jsonl),
        "malformed_jsonl_sha256": sha256(malformed_jsonl),
        "individual_result_json_count": 10,
        "timing_reexecution_performed": False,
        "measurement_rows_reused": True,
    },
    "scientific_controls": {
        "functional_execution_rerun_performed": False,
        "timing_execution_authorized": True,
        "timing_execution_performed": True,
        "precision_analysis_authorized": False,
        "precision_analysis_performed": False,
        "stage20_execution_authorized": False,
        "latency_claim_authorized": False,
        "scientific_freeze": False,
        "global_scientific_freeze": False,
        "manuscript_resume_authorized": False,
    },
    "next_stage": (
        "audit_membership_density_timing_stage10_outputs"
    ),
}

ledger_json.write_text(
    json.dumps(ledger, indent=2, sort_keys=True) + "\n",
    encoding="utf-8",
)

ledger_md.write_text(
    "\n".join([
        "# SA4 membership-density Stage-10 timing execution",
        "",
        "- Status: `PASS`",
        "- Successful replications: `10/10`",
        "- Failed replications: `0`",
        "- Maximum parallel replications: `1`",
        "- Raw timing cells: `920`",
        "- Warmup observations: `9,200`",
        "- Measurement observations: `92,000`",
        "- Total observations: `101,200`",
        "- Timing re-execution during ledger recovery: `false`",
        "- Precision analysis performed: `false`",
        "- Latency claims authorized: `false`",
        "",
        "## Ledger recovery",
        "",
        (
            "The ten successful replication result JSON files "
            "were reused after the original JSONL parser failed. "
            "No runner process or measurement was repeated."
        ),
        "",
        "## Next stage",
        "",
        "`audit_membership_density_timing_stage10_outputs`",
        "",
    ]),
    encoding="utf-8",
)

print("stage10_execution_ledger_recovery=PASS")
print("successful_replication_count=10")
print("failed_replication_count=0")
print("raw_timing_cell_count=920")
print("warmup_observation_count=9200")
print("measurement_observation_count=92000")
print("total_observation_count=101200")
print("timing_reexecution_performed=false")
print("precision_analysis_performed=false")
print(
    "next_stage="
    "audit_membership_density_timing_stage10_outputs"
)
PY

echo
echo "=== 3. Validate recovered ledger ==="

test -f "$LEDGER_JSON"
test -f "$LEDGER_MD"

jq -e '
  .status
    == "membership_density_stage10_timing_execution_complete"
  and .execution_totals.successful_replication_count == 10
  and .execution_totals.failed_replication_count == 0
  and .execution_totals.raw_timing_cell_count == 920
  and .execution_totals.warmup_observation_count == 9200
  and .execution_totals.measurement_observation_count == 92000
  and .execution_totals.total_observation_count == 101200
  and (.replications | length) == 10
  and ([.replications[].replication_index])
      == [range(0; 10)]
  and ([.replications[].runner_exit_status] | unique) == [0]
  and ([.replications[].balanced_cell_counts] | unique) == [true]
  and .ledger_recovery.required == true
  and .ledger_recovery.individual_result_json_count == 10
  and .ledger_recovery.timing_reexecution_performed == false
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.precision_analysis_authorized == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.latency_claim_authorized == false
  and .next_stage
      == "audit_membership_density_timing_stage10_outputs"
' "$LEDGER_JSON" >/dev/null

LEDGER_SHA="$(
  sha256sum "$LEDGER_JSON" | awk '{print $1}'
)"

echo "recovered_execution_ledger_validation=PASS"
echo "execution_ledger_sha256=$LEDGER_SHA"

echo
echo "=== 4. Final state ==="

echo "membership_density_stage10_timing_execution=PASS"
echo "successful_replication_count=10"
echo "failed_replication_count=0"
echo "raw_timing_cell_count=920"
echo "warmup_observation_count=9200"
echo "measurement_observation_count=92000"
echo "total_observation_count=101200"
echo "timing_execution_performed=true"
echo "timing_reexecution_performed=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "next_stage=audit_membership_density_timing_stage10_outputs"

git status --short --branch
