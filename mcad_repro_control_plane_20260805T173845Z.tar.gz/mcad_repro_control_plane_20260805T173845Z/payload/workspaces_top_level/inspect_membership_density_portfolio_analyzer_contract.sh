#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="6d244ec318cf3986900b3220924050974b141cd1"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

REPORTS="reports/article_experiments/sensitivity/e3_controlled_execution"

ANALYZER="backend/harness/sensitivity_execution/analyze_clustered_timing_precision_v2.py"

PREREG="$REPORTS/planning/sa4_membership_density_portfolio_timing_preregistration.json"

AUDIT="$REPORTS/audits/membership_density/timing_stage10/stage10_output_audit.json"

RUN_ROOT="$REPORTS/timing_runs/membership_density_stage10_portfolio"

EXPECTED_ANALYZER_SHA="8e1e58cf4eb85d8b4c6b3b8c9a9f5bca69e871d6b15a1098da2f8fcc3f50a504"

trap 'echo "[ERROR] Analyzer inspection stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Read-only inspection gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$ANALYZER"
test -f "$PREREG"
test -f "$AUDIT"
test -d "$RUN_ROOT"

test "$(
  sha256sum "$ANALYZER" | awk '{print $1}'
)" = "$EXPECTED_ANALYZER_SHA"

CSV_COUNT="$(
  find "$RUN_ROOT" \
    -mindepth 2 \
    -maxdepth 2 \
    -type f \
    -name 'timing_observations.csv' |
    wc -l
)"

test "$CSV_COUNT" -eq 10

echo "inspection_gate=PASS"
echo "analyzer_sha256=$EXPECTED_ANALYZER_SHA"
echo "canonical_timing_csv_count=$CSV_COUNT"
echo "adapter_materialization_performed=false"
echo "precision_analysis_performed=false"

echo
echo "=== 2. Analyzer command-line contract ==="

PYTHONPATH="$ROOT" \
"$PYTHON" "$ANALYZER" --help

echo
echo "=== 3. Inspect source CSV schemas ==="

"$PYTHON" - \
  "$ROOT" \
  "$RUN_ROOT" <<'PY'
from __future__ import annotations

import csv
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
run_root = (root / sys.argv[2]).resolve()

csv_paths = sorted(
    run_root.glob(
        "membership_density_rep_*_portfolio_timing_stage10/"
        "timing_observations.csv"
    )
)

if len(csv_paths) != 10:
    raise SystemExit(
        f"Expected ten timing CSVs, got {len(csv_paths)}."
    )

reference_header: list[str] | None = None

for replication, path in enumerate(csv_paths):
    with path.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as handle:
        reader = csv.reader(handle)
        header = next(reader)

    if reference_header is None:
        reference_header = header
    elif header != reference_header:
        raise SystemExit(
            f"Replication {replication}: CSV header differs."
        )

assert reference_header is not None

print("timing_csv_schema_gate=PASS")
print(f"timing_csv_column_count={len(reference_header)}")
print("timing_csv_columns=")

for index, column in enumerate(reference_header):
    print(f"  {index:02d}: {column}")
PY

echo
echo "=== 4. Inspect preregistered adapter contract ==="

"$PYTHON" - \
  "$PREREG" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Iterator

path = Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))

if not isinstance(payload, dict):
    raise SystemExit("Preregistration must be a JSON object.")


def walk(
    value: Any,
    prefix: str = "$",
) -> Iterator[tuple[str, Any]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from walk(child, f"{prefix}.{key}")

    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from walk(child, f"{prefix}[{index}]")

    else:
        yield prefix, value


keywords = {
    "adapter",
    "analyzer",
    "bootstrap",
    "cluster",
    "confidence",
    "density",
    "level",
    "measurement",
    "portfolio",
    "provenance",
    "relative",
    "rhw",
    "seed",
    "step",
    "synthetic",
    "target",
}

selected = [
    (field, value)
    for field, value in walk(payload)
    if any(
        keyword in field.lower()
        for keyword in keywords
    )
]

print("preregistration_contract_fields=")

for field, value in selected:
    rendered = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
    )
    print(f"{field}={rendered}")

print("preregistration_contract_inspection=PASS")
PY

echo
echo "=== 5. Inspect analyzer implementation contexts ==="

"$PYTHON" - \
  "$ANALYZER" <<'PY'
from __future__ import annotations

import ast
import sys
from pathlib import Path

path = Path(sys.argv[1])
source = path.read_text(encoding="utf-8")
lines = source.splitlines()

tree = ast.parse(source)

function_names = sorted({
    node.name
    for node in ast.walk(tree)
    if isinstance(
        node,
        (ast.FunctionDef, ast.AsyncFunctionDef),
    )
})

print("analyzer_function_count=", len(function_names))
print("analyzer_functions=")

for name in function_names:
    print(f"  {name}")

keywords = [
    "parse_integer_sequence",
    "factor_level",
    "step_index",
    "structural_seed",
    "measurement_observation_count",
    "cell_count",
    "bootstrap",
    "relative_half_width",
    "median_relative_half_width",
    "p95_relative_half_width",
    "confidence",
    "output_dir",
    "timing_observations",
]

occurrences: list[tuple[int, str]] = []

for number, line in enumerate(lines, start=1):
    if any(keyword in line for keyword in keywords):
        occurrences.append((number, line))

print()
print("analyzer_relevant_source_lines=")

for number, line in occurrences:
    print(f"{number}:{line}")

print()
print("analyzer_relevant_source_contexts=")

context_centers = sorted({
    number
    for number, _ in occurrences
})

emitted: set[int] = set()

for center in context_centers:
    start = max(1, center - 3)
    end = min(len(lines), center + 3)

    for number in range(start, end + 1):
        if number not in emitted:
            print(f"{number}:{lines[number - 1]}")
            emitted.add(number)

    print("...")

print("analyzer_source_contract_inspection=PASS")
PY

echo
echo "=== 6. Verify expected portfolio dimensions ==="

jq -e '
  .status
    == "membership_density_stage10_output_audit_complete"
  and .execution_results.successful_replication_count == 10
  and .execution_results.measurement_observation_count == 92000
  and .execution_results.raw_timing_cell_count == 920
  and .audit_decision.stage10_timing_execution_accepted == true
  and .scientific_controls.precision_analysis_performed == false
  and .next_stage
      == "prepare_membership_density_portfolio_analysis_adapter"
' "$AUDIT" >/dev/null

echo "source_replication_count=10"
echo "source_density_level_count=4"
echo "source_step_count_per_replication=23"
echo "source_raw_cell_count=920"
echo "source_measurement_observation_count=92000"

echo "proposed_analyzer_step_index=0"
echo "proposed_analyzer_cell_count=40"
echo "proposed_measurements_per_cluster=2300"
echo "proposed_inferential_density_cell_count=4"

echo
echo "=== 7. Final read-only state ==="

test -z "$(git status --porcelain)"

echo "membership_density_portfolio_analyzer_contract_inspection=PASS"
echo "source_files_modified=false"
echo "adapter_artifact_created=false"
echo "precision_analysis_authorized=false"
echo "precision_analysis_performed=false"
echo "latency_claim_authorized=false"
echo "next_stage=design_membership_density_portfolio_analysis_adapter"

git status --short --branch
