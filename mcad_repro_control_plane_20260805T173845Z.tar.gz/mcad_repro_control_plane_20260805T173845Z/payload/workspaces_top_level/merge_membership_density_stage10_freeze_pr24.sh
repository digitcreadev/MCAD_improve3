#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=24

BASE="paper/phase3-controlled-execution"
BRANCH="paper/freeze-membership-density-stage10-20260804T161119Z"

EXPECTED_HEAD="3d288a5560d32b5985b77416c6f32a1a45584050"
EXPECTED_BASE_HEAD="39da63c63a3062a79460377280758771d934c9b4"

PACKAGE="experiments/article/frozen_campaigns/sa4_membership_density_stage10"
REGISTRY="experiments/article/frozen_campaigns/REGISTRY.yaml"

ARCHIVE_NAME="membership_density_stage10_canonical_20260804T161119Z.tar.gz"
ARCHIVE="$PACKAGE/archive/$ARCHIVE_NAME"
ARCHIVE_SHA_FILE="$PACKAGE/archive/$ARCHIVE_NAME.sha256"

EXPECTED_ARCHIVE_SHA="1729d7913e68407f754804c9d23468559e0eeefbf616e8f7ecc6be5fab940ffc"
EXPECTED_ARCHIVE_SIZE=9004737
EXPECTED_PAYLOAD_FILE_COUNT=149
EXPECTED_PACKAGE_FILE_COUNT=10

trap 'echo "[ERROR] PR #24 merge stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Local frozen-package gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -d "$PACKAGE"
test -f "$REGISTRY"
test -f "$ARCHIVE"
test -f "$ARCHIVE_SHA_FILE"

PACKAGE_FILE_COUNT="$(
  find "$PACKAGE" -type f | wc -l
)"

test "$PACKAGE_FILE_COUNT" -eq "$EXPECTED_PACKAGE_FILE_COUNT"

test "$(stat -c '%s' "$ARCHIVE")" \
  -eq "$EXPECTED_ARCHIVE_SIZE"

test "$(sha256sum "$ARCHIVE" | awk '{print $1}')" \
  = "$EXPECTED_ARCHIVE_SHA"

(
  cd "$PACKAGE"
  sha256sum -c SHA256SUMS
)

jq -e \
  --arg source_commit "$EXPECTED_BASE_HEAD" \
  --arg archive_sha "$EXPECTED_ARCHIVE_SHA" \
  '
    .campaign_id == "sa4_membership_density_stage10"
    and .status == "completed_precision_targets_met"
    and .factor == "membership_density"
    and .stage == 10
    and .source_commit == $source_commit
    and .run_count == 10
    and .measurement_observation_count == 92000
    and .successful_bootstrap_execution_count == 1
    and .bootstrap_repetitions == 10000
    and .bootstrap_seed == 20260728
    and .all_precision_targets_met == true
    and .failing_cell_count == 0
    and .stage10_sufficient == true
    and .stage20_extension_required == false
    and .stage20_execution_authorized == false
    and .scientific_freeze == true
    and .latency_claim_authorized == true
    and .manuscript_resume_authorized == true
    and .global_scientific_freeze == false
  ' "$PACKAGE/STATUS.json" >/dev/null

jq -e \
  --arg source_commit "$EXPECTED_BASE_HEAD" \
  --arg archive_sha "$EXPECTED_ARCHIVE_SHA" \
  '
    .campaign_id == "sa4_membership_density_stage10"
    and .freeze_status == "frozen"
    and .factor == "membership_density"
    and .stage == 10
    and .source_commit == $source_commit
    and .canonical_archive.sha256 == $archive_sha
    and .scientific_decision.successful_bootstrap_execution_count == 1
    and .scientific_decision.all_median_targets_met == true
    and .scientific_decision.all_p95_targets_met == true
    and .scientific_decision.all_precision_targets_met == true
    and .scientific_decision.failing_cell_count == 0
    and .scientific_decision.stage10_sufficient == true
    and .scientific_decision.stage20_extension_required == false
    and .scientific_decision.stage20_execution_authorized == false
    and .immutability.canonical_timing_rerun_allowed == false
    and .immutability.canonical_adapter_rematerialization_allowed == false
    and .immutability.canonical_bootstrap_rerun_allowed == false
    and .immutability.canonical_evidence_modification_allowed == false
    and .publication_controls.scientific_freeze == true
    and .publication_controls.latency_claim_authorized == true
    and .publication_controls.manuscript_resume_authorized == true
    and .publication_controls.global_scientific_freeze == false
  ' "$PACKAGE/freeze/FREEZE.json" >/dev/null

jq -e \
  --arg archive_sha "$EXPECTED_ARCHIVE_SHA" \
  --argjson archive_size "$EXPECTED_ARCHIVE_SIZE" \
  --argjson payload_count "$EXPECTED_PAYLOAD_FILE_COUNT" \
  '
    .campaign_id == "sa4_membership_density_stage10"
    and .source_repository == "digitcreadev/MCAD_improve3"
    and .canonical_archive.sha256 == $archive_sha
    and .canonical_archive.size_bytes == $archive_size
    and .canonical_archive.payload_file_count == $payload_count
    and .canonical_archive.deterministic_tar_metadata == true
    and .canonical_archive.gzip_timestamp_suppressed == true
    and .raw_analyzer_interpretation.raw_factor_label
        == "constraint_count"
    and .raw_analyzer_interpretation.raw_factor_label_authoritative
        == false
    and .raw_analyzer_interpretation.raw_next_stage_authoritative
        == false
    and .raw_analyzer_interpretation.canonical_factor
        == "membership_density"
  ' "$PACKAGE/PROVENANCE.json" >/dev/null

grep -Eq \
  '^[[:space:]]{2}sa4_membership_density_stage10:[[:space:]]*$' \
  "$REGISTRY"

grep -F \
  "    canonical_archive_sha256: $EXPECTED_ARCHIVE_SHA" \
  "$REGISTRY" >/dev/null

grep -F \
  "    canonical_archive_size_bytes: $EXPECTED_ARCHIVE_SIZE" \
  "$REGISTRY" >/dev/null

grep -F \
  "    scientific_freeze: true" \
  "$REGISTRY" >/dev/null

grep -F \
  "    latency_claim_authorized: true" \
  "$REGISTRY" >/dev/null

CHANGED_FILES="$(
  git diff --name-only "$EXPECTED_BASE_HEAD..$EXPECTED_HEAD"
)"

CHANGED_FILE_COUNT="$(
  printf '%s\n' "$CHANGED_FILES" |
    sed '/^$/d' |
    wc -l
)"

test "$CHANGED_FILE_COUNT" -eq 11

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    grep -Fx "$REGISTRY" |
    wc -l
)" -eq 1

test "$(
  printf '%s\n' "$CHANGED_FILES" |
    grep -E "^${PACKAGE}/" |
    wc -l
)" -eq 10

echo "local_freeze_gate=PASS"
echo "changed_file_count=$CHANGED_FILE_COUNT"
echo "package_file_count=$PACKAGE_FILE_COUNT"
echo "canonical_payload_file_count=$EXPECTED_PAYLOAD_FILE_COUNT"
echo "canonical_archive_size_bytes=$EXPECTED_ARCHIVE_SIZE"
echo "canonical_archive_sha256=$EXPECTED_ARCHIVE_SHA"
echo "canonical_bootstrap_rerun_performed=false"

echo
echo "=== 2. PR identity gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json state,headRefOid,headRefName,baseRefName,isDraft
)"

jq -e \
  --arg head "$EXPECTED_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .isDraft == false
  ' <<<"$PR_DATA" >/dev/null

echo "pr_identity_gate=PASS"

echo
echo "=== 3. CI gate ==="

CHECKS="$(
  gh pr checks "$PR" \
    --repo "$REPO" \
    --json bucket,name,state,link \
    2>/dev/null || true
)"

if ! jq -e 'type == "array"' >/dev/null 2>&1 <<<"$CHECKS"; then
  CHECKS='[]'
fi

CHECK_COUNT="$(jq 'length' <<<"$CHECKS")"

echo "check_count=$CHECK_COUNT"

if [ "$CHECK_COUNT" -gt 0 ]; then
  gh pr checks "$PR" \
    --repo "$REPO" \
    --watch \
    --interval 10

  FINAL_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link
  )"

  NON_PASS_COUNT="$(
    jq '[.[] | select(.bucket != "pass")] | length' \
      <<<"$FINAL_CHECKS"
  )"

  test "$NON_PASS_COUNT" -eq 0

  echo "membership_density_freeze_ci=PASS"
else
  echo "membership_density_freeze_ci=NOT_APPLICABLE"
fi

echo
echo "=== 4. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]; then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "merge_gate=PASS"

echo
echo "=== 5. Merge PR #24 ==="

gh pr merge "$PR" \
  --repo "$REPO" \
  --merge \
  --delete-branch

echo "merge_command=PASS"

echo
echo "=== 6. Update base branch ==="

git fetch origin --prune
git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull --ff-only origin "$BASE"

BASE_HEAD="$(git rev-parse HEAD)"

git merge-base --is-ancestor \
  "$EXPECTED_HEAD" \
  "$BASE_HEAD"

echo "freeze_commit_is_ancestor=PASS"
echo "base_head=$BASE_HEAD"

echo
echo "=== 7. Verify merged scientific freeze ==="

test -d "$PACKAGE"
test -f "$ARCHIVE"
test -f "$REGISTRY"

test "$(stat -c '%s' "$ARCHIVE")" \
  -eq "$EXPECTED_ARCHIVE_SIZE"

test "$(sha256sum "$ARCHIVE" | awk '{print $1}')" \
  = "$EXPECTED_ARCHIVE_SHA"

(
  cd "$PACKAGE"
  sha256sum -c SHA256SUMS
)

jq -e '
  .status == "completed_precision_targets_met"
  and .factor == "membership_density"
  and .successful_bootstrap_execution_count == 1
  and .all_precision_targets_met == true
  and .failing_cell_count == 0
  and .stage10_sufficient == true
  and .stage20_extension_required == false
  and .stage20_execution_authorized == false
  and .scientific_freeze == true
  and .latency_claim_authorized == true
  and .manuscript_resume_authorized == true
  and .global_scientific_freeze == false
' "$PACKAGE/STATUS.json" >/dev/null

VALIDATION_ROOT="$(
  mktemp -d \
    /workspaces/membership_density_stage10_archive_validation.XXXXXX
)"

trap 'rm -rf "$VALIDATION_ROOT"' EXIT

tar -xzf "$ARCHIVE" -C "$VALIDATION_ROOT"

test "$(
  jq -r '.file_count' \
    "$VALIDATION_ROOT/PAYLOAD_MANIFEST.json"
)" -eq "$EXPECTED_PAYLOAD_FILE_COUNT"

(
  cd "$VALIDATION_ROOT"
  sha256sum -c PAYLOAD_SHA256SUMS >/dev/null
)

echo "merged_archive_payload_validation=PASS"
echo "validated_payload_file_count=$EXPECTED_PAYLOAD_FILE_COUNT"

echo
echo "=== 8. Cleanup local branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch -d "$BRANCH"
fi

echo
echo "=== 9. Final state ==="

gh pr view "$PR" \
  --repo "$REPO" \
  --json state,mergedAt,mergeCommit \
  --jq '{
    state,
    mergedAt,
    mergeCommit: .mergeCommit.oid
  }'

test -z "$(git status --porcelain)"

echo "membership_density_stage10_freeze_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "canonical_archive_sha256=$EXPECTED_ARCHIVE_SHA"
echo "canonical_archive_size_bytes=$EXPECTED_ARCHIVE_SIZE"
echo "canonical_payload_file_count=$EXPECTED_PAYLOAD_FILE_COUNT"
echo "successful_bootstrap_execution_count=1"
echo "all_precision_targets_met=true"
echo "failing_cell_count=0"
echo "stage10_sufficient=true"
echo "stage20_extension_required=false"
echo "stage20_execution_authorized=false"
echo "scientific_freeze=true"
echo "latency_claim_authorized=true"
echo "manuscript_resume_authorized=true"
echo "global_scientific_freeze=false"
echo "canonical_bootstrap_rerun_performed=false"
echo "next_stage=integrate_membership_density_stage10_results_into_manuscript"

git status --short --branch
git log --oneline --decorate -5
