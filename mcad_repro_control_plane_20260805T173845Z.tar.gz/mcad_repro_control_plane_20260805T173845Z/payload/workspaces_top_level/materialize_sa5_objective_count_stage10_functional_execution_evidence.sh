#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="809ec874ca1bc6d4ad3c37b022d75dced7da5e98"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

RUN_ROOT="$E3/runs"
SPEC_MANIFEST="$E3/execution_specs/objective_count_stage10_execution_spec_manifest.json"
EXPECTED_SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

CAMPAIGN_HASHES="$E3/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_HASHES_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

AUTH_ROOT="/workspaces/sa5_objective_count_stage10_functional_execution_authorization_20260805T133627Z"
AUTH_REPORT="$AUTH_ROOT/sa5_objective_count_stage10_functional_execution_authorization.json"
EXPECTED_AUTH_REPORT_SHA="e21998b445f199253894aa40dbfeb4508c1cd6e64b7002ce1c438bbe05e7cb04"
AUTH_SURFACE="$AUTH_ROOT/sa5_objective_count_stage10_functional_execution_authorization.txt"
EXPECTED_AUTH_SURFACE_SHA="5defd8ff1c5107d6b257343f8e05336644cfb58f943190d85eff34bcc78ea0a7"

EXEC_ROOT="/workspaces/sa5_objective_count_stage10_functional_execution_20260805T134741Z"
EXEC_LEDGER="$EXEC_ROOT/sa5_objective_count_stage10_functional_execution_ledger.json"
EXPECTED_EXEC_LEDGER_SHA="6432e399be10798362a27d00ca55208909c85d9a538de0c53c89b8f7c90d85e0"
EXEC_SURFACE="$EXEC_ROOT/sa5_objective_count_stage10_functional_execution_ledger.txt"
EXPECTED_EXEC_SURFACE_SHA="3db78e3df9c4bff3c33e88a9845d1ae7c4e2a4d08b243a7bf37c2d1a8739199b"
EXEC_LOG_ROOT="$EXEC_ROOT/logs"

POST_ROOT="/workspaces/sa5_objective_count_stage10_post_functional_execution_20260805T135604Z"
POST_REPORT="$POST_ROOT/sa5_objective_count_stage10_post_functional_execution_audit.json"
EXPECTED_POST_REPORT_SHA="f53ed50765ed41fc253de969a7a5f8858b6627bab774bd3add013d5177872647"
POST_SURFACE="$POST_ROOT/sa5_objective_count_stage10_post_functional_execution_audit.txt"
EXPECTED_POST_SURFACE_SHA="5c4e2493d673efadc523552976a887cf55864b0d807fad8ad1b499e5904606cb"
SOURCE_RUN_MANIFEST="$POST_ROOT/canonical_functional_run_file_manifest.sha256"
EXPECTED_SOURCE_RUN_MANIFEST_SHA="10f2795a20c27c7ba2222636eee8d0800709e12f3fe290138bf4e31c29db6bf1"

EVIDENCE_ROOT="$E3/audits/$CAMPAIGN_ID/functional_execution"
AUTH_EVIDENCE_DIR="$EVIDENCE_ROOT/source_authorization"
EXEC_EVIDENCE_DIR="$EVIDENCE_ROOT/source_execution"
POST_EVIDENCE_DIR="$EVIDENCE_ROOT/source_post_execution"
CANONICAL_LOG_DIR="$EXEC_EVIDENCE_DIR/logs"

EVIDENCE_MANIFEST="$EVIDENCE_ROOT/functional_execution_evidence_manifest.json"

PLANNING_ROOT="$E3/planning"
MATERIALIZATION_REPORT="$PLANNING_ROOT/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.json"
MATERIALIZATION_SUMMARY="$PLANNING_ROOT/sa5_objective_count_stage10_functional_execution_evidence_materialization_report.md"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BRANCH="paper/materialize-sa5-objective-count-stage10-functional-evidence-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_functional_evidence_materialization.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 functional-evidence materialization stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Exact post-execution audit gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha "$SPEC_MANIFEST" "$EXPECTED_SPEC_MANIFEST_SHA"
verify_sha "$CAMPAIGN_HASHES" "$EXPECTED_CAMPAIGN_HASHES_SHA"
verify_sha "$AUTH_REPORT" "$EXPECTED_AUTH_REPORT_SHA"
verify_sha "$AUTH_SURFACE" "$EXPECTED_AUTH_SURFACE_SHA"
verify_sha "$EXEC_LEDGER" "$EXPECTED_EXEC_LEDGER_SHA"
verify_sha "$EXEC_SURFACE" "$EXPECTED_EXEC_SURFACE_SHA"
verify_sha "$POST_REPORT" "$EXPECTED_POST_REPORT_SHA"
verify_sha "$POST_SURFACE" "$EXPECTED_POST_SURFACE_SHA"
verify_sha "$SOURCE_RUN_MANIFEST" "$EXPECTED_SOURCE_RUN_MANIFEST_SHA"

sha256sum -c "$CAMPAIGN_HASHES" >/dev/null
sha256sum -c "$SOURCE_RUN_MANIFEST" >/dev/null

test "$(wc -l < "$SOURCE_RUN_MANIFEST")" -eq 280
test "$(find "$RUN_ROOT" -maxdepth 1 -type d \
  -name 'objective_count_stage10_rep_*_canonical' | wc -l)" -eq 10
test "$(find "$EXEC_LOG_ROOT" -maxdepth 1 -type f -name 'rep_*.log' | wc -l)" -eq 10

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_complete_and_audited"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .completion.successful_execution_spec_count == 10
  and .completion.failed_execution_spec_count == 0
  and .completion.canonical_run_count == 10
  and .completion.total_instance_count == 60
  and .completion.unique_instance_count == 60
  and .completion.total_step_evaluations == 1920
  and .completion.total_output_file_count == 280
  and .completion.total_output_bytes == 25018782
  and .completion.unique_execution_digest_count == 10
  and .completion.explicit_failure_count == 0
  and .authorization.functional_execution_evidence_materialization_authorized == true
  and .authorization.timing_analysis_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .scientific_controls.functional_execution_completion_audited == true
  and .scientific_controls.functional_execution_evidence_committed == false
  and .scientific_controls.manuscript_modified == false
  and .blocker_count == 0
  and .audit_complete == true
  and .next_stage
    == "materialize_sa5_objective_count_stage10_functional_execution_evidence"
' "$POST_REPORT" >/dev/null

test ! -e "$EVIDENCE_ROOT"
test ! -e "$MATERIALIZATION_REPORT"
test ! -e "$MATERIALIZATION_SUMMARY"

test -f "$MANUSCRIPT"
test -f "$DEFERRED"

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

echo "post_execution_audit_gate=PASS"
echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "total_output_bytes=25018782"
echo "functional_execution_evidence_materialization_authorized=true"

echo
echo "=== 2. Create isolated evidence-materialization branch ==="

git switch -c "$BRANCH"

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

echo "evidence_branch_creation=PASS"
echo "branch=$BRANCH"

echo
echo "=== 3. Copy exact detached provenance into canonical evidence root ==="

mkdir -p \
  "$AUTH_EVIDENCE_DIR" \
  "$CANONICAL_LOG_DIR" \
  "$POST_EVIDENCE_DIR"

cp "$AUTH_REPORT" \
  "$AUTH_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_authorization.json"
cp "$AUTH_SURFACE" \
  "$AUTH_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_authorization.txt"

cp "$EXEC_LEDGER" \
  "$EXEC_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_ledger.json"
cp "$EXEC_SURFACE" \
  "$EXEC_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_ledger.txt"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  cp "$EXEC_LOG_ROOT/rep_${TOKEN}.log" \
    "$CANONICAL_LOG_DIR/rep_${TOKEN}.log"
done

cp "$POST_REPORT" \
  "$POST_EVIDENCE_DIR/sa5_objective_count_stage10_post_functional_execution_audit.json"
cp "$POST_SURFACE" \
  "$POST_EVIDENCE_DIR/sa5_objective_count_stage10_post_functional_execution_audit.txt"
cp "$SOURCE_RUN_MANIFEST" \
  "$POST_EVIDENCE_DIR/canonical_functional_run_file_manifest.sha256"

cmp "$AUTH_REPORT" \
  "$AUTH_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_authorization.json"
cmp "$AUTH_SURFACE" \
  "$AUTH_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_authorization.txt"
cmp "$EXEC_LEDGER" \
  "$EXEC_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_ledger.json"
cmp "$EXEC_SURFACE" \
  "$EXEC_EVIDENCE_DIR/sa5_objective_count_stage10_functional_execution_ledger.txt"
cmp "$POST_REPORT" \
  "$POST_EVIDENCE_DIR/sa5_objective_count_stage10_post_functional_execution_audit.json"
cmp "$POST_SURFACE" \
  "$POST_EVIDENCE_DIR/sa5_objective_count_stage10_post_functional_execution_audit.txt"
cmp "$SOURCE_RUN_MANIFEST" \
  "$POST_EVIDENCE_DIR/canonical_functional_run_file_manifest.sha256"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  cmp "$EXEC_LOG_ROOT/rep_${TOKEN}.log" \
    "$CANONICAL_LOG_DIR/rep_${TOKEN}.log"
done

echo "detached_provenance_copy=PASS"
echo "copied_authorization_file_count=2"
echo "copied_execution_ledger_file_count=2"
echo "copied_execution_log_count=10"
echo "copied_post_execution_file_count=3"

echo
echo "=== 4. Generate canonical evidence manifest and planning report ==="

export ROOT EXPECTED_HEAD
export SPEC_MANIFEST EXPECTED_SPEC_MANIFEST_SHA
export AUTH_REPORT EXPECTED_AUTH_REPORT_SHA
export EXEC_LEDGER EXPECTED_EXEC_LEDGER_SHA
export POST_REPORT EXPECTED_POST_REPORT_SHA
export SOURCE_RUN_MANIFEST EXPECTED_SOURCE_RUN_MANIFEST_SHA
export EVIDENCE_ROOT EVIDENCE_MANIFEST
export AUTH_EVIDENCE_DIR EXEC_EVIDENCE_DIR POST_EVIDENCE_DIR CANONICAL_LOG_DIR
export MATERIALIZATION_REPORT MATERIALIZATION_SUMMARY

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        ) + "\n",
        encoding="utf-8",
    )


root = Path(os.environ["ROOT"]).resolve()
evidence_root = Path(os.environ["EVIDENCE_ROOT"])
manifest_path = Path(os.environ["EVIDENCE_MANIFEST"])
report_path = Path(os.environ["MATERIALIZATION_REPORT"])
summary_path = Path(os.environ["MATERIALIZATION_SUMMARY"])

auth_dir = Path(os.environ["AUTH_EVIDENCE_DIR"])
exec_dir = Path(os.environ["EXEC_EVIDENCE_DIR"])
post_dir = Path(os.environ["POST_EVIDENCE_DIR"])
log_dir = Path(os.environ["CANONICAL_LOG_DIR"])

source_auth = Path(os.environ["AUTH_REPORT"])
source_ledger = Path(os.environ["EXEC_LEDGER"])
source_post = Path(os.environ["POST_REPORT"])
source_run_manifest = Path(os.environ["SOURCE_RUN_MANIFEST"])

auth = read_json(source_auth)
ledger = read_json(source_ledger)
post = read_json(source_post)

assert auth["authorization"]["canonical_functional_execution_authorized"] is True
assert ledger["process_results"]["successful_process_count"] == 10
assert post["completion"]["successful_execution_spec_count"] == 10
assert post["completion"]["total_output_file_count"] == 280
assert post["completion"]["total_output_bytes"] == 25018782

source_artifact_paths = [
    auth_dir / "sa5_objective_count_stage10_functional_execution_authorization.json",
    auth_dir / "sa5_objective_count_stage10_functional_execution_authorization.txt",
    exec_dir / "sa5_objective_count_stage10_functional_execution_ledger.json",
    exec_dir / "sa5_objective_count_stage10_functional_execution_ledger.txt",
    post_dir / "sa5_objective_count_stage10_post_functional_execution_audit.json",
    post_dir / "sa5_objective_count_stage10_post_functional_execution_audit.txt",
    post_dir / "canonical_functional_run_file_manifest.sha256",
]

log_paths = sorted(log_dir.glob("rep_*.log"))
assert len(log_paths) == 10

ledger_rows = {
    int(row["replication_index"]): row
    for row in ledger["process_results"]["rows"]
}
assert set(ledger_rows) == set(range(10))

logs = []
for index, path in enumerate(log_paths):
    row = ledger_rows[index]
    assert sha(path) == row["log_sha256"]
    logs.append({
        "replication_index": index,
        "canonical_path": path.as_posix(),
        "sha256": sha(path),
        "source_path": row["log_path"],
    })

source_artifacts = []
for path in source_artifact_paths:
    source_artifacts.append({
        "path": path.as_posix(),
        "sha256": sha(path),
        "byte_count": path.stat().st_size,
    })

manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "functional-execution-evidence-manifest-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "functional_execution_evidence_materialized"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "canonical_evidence": {
        "execution_spec_manifest_path": os.environ["SPEC_MANIFEST"],
        "execution_spec_manifest_sha256": os.environ[
            "EXPECTED_SPEC_MANIFEST_SHA"
        ],
        "authorization_report_source_sha256": os.environ[
            "EXPECTED_AUTH_REPORT_SHA"
        ],
        "execution_ledger_source_sha256": os.environ[
            "EXPECTED_EXEC_LEDGER_SHA"
        ],
        "post_execution_audit_source_sha256": os.environ[
            "EXPECTED_POST_REPORT_SHA"
        ],
        "canonical_run_file_manifest_source_sha256": os.environ[
            "EXPECTED_SOURCE_RUN_MANIFEST_SHA"
        ],
        "source_artifact_count": 7,
        "execution_log_count": 10,
        "source_artifacts": source_artifacts,
        "execution_logs": logs,
    },
    "completion": {
        "execution_spec_count": 10,
        "successful_execution_spec_count": 10,
        "failed_execution_spec_count": 0,
        "canonical_run_count": 10,
        "total_instance_count": 60,
        "unique_instance_count": 60,
        "total_step_evaluations": 1920,
        "canonical_run_file_count": 280,
        "canonical_run_total_bytes": 25018782,
        "unique_execution_digest_count": 10,
        "explicit_failure_count": 0,
    },
    "repository_scope": {
        "canonical_run_file_count": 280,
        "canonical_evidence_file_count": 18,
        "planning_file_count": 2,
        "total_materialized_file_count": 300,
    },
    "scientific_controls": {
        "canonical_stage10_functional_execution_performed": True,
        "functional_execution_completion_audited": True,
        "functional_execution_evidence_materialized": True,
        "functional_execution_evidence_committed": False,
        "timing_analysis_performed": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "manuscript_modified": False,
    },
    "authorization": {
        "functional_execution_evidence_commit_authorized": True,
        "timing_analysis_authorized": False,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "materialization_complete": True,
}

write_json(manifest_path, manifest)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "functional-execution-evidence-materialization-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_"
        "functional_execution_evidence_materialized"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "evidence_manifest_path": manifest_path.as_posix(),
    "evidence_manifest_sha256": sha(manifest_path),
    "source_evidence": {
        "authorization_report_sha256": os.environ[
            "EXPECTED_AUTH_REPORT_SHA"
        ],
        "execution_ledger_sha256": os.environ[
            "EXPECTED_EXEC_LEDGER_SHA"
        ],
        "post_execution_audit_sha256": os.environ[
            "EXPECTED_POST_REPORT_SHA"
        ],
        "canonical_run_file_manifest_sha256": os.environ[
            "EXPECTED_SOURCE_RUN_MANIFEST_SHA"
        ],
    },
    "completion": manifest["completion"],
    "repository_scope": manifest["repository_scope"],
    "scientific_controls": manifest["scientific_controls"],
    "authorization": manifest["authorization"],
    "blockers": [],
    "blocker_count": 0,
    "materialization_complete": True,
    "next_stage": (
        "wait_for_ci_then_merge_sa5_objective_count_"
        "stage10_functional_execution_evidence"
    ),
}

write_json(report_path, report)

summary_path.write_text(
    "\n".join([
        "# SA5 objective-count Stage-10 functional-execution evidence",
        "",
        f"- Source commit: `{report['source_commit']}`",
        "- Canonical runs: `10`",
        "- Successful execution specifications: `10`",
        "- Failed execution specifications: `0`",
        "- Canonical instances: `60`",
        "- Functional step evaluations: `1920`",
        "- Canonical run files: `280`",
        "- Canonical run bytes: `25018782`",
        "- Canonical evidence files: `18`",
        "- Planning files: `2`",
        "- Total materialized files: `300`",
        f"- Evidence manifest SHA-256: `{report['evidence_manifest_sha256']}`",
        "",
        "## Scientific control",
        "",
        "- Functional execution: performed and completion-audited",
        "- Timing analysis: not performed",
        "- Precision analysis: not performed",
        "- Bootstrap analysis: not performed",
        "- Scientific interpretation: not performed",
        "- Manuscript modification: not performed",
        "",
        "Next stage: review and merge this evidence-only change.",
        "",
    ]),
    encoding="utf-8",
)

print("canonical_evidence_manifest_generation=PASS")
print(f"evidence_manifest_sha256={sha(manifest_path)}")
print(f"materialization_report_sha256={sha(report_path)}")
print(f"materialization_summary_sha256={sha(summary_path)}")
PY

echo "canonical_evidence_provenance=PASS"

echo
echo "=== 5. Validate materialized evidence decision ==="

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .completion.successful_execution_spec_count == 10
  and .completion.failed_execution_spec_count == 0
  and .completion.canonical_run_count == 10
  and .completion.total_instance_count == 60
  and .completion.total_step_evaluations == 1920
  and .completion.canonical_run_file_count == 280
  and .completion.canonical_run_total_bytes == 25018782
  and .repository_scope.canonical_run_file_count == 280
  and .repository_scope.canonical_evidence_file_count == 18
  and .repository_scope.planning_file_count == 2
  and .repository_scope.total_materialized_file_count == 300
  and .scientific_controls.canonical_stage10_functional_execution_performed == true
  and .scientific_controls.functional_execution_completion_audited == true
  and .scientific_controls.functional_execution_evidence_materialized == true
  and .scientific_controls.functional_execution_evidence_committed == false
  and .scientific_controls.timing_analysis_performed == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.scientific_result_interpretation_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization.functional_execution_evidence_commit_authorized == true
  and .authorization.timing_analysis_authorized == false
  and .authorization.precision_analysis_authorized == false
  and .authorization.bootstrap_analysis_authorized == false
  and .authorization.scientific_result_interpretation_authorized == false
  and .authorization.manuscript_integration_authorized == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$EVIDENCE_MANIFEST" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_stage10_functional_execution_evidence_materialized"
  and .source_commit
    == "809ec874ca1bc6d4ad3c37b022d75dced7da5e98"
  and .repository_scope.total_materialized_file_count == 300
  and .scientific_controls.functional_execution_evidence_committed == false
  and .authorization.functional_execution_evidence_commit_authorized == true
  and .blocker_count == 0
  and .materialization_complete == true
  and .next_stage
    == "wait_for_ci_then_merge_sa5_objective_count_stage10_functional_execution_evidence"
' "$MATERIALIZATION_REPORT" >/dev/null

echo "functional_evidence_materialization_report_validation=PASS"

echo
echo "=== 6. Exact generated scope gate ==="

awk '{print $2}' "$SOURCE_RUN_MANIFEST" |
  sort > "$TMP_ROOT/run_files.txt"

find "$EVIDENCE_ROOT" -type f |
  sort > "$TMP_ROOT/evidence_files.txt"

printf '%s\n' \
  "$MATERIALIZATION_REPORT" \
  "$MATERIALIZATION_SUMMARY" |
  sort > "$TMP_ROOT/planning_files.txt"

cat \
  "$TMP_ROOT/run_files.txt" \
  "$TMP_ROOT/evidence_files.txt" \
  "$TMP_ROOT/planning_files.txt" |
  sort > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/run_files.txt")" -eq 280
test "$(wc -l < "$TMP_ROOT/evidence_files.txt")" -eq 18
test "$(wc -l < "$TMP_ROOT/planning_files.txt")" -eq 2
test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 300

sha256sum -c "$SOURCE_RUN_MANIFEST" >/dev/null

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "generated_scope_gate=PASS"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_generated_file_count=300"

echo
echo "=== 7. Force-stage exact evidence scope ==="

mapfile -t GENERATED_FILES < "$TMP_ROOT/expected_files.txt"

git add -f -- "${GENERATED_FILES[@]}"

git diff --cached --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 300
test -z "$(git diff --name-only)"

sha256sum -c "$SOURCE_RUN_MANIFEST" >/dev/null

echo "functional_evidence_stage=PASS"
echo "staged_file_count=300"

echo
echo "=== 8. Commit canonical functional evidence ==="

git commit \
  -m "evidence(experiments): materialize SA5 objective-count functional execution"

COMMIT="$(git rev-parse HEAD)"

test "$COMMIT" != "$EXPECTED_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git diff-tree --no-commit-id --name-only -r "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/committed_files.txt"

echo "functional_evidence_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=300"

echo
echo "=== 9. Push evidence branch ==="

git push -u origin "$BRANCH"

test "$(git rev-parse "origin/$BRANCH")" = "$COMMIT"

echo "functional_evidence_push=PASS"

echo
echo "=== 10. Create pull request ==="

EVIDENCE_MANIFEST_SHA="$(
  sha256sum "$EVIDENCE_MANIFEST" |
    awk '{print $1}'
)"

REPORT_SHA="$(
  sha256sum "$MATERIALIZATION_REPORT" |
    awk '{print $1}'
)"

SUMMARY_SHA="$(
  sha256sum "$MATERIALIZATION_SUMMARY" |
    awk '{print $1}'
)"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Materialize SA5 objective-count Stage-10 functional evidence" \
    --body-file - <<EOF
## Scope

Materialize the completion-audited SA5 objective-count Stage-10 functional-execution evidence.

- 10 successful canonical runs
- 60 unique canonical instances
- 1,920 functional step evaluations
- 280 canonical run files
- 25,018,782 canonical run bytes
- exact authorization, execution-ledger, logs, and post-execution audit provenance
- 300 files in the exact PR scope

## Validation

- failed execution specifications: 0
- explicit execution failures: 0
- run-tree hashes match the detached ledger
- execution-log hashes match the detached ledger
- all expected instance identifiers observed
- all execution digests observed
- source run-file manifest SHA-256: \`$EXPECTED_SOURCE_RUN_MANIFEST_SHA\`
- canonical evidence manifest SHA-256: \`$EVIDENCE_MANIFEST_SHA\`
- materialization report SHA-256: \`$REPORT_SHA\`
- materialization summary SHA-256: \`$SUMMARY_SHA\`

## Scientific control

This PR records functional-execution evidence only. Timing analysis, precision analysis, bootstrap analysis, scientific interpretation, and manuscript integration have not been performed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 11. Verify PR identity and exact scope ==="

PR_DATA="$(
  gh pr view "$PR_NUMBER" \
    --repo "$REPO" \
    --json \
state,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg commit "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $commit
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 functional evidence"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 300

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=300"

echo
echo "=== 12. Final state ==="

echo "sa5_objective_count_stage10_functional_evidence_materialization=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "canonical_run_count=10"
echo "canonical_run_file_count=280"
echo "canonical_evidence_file_count=18"
echo "planning_file_count=2"
echo "total_committed_file_count=300"
echo "total_instance_count=60"
echo "total_step_evaluations=1920"
echo "total_output_bytes=25018782"

echo "evidence_manifest=$EVIDENCE_MANIFEST"
echo "evidence_manifest_sha256=$EVIDENCE_MANIFEST_SHA"
echo "materialization_report=$MATERIALIZATION_REPORT"
echo "materialization_report_sha256=$REPORT_SHA"
echo "materialization_summary=$MATERIALIZATION_SUMMARY"
echo "materialization_summary_sha256=$SUMMARY_SHA"

echo "canonical_stage10_functional_execution_performed=true"
echo "functional_execution_completion_audited=true"
echo "functional_execution_evidence_materialized=true"
echo "functional_execution_evidence_committed=true"

echo "timing_analysis_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_result_interpretation_performed=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_functional_execution_evidence"

git status --short --branch
git log --oneline --decorate -5
