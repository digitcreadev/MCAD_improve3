#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"
PR=35

BASE="paper/phase3-controlled-execution"
BRANCH="paper/materialize-sa5-objective-count-stage10-execution-specs-20260805T115406Z"

EXPECTED_BASE_HEAD="6c4dac8312f4798fd0f1ede499cba58f57ab8368"
EXPECTED_FEATURE_HEAD="4aeb2749f480593038e3118ab61414824da85d91"

E3_ROOT="reports/article_experiments/sensitivity/e3_controlled_execution"
CAMPAIGN_ID="objective_count_stage10_c8_nv32"

CAMPAIGN_ROOT="$E3_ROOT/campaigns/$CAMPAIGN_ID"
WORKLOAD_ROOT="$CAMPAIGN_ROOT/common_workloads"
RUN_ROOT="$E3_ROOT/runs"

SPEC_DIR="$E3_ROOT/execution_specs"
SPEC_MANIFEST="$SPEC_DIR/objective_count_stage10_execution_spec_manifest.json"
EXPECTED_SPEC_MANIFEST_SHA="c217dd50476e3c378afb33d2c68540b18fe9f1e1291bbadd5b71659e35ff061c"

MATERIALIZATION_REPORT="$E3_ROOT/planning/sa5_objective_count_stage10_execution_spec_materialization_report.json"
EXPECTED_MATERIALIZATION_REPORT_SHA="5aba779eee953daaba56eeb39e6f3ee189eca379de3a38b4b720db66be46f23e"

MATERIALIZATION_SUMMARY="$E3_ROOT/planning/sa5_objective_count_stage10_execution_spec_materialization_report.md"
EXPECTED_MATERIALIZATION_SUMMARY_SHA="d38d216f6e4a75225a49d1e433c437beda4a410ae6af4c0466273102275e9671"

CAMPAIGN_FILE_MANIFEST="$E3_ROOT/audits/$CAMPAIGN_ID/canonical_campaign_file_manifest.sha256"
EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA="b648bf2aaaddb75e39b117a42fce75161f9c9c82c1111a1a8596f5215210c8ae"

INPUT_MATERIALIZATION_REPORT="$E3_ROOT/planning/sa5_objective_count_stage10_materialization_report.json"
EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA="36a9a5a7504875da3e72e230447218b2da6386ad1dcd1015836f2c137fbfb08e"

READINESS_ROOT="/workspaces/sa5_objective_count_stage10_functional_execution_readiness_20260805T114315Z"
READINESS_REPORT="$READINESS_ROOT/sa5_objective_count_stage10_functional_execution_readiness.json"
EXPECTED_READINESS_REPORT_SHA="ec84c769338f9c537c0e15166d844e218f4095029a4bf19126dfc3443cd4250a"

CANDIDATE_MANIFEST="$READINESS_ROOT/candidate_a/reports/article_experiments/sensitivity/e3_controlled_execution/execution_spec_candidate_manifest.json"
EXPECTED_CANDIDATE_MANIFEST_SHA="8ef2f0b23e81bd0a9fdd32393af2af8223a01fb435ff8851cf4294bbd588506f"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV_PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
CI_AUDIT_ROOT="/workspaces/sa5_objective_count_pr35_ci_eligibility_audit_${STAMP}"
CI_AUDIT_REPORT="$CI_AUDIT_ROOT/sa5_objective_count_pr35_ci_eligibility_audit.json"
CI_AUDIT_SURFACE="$CI_AUDIT_ROOT/sa5_objective_count_pr35_ci_eligibility_audit.txt"

TMP_ROOT="$(mktemp -d /workspaces/sa5_pr35_controlled_merge.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] PR #35 controlled merge stopped at line $LINENO."' ERR

cd "$ROOT"

if [ -x "$VENV_PYTHON" ]; then
  PYTHON="$VENV_PYTHON"
else
  PYTHON="$(command -v python3)"
fi

test -n "$PYTHON"

verify_sha() {
  local FILE="$1"
  local EXPECTED="$2"
  local ACTUAL

  test -f "$FILE"

  ACTUAL="$(
    sha256sum "$FILE" |
      awk '{print $1}'
  )"

  test "$ACTUAL" = "$EXPECTED"
}

cat > "$TMP_ROOT/expected_files.txt" <<'EOF'
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_execution_spec_manifest.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_000_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_001_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_002_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_003_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_004_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_005_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_006_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_007_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_008_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/execution_specs/objective_count_stage10_rep_009_canonical.json
reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_execution_spec_materialization_report.json
reports/article_experiments/sensitivity/e3_controlled_execution/planning/sa5_objective_count_stage10_execution_spec_materialization_report.md
EOF

sort -o \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 13

echo "=== 1. Exact local execution-spec gate ==="

test "$(git branch --show-current)" = "$BRANCH"
test "$(git rev-parse HEAD)" = "$EXPECTED_FEATURE_HEAD"
test "$(git rev-parse HEAD^)" = "$EXPECTED_BASE_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune

test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_BASE_HEAD"
test "$(git rev-parse "origin/$BRANCH")" = "$EXPECTED_FEATURE_HEAD"

git diff \
  --name-only \
  "$EXPECTED_BASE_HEAD..$EXPECTED_FEATURE_HEAD" |
  sort > "$TMP_ROOT/feature_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/feature_files.txt"

verify_sha \
  "$SPEC_MANIFEST" \
  "$EXPECTED_SPEC_MANIFEST_SHA"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

verify_sha \
  "$INPUT_MATERIALIZATION_REPORT" \
  "$EXPECTED_INPUT_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$READINESS_REPORT" \
  "$EXPECTED_READINESS_REPORT_SHA"

verify_sha \
  "$CANDIDATE_MANIFEST" \
  "$EXPECTED_CANDIDATE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

test -f "$MANUSCRIPT"
test -f "$DEFERRED_FRAGMENT"

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "local_execution_spec_gate=PASS"
echo "base_head=$EXPECTED_BASE_HEAD"
echo "feature_head=$EXPECTED_FEATURE_HEAD"
echo "changed_file_count=13"

echo
echo "=== 2. Canonical execution-spec evidence gate ==="

export SPEC_DIR
export SPEC_MANIFEST
export RUN_ROOT_ABS="$ROOT/$RUN_ROOT"
export CAMPAIGN_ROOT_ABS="$ROOT/$CAMPAIGN_ROOT"
export WORKLOAD_ROOT_ABS="$ROOT/$WORKLOAD_ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


spec_dir = Path(os.environ["SPEC_DIR"])
manifest_path = Path(os.environ["SPEC_MANIFEST"])
run_root = Path(os.environ["RUN_ROOT_ABS"]).resolve()
campaign_root = Path(os.environ["CAMPAIGN_ROOT_ABS"]).resolve()
workload_root = Path(os.environ["WORKLOAD_ROOT_ABS"]).resolve()

manifest = json.loads(
    manifest_path.read_text(encoding="utf-8")
)

assert manifest["status"] == (
    "sa5_objective_count_stage10_"
    "execution_specs_materialized"
)
assert manifest["source_commit"] == (
    "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
)
assert manifest["execution_spec_count"] == 10
assert manifest["selected_instances_per_spec"] == 6
assert manifest["total_selected_instance_count"] == 60
assert manifest["unique_selected_instance_count"] == 60
assert manifest["portable_relative_paths"] is True
assert len(manifest["entries"]) == 10

spec_paths = sorted(
    spec_dir.glob(
        "objective_count_stage10_rep_*_canonical.json"
    )
)
assert len(spec_paths) == 10

selected_ids: list[str] = []

for entry, spec_path in zip(
    manifest["entries"],
    spec_paths,
):
    assert spec_path.name == entry["filename"]
    assert sha256_file(spec_path) == entry["file_sha256"]

    payload = json.loads(
        spec_path.read_text(encoding="utf-8")
    )
    validate_execution_spec(payload)

    inputs = load_execution_inputs(spec_path)

    assert inputs.campaign_dir.resolve() == campaign_root
    assert inputs.workload_path.parent.resolve() == workload_root
    assert inputs.output_dir.parent == run_root
    assert not inputs.output_dir.exists()

    assert len(inputs.instances) == 6
    assert [
        instance.factor_level
        for instance in inputs.instances
    ] == [1, 2, 5, 10, 20, 50]

    replication_index = int(entry["replication_index"])
    seed = int(entry["seed"])

    assert {
        instance.replication_index
        for instance in inputs.instances
    } == {replication_index}

    assert {
        instance.seed
        for instance in inputs.instances
    } == {seed}

    ids = [
        instance.canonical_instance_id
        for instance in inputs.instances
    ]
    assert ids == entry["selected_instance_ids"]
    selected_ids.extend(ids)

assert len(selected_ids) == 60
assert len(set(selected_ids)) == 60

assert not list(
    run_root.glob(
        "objective_count_stage10_rep_*_canonical"
    )
)

print("canonical_execution_spec_evidence=PASS")
print("canonical_execution_spec_count=10")
print("selected_instances_per_spec=6")
print("total_selected_instance_count=60")
print("unique_selected_instance_count=60")
print("canonical_run_count=0")
PY

jq -e '
  .status
    == "sa5_objective_count_stage10_execution_specs_materialized"
  and .source_commit
    == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
  and .canonical_execution_specs.execution_spec_count == 10
  and .canonical_execution_specs.total_selected_instance_count == 60
  and .canonical_execution_specs.unique_selected_instance_count == 60
  and .canonical_execution_specs.all_validate_execution_spec == true
  and .canonical_execution_specs.all_load_execution_inputs == true
  and .canonical_execution_specs.all_output_directories_absent == true
  and .scientific_controls.canonical_execution_specs_materialized == true
  and .scientific_controls.canonical_execution_specs_committed == false
  and .scientific_controls.canonical_stage10_functional_execution_performed == false
  and .scientific_controls.scientific_execution_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization.canonical_functional_execution_authorized == false
  and .blocker_count == 0
  and .materialization_complete == true
' "$MATERIALIZATION_REPORT" >/dev/null

echo "execution_spec_evidence_gate=PASS"
echo "canonical_functional_execution_authorized=false"
echo "canonical_stage10_functional_execution_performed=false"

echo
echo "=== 3. Pull-request identity and exact-scope gate ==="

PR_DATA="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,isDraft,headRefOid,headRefName,baseRefName,title
)"

jq -e \
  --arg feature "$EXPECTED_FEATURE_HEAD" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .mergedAt == null
    and .isDraft == false
    and .headRefOid == $feature
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Materialize SA5 objective-count Stage-10 execution specs"
  ' <<<"$PR_DATA" >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u \
  "$TMP_ROOT/expected_files.txt" \
  "$TMP_ROOT/pr_files.txt"

test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 13

echo "pr_identity_gate=PASS"
echo "pr_scope_gate=PASS"
echo "pr_file_count=13"

echo
echo "=== 4. Detect registered CI or prove workflow ineligibility ==="

CI_OBJECT_COUNT=0
PR_CHECK_COUNT=0
ACTIONS_RUN_COUNT=0
CHECK_RUN_COUNT=0
LEGACY_STATUS_COUNT=0

for ATTEMPT in $(seq 1 6); do
  PR_CHECKS="$(
    gh pr checks "$PR" \
      --repo "$REPO" \
      --json bucket,name,state,link \
      2>/dev/null || printf '[]'
  )"

  if ! jq -e \
    'type == "array"' \
    >/dev/null \
    <<<"$PR_CHECKS"
  then
    PR_CHECKS='[]'
  fi

  PR_CHECK_COUNT="$(
    jq 'length' <<<"$PR_CHECKS"
  )"

  ACTIONS_RUNS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
  )"

  ACTIONS_RUN_COUNT="$(
    jq '.total_count' <<<"$ACTIONS_RUNS"
  )"

  CHECK_RUNS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
  )"

  CHECK_RUN_COUNT="$(
    jq '.total_count' <<<"$CHECK_RUNS"
  )"

  COMBINED_STATUS="$(
    gh api \
      -H "Accept: application/vnd.github+json" \
      "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
  )"

  LEGACY_STATUS_COUNT="$(
    jq '.statuses | length' <<<"$COMBINED_STATUS"
  )"

  CI_OBJECT_COUNT="$(
    printf '%s\n' \
      "$PR_CHECK_COUNT" \
      "$ACTIONS_RUN_COUNT" \
      "$CHECK_RUN_COUNT" \
      "$LEGACY_STATUS_COUNT" |
      awk '{sum += $1} END {print sum + 0}'
  )"

  echo \
    "ci_detection_attempt=$ATTEMPT " \
    "pr_checks=$PR_CHECK_COUNT " \
    "actions_runs=$ACTIONS_RUN_COUNT " \
    "check_runs=$CHECK_RUN_COUNT " \
    "legacy_statuses=$LEGACY_STATUS_COUNT"

  if [ "$CI_OBJECT_COUNT" -gt 0 ]; then
    break
  fi

  sleep 5
done

CI_MODE=""

if [ "$CI_OBJECT_COUNT" -gt 0 ]; then
  CI_MODE="registered"

  echo "registered_ci_detected=true"

  COMPLETE=0

  for ATTEMPT in $(seq 1 60); do
    ACTIONS_RUNS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/actions/runs?head_sha=$EXPECTED_FEATURE_HEAD&per_page=100"
    )"

    CHECK_RUNS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/check-runs?per_page=100"
    )"

    COMBINED_STATUS="$(
      gh api \
        -H "Accept: application/vnd.github+json" \
        "/repos/$REPO/commits/$EXPECTED_FEATURE_HEAD/status"
    )"

    ACTION_PENDING="$(
      jq '
        [
          .workflow_runs[]
          | select(
              .status != "completed"
            )
        ]
        | length
      ' <<<"$ACTIONS_RUNS"
    )"

    ACTION_FAILURE="$(
      jq '
        [
          .workflow_runs[]
          | select(
              .status == "completed"
              and (
                .conclusion
                | IN(
                    "success",
                    "neutral",
                    "skipped"
                  )
                | not
              )
            )
        ]
        | length
      ' <<<"$ACTIONS_RUNS"
    )"

    CHECK_PENDING="$(
      jq '
        [
          .check_runs[]
          | select(.status != "completed")
        ]
        | length
      ' <<<"$CHECK_RUNS"
    )"

    CHECK_FAILURE="$(
      jq '
        [
          .check_runs[]
          | select(
              .status == "completed"
              and (
                .conclusion
                | IN(
                    "success",
                    "neutral",
                    "skipped"
                  )
                | not
              )
            )
        ]
        | length
      ' <<<"$CHECK_RUNS"
    )"

    LEGACY_FAILURE="$(
      jq '
        [
          .statuses[]
          | select(.state != "success")
        ]
        | length
      ' <<<"$COMBINED_STATUS"
    )"

    echo \
      "ci_completion_attempt=$ATTEMPT " \
      "action_pending=$ACTION_PENDING " \
      "action_failure=$ACTION_FAILURE " \
      "check_pending=$CHECK_PENDING " \
      "check_failure=$CHECK_FAILURE " \
      "legacy_failure=$LEGACY_FAILURE"

    test "$ACTION_FAILURE" -eq 0
    test "$CHECK_FAILURE" -eq 0

    if [ "$ACTION_PENDING" -eq 0 ] \
       && [ "$CHECK_PENDING" -eq 0 ] \
       && [ "$LEGACY_FAILURE" -eq 0 ]
    then
      COMPLETE=1
      break
    fi

    sleep 10
  done

  test "$COMPLETE" -eq 1

  echo "registered_ci_completion_gate=PASS"
else
  CI_MODE="workflow_ineligible"

  mkdir -p "$CI_AUDIT_ROOT"

  export ROOT
  export BASE
  export EXPECTED_BASE_HEAD
  export EXPECTED_FEATURE_HEAD
  export PR
  export REPO
  export CI_AUDIT_REPORT
  export CI_AUDIT_SURFACE
  export EXPECTED_FILES_PATH="$TMP_ROOT/expected_files.txt"

  "$PYTHON" - <<'PY'
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import yaml


root = Path(os.environ["ROOT"])
base_branch = os.environ["BASE"]
base_head = os.environ["EXPECTED_BASE_HEAD"]
feature_head = os.environ["EXPECTED_FEATURE_HEAD"]
pr_number = int(os.environ["PR"])
repo = os.environ["REPO"]

report_path = Path(os.environ["CI_AUDIT_REPORT"])
surface_path = Path(os.environ["CI_AUDIT_SURFACE"])

changed_files = Path(
    os.environ["EXPECTED_FILES_PATH"]
).read_text(encoding="utf-8").splitlines()

workflow_root = root / ".github" / "workflows"
workflow_files = sorted(
    [
        *workflow_root.glob("*.yml"),
        *workflow_root.glob("*.yaml"),
    ]
)

assert workflow_files


def as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value]
    return [str(value)]


def github_match(value: str, pattern: str) -> bool:
    # This deliberately over-approximates GitHub's glob matching.
    # A false positive stops the merge; it cannot authorize one.
    return fnmatch.fnmatchcase(value, pattern)


def ordered_inclusion(
    value: str,
    patterns: list[str],
) -> bool:
    included = False

    for raw in patterns:
        negated = raw.startswith("!")
        pattern = raw[1:] if negated else raw

        if github_match(value, pattern):
            included = not negated

    return included


def ignored(
    value: str,
    patterns: list[str],
) -> bool:
    return any(
        github_match(value, pattern)
        for pattern in patterns
    )


def event_config(
    on_value: Any,
    name: str,
) -> tuple[bool, Any]:
    if isinstance(on_value, str):
        return on_value == name, None

    if isinstance(on_value, list):
        return (
            name in [str(item) for item in on_value],
            None,
        )

    if isinstance(on_value, dict):
        return name in on_value, on_value.get(name)

    return False, None


results: list[dict[str, Any]] = []

for workflow_path in workflow_files:
    document = yaml.load(
        workflow_path.read_text(encoding="utf-8"),
        Loader=yaml.BaseLoader,
    )

    if not isinstance(document, dict):
        raise TypeError(
            f"Workflow root must be a mapping: "
            f"{workflow_path}"
        )

    on_value = document.get("on")
    relative_path = workflow_path.relative_to(
        root
    ).as_posix()

    event_results: list[dict[str, Any]] = []

    for event_name in (
        "pull_request",
        "pull_request_target",
    ):
        present, config = event_config(
            on_value,
            event_name,
        )

        if not present:
            continue

        if not isinstance(config, dict):
            config = {}

        branches = as_list(config.get("branches"))
        branches_ignore = as_list(
            config.get("branches-ignore")
        )
        paths = as_list(config.get("paths"))
        paths_ignore = as_list(
            config.get("paths-ignore")
        )

        branch_eligible = True
        branch_reason = "no_branch_filter"

        if branches:
            branch_eligible = ordered_inclusion(
                base_branch,
                branches,
            )
            branch_reason = (
                "branch_included"
                if branch_eligible
                else "branch_not_included"
            )
        elif branches_ignore:
            branch_eligible = not ignored(
                base_branch,
                branches_ignore,
            )
            branch_reason = (
                "branch_not_ignored"
                if branch_eligible
                else "branch_ignored"
            )

        matched_files: list[str] = []
        path_eligible = True
        path_reason = "no_path_filter"

        if paths:
            matched_files = [
                path
                for path in changed_files
                if ordered_inclusion(path, paths)
            ]
            path_eligible = bool(matched_files)
            path_reason = (
                "paths_match"
                if path_eligible
                else "paths_no_match"
            )
        elif paths_ignore:
            matched_files = [
                path
                for path in changed_files
                if not ignored(path, paths_ignore)
            ]
            path_eligible = bool(matched_files)
            path_reason = (
                "at_least_one_path_not_ignored"
                if path_eligible
                else "all_paths_ignored"
            )

        eligible = (
            branch_eligible
            and path_eligible
        )

        event_results.append(
            {
                "event": event_name,
                "eligible": eligible,
                "branch_eligible": branch_eligible,
                "branch_reason": branch_reason,
                "path_eligible": path_eligible,
                "path_reason": path_reason,
                "branches": branches,
                "branches_ignore": branches_ignore,
                "paths": paths,
                "paths_ignore": paths_ignore,
                "matched_file_count": len(
                    matched_files
                ),
                "matched_files": matched_files,
            }
        )

    results.append(
        {
            "workflow": relative_path,
            "name": document.get("name"),
            "has_pull_request_event": bool(
                event_results
            ),
            "eligible": any(
                item["eligible"]
                for item in event_results
            ),
            "pull_request_events": event_results,
        }
    )


pr_workflows = [
    item
    for item in results
    if item["has_pull_request_event"]
]

eligible_workflows = [
    item
    for item in results
    if item["eligible"]
]

assert len(changed_files) == 13
assert pr_workflows
assert not eligible_workflows, (
    "At least one pull-request workflow is "
    "eligible. The merge must wait for CI."
)

report = {
    "schema_version": (
        "mcad-sa5-objective-count-pr35-"
        "ci-eligibility-audit-v1"
    ),
    "status": (
        "no_ci_registration_expected_from_"
        "workflow_trigger_filters"
    ),
    "repository": repo,
    "pull_request": pr_number,
    "base_branch": base_branch,
    "base_head": base_head,
    "feature_head": feature_head,
    "changed_file_count": len(changed_files),
    "changed_files": changed_files,
    "workflow_file_count": len(results),
    "pull_request_workflow_count": len(
        pr_workflows
    ),
    "eligible_pull_request_workflow_count": 0,
    "workflow_results": results,
    "registered_ci": {
        "object_count": 0,
        "failure_count": 0,
    },
    "decision": {
        "ci_absence_is_expected": True,
        "merge_requires_full_local_regression": True,
        "merge_requires_exact_scope_and_hash_validation": True,
        "merge_requires_mergeable_clean": True,
    },
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
}

report_path.write_text(
    json.dumps(
        report,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    )
    + "\n",
    encoding="utf-8",
)

surface_lines = [
    "SA5 OBJECTIVE-COUNT PR #35 CI ELIGIBILITY AUDIT",
    "=" * 84,
    f"repository={repo}",
    f"pull_request={pr_number}",
    f"base_branch={base_branch}",
    f"base_head={base_head}",
    f"feature_head={feature_head}",
    f"changed_file_count={len(changed_files)}",
    f"workflow_file_count={len(results)}",
    (
        "pull_request_workflow_count="
        f"{len(pr_workflows)}"
    ),
    "eligible_pull_request_workflow_count=0",
    "registered_ci_object_count=0",
    "ci_failure_count=0",
    "ci_absence_is_expected=true",
    "blocker_count=0",
    "audit_complete=true",
    "",
    "WORKFLOW DECISIONS",
    "-" * 84,
]

for workflow in results:
    surface_lines.append(
        f"{workflow['workflow']}: "
        f"has_pull_request_event="
        f"{str(workflow['has_pull_request_event']).lower()} "
        f"eligible="
        f"{str(workflow['eligible']).lower()}"
    )

    for event in workflow["pull_request_events"]:
        surface_lines.append(
            "  "
            f"event={event['event']} "
            f"branch_reason={event['branch_reason']} "
            f"path_reason={event['path_reason']} "
            f"matched_file_count="
            f"{event['matched_file_count']} "
            f"eligible="
            f"{str(event['eligible']).lower()}"
        )

surface_path.write_text(
    "\n".join(surface_lines) + "\n",
    encoding="utf-8",
)

print("workflow_trigger_eligibility_audit=PASS")
print(f"workflow_file_count={len(results)}")
print(
    "pull_request_workflow_count="
    f"{len(pr_workflows)}"
)
print("eligible_pull_request_workflow_count=0")
print("registered_ci_object_count=0")
print("ci_absence_is_expected=true")
print("blocker_count=0")
print(f"ci_audit_report={report_path}")
print(
    "ci_audit_report_sha256="
    + hashlib.sha256(
        report_path.read_bytes()
    ).hexdigest()
)
print(f"ci_audit_surface={surface_path}")
print(
    "ci_audit_surface_sha256="
    + hashlib.sha256(
        surface_path.read_bytes()
    ).hexdigest()
)
PY

  jq -e '
    .status
      == "no_ci_registration_expected_from_workflow_trigger_filters"
    and .pull_request == 35
    and .base_head
      == "6c4dac8312f4798fd0f1ede499cba58f57ab8368"
    and .feature_head
      == "4aeb2749f480593038e3118ab61414824da85d91"
    and .changed_file_count == 13
    and .eligible_pull_request_workflow_count == 0
    and .registered_ci.object_count == 0
    and .registered_ci.failure_count == 0
    and .decision.ci_absence_is_expected == true
    and .blocker_count == 0
    and .audit_complete == true
  ' "$CI_AUDIT_REPORT" >/dev/null

  echo "workflow_ineligibility_gate=PASS"
fi

echo "ci_mode=$CI_MODE"

echo
echo "=== 5. Full local regression before merge ==="

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

verify_sha \
  "$SPEC_MANIFEST" \
  "$EXPECTED_SPEC_MANIFEST_SHA"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

test -z "$(git status --porcelain)"

echo "pre_merge_full_regression_gate=PASS"

echo
echo "=== 6. Mergeability gate ==="

READY=0

for ATTEMPT in $(seq 1 30); do
  DATA="$(
    gh pr view "$PR" \
      --repo "$REPO" \
      --json \
state,headRefOid,isDraft,mergeable,mergeStateStatus
  )"

  STATE="$(jq -r '.state' <<<"$DATA")"
  HEAD="$(jq -r '.headRefOid' <<<"$DATA")"
  DRAFT="$(jq -r '.isDraft' <<<"$DATA")"
  MERGEABLE="$(jq -r '.mergeable' <<<"$DATA")"
  MERGE_STATE="$(jq -r '.mergeStateStatus' <<<"$DATA")"

  echo \
    "attempt=$ATTEMPT " \
    "state=$STATE " \
    "mergeable=$MERGEABLE " \
    "merge_state=$MERGE_STATE"

  if [ "$STATE" = "OPEN" ] \
     && [ "$HEAD" = "$EXPECTED_FEATURE_HEAD" ] \
     && [ "$DRAFT" = "false" ] \
     && [ "$MERGEABLE" = "MERGEABLE" ] \
     && [ "$MERGE_STATE" = "CLEAN" ]
  then
    READY=1
    break
  fi

  sleep 5
done

test "$READY" -eq 1

echo "mergeability_gate=PASS"

echo
echo "=== 7. Merge exact PR #35 head ==="

MERGE_RESULT="$(
  gh api \
    --method PUT \
    -H "Accept: application/vnd.github+json" \
    "/repos/$REPO/pulls/$PR/merge" \
    -f merge_method=merge \
    -f sha="$EXPECTED_FEATURE_HEAD"
)"

jq -e '.merged == true' <<<"$MERGE_RESULT" >/dev/null

REMOTE_MERGE_COMMIT="$(
  jq -r '.sha' <<<"$MERGE_RESULT"
)"

test -n "$REMOTE_MERGE_COMMIT"
test "$REMOTE_MERGE_COMMIT" != "null"

echo "merge_command=PASS"
echo "remote_merge_commit=$REMOTE_MERGE_COMMIT"

echo
echo "=== 8. Delete remote execution-spec branch ==="

git fetch origin --prune

if [ -n "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)" ]; then
  git push \
    origin \
    --delete \
    "$BRANCH"
fi

test -z "$(
  git ls-remote \
    --heads \
    origin \
    "$BRANCH"
)"

echo "remote_branch_cleanup=PASS"

echo
echo "=== 9. Update and validate base lineage ==="

git switch "$BASE"

test "$(git rev-parse HEAD)" = "$EXPECTED_BASE_HEAD"

git pull \
  --ff-only \
  origin \
  "$BASE"

BASE_HEAD="$(
  git rev-parse HEAD
)"

test "$BASE_HEAD" = "$REMOTE_MERGE_COMMIT"

read -r \
  MERGE_COMMIT \
  FIRST_PARENT \
  SECOND_PARENT \
  EXTRA_PARENT \
  <<<"$(
    git rev-list \
      --parents \
      -n 1 \
      "$BASE_HEAD"
  )"

test "$MERGE_COMMIT" = "$BASE_HEAD"
test "$FIRST_PARENT" = "$EXPECTED_BASE_HEAD"
test "$SECOND_PARENT" = "$EXPECTED_FEATURE_HEAD"
test -z "${EXTRA_PARENT:-}"

echo "merge_lineage_validation=PASS"
echo "merge_commit=$BASE_HEAD"
echo "first_parent=$FIRST_PARENT"
echo "second_parent=$SECOND_PARENT"

echo
echo "=== 10. Post-merge exact execution-spec integrity ==="

while IFS= read -r FILE; do
  test -f "$FILE"

  git ls-files \
    --error-unmatch \
    "$FILE" \
    >/dev/null
done < "$TMP_ROOT/expected_files.txt"

find "$SPEC_DIR" \
  -maxdepth 1 \
  -type f \
  -name 'objective_count_stage10_rep_*_canonical.json' |
  sort > "$TMP_ROOT/post_merge_spec_files.txt"

test "$(wc -l < "$TMP_ROOT/post_merge_spec_files.txt")" -eq 10

verify_sha \
  "$SPEC_MANIFEST" \
  "$EXPECTED_SPEC_MANIFEST_SHA"

verify_sha \
  "$MATERIALIZATION_REPORT" \
  "$EXPECTED_MATERIALIZATION_REPORT_SHA"

verify_sha \
  "$MATERIALIZATION_SUMMARY" \
  "$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

verify_sha \
  "$CAMPAIGN_FILE_MANIFEST" \
  "$EXPECTED_CAMPAIGN_FILE_MANIFEST_SHA"

sha256sum \
  -c \
  "$CAMPAIGN_FILE_MANIFEST" \
  >/dev/null

"$PYTHON" - <<'PY'
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


spec_dir = Path(os.environ["SPEC_DIR"])
manifest = json.loads(
    Path(
        os.environ["SPEC_MANIFEST"]
    ).read_text(encoding="utf-8")
)
run_root = Path(os.environ["RUN_ROOT_ABS"]).resolve()

selected_ids: list[str] = []

for entry in manifest["entries"]:
    spec_path = spec_dir / entry["filename"]
    assert sha256_file(spec_path) == entry["file_sha256"]

    payload = json.loads(
        spec_path.read_text(encoding="utf-8")
    )
    validate_execution_spec(payload)

    inputs = load_execution_inputs(spec_path)
    assert len(inputs.instances) == 6
    assert not inputs.output_dir.exists()
    assert inputs.output_dir.parent == run_root

    selected_ids.extend(
        instance.canonical_instance_id
        for instance in inputs.instances
    )

assert len(selected_ids) == 60
assert len(set(selected_ids)) == 60
assert not list(
    run_root.glob(
        "objective_count_stage10_rep_*_canonical"
    )
)

print("post_merge_execution_spec_validation=PASS")
print("canonical_execution_spec_count=10")
print("canonical_selected_instance_count=60")
print("canonical_unique_selected_instance_count=60")
print("canonical_run_count=0")
PY

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

test -z "$(git status --porcelain)"

echo "post_merge_execution_spec_integrity_gate=PASS"

echo
echo "=== 11. Post-merge full regression ==="

"$PYTHON" \
  backend/harness/sensitivity_execution/validate_e3_contract.py

"$PYTHON" -m pytest \
  backend/harness/sensitivity_execution/tests \
  -q \
  -p no:cacheprovider

"$PYTHON" -m pytest \
  backend/harness/sensitivity_generator/tests \
  -q \
  -p no:cacheprovider

test -z "$(git status --porcelain)"

echo "post_merge_full_regression_gate=PASS"

echo
echo "=== 12. Verify final PR state ==="

FINAL_PR="$(
  gh pr view "$PR" \
    --repo "$REPO" \
    --json \
state,mergedAt,mergeCommit
)"

jq -e \
  --arg merge_commit "$BASE_HEAD" \
  '
    .state == "MERGED"
    and .mergedAt != null
    and .mergeCommit.oid == $merge_commit
  ' <<<"$FINAL_PR" >/dev/null

jq '{
  state,
  mergedAt,
  mergeCommit: .mergeCommit.oid
}' <<<"$FINAL_PR"

echo "pr_final_state=PASS"

echo
echo "=== 13. Cleanup local execution-spec branch ==="

if git show-ref \
  --verify \
  --quiet \
  "refs/heads/$BRANCH"
then
  git branch \
    -d \
    "$BRANCH"
fi

test -z "$(git status --porcelain)"

echo "local_branch_cleanup=PASS"

echo
echo "=== 14. Final state ==="

echo "sa5_objective_count_stage10_execution_spec_merge=PASS"
echo "base_head=$BASE_HEAD"
echo "feature_commit=$EXPECTED_FEATURE_HEAD"
echo "pull_request=$PR"
echo "ci_mode=$CI_MODE"

if [ "$CI_MODE" = "workflow_ineligible" ]; then
  CI_AUDIT_REPORT_SHA="$(
    sha256sum "$CI_AUDIT_REPORT" |
      awk '{print $1}'
  )"

  CI_AUDIT_SURFACE_SHA="$(
    sha256sum "$CI_AUDIT_SURFACE" |
      awk '{print $1}'
  )"

  echo "ci_audit_report=$CI_AUDIT_REPORT"
  echo "ci_audit_report_sha256=$CI_AUDIT_REPORT_SHA"
  echo "ci_audit_surface=$CI_AUDIT_SURFACE"
  echo "ci_audit_surface_sha256=$CI_AUDIT_SURFACE_SHA"
fi

echo "pre_merge_full_regression=PASS"
echo "post_merge_full_regression=PASS"

echo "canonical_execution_spec_count=10"
echo "selected_instances_per_spec=6"
echo "total_selected_instance_count=60"
echo "unique_selected_instance_count=60"
echo "total_merged_file_count=13"

echo "canonical_execution_spec_manifest_sha256=$EXPECTED_SPEC_MANIFEST_SHA"
echo "materialization_report_sha256=$EXPECTED_MATERIALIZATION_REPORT_SHA"
echo "materialization_summary_sha256=$EXPECTED_MATERIALIZATION_SUMMARY_SHA"

echo "canonical_execution_specs_materialized=true"
echo "canonical_execution_specs_committed=true"
echo "canonical_stage10_functional_execution_performed=false"
echo "canonical_functional_execution_authorized=false"
echo "timing_execution_performed=false"
echo "precision_analysis_performed=false"
echo "bootstrap_analysis_performed=false"
echo "scientific_execution_performed=false"
echo "manuscript_modified=false"

echo "functional_execution_authorization_audit_eligible=true"
echo "next_stage=audit_sa5_objective_count_stage10_functional_execution_authorization"

git status --short --branch
git log --oneline --decorate -6
