#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="ef2baf868f3531297bc33bda6549648696c6d988"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED_FRAGMENT="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

CONTROLLED="backend/harness/sensitivity_generator/families/controlled_families.py"
STRUCTURAL="backend/harness/sensitivity_generator/structural_generator.py"
EXECUTOR="backend/harness/sensitivity_execution/execute_controlled_family.py"
E3_VALIDATOR="backend/harness/sensitivity_execution/validate_e3_contract.py"

CONTROLLED_TEST="backend/harness/sensitivity_generator/tests/test_controlled_families.py"
COMPATIBILITY_TEST="backend/harness/sensitivity_execution/tests/test_membership_density_compatibility.py"
E3_CONTRACT_TEST="backend/harness/sensitivity_execution/tests/test_e3_contract.py"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_ROOT="/workspaces/sa5_objective_count_exact_patch_surface_${STAMP}"
SURFACE="$OUT_ROOT/sa5_objective_count_exact_patch_surface.txt"
MANIFEST="$OUT_ROOT/sa5_objective_count_exact_patch_surface.json"

trap 'echo "[ERROR] Exact SA5 surface extraction stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Exact-surface gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

for FILE in \
  "$MANUSCRIPT" \
  "$DEFERRED_FRAGMENT" \
  "$CONTROLLED" \
  "$STRUCTURAL" \
  "$EXECUTOR" \
  "$E3_VALIDATOR" \
  "$CONTROLLED_TEST" \
  "$COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST"
do
  test -f "$FILE"
done

MANUSCRIPT_SHA_BEFORE="$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)"

FRAGMENT_SHA_BEFORE="$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)"

echo "exact_surface_gate=PASS"
echo "repository_modified=false"
echo "scientific_execution_performed=false"
echo "campaign_execution_authorized=false"

echo
echo "=== 2. Extract exact definitions and dependencies ==="

rm -rf "$OUT_ROOT"
mkdir -p "$OUT_ROOT"

python3 - \
  "$ROOT" \
  "$SURFACE" \
  "$MANIFEST" \
  "$CONTROLLED" \
  "$STRUCTURAL" \
  "$EXECUTOR" \
  "$E3_VALIDATOR" \
  "$CONTROLLED_TEST" \
  "$COMPATIBILITY_TEST" \
  "$E3_CONTRACT_TEST" <<'PY'
from __future__ import annotations

import ast
import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Iterable

root = Path(sys.argv[1]).resolve()
surface_path = Path(sys.argv[2]).resolve()
manifest_path = Path(sys.argv[3]).resolve()

files = sys.argv[4:]

root_definitions: dict[str, tuple[str, ...]] = {
    files[0]: (
        "ControlledFamilySpec",
        "InstanceRecord",
        "ControlledFamilyManifest",
        "validate_spec",
        "stable_spec_payload",
        "factor_configuration",
        "objective_identifier",
        "build_instance_record",
        "validate_ofat_invariants",
        "generate_controlled_family",
    ),
    files[1]: (
        "StructuralConfig",
        "StructuralManifest",
        "build_objectives_document",
        "write_yaml",
        "count_structure",
        "validate_reference_integrity",
        "validate_graph_projection",
        "generate_structural_instance",
    ),
    files[2]: (
        "_expected_generator_versions",
        "DiscoveredInstance",
        "ExecutionInputs",
        "_load_instance_rows",
        "_discover_all_instances",
        "_base_instance_manifest",
    ),
    files[3]: (
        "validate_contract",
    ),
}

relevant_assignment_names: dict[str, tuple[str, ...]] = {
    files[0]: (
        "CAMPAIGN_GENERATOR_VERSION",
        "STRUCTURAL_GENERATOR_VERSION",
        "SUPPORTED_FACTORS",
        "INSTANCE_COLUMNS",
    ),
    files[1]: (
        "GENERATOR_VERSION",
    ),
    files[2]: (
        "E3_EXECUTOR_VERSION",
        "SUPPORTED_GENERATOR_VERSION_PAIRS",
        "INSTANCE_RESULT_COLUMNS",
    ),
    files[3]: (
        "REQUIRED_TOP_LEVEL_KEYS",
        "REQUIRED_EXECUTION_KEYS",
    ),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_segment(
    text: str,
    node: ast.AST,
) -> str:
    segment = ast.get_source_segment(text, node)

    if segment is None:
        raise SystemExit(
            f"Unable to extract source at line "
            f"{getattr(node, 'lineno', '?')}."
        )

    return segment


def assigned_names(node: ast.AST) -> set[str]:
    names: set[str] = set()

    targets: Iterable[ast.AST]

    if isinstance(node, ast.Assign):
        targets = node.targets
    elif isinstance(node, ast.AnnAssign):
        targets = (node.target,)
    else:
        return names

    for target in targets:
        for child in ast.walk(target):
            if isinstance(child, ast.Name):
                names.add(child.id)

    return names


def referenced_names(node: ast.AST) -> set[str]:
    return {
        child.id
        for child in ast.walk(node)
        if isinstance(child, ast.Name)
        and isinstance(child.ctx, ast.Load)
    }


def top_level_maps(
    tree: ast.Module,
) -> tuple[
    dict[str, ast.AST],
    dict[str, ast.AST],
]:
    definitions: dict[str, ast.AST] = {}
    assignments: dict[str, ast.AST] = {}

    for node in tree.body:
        if isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        ):
            definitions[node.name] = node

        elif isinstance(
            node,
            (ast.Assign, ast.AnnAssign),
        ):
            for name in assigned_names(node):
                assignments[name] = node

    return definitions, assignments


def dependency_closure(
    roots: Iterable[str],
    definitions: dict[str, ast.AST],
    assignments: dict[str, ast.AST],
) -> tuple[set[str], set[str]]:
    selected_definitions: set[str] = set()
    selected_assignments: set[str] = set()

    queue = list(roots)

    while queue:
        name = queue.pop()

        if name in definitions:
            if name in selected_definitions:
                continue

            selected_definitions.add(name)
            node = definitions[name]

        elif name in assignments:
            if name in selected_assignments:
                continue

            selected_assignments.add(name)
            node = assignments[name]

        else:
            continue

        for referenced in referenced_names(node):
            if (
                referenced in definitions
                and referenced not in selected_definitions
            ):
                queue.append(referenced)

            if (
                referenced in assignments
                and referenced not in selected_assignments
            ):
                queue.append(referenced)

    return selected_definitions, selected_assignments


def render_imports(
    text: str,
    tree: ast.Module,
) -> list[str]:
    rendered: list[str] = []

    for node in tree.body:
        if isinstance(
            node,
            (ast.Import, ast.ImportFrom),
        ):
            rendered.append(source_segment(text, node))

    return rendered


def render_selected_module(
    relative_path: str,
    roots: tuple[str, ...],
    assignment_roots: tuple[str, ...],
) -> tuple[str, dict[str, Any]]:
    path = root / relative_path
    text = path.read_text(encoding="utf-8")
    tree = ast.parse(text)

    definitions, assignments = top_level_maps(tree)

    selected_definitions, selected_assignments = (
        dependency_closure(
            (*roots, *assignment_roots),
            definitions,
            assignments,
        )
    )

    missing_roots = sorted(
        name
        for name in roots
        if name not in definitions
    )

    selected_nodes: list[ast.AST] = []

    seen_node_ids: set[int] = set()

    for name in selected_assignments:
        node = assignments[name]

        if id(node) not in seen_node_ids:
            selected_nodes.append(node)
            seen_node_ids.add(id(node))

    for name in selected_definitions:
        node = definitions[name]

        if id(node) not in seen_node_ids:
            selected_nodes.append(node)
            seen_node_ids.add(id(node))

    selected_nodes.sort(
        key=lambda node: getattr(node, "lineno", 0)
    )

    lines = [
        "=" * 100,
        f"FILE={relative_path}",
        f"SHA256={sha256(path)}",
        f"LINE_COUNT={len(text.splitlines())}",
        "=" * 100,
        "",
        "--- IMPORTS ---",
        "",
        *render_imports(text, tree),
        "",
        "--- SELECTED ASSIGNMENTS AND DEFINITIONS ---",
    ]

    selected_records: list[dict[str, Any]] = []

    for node in selected_nodes:
        start = getattr(node, "lineno", None)
        end = getattr(node, "end_lineno", start)

        if isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        ):
            name = node.name
            kind = type(node).__name__
        else:
            names = sorted(assigned_names(node))
            name = ",".join(names)
            kind = type(node).__name__

        lines.extend([
            "",
            f"### {kind} {name} [{start}-{end}]",
            source_segment(text, node),
        ])

        selected_records.append({
            "name": name,
            "kind": kind,
            "start_line": start,
            "end_line": end,
        })

    return "\n".join(lines) + "\n", {
        "path": relative_path,
        "sha256": sha256(path),
        "line_count": len(text.splitlines()),
        "requested_roots": list(roots),
        "missing_roots": missing_roots,
        "selected_nodes": selected_records,
    }


def render_test_module(
    relative_path: str,
) -> tuple[str, dict[str, Any]]:
    path = root / relative_path
    text = path.read_text(encoding="utf-8")
    tree = ast.parse(text)

    definitions, assignments = top_level_maps(tree)

    test_roots = tuple(
        name
        for name in definitions
        if (
            name.startswith("test_")
            or name.startswith("generate_")
            or name.startswith("make_")
            or name.startswith("read_")
        )
    )

    assignment_roots = tuple(assignments)

    selected_definitions, selected_assignments = (
        dependency_closure(
            (*test_roots, *assignment_roots),
            definitions,
            assignments,
        )
    )

    selected_nodes: list[ast.AST] = []
    seen_node_ids: set[int] = set()

    for name in selected_assignments:
        node = assignments[name]

        if id(node) not in seen_node_ids:
            selected_nodes.append(node)
            seen_node_ids.add(id(node))

    for name in selected_definitions:
        node = definitions[name]

        if id(node) not in seen_node_ids:
            selected_nodes.append(node)
            seen_node_ids.add(id(node))

    selected_nodes.sort(
        key=lambda node: getattr(node, "lineno", 0)
    )

    lines = [
        "=" * 100,
        f"FILE={relative_path}",
        f"SHA256={sha256(path)}",
        f"LINE_COUNT={len(text.splitlines())}",
        "=" * 100,
        "",
        "--- IMPORTS ---",
        "",
        *render_imports(text, tree),
        "",
        "--- TEST HELPERS AND TEST DEFINITIONS ---",
    ]

    selected_records: list[dict[str, Any]] = []

    for node in selected_nodes:
        start = getattr(node, "lineno", None)
        end = getattr(node, "end_lineno", start)

        if isinstance(
            node,
            (
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        ):
            name = node.name
            kind = type(node).__name__
        else:
            names = sorted(assigned_names(node))
            name = ",".join(names)
            kind = type(node).__name__

        lines.extend([
            "",
            f"### {kind} {name} [{start}-{end}]",
            source_segment(text, node),
        ])

        selected_records.append({
            "name": name,
            "kind": kind,
            "start_line": start,
            "end_line": end,
        })

    return "\n".join(lines) + "\n", {
        "path": relative_path,
        "sha256": sha256(path),
        "line_count": len(text.splitlines()),
        "selected_nodes": selected_records,
    }


sections: list[str] = []
records: list[dict[str, Any]] = []

for relative_path in files[:4]:
    rendered, record = render_selected_module(
        relative_path,
        root_definitions[relative_path],
        relevant_assignment_names.get(
            relative_path,
            (),
        ),
    )

    sections.append(rendered)
    records.append(record)

for relative_path in files[4:]:
    rendered, record = render_test_module(
        relative_path
    )

    sections.append(rendered)
    records.append(record)

surface_path.write_text(
    "\n".join(sections),
    encoding="utf-8",
)

manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-"
        "exact-patch-surface-v1"
    ),
    "source_commit": (
        "ef2baf868f3531297bc33bda6549648696c6d988"
    ),
    "read_only": True,
    "file_count": len(records),
    "surface_file": str(surface_path),
    "surface_sha256": sha256(surface_path),
    "surface_size_bytes": surface_path.stat().st_size,
    "files": records,
}

manifest_path.write_text(
    json.dumps(
        manifest,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

missing = [
    {
        "path": record["path"],
        "roots": record.get("missing_roots", []),
    }
    for record in records
    if record.get("missing_roots")
]

print("exact_patch_surface_extraction=PASS")
print(f"surface_file={surface_path}")
print(f"surface_sha256={sha256(surface_path)}")
print(f"surface_size_bytes={surface_path.stat().st_size}")
print(f"source_file_count={len(records)}")
print(f"files_with_missing_requested_roots={len(missing)}")

for record in missing:
    print(
        f"missing_roots_file={record['path']} "
        f"roots={','.join(record['roots'])}"
    )
PY

test -s "$SURFACE"
test -s "$MANIFEST"

SURFACE_SHA="$(
  sha256sum "$SURFACE" |
    awk '{print $1}'
)"

SURFACE_SIZE="$(
  stat -c '%s' "$SURFACE"
)"

jq -e \
  --arg sha "$SURFACE_SHA" \
  --argjson size "$SURFACE_SIZE" \
  '
    .schema_version
      == "mcad-sa5-objective-count-exact-patch-surface-v1"
    and .source_commit
      == "ef2baf868f3531297bc33bda6549648696c6d988"
    and .read_only == true
    and .file_count == 7
    and .surface_sha256 == $sha
    and .surface_size_bytes == $size
  ' "$MANIFEST" >/dev/null

echo
echo "=== 3. Exact-surface summary ==="

jq '{
  source_commit,
  file_count,
  surface_file,
  surface_sha256,
  surface_size_bytes,
  files: [
    .files[] | {
      path,
      sha256,
      line_count,
      missing_roots,
      selected_node_count:
        (.selected_nodes | length)
    }
  ]
}' "$MANIFEST"

echo
echo "=== 4. Final immutability gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test "$(
  sha256sum "$MANUSCRIPT" |
    awk '{print $1}'
)" = "$MANUSCRIPT_SHA_BEFORE"

test "$(
  sha256sum "$DEFERRED_FRAGMENT" |
    awk '{print $1}'
)" = "$FRAGMENT_SHA_BEFORE"

echo "sa5_objective_count_exact_patch_surface=PASS"
echo "repository_modified=false"
echo "manuscript_modified=false"
echo "scientific_execution_performed=false"
echo "campaign_execution_authorized=false"
echo "surface_file=$SURFACE"
echo "surface_manifest=$MANIFEST"
echo "surface_sha256=$SURFACE_SHA"
echo "surface_size_bytes=$SURFACE_SIZE"
echo "next_stage=author_single_sa5_objective_count_implementation_patch"

git status --short --branch
