#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="20dfec11a502cc0fccbcc07f6e2df0734debe29c"

E3="reports/article_experiments/sensitivity/e3_controlled_execution"
SETUP_ROOT="$E3/timing_setup/objective_count_stage10_portfolio"
SETUP_SPECS="$SETUP_ROOT/specs"

SETUP_MANIFEST="$SETUP_ROOT/objective_count_stage10_timing_setup_manifest.json"
EXPECTED_SETUP_MANIFEST_SHA="5e5baad8a32d5c9c8e647d8d2365d68a9e3a286e620fc783373ec577a26cf155"

SETUP_FILES="$SETUP_ROOT/objective_count_stage10_timing_setup_files.sha256"
EXPECTED_SETUP_FILES_SHA="c785ab0fafc1c424e7a737d0dfd4282cb01b7ef071cf54c2adeb4304fb9ad9af"

AUTHORIZATION="$E3/planning/sa5_objective_count_stage10_timing_execution_authorization.json"
EXPECTED_AUTHORIZATION_SHA="bb8805eaaedb3277e25197a1eab2d5b4e484aa66006fc4a4dcf0bff424b47c20"

RUNNER_MODULE="backend.harness.sensitivity_execution.run_timing_repetitions"
RUNNER_FILE="backend/harness/sensitivity_execution/run_timing_repetitions.py"
EXPECTED_RUNNER_SHA="6332cc63f8e50ee25df782b3b34b7110c7f5abb4af25bb6fcfd5cde5d18a7595"

TIMING_RUN_ROOT="$E3/timing_runs/objective_count_stage10_portfolio"

EVIDENCE_ROOT="$E3/audits/objective_count_stage10_c8_nv32/timing_execution"
EVIDENCE_LOG_ROOT="$EVIDENCE_ROOT/logs"
REBINDING_MANIFEST="$EVIDENCE_ROOT/execution_path_rebinding_manifest.json"
RUN_FILE_MANIFEST="$EVIDENCE_ROOT/objective_count_stage10_timing_run_files.sha256"
EVIDENCE_MANIFEST="$EVIDENCE_ROOT/objective_count_stage10_timing_execution_evidence.json"

PLANNING_REPORT="$E3/planning/sa5_objective_count_stage10_timing_execution_report.json"
PLANNING_SUMMARY="$E3/planning/sa5_objective_count_stage10_timing_execution_report.md"

MANUSCRIPT="MCAD_audited_real_main_fr.tex"
DEFERRED="experiments/article/deferred_manuscript_fragments/sa4_membership_density_stage10_results_deferred.tex"

VENV="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"
PYTHON="$VENV"
[ -x "$PYTHON" ] || PYTHON="$(command -v python3)"

FAILED_ROOT="/workspaces/sa5_objective_count_stage10_timing_execution_20260805T160000Z"
FAILED_PLAN="$FAILED_ROOT/timing_execution_plan.json"
EXPECTED_FAILED_PLAN_SHA="e9004f2692e057b7ad3fdc5d686aeba9be43adf259f4961dd2277747c892d6eb"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
DETACHED_ROOT="/workspaces/sa5_objective_count_stage10_timing_execution_recovery_${STAMP}"
ADAPTED_SPEC_ROOT="$DETACHED_ROOT/adapted_execution_specs"
DETACHED_LOG_ROOT="$DETACHED_ROOT/logs"
QUARANTINE_ROOT="$DETACHED_ROOT/quarantine"
DETACHED_REBINDING="$DETACHED_ROOT/execution_path_rebinding_manifest.json"

BRANCH="paper/persist-sa5-objective-count-stage10-timing-${STAMP}"

TMP_ROOT="$(mktemp -d /workspaces/sa5_timing_recovery.XXXXXX)"

cleanup() {
  rm -rf "$TMP_ROOT"
}

trap cleanup EXIT
trap 'echo "[ERROR] SA5 timing recovery stopped at line $LINENO."' ERR

cd "$ROOT"

verify_sha() {
  test -f "$1"
  test "$(sha256sum "$1" | awk '{print $1}')" = "$2"
}

echo "=== 1. Resume gate after pre-execution path-resolution failure ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git fetch origin --prune
test "$(git rev-parse "origin/$BASE")" = "$EXPECTED_HEAD"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$SETUP_FILES" "$EXPECTED_SETUP_FILES_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
verify_sha "$RUNNER_FILE" "$EXPECTED_RUNNER_SHA"
verify_sha "$FAILED_PLAN" "$EXPECTED_FAILED_PLAN_SHA"

sha256sum -c "$SETUP_FILES" >/dev/null

jq -e '
  .timing_execution_authorized == true
  and .timing_execution_performed == false
  and .timing_spec_count == 10
  and .expected_total_observation_rows == 151800
  and .next_stage == "execute_sa5_objective_count_stage10_timing_campaign"
' "$AUTHORIZATION" >/dev/null

test ! -e "$EVIDENCE_ROOT"
test ! -e "$PLANNING_REPORT"
test ! -e "$PLANNING_SUMMARY"

MANUSCRIPT_SHA="$(sha256sum "$MANUSCRIPT" | awk '{print $1}')"
DEFERRED_SHA="$(sha256sum "$DEFERRED" | awk '{print $1}')"

mkdir -p \
  "$ADAPTED_SPEC_ROOT" \
  "$DETACHED_LOG_ROOT" \
  "$QUARANTINE_ROOT"

echo "resume_gate=PASS"
echo "prior_failure_stage=first_timing_replication_before_measurement"
echo "prior_failure_cause=relative_immutable_paths_resolved_outside_repository"
echo "prior_timing_observations_completed=0"
echo "timing_execution_authorized=true"

echo
echo "=== 2. Create detached path-rebound execution specifications ==="

export ROOT E3 SETUP_SPECS ADAPTED_SPEC_ROOT DETACHED_REBINDING
export EXPECTED_HEAD

export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=0
export PYTHONPATH="$ROOT"

"$PYTHON" - <<'PY'
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
from typing import Any

from backend.harness.sensitivity_execution.execute_controlled_family import (
    load_execution_inputs,
)
from backend.harness.sensitivity_execution.validate_execution_spec import (
    validate_execution_spec,
)


root = Path(os.environ["ROOT"]).resolve()
e3_root = (root / os.environ["E3"]).resolve()
setup_spec_root = (root / os.environ["SETUP_SPECS"]).resolve()
adapted_root = Path(os.environ["ADAPTED_SPEC_ROOT"]).resolve()
manifest_path = Path(os.environ["DETACHED_REBINDING"]).resolve()


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    assert isinstance(value, dict)
    return value


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(
            value,
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            allow_nan=False,
        ) + "\n",
        encoding="utf-8",
    )


path_key_tokens = (
    "path",
    "file",
    "dir",
    "root",
    "manifest",
    "spec",
    "csv",
    "workload",
)


def resolve_existing_relative(
    value: str,
    source_dir: Path,
) -> Path | None:
    candidate_value = Path(value)

    if candidate_value.is_absolute():
        return candidate_value if candidate_value.exists() else None

    candidates = [
        (source_dir / candidate_value).resolve(),
        (e3_root / candidate_value).resolve(),
        (root / candidate_value).resolve(),
    ]

    existing = []
    for candidate in candidates:
        if candidate.exists() and candidate not in existing:
            existing.append(candidate)

    if len(existing) == 1:
        return existing[0]

    if len(existing) > 1:
        # Prefer canonical E3-relative paths, then repository-relative paths.
        for preferred_root in (e3_root, root, source_dir):
            for candidate in existing:
                try:
                    candidate.relative_to(preferred_root)
                except ValueError:
                    continue
                return candidate

    return None


def rebind(
    value: Any,
    source_dir: Path,
    mappings: list[dict[str, str]],
    key: str = "",
) -> Any:
    if isinstance(value, dict):
        return {
            child_key: rebind(
                child,
                source_dir,
                mappings,
                str(child_key),
            )
            for child_key, child in value.items()
        }

    if isinstance(value, list):
        return [
            rebind(child, source_dir, mappings, key)
            for child in value
        ]

    if not isinstance(value, str):
        return value

    lowered_key = key.lower()
    looks_like_path = any(
        token in lowered_key for token in path_key_tokens
    )

    if not looks_like_path:
        return value

    resolved = resolve_existing_relative(value, source_dir)
    if resolved is None:
        return value

    resolved_text = str(resolved)
    if resolved_text == value:
        return value

    mappings.append({
        "key": key,
        "original": value,
        "rebound": resolved_text,
    })
    return resolved_text


rows = []
total_mapping_count = 0

for index in range(10):
    token = f"{index:03d}"
    timing_spec_path = (
        setup_spec_root
        / f"objective_count_rep_{token}_portfolio_timing_stage10.json"
    )
    timing_spec = read_json(timing_spec_path)

    original_path = (
        root / timing_spec["functional_execution_spec"]
    ).resolve()
    assert original_path.is_file()
    assert sha(original_path) == timing_spec[
        "functional_execution_spec_sha256"
    ]

    original = read_json(original_path)
    adapted = copy.deepcopy(original)
    mappings: list[dict[str, str]] = []

    adapted = rebind(
        adapted,
        original_path.parent,
        mappings,
    )

    assert mappings
    validate_execution_spec(adapted)

    adapted_path = (
        adapted_root
        / f"objective_count_stage10_rep_{token}_path_rebound.json"
    )
    write_json(adapted_path, adapted)

    # This is a non-executing input-construction check. It must find every
    # immutable file and construct all six instances successfully.
    inputs = load_execution_inputs(adapted_path)
    assert len(inputs.instances) == 6
    assert [
        item.factor_level for item in inputs.instances
    ] == [1, 2, 5, 10, 20, 50]

    assert original.get("execution_id") == adapted.get("execution_id")

    total_mapping_count += len(mappings)

    rows.append({
        "replication_index": index,
        "timing_spec_path": timing_spec_path.relative_to(root).as_posix(),
        "timing_spec_sha256": sha(timing_spec_path),
        "original_execution_spec_path": (
            original_path.relative_to(root).as_posix()
        ),
        "original_execution_spec_sha256": sha(original_path),
        "adapted_execution_spec_path": str(adapted_path),
        "adapted_execution_spec_sha256": sha(adapted_path),
        "mapping_count": len(mappings),
        "mappings": mappings,
        "load_execution_inputs": "PASS",
        "instance_count": 6,
        "factor_levels": [1, 2, 5, 10, 20, 50],
    })

assert len(rows) == 10
assert total_mapping_count >= 40

manifest = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-"
        "execution-path-rebinding-manifest-v1"
    ),
    "status": "detached_path_rebinding_complete",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "reason": (
        "Committed execution specs intentionally store E3-relative paths; "
        "the timing runner resolves them against the process working "
        "directory. Detached copies rebind only path-valued immutable "
        "inputs to absolute repository paths."
    ),
    "original_specs_modified": False,
    "functional_outputs_modified": False,
    "evaluator_called_during_rebinding": False,
    "replication_count": 10,
    "total_mapping_count": total_mapping_count,
    "rows": rows,
    "timing_execution_performed": False,
}

write_json(manifest_path, manifest)

print("path_rebinding=PASS")
print("adapted_execution_spec_count=10")
print(f"total_path_mapping_count={total_mapping_count}")
print("load_execution_inputs_count=10")
print("evaluator_called_during_rebinding=false")
print(f"detached_rebinding_manifest={manifest_path}")
print(f"detached_rebinding_manifest_sha256={sha(manifest_path)}")
PY

echo
echo "=== 3. Quarantine only incomplete prior timing output ==="

REUSABLE_BEFORE=0
QUARANTINED_COUNT=0

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  SPEC="$SETUP_SPECS/objective_count_rep_${TOKEN}_portfolio_timing_stage10.json"
  OUTPUT_DIR="$(jq -r '.timing_output_dir' "$SPEC")"

  if [ ! -e "$OUTPUT_DIR" ]; then
    continue
  fi

  COMPLETE=true

  for NAME in \
    timing_manifest.json \
    timing_observations.csv \
    timing_summary.json \
    functional_references.json
  do
    [ -s "$OUTPUT_DIR/$NAME" ] || COMPLETE=false
  done

  if [ "$COMPLETE" = true ]; then
    ROWS="$(
      awk 'END {print NR > 0 ? NR - 1 : 0}' \
        "$OUTPUT_DIR/timing_observations.csv"
    )"
    [ "$ROWS" -eq 15180 ] || COMPLETE=false
  fi

  if [ "$COMPLETE" = true ]; then
    REUSABLE_BEFORE="$((REUSABLE_BEFORE + 1))"
  else
    mv "$OUTPUT_DIR" \
      "$QUARANTINE_ROOT/rep_${TOKEN}_incomplete"
    QUARANTINED_COUNT="$((QUARANTINED_COUNT + 1))"
  fi
done

echo "partial_output_recovery_gate=PASS"
echo "reusable_complete_replication_count_before_run=$REUSABLE_BEFORE"
echo "quarantined_incomplete_replication_count=$QUARANTINED_COUNT"

echo
echo "=== 4. Execute or resume ten timing replications ==="

SUCCESSFUL_REPLICATIONS=0
TOTAL_STARTED_AT="$(date +%s)"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"

  TIMING_SPEC="$SETUP_SPECS/objective_count_rep_${TOKEN}_portfolio_timing_stage10.json"
  ADAPTED_SPEC="$ADAPTED_SPEC_ROOT/objective_count_stage10_rep_${TOKEN}_path_rebound.json"
  OUTPUT_DIR="$(jq -r '.timing_output_dir' "$TIMING_SPEC")"
  LOG="$DETACHED_LOG_ROOT/rep_${TOKEN}.log"

  test -f "$ADAPTED_SPEC"

  echo
  echo "--- timing replication $TOKEN ---"
  echo "adapted_execution_spec=$ADAPTED_SPEC"
  echo "output_dir=$OUTPUT_DIR"
  echo "expected_observation_rows=15180"

  STARTED_AT="$(date +%s)"

  "$PYTHON" \
    -m "$RUNNER_MODULE" \
    "$ADAPTED_SPEC" \
    --output-dir "$OUTPUT_DIR" \
    --warmups 10 \
    --measurements 100 \
    --order-seed 20260728 \
    --reuse-successful \
    2>&1 |
    tee "$LOG"

  ELAPSED="$(( $(date +%s) - STARTED_AT ))"

  test -d "$OUTPUT_DIR"

  for NAME in \
    timing_manifest.json \
    timing_observations.csv \
    timing_summary.json \
    functional_references.json
  do
    test -s "$OUTPUT_DIR/$NAME"
  done

  test "$(find "$OUTPUT_DIR" -maxdepth 1 -type f | wc -l)" -eq 4

  ACTUAL_ROWS="$(
    awk 'END {print NR > 0 ? NR - 1 : 0}' \
      "$OUTPUT_DIR/timing_observations.csv"
  )"

  test "$ACTUAL_ROWS" -eq 15180

  "$PYTHON" - <<PY
import json
from pathlib import Path

for name in (
    "timing_manifest.json",
    "timing_summary.json",
    "functional_references.json",
):
    path = Path("$OUTPUT_DIR") / name
    json.loads(path.read_text(encoding="utf-8"))
PY

  SUCCESSFUL_REPLICATIONS="$((SUCCESSFUL_REPLICATIONS + 1))"

  echo "replication_${TOKEN}=PASS"
  echo "replication_${TOKEN}_observation_rows=$ACTUAL_ROWS"
  echo "replication_${TOKEN}_elapsed_seconds=$ELAPSED"
done

test "$SUCCESSFUL_REPLICATIONS" -eq 10

TOTAL_ELAPSED="$(( $(date +%s) - TOTAL_STARTED_AT ))"

echo
echo "timing_process_execution=PASS"
echo "successful_replication_count=10"
echo "total_execution_elapsed_seconds=$TOTAL_ELAPSED"

echo
echo "=== 5. Audit outputs and materialize exact evidence ==="

mkdir -p "$EVIDENCE_LOG_ROOT"

for INDEX in $(seq 0 9); do
  TOKEN="$(printf '%03d' "$INDEX")"
  cp "$DETACHED_LOG_ROOT/rep_${TOKEN}.log" \
    "$EVIDENCE_LOG_ROOT/rep_${TOKEN}.log"
done

cp "$DETACHED_REBINDING" "$REBINDING_MANIFEST"

export EVIDENCE_ROOT EVIDENCE_LOG_ROOT REBINDING_MANIFEST
export RUN_FILE_MANIFEST EVIDENCE_MANIFEST
export PLANNING_REPORT PLANNING_SUMMARY
export AUTHORIZATION TIMING_RUN_ROOT TOTAL_ELAPSED

"$PYTHON" - <<'PY'
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any, Iterable


root = Path(os.environ["ROOT"]).resolve()
spec_root = root / os.environ["SETUP_SPECS"]
timing_root = root / os.environ["TIMING_RUN_ROOT"]
log_root = root / os.environ["EVIDENCE_LOG_ROOT"]

rebinding_path = root / os.environ["REBINDING_MANIFEST"]
run_manifest_path = root / os.environ["RUN_FILE_MANIFEST"]
evidence_path = root / os.environ["EVIDENCE_MANIFEST"]
planning_report_path = root / os.environ["PLANNING_REPORT"]
planning_summary_path = root / os.environ["PLANNING_SUMMARY"]
authorization_path = root / os.environ["AUTHORIZATION"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def explicit_failures(value: Any) -> list[dict[str, str]]:
    failure_values = {
        "FAIL",
        "FAILED",
        "ERROR",
        "ABORTED",
        "CANCELLED",
    }
    rows: list[dict[str, str]] = []

    for node in walk(value):
        if not isinstance(node, dict):
            continue
        for key, child in node.items():
            normalized = str(key).lower().replace("-", "_")
            if (
                normalized in {
                    "status",
                    "execution_status",
                    "result_status",
                    "timing_status",
                }
                and isinstance(child, str)
                and child.upper() in failure_values
            ):
                rows.append({"key": normalized, "value": child})

    return rows


rebinding = read_json(rebinding_path)
assert rebinding["replication_count"] == 10
assert rebinding["original_specs_modified"] is False
assert rebinding["evaluator_called_during_rebinding"] is False

run_rows = []
all_run_files: list[Path] = []
headers: list[list[str]] = []
total_rows = 0
total_bytes = 0
explicit_failure_count = 0

for index in range(10):
    token = f"{index:03d}"
    timing_spec_path = (
        spec_root
        / f"objective_count_rep_{token}_portfolio_timing_stage10.json"
    )
    timing_spec = read_json(timing_spec_path)
    output_dir = root / timing_spec["timing_output_dir"]
    log_path = log_root / f"rep_{token}.log"

    expected_names = {
        "timing_manifest.json",
        "timing_observations.csv",
        "timing_summary.json",
        "functional_references.json",
    }
    files = sorted(path for path in output_dir.iterdir() if path.is_file())

    assert {path.name for path in files} == expected_names
    assert log_path.is_file() and log_path.stat().st_size > 0

    manifest = read_json(output_dir / "timing_manifest.json")
    summary = read_json(output_dir / "timing_summary.json")
    references = read_json(output_dir / "functional_references.json")

    failures = (
        explicit_failures(manifest)
        + explicit_failures(summary)
        + explicit_failures(references)
    )
    explicit_failure_count += len(failures)
    assert not failures

    csv_path = output_dir / "timing_observations.csv"
    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        header = list(reader.fieldnames or [])

    assert header
    assert len(rows) == 15180
    headers.append(header)

    for row in rows:
        for raw in row.values():
            if raw is None or raw == "":
                continue
            try:
                number = float(raw)
            except ValueError:
                continue
            assert math.isfinite(number)

    selected_ids = set(timing_spec["selected_instance_ids"])
    reference_strings = {
        node
        for node in walk(references)
        if isinstance(node, str)
    }
    assert selected_ids.issubset(reference_strings)

    log_text = log_path.read_text(encoding="utf-8")
    assert "Traceback" not in log_text
    assert "[ERROR]" not in log_text

    file_rows = [
        {
            "path": path.relative_to(root).as_posix(),
            "sha256": sha(path),
            "byte_count": path.stat().st_size,
        }
        for path in files
    ]

    output_bytes = sum(path.stat().st_size for path in files)
    total_bytes += output_bytes
    total_rows += len(rows)
    all_run_files.extend(files)

    run_rows.append({
        "replication_index": index,
        "seed": timing_spec["seed"],
        "timing_spec": timing_spec_path.relative_to(root).as_posix(),
        "timing_spec_sha256": sha(timing_spec_path),
        "timing_output_dir": output_dir.relative_to(root).as_posix(),
        "warmups": 10,
        "measurements": 100,
        "order_seed": 20260728,
        "observation_row_count": len(rows),
        "csv_header": header,
        "output_file_count": 4,
        "output_total_bytes": output_bytes,
        "files": file_rows,
        "log_path": log_path.relative_to(root).as_posix(),
        "log_sha256": sha(log_path),
        "status": "PASS",
    })

assert len(run_rows) == 10
assert total_rows == 151800
assert len(all_run_files) == 40
assert len({path.resolve() for path in all_run_files}) == 40
assert all(header == headers[0] for header in headers)
assert explicit_failure_count == 0

run_manifest_path.write_text(
    "".join(
        f"{sha(path)}  {path.relative_to(root).as_posix()}\n"
        for path in sorted(all_run_files)
    ),
    encoding="utf-8",
)

evidence = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-timing-execution-evidence-v1"
    ),
    "status": (
        "sa5_objective_count_stage10_timing_execution_complete_and_audited"
    ),
    "source_commit": os.environ["EXPECTED_HEAD"],
    "authorization": {
        "path": authorization_path.relative_to(root).as_posix(),
        "sha256": sha(authorization_path),
    },
    "path_rebinding": {
        "path": rebinding_path.relative_to(root).as_posix(),
        "sha256": sha(rebinding_path),
        "replication_count": 10,
        "original_specs_modified": False,
        "evaluator_called_during_rebinding": False,
    },
    "execution_parameters": {
        "runner_module": (
            "backend.harness.sensitivity_execution.run_timing_repetitions"
        ),
        "runner_sha256": os.environ["EXPECTED_RUNNER_SHA"],
        "warmups": 10,
        "measurements": 100,
        "order_seed": 20260728,
        "reuse_successful": True,
    },
    "completion": {
        "replication_count": 10,
        "successful_replication_count": 10,
        "failed_replication_count": 0,
        "factor_levels": [1, 2, 5, 10, 20, 50],
        "instance_count": 60,
        "observation_rows_per_replication": 15180,
        "total_observation_rows": total_rows,
        "timing_output_file_count": 40,
        "timing_output_total_bytes": total_bytes,
        "execution_log_count": 10,
        "explicit_failure_count": explicit_failure_count,
        "consistent_csv_schema": True,
        "finite_numeric_values": True,
        "runs": run_rows,
    },
    "canonical_run_file_manifest": {
        "path": run_manifest_path.relative_to(root).as_posix(),
        "sha256": sha(run_manifest_path),
        "line_count": 40,
    },
    "scientific_controls": {
        "timing_execution_performed": True,
        "timing_execution_completion_audited": True,
        "timing_values_interpreted": False,
        "precision_analysis_performed": False,
        "bootstrap_analysis_performed": False,
        "scientific_result_interpretation_performed": False,
        "scientific_freeze_performed": False,
        "manuscript_modified": False,
    },
    "authorization_decision": {
        "timing_evidence_commit_authorized": True,
        "precision_setup_authorized_after_merge": True,
        "precision_analysis_authorized": False,
        "bootstrap_analysis_authorized": False,
        "scientific_result_interpretation_authorized": False,
        "scientific_freeze_authorized": False,
        "manuscript_integration_authorized": False,
    },
    "blockers": [],
    "blocker_count": 0,
    "audit_complete": True,
    "next_stage": (
        "commit_and_merge_sa5_objective_count_stage10_timing_evidence"
    ),
}

evidence_path.write_text(
    json.dumps(
        evidence,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

planning = {
    "schema_version": (
        "mcad-sa5-objective-count-stage10-timing-execution-report-v1"
    ),
    "status": "timing_execution_evidence_materialized",
    "source_commit": os.environ["EXPECTED_HEAD"],
    "timing_execution_evidence": {
        "path": evidence_path.relative_to(root).as_posix(),
        "sha256": sha(evidence_path),
    },
    "path_rebinding_manifest": {
        "path": rebinding_path.relative_to(root).as_posix(),
        "sha256": sha(rebinding_path),
    },
    "canonical_run_file_manifest": {
        "path": run_manifest_path.relative_to(root).as_posix(),
        "sha256": sha(run_manifest_path),
    },
    "replication_count": 10,
    "successful_replication_count": 10,
    "failed_replication_count": 0,
    "total_observation_rows": total_rows,
    "timing_output_file_count": 40,
    "timing_output_total_bytes": total_bytes,
    "execution_log_count": 10,
    "total_execution_elapsed_seconds": int(
        os.environ["TOTAL_ELAPSED"]
    ),
    "timing_execution_performed": True,
    "timing_execution_completion_audited": True,
    "timing_values_interpreted": False,
    "precision_analysis_performed": False,
    "bootstrap_analysis_performed": False,
    "scientific_result_interpretation_performed": False,
    "manuscript_modified": False,
    "blockers": [],
    "blocker_count": 0,
    "report_complete": True,
    "next_stage": (
        "wait_for_ci_then_merge_sa5_objective_count_stage10_timing_evidence"
    ),
}

planning_report_path.write_text(
    json.dumps(
        planning,
        indent=2,
        ensure_ascii=False,
        sort_keys=True,
        allow_nan=False,
    ) + "\n",
    encoding="utf-8",
)

planning_summary_path.write_text(
    "\n".join([
        "# SA5 objective-count Stage-10 timing execution",
        "",
        "- Replications: `10/10 PASS`",
        "- Factor levels: `1, 2, 5, 10, 20, 50`",
        "- Warmups: `10`",
        "- Measurements: `100`",
        "- Order seed: `20260728`",
        "- Total timing observations: `151800`",
        "- Timing output files: `40`",
        f"- Timing output bytes: `{total_bytes}`",
        "- Execution logs: `10`",
        "- Explicit failures: `0`",
        "- E3-relative immutable paths: rebound in detached copies",
        "- Committed execution specs: unchanged",
        "- Timing execution: `performed and completion-audited`",
        "- Timing-value interpretation: `not performed`",
        "- Precision analysis: `not performed`",
        "- Bootstrap analysis: `not performed`",
        "- Manuscript modification: `not performed`",
        "",
        "Next stage: review and merge this timing-evidence-only change.",
        "",
    ]),
    encoding="utf-8",
)

print("timing_output_audit=PASS")
print("successful_replication_count=10")
print("failed_replication_count=0")
print("total_observation_rows=151800")
print("timing_output_file_count=40")
print(f"timing_output_total_bytes={total_bytes}")
print("execution_log_count=10")
print("explicit_failure_count=0")
print("consistent_csv_schema=true")
print("finite_numeric_values=true")
print(f"run_file_manifest_sha256={sha(run_manifest_path)}")
print(f"evidence_manifest_sha256={sha(evidence_path)}")
print(f"rebinding_manifest_sha256={sha(rebinding_path)}")
print(f"planning_report_sha256={sha(planning_report_path)}")
print(f"planning_summary_sha256={sha(planning_summary_path)}")
PY

test "$(wc -l < "$RUN_FILE_MANIFEST")" -eq 40
sha256sum -c "$RUN_FILE_MANIFEST" >/dev/null

jq -e '
  .status
    == "sa5_objective_count_stage10_timing_execution_complete_and_audited"
  and .source_commit
    == "20dfec11a502cc0fccbcc07f6e2df0734debe29c"
  and .path_rebinding.replication_count == 10
  and .path_rebinding.original_specs_modified == false
  and .path_rebinding.evaluator_called_during_rebinding == false
  and .completion.successful_replication_count == 10
  and .completion.failed_replication_count == 0
  and .completion.total_observation_rows == 151800
  and .completion.timing_output_file_count == 40
  and .completion.execution_log_count == 10
  and .completion.explicit_failure_count == 0
  and .completion.consistent_csv_schema == true
  and .completion.finite_numeric_values == true
  and .scientific_controls.timing_execution_performed == true
  and .scientific_controls.timing_execution_completion_audited == true
  and .scientific_controls.timing_values_interpreted == false
  and .scientific_controls.precision_analysis_performed == false
  and .scientific_controls.bootstrap_analysis_performed == false
  and .scientific_controls.manuscript_modified == false
  and .authorization_decision.timing_evidence_commit_authorized == true
  and .authorization_decision.precision_setup_authorized_after_merge == true
  and .authorization_decision.precision_analysis_authorized == false
  and .blocker_count == 0
  and .audit_complete == true
' "$EVIDENCE_MANIFEST" >/dev/null

echo "timing_evidence_validation=PASS"

echo
echo "=== 6. Repository and manuscript gate before persistence ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

verify_sha "$SETUP_MANIFEST" "$EXPECTED_SETUP_MANIFEST_SHA"
verify_sha "$AUTHORIZATION" "$EXPECTED_AUTHORIZATION_SHA"
verify_sha "$RUNNER_FILE" "$EXPECTED_RUNNER_SHA"

test "$(sha256sum "$MANUSCRIPT" | awk '{print $1}')" = "$MANUSCRIPT_SHA"
test "$(sha256sum "$DEFERRED" | awk '{print $1}')" = "$DEFERRED_SHA"

echo "pre_persistence_immutability_gate=PASS"
echo "committed_execution_specs_modified=false"
echo "manuscript_modified=false"

echo
echo "=== 7. Commit all Timing Evidence in one branch ==="

git switch -c "$BRANCH"

{
  awk '{print $2}' "$RUN_FILE_MANIFEST"
  find "$EVIDENCE_ROOT" -type f
  printf '%s\n' "$PLANNING_REPORT" "$PLANNING_SUMMARY"
} |
  sort -u > "$TMP_ROOT/expected_files.txt"

test "$(wc -l < "$TMP_ROOT/expected_files.txt")" -eq 55

mapfile -t GENERATED_FILES < "$TMP_ROOT/expected_files.txt"
git add -f -- "${GENERATED_FILES[@]}"

git diff --cached --name-only |
  sort > "$TMP_ROOT/staged_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/staged_files.txt"

test "$(wc -l < "$TMP_ROOT/staged_files.txt")" -eq 55
test -z "$(git diff --name-only)"

git commit \
  -m "evidence(experiments): persist SA5 objective-count Stage-10 timing"

COMMIT="$(git rev-parse HEAD)"

test "$(git rev-parse HEAD^)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

git diff-tree --no-commit-id --name-only -r "$COMMIT" |
  sort > "$TMP_ROOT/committed_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/committed_files.txt"

echo "timing_evidence_commit=PASS"
echo "commit=$COMMIT"
echo "committed_file_count=55"

echo
echo "=== 8. Push and create Timing Evidence PR ==="

git push -u origin "$BRANCH"

EVIDENCE_SHA="$(sha256sum "$EVIDENCE_MANIFEST" | awk '{print $1}')"
RUN_FILES_SHA="$(sha256sum "$RUN_FILE_MANIFEST" | awk '{print $1}')"
REBINDING_SHA="$(sha256sum "$REBINDING_MANIFEST" | awk '{print $1}')"
REPORT_SHA="$(sha256sum "$PLANNING_REPORT" | awk '{print $1}')"

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --base "$BASE" \
    --head "$BRANCH" \
    --title "Persist SA5 objective-count Stage-10 timing evidence" \
    --body-file - <<EOF
## Timing Execution

- 10/10 successful timing replications
- warmups: 10
- measurements: 100
- order seed: 20260728
- 151,800 total timing observations
- 40 timing-output files
- 10 execution logs
- 0 explicit failures
- consistent CSV schema and finite numeric values

## Controlled path rebinding

The committed functional execution specs store E3-relative immutable paths. The timing runner resolves relative paths against the process working directory. Execution therefore used detached, validated copies in which only path-valued inputs were rebound to absolute repository locations.

- committed execution specs modified: false
- evaluator called during rebinding: false
- rebinding manifest SHA-256: \`$REBINDING_SHA\`

## Provenance

- source commit: \`$EXPECTED_HEAD\`
- timing evidence SHA-256: \`$EVIDENCE_SHA\`
- timing run-file manifest SHA-256: \`$RUN_FILES_SHA\`
- timing execution report SHA-256: \`$REPORT_SHA\`

Timing values have not been interpreted. Precision analysis, bootstrap analysis, scientific interpretation, scientific freeze, and manuscript integration have not been performed.
EOF
)"

PR_NUMBER="$(
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number \
    --jq '.number'
)"

test -n "$PR_NUMBER"

gh pr view "$PR_NUMBER" \
  --repo "$REPO" \
  --json state,isDraft,headRefOid,headRefName,baseRefName,title |
jq -e \
  --arg head "$COMMIT" \
  --arg branch "$BRANCH" \
  --arg base "$BASE" \
  '
    .state == "OPEN"
    and .isDraft == false
    and .headRefOid == $head
    and .headRefName == $branch
    and .baseRefName == $base
    and .title
      == "Persist SA5 objective-count Stage-10 timing evidence"
  ' >/dev/null

gh api \
  --paginate \
  -H "Accept: application/vnd.github+json" \
  "/repos/$REPO/pulls/$PR_NUMBER/files?per_page=100" \
  --jq '.[].filename' |
  sort > "$TMP_ROOT/pr_files.txt"

diff -u "$TMP_ROOT/expected_files.txt" "$TMP_ROOT/pr_files.txt"
test "$(wc -l < "$TMP_ROOT/pr_files.txt")" -eq 55

echo "timing_evidence_push=PASS"
echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"
echo "pr_file_count=55"

echo
echo "=== 9. Final state ==="

echo "sa5_objective_count_stage10_timing_execution_recovery=PASS"
echo "base_head=$EXPECTED_HEAD"
echo "branch=$BRANCH"
echo "commit=$COMMIT"
echo "pull_request=$PR_NUMBER"

echo "successful_replication_count=10"
echo "failed_replication_count=0"
echo "total_observation_rows=151800"
echo "timing_output_file_count=40"
echo "execution_log_count=10"
echo "committed_file_count=55"

echo "path_rebinding_performed=true"
echo "committed_execution_specs_modified=false"
echo "evaluator_called_during_rebinding=false"
echo "rebinding_manifest_sha256=$REBINDING_SHA"

echo "timing_execution_performed=true"
echo "timing_execution_completion_audited=true"
echo "timing_values_interpreted=false"

echo "precision_setup_authorized_after_merge=true"
echo "precision_analysis_authorized=false"
echo "bootstrap_analysis_authorized=false"
echo "scientific_result_interpretation_authorized=false"
echo "scientific_freeze_authorized=false"
echo "manuscript_integration_authorized=false"
echo "manuscript_modified=false"

echo "next_stage=wait_for_ci_then_merge_sa5_objective_count_stage10_timing_evidence"

git status --short --branch
git log --oneline --decorate -5
