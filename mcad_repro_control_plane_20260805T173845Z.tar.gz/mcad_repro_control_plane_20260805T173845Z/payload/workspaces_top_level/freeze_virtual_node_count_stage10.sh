#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="/workspaces/MCAD_improve3"
REPO="digitcreadev/MCAD_improve3"

BASE="paper/phase3-controlled-execution"
EXPECTED_HEAD="4ad3f6aa90fd47107bb767ffeb23e38d995e3120"

PYTHON="/workspaces/.venvs/mcad-bridge-reconciliation-20260801T180758Z/bin/python"

PACKAGE_REL="experiments/article/frozen_campaigns/sa3_virtual_node_count_stage10"
REGISTRY_REL="experiments/article/frozen_campaigns/REGISTRY.yaml"

TIMING_REPORT_REL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/timing_execution/formal_timing_execution_report.json"

DECISION_REL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis/stage10_precision_decision_report.json"

ADAPTER_REL="reports/article_experiments/sensitivity/e3_controlled_execution/audits/virtual_node_count_stage10/precision_analysis/analyzer_timing_report_adapter.json"

trap 'echo "[ERROR] Freeze script stopped at line $LINENO."' ERR

cd "$ROOT"

echo "=== 1. Freeze gate ==="

test "$(git branch --show-current)" = "$BASE"
test "$(git rev-parse HEAD)" = "$EXPECTED_HEAD"
test -z "$(git status --porcelain)"

test -x "$PYTHON"
test -f "$TIMING_REPORT_REL"
test -f "$DECISION_REL"
test -f "$ADAPTER_REL"
test -f "$REGISTRY_REL"
test ! -e "$PACKAGE_REL"

echo "repository_gate=PASS"
echo "source_commit=$EXPECTED_HEAD"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_rerun_performed=false"
echo "campaign_freeze_performed=false"
echo "global_scientific_freeze=false"

echo
echo "=== 2. Validate completed campaign ==="

"$PYTHON" - \
  "$TIMING_REPORT_REL" \
  "$DECISION_REL" \
  "$ADAPTER_REL" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def load(path: str) -> dict[str, Any]:
    payload = json.loads(
        Path(path).read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


timing = load(sys.argv[1])
decision = load(sys.argv[2])
adapter = load(sys.argv[3])

expected_timing = {
    "status": "pass",
    "campaign_id": "virtual_node_count_stage10_c4",
    "replication_count": 10,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "all_replications_passed": True,
    "functional_execution_rerun_performed": False,
    "historical_prefix_rerun_performed": False,
    "timing_execution_performed": True,
    "precision_analysis_performed": False,
    "latency_claim_authorized": False,
    "stage20_execution_authorized": False,
}

for key, expected in expected_timing.items():
    actual = timing.get(key)

    if actual != expected:
        raise SystemExit(
            f"Timing report {key}: "
            f"expected {expected!r}, got {actual!r}"
        )

expected_decision = {
    "status": "pass",
    "campaign_id": "virtual_node_count_stage10_c4",
    "replication_count": 10,
    "structural_seed_count": 10,
    "timing_cell_count": 60,
    "precision_cell_count": 6,
    "measurement_observation_count": 6000,
    "all_median_targets_met": True,
    "all_p95_targets_met": True,
    "all_precision_targets_met": True,
    "failing_cell_count": 0,
    "stage10_sufficient": True,
    "stage20_extension_required": False,
}

for key, expected in expected_decision.items():
    actual = decision.get(key)

    if actual != expected:
        raise SystemExit(
            f"Precision decision {key}: "
            f"expected {expected!r}, got {actual!r}"
        )

analysis = decision.get("analysis", {})

if analysis.get(
    "successful_bootstrap_execution_count"
) != 1:
    raise SystemExit(
        "Expected exactly one successful bootstrap."
    )

constraints = decision.get(
    "scientific_constraints",
    {},
)

expected_constraints = {
    "functional_execution_rerun_performed": False,
    "timing_execution_rerun_performed": False,
    "stage20_execution_authorized": False,
    "latency_claim_authorized": False,
    "scientific_freeze_authorized": False,
}

for key, expected in expected_constraints.items():
    actual = constraints.get(key)

    if actual != expected:
        raise SystemExit(
            f"Scientific constraint {key}: "
            f"expected {expected!r}, got {actual!r}"
        )

totals = adapter.get("totals", {})

expected_totals = {
    "run_count": 10,
    "successful_run_count": 10,
    "cell_count": 60,
    "measurement_observation_count": 6000,
    "functional_mismatch_count": 0,
    "exactly_balanced_run_count": 10,
    "structural_seed_count": 10,
}

for key, expected in expected_totals.items():
    actual = totals.get(key)

    if actual != expected:
        raise SystemExit(
            f"Adapter total {key}: "
            f"expected {expected!r}, got {actual!r}"
        )

print("completed_campaign_validation=PASS")
print("run_count=10")
print("successful_run_count=10")
print("functional_step_count=60")
print("timing_cell_count=60")
print("measurement_observation_count=6000")
print("functional_mismatch_count=0")
print("precision_targets_met=true")
print("stage10_sufficient=true")
print("stage20_extension_required=false")
PY

echo
echo "=== 3. Create freeze branch ==="

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FROZEN_UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

BRANCH="paper/freeze-virtual-node-count-stage10-${STAMP}"
ARCHIVE_NAME="virtual_node_count_stage10_canonical_${STAMP}.tar.gz"

git switch -c "$BRANCH" "$EXPECTED_HEAD"

echo "branch=$BRANCH"
echo "archive_name=$ARCHIVE_NAME"
echo "frozen_utc=$FROZEN_UTC"

echo
echo "=== 4. Build exact repository snapshot ==="

STAGING="$(mktemp -d)"
ARCHIVE_ROOT="$STAGING/archive_root"
SNAPSHOT_ROOT="$ARCHIVE_ROOT/repository_snapshot"

mkdir -p "$SNAPSHOT_ROOT"
mkdir -p "$PACKAGE_REL/archive"
mkdir -p "$PACKAGE_REL/freeze"

"$PYTHON" - \
  "$ROOT" \
  "$SNAPSHOT_ROOT" \
  "$TIMING_REPORT_REL" \
  "$DECISION_REL" \
  "$ADAPTER_REL" \
  "$EXPECTED_HEAD" \
  "$FROZEN_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

root = Path(sys.argv[1])
snapshot_root = Path(sys.argv[2])
timing_report_path = root / sys.argv[3]
decision_path = root / sys.argv[4]
adapter_path = root / sys.argv[5]
source_commit = sys.argv[6]
frozen_utc = sys.argv[7]

archive_root = snapshot_root.parent


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(f"Expected JSON object: {path}")

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


selected: set[Path] = set()


def add_file(path: Path) -> None:
    if not path.is_file():
        raise SystemExit(f"Missing snapshot file: {path}")

    selected.add(path.resolve())


def add_optional_file(path: Path) -> None:
    if path.is_file():
        selected.add(path.resolve())


def add_directory(path: Path) -> None:
    if not path.is_dir():
        raise SystemExit(
            f"Missing snapshot directory: {path}"
        )

    for child in path.rglob("*"):
        if child.is_file():
            selected.add(child.resolve())


def add_optional_directory(path: Path) -> None:
    if path.is_dir():
        for child in path.rglob("*"):
            if child.is_file():
                selected.add(child.resolve())


timing = load_json(timing_report_path)
decision = load_json(decision_path)
adapter = load_json(adapter_path)

# Preregistered and execution tooling.
for relative in (
    "backend/harness/sensitivity_execution/"
    "run_timing_repetitions.py",

    "backend/harness/sensitivity_execution/"
    "analyze_clustered_timing_precision_v2.py",

    "backend/harness/sensitivity_execution/"
    "execute_controlled_family.py",

    "backend/harness/sensitivity_execution/tools/"
    "generate_virtual_node_count_stage10_structure.py",

    "backend/harness/sensitivity_execution/tools/"
    "prepare_virtual_node_count_stage10_common_workloads.py",

    "backend/harness/sensitivity_execution/tools/"
    "prepare_virtual_node_count_stage10_timing_plan.py",

    "backend/harness/sensitivity_execution/tests/"
    "test_virtual_node_count_stage10_structure.py",

    "backend/harness/sensitivity_execution/tests/"
    "test_virtual_node_count_stage10_common_workloads.py",

    "backend/harness/sensitivity_execution/tests/"
    "test_virtual_node_count_stage10_timing_plan.py",

    "backend/harness/sensitivity_execution/tests/"
    "test_timing_repetitions.py",

    "backend/harness/sensitivity_execution/tests/"
    "test_clustered_timing_precision_v2.py",

    "backend/harness/sensitivity_generator/"
    "structural_generator.py",

    "backend/harness/sensitivity_generator/families/"
    "controlled_families.py",

    "backend/harness/sensitivity_generator/families/"
    "e2_2_contract.yaml",
):
    add_file(root / relative)

reports_root = (
    root
    / "reports/article_experiments/sensitivity/"
      "e3_controlled_execution"
)

# All campaign planning and authorization artifacts.
planning_root = reports_root / "planning"

for path in planning_root.glob(
    "virtual_node_count_stage10*.json"
):
    add_file(path)

# Structural campaign, workloads and execution specs.
add_directory(
    reports_root
    / "formal_campaigns/"
      "virtual_node_count_stage10_c4"
)

for directory_name in (
    "workloads",
    "execution_specs",
):
    directory = reports_root / directory_name

    matches = sorted(
        directory.glob(
            "virtual_node_count_stage10_"
            "rep_*_strict_common.json"
        )
    )

    if len(matches) != 10:
        raise SystemExit(
            f"Expected 10 {directory_name} artifacts, "
            f"got {len(matches)}."
        )

    for path in matches:
        add_file(path)

# Complete campaign audit chain.
add_directory(
    reports_root
    / "audits/virtual_node_count_stage10"
)

# Formal timing evidence.
add_directory(
    reports_root
    / "timing_runs/virtual_node_count_stage10_c4"
)

# Functional source runs referenced by the timing report.
replications = timing.get("replications")

if not isinstance(replications, list):
    raise SystemExit(
        "Timing report lacks replication records."
    )

if len(replications) != 10:
    raise SystemExit(
        "Expected ten timing replication records."
    )

functional_run_paths: list[str] = []

for item in replications:
    value = Path(item["source_functional_run_path"])

    if value.is_absolute():
        run_path = value
    else:
        run_path = root / value

    add_directory(run_path)

    functional_run_paths.append(
        run_path.relative_to(root).as_posix()
    )

# Copy selected repository files.
records: list[dict[str, Any]] = []

for source in sorted(selected):
    try:
        relative = source.relative_to(root)
    except ValueError as exc:
        raise SystemExit(
            f"Snapshot source outside repository: {source}"
        ) from exc

    destination = snapshot_root / relative
    destination.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    shutil.copy2(source, destination)

    records.append(
        {
            "path": relative.as_posix(),
            "sha256": sha256_file(source),
            "size_bytes": source.stat().st_size,
        }
    )

if not records:
    raise SystemExit("Snapshot selection is empty.")

source_manifest = {
    "schema_version": (
        "mcad-frozen-campaign-source-manifest-v1"
    ),
    "campaign_id": "sa3_virtual_node_count_stage10",
    "source_commit": source_commit,
    "source_file_count": len(records),
    "files": records,
}

write_json(
    archive_root / "SOURCE_MANIFEST.json",
    source_manifest,
)

validation_summary = {
    "schema_version": (
        "mcad-virtual-node-count-stage10-"
        "freeze-validation-summary-v1"
    ),
    "campaign_id": "sa3_virtual_node_count_stage10",
    "source_campaign_id": (
        "virtual_node_count_stage10_c4"
    ),
    "factor": "virtual_node_count",
    "stage": 10,
    "source_commit": source_commit,
    "frozen_utc": frozen_utc,
    "run_count": 10,
    "successful_run_count": 10,
    "structural_seed_count": 10,
    "functional_step_count": 60,
    "timing_cell_count": 60,
    "warmup_observation_count": 600,
    "measurement_observation_count": 6000,
    "functional_mismatch_count": 0,
    "precision_cell_count": 6,
    "precision_targets_met": True,
    "failing_precision_cell_count": 0,
    "stage10_sufficient": True,
    "stage20_extension_required": False,
    "stage20_execution_authorized": False,
    "scientific_freeze": True,
    "global_scientific_freeze": False,
    "latency_claim_authorized": False,
    "rerun_required": False,
    "functional_execution_rerun_performed": False,
    "timing_execution_rerun_performed": False,
    "precision_analysis_rerun_performed": False,
    "successful_bootstrap_execution_count": 1,
    "functional_source_run_paths": sorted(
        functional_run_paths
    ),
    "key_evidence": {
        "timing_report": {
            "path": timing_report_path
            .relative_to(root)
            .as_posix(),
            "sha256": sha256_file(
                timing_report_path
            ),
        },
        "precision_decision": {
            "path": decision_path
            .relative_to(root)
            .as_posix(),
            "sha256": sha256_file(
                decision_path
            ),
        },
        "analyzer_timing_adapter": {
            "path": adapter_path
            .relative_to(root)
            .as_posix(),
            "sha256": sha256_file(
                adapter_path
            ),
        },
    },
}

write_json(
    archive_root / "VALIDATION_SUMMARY.json",
    validation_summary,
)

print("repository_snapshot_preparation=PASS")
print(f"snapshot_file_count={len(records)}")
print("functional_source_run_count=10")
print("campaign_execution_performed=false")
print("timing_execution_performed=false")
print("precision_analysis_performed=false")
PY

ARCHIVE_PATH="$PACKAGE_REL/archive/$ARCHIVE_NAME"

tar \
  --sort=name \
  --mtime='UTC 1970-01-01' \
  --owner=0 \
  --group=0 \
  --numeric-owner \
  -C "$ARCHIVE_ROOT" \
  -cf - \
  . \
  | gzip -n > "$ARCHIVE_PATH"

ARCHIVE_SHA256="$(sha256sum "$ARCHIVE_PATH" | awk '{print $1}')"
ARCHIVE_SIZE="$(stat -c '%s' "$ARCHIVE_PATH")"

printf '%s  %s\n' \
  "$ARCHIVE_SHA256" \
  "$ARCHIVE_NAME" \
  > "$ARCHIVE_PATH.sha256"

tar -tzf "$ARCHIVE_PATH" > "$PACKAGE_REL/CONTENTS.txt"

echo "repository_snapshot_archive=PASS"
echo "canonical_archive=$ARCHIVE_NAME"
echo "canonical_archive_sha256=$ARCHIVE_SHA256"
echo "canonical_archive_size_bytes=$ARCHIVE_SIZE"

echo
echo "=== 5. Create external freeze metadata ==="

"$PYTHON" - \
  "$ROOT" \
  "$PACKAGE_REL" \
  "$REGISTRY_REL" \
  "$ARCHIVE_NAME" \
  "$ARCHIVE_SHA256" \
  "$ARCHIVE_SIZE" \
  "$EXPECTED_HEAD" \
  "$FROZEN_UTC" <<'PY'
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
package = root / sys.argv[2]
registry_path = root / sys.argv[3]
archive_name = sys.argv[4]
archive_sha256 = sys.argv[5]
archive_size = int(sys.argv[6])
source_commit = sys.argv[7]
frozen_utc = sys.argv[8]


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(
        json.dumps(
            payload,
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


(package / "README.md").write_text(
    """# SA3 virtual-node-count Stage-10 campaign

Canonical frozen package for the completed `virtual_node_count`
sensitivity campaign.

The campaign reached sufficient precision at Stage 10 with 10 successful
runs, 6,000 formal timing measurements, zero functional mismatches and
all six precision cells satisfying both preregistered targets.

No campaign execution, timing execution or precision analysis was
performed while creating this package.
""",
    encoding="utf-8",
)

(package / "REPRODUCE.md").write_text(
    f"""# Reproducibility status

The archive contains the exact existing Stage-10 planning artifacts,
structural instances, common workloads, functional evidence, formal
timing evidence, precision-analysis evidence and relevant versioned
scripts.

Source commit:

`{source_commit}`

The campaign must not be rerun merely to recreate this package.

Stage 20 is not required and remains unauthorized. Timing evidence is
preserved, but no latency claim is authorized.
""",
    encoding="utf-8",
)

provenance = {
    "campaign_regenerated_during_freeze": False,
    "canonical_archive": archive_name,
    "canonical_archive_sha256": archive_sha256,
    "canonical_archive_size_bytes": archive_size,
    "packaging_mode": "existing_evidence_exact_snapshot",
    "source_commit": source_commit,
}

write_json(package / "PROVENANCE.json", provenance)

status = {
    "campaign_id": "sa3_virtual_node_count_stage10",
    "freeze_scope": "virtual_node_count_stage10",
    "functional_mismatch_count": 0,
    "global_scientific_freeze": False,
    "latency_claim_authorized": False,
    "measurement_observation_count": 6000,
    "precision_targets_met": True,
    "repository_persistence_status": "complete",
    "rerun_required": False,
    "run_count": 10,
    "scientific_freeze": True,
    "scientific_status": (
        "completed_precision_targets_met"
    ),
    "successful_run_count": 10,
}

write_json(package / "STATUS.json", status)

freeze = {
    "freeze_scope": "virtual_node_count_stage10",
    "global_scientific_freeze": False,
    "latency_claim_authorized": False,
    "precision_targets_met": True,
    "scientific_freeze": True,
}

write_json(
    package / "freeze/FREEZE.json",
    freeze,
)

manifest_paths = [
    Path("CONTENTS.txt"),
    Path("PROVENANCE.json"),
    Path("README.md"),
    Path("REPRODUCE.md"),
    Path("STATUS.json"),
    Path("archive") / archive_name,
    Path("archive") / f"{archive_name}.sha256",
    Path("freeze/FREEZE.json"),
]

manifest_files: list[dict[str, Any]] = []

for relative in manifest_paths:
    path = package / relative

    if not path.is_file():
        raise SystemExit(
            f"Missing package file: {relative}"
        )

    manifest_files.append(
        {
            "path": relative.as_posix(),
            "sha256": sha256_file(path),
            "size_bytes": path.stat().st_size,
        }
    )

manifest = {
    "campaign_id": "sa3_virtual_node_count_stage10",
    "file_count": len(manifest_files),
    "files": manifest_files,
    "schema_version": (
        "mcad-frozen-campaign-manifest-v1"
    ),
}

write_json(package / "MANIFEST.json", manifest)

checksum_paths = sorted(
    manifest_paths + [Path("MANIFEST.json")],
    key=lambda path: path.as_posix(),
)

checksum_lines = [
    (
        f"{sha256_file(package / relative)}  "
        f"{relative.as_posix()}"
    )
    for relative in checksum_paths
]

(package / "SHA256SUMS").write_text(
    "\n".join(checksum_lines) + "\n",
    encoding="utf-8",
)

registry_text = registry_path.read_text(
    encoding="utf-8"
)

entry_name = "  sa3_virtual_node_count_stage10:"

if entry_name in registry_text:
    raise SystemExit(
        "Frozen registry entry already exists."
    )

marker = "  remaining_sensitivity:\n"

if marker not in registry_text:
    raise SystemExit(
        "Registry insertion marker not found."
    )

entry = f"""  sa3_virtual_node_count_stage10:
    scientific_status: completed_precision_targets_met
    repository_persistence_status: complete
    path: sa3_virtual_node_count_stage10
    canonical_archive_sha256: {archive_sha256}
    scientific_freeze: true
    run_count: 10
    measurement_observation_count: 6000
    functional_mismatch_count: 0
    precision_targets_met: true
    latency_claim_authorized: false
    rerun_required: false

"""

registry_text = registry_text.replace(
    marker,
    entry + marker,
    1,
)

old_action = (
    "    next_action: continue_virtual_node_count"
)

new_action = (
    "    next_action: "
    "continue_membership_density_temporal"
)

if old_action not in registry_text:
    raise SystemExit(
        "Expected previous sensitivity action "
        "was not found."
    )

registry_text = registry_text.replace(
    old_action,
    new_action,
    1,
)

registry_path.write_text(
    registry_text,
    encoding="utf-8",
)

print("external_freeze_metadata=PASS")
print("manifest_file_count=8")
print("registry_entry_created=true")
print(
    "remaining_sensitivity_next_action="
    "continue_membership_density_temporal"
)
print("campaign_scientific_freeze=true")
print("global_scientific_freeze=false")
print("latency_claim_authorized=false")
PY

echo
echo "=== 6. Validate canonical package ==="

(
  cd "$PACKAGE_REL"
  sha256sum -c SHA256SUMS
)

"$PYTHON" - \
  "$ROOT" \
  "$PACKAGE_REL" \
  "$REGISTRY_REL" \
  "$ARCHIVE_SHA256" <<'PY'
from __future__ import annotations

import hashlib
import json
import tarfile
import sys
from pathlib import Path
from typing import Any

root = Path(sys.argv[1])
package = root / sys.argv[2]
registry_path = root / sys.argv[3]
expected_archive_sha256 = sys.argv[4]


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(
        path.read_text(encoding="utf-8")
    )

    if not isinstance(payload, dict):
        raise SystemExit(
            f"Expected JSON object: {path}"
        )

    return payload


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


manifest = load_json(package / "MANIFEST.json")
provenance = load_json(package / "PROVENANCE.json")
status = load_json(package / "STATUS.json")
freeze = load_json(package / "freeze/FREEZE.json")

if manifest.get("file_count") != 8:
    raise SystemExit("Expected eight manifest files.")

for record in manifest["files"]:
    path = package / record["path"]

    if not path.is_file():
        raise SystemExit(
            f"Missing manifest file: {path}"
        )

    if sha256_file(path) != record["sha256"]:
        raise SystemExit(
            f"Manifest hash mismatch: {path}"
        )

    if path.stat().st_size != record["size_bytes"]:
        raise SystemExit(
            f"Manifest size mismatch: {path}"
        )

archive = (
    package
    / "archive"
    / provenance["canonical_archive"]
)

if sha256_file(archive) != expected_archive_sha256:
    raise SystemExit("Canonical archive hash mismatch.")

with tarfile.open(archive, "r:gz") as stream:
    names = set(
        member.name
        for member in stream.getmembers()
    )

required_members = {
    ".",
    "./SOURCE_MANIFEST.json",
    "./VALIDATION_SUMMARY.json",
    "./repository_snapshot",
}

if not required_members.issubset(names):
    raise SystemExit(
        "Canonical archive structure is incomplete."
    )

if status.get("scientific_freeze") is not True:
    raise SystemExit(
        "Campaign scientific freeze is not enabled."
    )

if status.get("global_scientific_freeze") is not False:
    raise SystemExit(
        "Global scientific freeze changed unexpectedly."
    )

if status.get("latency_claim_authorized") is not False:
    raise SystemExit(
        "Latency claim became authorized unexpectedly."
    )

if freeze.get("precision_targets_met") is not True:
    raise SystemExit(
        "Freeze record lacks precision success."
    )

registry = registry_path.read_text(
    encoding="utf-8"
)

required_registry_fragments = (
    "sa3_virtual_node_count_stage10:",
    f"canonical_archive_sha256: "
    f"{expected_archive_sha256}",
    "next_action: "
    "continue_membership_density_temporal",
    "global_scientific_freeze: false",
    "latency_claim_authorized: false",
    "manuscript_resume_authorized: false",
)

for fragment in required_registry_fragments:
    if fragment not in registry:
        raise SystemExit(
            f"Registry fragment missing: {fragment}"
        )

print("canonical_freeze_package_validation=PASS")
print("campaign_id=sa3_virtual_node_count_stage10")
print("run_count=10")
print("measurement_observation_count=6000")
print("functional_mismatch_count=0")
print("precision_targets_met=true")
print("campaign_scientific_freeze=true")
print("global_scientific_freeze=false")
print("latency_claim_authorized=false")
print("rerun_required=false")
PY

rm -rf "$STAGING"

echo
echo "=== 7. Commit and push freeze package ==="

git add \
  "$PACKAGE_REL" \
  "$REGISTRY_REL"

git diff --cached --check

git diff --cached --stat

git commit \
  -m "chore(experiments): freeze virtual-node-count Stage-10 campaign"

COMMIT="$(git rev-parse HEAD)"

git push -u origin "$BRANCH"

echo "commit=$COMMIT"
echo "push=PASS"

echo
echo "=== 8. Create pull request ==="

PR_URL="$(
  gh pr create \
    --repo "$REPO" \
    --head "$BRANCH" \
    --base "$BASE" \
    --title "Freeze virtual-node-count Stage-10 campaign" \
    --body "$(cat <<EOF
## Frozen campaign

- campaign: \`sa3_virtual_node_count_stage10\`;
- Stage-10 runs: \`10\`;
- formal measurements: \`6000\`;
- functional mismatches: \`0\`;
- precision targets met: \`true\`;
- failing precision cells: \`0\`;
- Stage-10 sufficient: \`true\`;
- Stage-20 required: \`false\`;
- canonical archive SHA-256: \`$ARCHIVE_SHA256\`.

## Execution safeguards

- campaign execution during freeze: \`false\`;
- timing execution during freeze: \`false\`;
- precision analysis during freeze: \`false\`;
- rerun required: \`false\`.

## Scientific scope

- campaign scientific freeze: \`true\`;
- global scientific freeze: \`false\`;
- latency claims authorized: \`false\`;
- manuscript resume authorized: \`false\`.

## Next sensitivity action

\`continue_membership_density_temporal\`
EOF
)"
)"

PR_NUMBER="${PR_URL##*/}"

echo "pull_request=$PR_NUMBER"
echo "pull_request_url=$PR_URL"

echo
echo "=== 9. Final state ==="

echo "virtual_node_count_stage10_freeze_package=PASS"
echo "commit=$COMMIT"
echo "canonical_archive=$ARCHIVE_NAME"
echo "canonical_archive_sha256=$ARCHIVE_SHA256"
echo "campaign_scientific_freeze=true"
echo "global_scientific_freeze=false"
echo "latency_claim_authorized=false"
echo "functional_execution_rerun_performed=false"
echo "timing_execution_rerun_performed=false"
echo "precision_analysis_rerun_performed=false"
echo "pull_request=$PR_NUMBER"
echo "next_stage=wait_for_ci_then_merge_virtual_node_count_freeze"

git status --short --branch
git log --oneline --decorate -4
