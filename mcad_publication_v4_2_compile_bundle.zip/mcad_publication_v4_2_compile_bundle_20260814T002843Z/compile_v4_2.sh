#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE/repo"
ENTRY="article_update/paper_artifacts_v4/manuscript/MCAD_audited_real_main_fr_v4.tex"
OUTDIR="$HERE/pdf_build"
mkdir -p "$OUTDIR"

if command -v latexmk >/dev/null 2>&1; then
  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    -outdir="$OUTDIR" "$ENTRY"
elif command -v pdflatex >/dev/null 2>&1; then
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$OUTDIR" "$ENTRY"
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$OUTDIR" "$ENTRY"
else
  echo "NO_TEX_ENGINE"
  exit 2
fi

PDF="$OUTDIR/MCAD_audited_real_main_fr_v4.pdf"
[[ -s "$PDF" ]]
echo "compiled_pdf=$PDF"
