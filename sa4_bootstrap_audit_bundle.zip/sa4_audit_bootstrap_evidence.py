from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import traceback
from pathlib import Path
from typing import Any

ROOT = Path('/workspaces/MCAD_improve3').resolve()
EXPECTED_HEAD = '36fe29d42c8ca53e79e5fa2a8dc35df6e1860c48'
E3 = ROOT / 'reports/article_experiments/sensitivity/e3_controlled_execution'
SPEC_DIR = E3 / 'execution_specs'
RUNS_DIR = E3 / 'runs'
SOURCE_LOG_DIR = Path('/tmp/sa4_membership_density_bootstrap')
ARCHIVE_LOG_DIR = E3 / 'audits/membership_density/bootstrap_logs'
PLANNING = E3 / 'planning'
REPORT_JSON = PLANNING / 'sa4_membership_density_bootstrap_audit.json'
REPORT_MD = PLANNING / 'sa4_membership_density_bootstrap_audit.md'
EXPECTED_LEVELS = (25, 50, 75, 100)
EXPECTED_SEEDS = (
    101, 202, 1198202409, 796786883, 1126922093,
    809989256, 618554674, 1363159082, 874332939, 1767972531,
)


def fail(message: str) -> None:
    raise RuntimeError(message)


def canonical_digest(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(',', ':'),
        allow_nan=False,
    ).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_output(*args: str) -> str:
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        fail(f'Invalid JSON root: {path}')
    return value


def require_ignored(path: Path) -> None:
    result = subprocess.run(
        ['git', 'check-ignore', '-q', str(path.relative_to(ROOT))],
        cwd=ROOT,
        check=False,
    )
    if result.returncode != 0:
        fail(f'Output path is not ignored by Git: {path}')


def strip_instances_prefix(value: str) -> str:
    normalized = value.replace('\\', '/').strip('/')
    prefix = 'instances/'
    return normalized[len(prefix):] if normalized.startswith(prefix) else normalized


created: list[Path] = []
try:
    print('=== 1. BOOTSTRAP AUDIT GATE ===')
    branch = git_output('git', 'branch', '--show-current')
    head = git_output('git', 'rev-parse', 'HEAD')
    upstream = git_output('git', 'rev-parse', '@{upstream}')
    porcelain = git_output('git', 'status', '--porcelain')

    if branch != 'paper/phase3-controlled-execution':
        fail(f'Unexpected branch: {branch}')
    if head != EXPECTED_HEAD or upstream != EXPECTED_HEAD:
        fail(f'Unexpected checkpoint: local={head}, remote={upstream}')
    if porcelain:
        fail(f'Working tree must be clean:\n{porcelain}')
    if REPORT_JSON.exists() or REPORT_MD.exists() or ARCHIVE_LOG_DIR.exists():
        fail('Bootstrap audit output already exists; overwrite refused.')
    for path in (REPORT_JSON, REPORT_MD, ARCHIVE_LOG_DIR / 'probe.log'):
        require_ignored(path)

    print(f'branch={branch}')
    print(f'source_commit={head}')
    print('[OK] working_tree_clean=true')
    print('[OK] audit_outputs_absent=true')

    print('\n=== 2. INDEPENDENT BOOTSTRAP AUDIT ===')
    ARCHIVE_LOG_DIR.mkdir(parents=True, exist_ok=False)
    created.append(ARCHIVE_LOG_DIR)

    records: list[dict[str, Any]] = []
    total_instances = 0

    for rep in range(10):
        spec_path = SPEC_DIR / f'membership_density_rep_{rep:03d}_canonical.json'
        log_path = SOURCE_LOG_DIR / f'membership_density_rep_{rep:03d}_canonical.log'
        if not spec_path.is_file():
            fail(f'Missing execution spec: {spec_path}')
        if not log_path.is_file():
            fail(f'Missing bootstrap log: {log_path}')

        spec = read_json(spec_path)
        output_dir = Path(spec['output_dir'])
        probe_dir = output_dir / '_bootstrap_probe'
        if not output_dir.is_dir() or not probe_dir.is_dir():
            fail(f'Missing bootstrap output tree: replication={rep}')
        if sorted(path.name for path in output_dir.iterdir()) != ['_bootstrap_probe']:
            fail(f'Unexpected top-level bootstrap content: replication={rep}')
        if any(path.is_file() for path in output_dir.rglob('*')):
            fail(f'Bootstrap output contains files: replication={rep}')

        selected = list(spec['instance_selection']['instance_ids'])
        expected_ids = [strip_instances_prefix(value) for value in selected]
        if len(expected_ids) != 4 or len(set(expected_ids)) != 4:
            fail(f'Invalid selected instance set: replication={rep}')

        leaves = sorted(
            str(path.relative_to(probe_dir)).replace('\\', '/')
            for path in probe_dir.glob('level_*/rep_*')
            if path.is_dir()
        )
        if leaves != sorted(expected_ids):
            fail(f'Bootstrap leaf binding differs: replication={rep}')

        text = log_path.read_text(encoding='utf-8')
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if '[OK] selected_instance_count=4' not in lines:
            fail(f'Missing selected-instance confirmation: replication={rep}')
        bootstrap_lines = [line for line in lines if line.startswith('[BOOTSTRAP] ')]
        if len(bootstrap_lines) != 4:
            fail(f'Unexpected bootstrap-line count: replication={rep}')

        for instance_id in expected_ids:
            matches = [line for line in bootstrap_lines if f'id={instance_id} ' in line]
            if len(matches) != 1:
                fail(f'Bootstrap log binding differs: replication={rep}, id={instance_id}')
            line = matches[0]
            for token in ('graph_nodes=33', 'objective_count=1', 'constraint_count=4'):
                if token not in line:
                    fail(f'Missing {token}: replication={rep}, id={instance_id}')

        seed_tokens = {int(value.rsplit('_seed_', 1)[1]) for value in expected_ids}
        if seed_tokens != {EXPECTED_SEEDS[rep]}:
            fail(f'Unexpected seed binding: replication={rep}, seeds={seed_tokens}')
        level_tokens = {
            int(value.split('/', 1)[0].replace('level_', ''))
            for value in expected_ids
        }
        if level_tokens != set(EXPECTED_LEVELS):
            fail(f'Unexpected level binding: replication={rep}, levels={level_tokens}')

        archived_log = ARCHIVE_LOG_DIR / log_path.name
        shutil.copy2(log_path, archived_log)
        created.append(archived_log)

        records.append({
            'replication_index': rep,
            'seed': EXPECTED_SEEDS[rep],
            'instance_count': 4,
            'instance_ids': expected_ids,
            'graph_nodes_per_instance': 33,
            'objective_count_per_instance': 1,
            'constraint_count_per_instance': 4,
            'bootstrap_output_dir': str(output_dir),
            'bootstrap_probe_dir': str(probe_dir),
            'bootstrap_output_file_count': 0,
            'source_log_path': str(log_path),
            'archived_log_path': str(archived_log.relative_to(ROOT)),
            'archived_log_sha256': file_sha256(archived_log),
        })
        total_instances += 4
        print(f'[OK] replication={rep} seed={EXPECTED_SEEDS[rep]} instances=4 files=0')

    if total_instances != 40:
        fail(f'Unexpected total bootstrap instance count: {total_instances}')

    print('audited_partition_count=10')
    print('audited_bootstrap_instance_count=40')
    print('bootstrap_output_directory_count=10')
    print('bootstrap_probe_instance_directory_count=40')
    print('bootstrap_output_file_count=0')
    print('archived_bootstrap_log_count=10')

    print('\n=== 3. WRITE AUDIT REPORT ===')
    report: dict[str, Any] = {
        'schema_version': 'mcad-sensitivity-sa4-membership-density-bootstrap-audit-v1',
        'status': 'sa4_membership_density_bootstrap_audit_success',
        'source_commit': head,
        'partition_count': 10,
        'bootstrap_instance_count': 40,
        'levels': list(EXPECTED_LEVELS),
        'graph_nodes_per_instance': 33,
        'objective_count_per_instance': 1,
        'constraint_count_per_instance': 4,
        'bootstrap_output_directory_count': 10,
        'bootstrap_probe_instance_directory_count': 40,
        'bootstrap_output_file_count': 0,
        'archived_bootstrap_log_count': 10,
        'records': records,
        'bootstrap_audited': True,
        'bootstrap_evidence_archived': True,
        'bootstrap_output_cleanup_authorized': True,
        'bootstrap_output_cleanup_started': False,
        'controlled_execution_authorized': True,
        'controlled_execution_started': False,
        'timing_execution_authorized': False,
        'timing_execution_started': False,
        'latency_claim_authorized': False,
        'scientific_freeze': False,
        'next_stage': 'SA4_membership_density_bootstrap_output_cleanup',
    }
    report['bootstrap_audit_digest'] = canonical_digest(report)

    REPORT_JSON.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8',
    )
    created.append(REPORT_JSON)
    REPORT_MD.write_text(
        '# SA4 membership-density bootstrap audit\n\n'
        '- Status: `success`\n'
        '- Partitions: `10`\n'
        '- Bootstrapped instances: `40`\n'
        '- Graph nodes per instance: `33`\n'
        '- Objectives per instance: `1`\n'
        '- Constraints per instance: `4`\n'
        '- Output files created: `0`\n'
        '- Archived bootstrap logs: `10`\n'
        '- Cleanup authorized: `true`\n'
        '- Controlled execution started: `false`\n'
        '- Timing execution authorized: `false`\n\n'
        '## Next stage\n\n'
        '`SA4_membership_density_bootstrap_output_cleanup`\n',
        encoding='utf-8',
    )
    created.append(REPORT_MD)

    print('status=sa4_membership_density_bootstrap_audit_success')
    print(f"bootstrap_audit_digest={report['bootstrap_audit_digest']}")
    print('bootstrap_audited=true')
    print('bootstrap_evidence_archived=true')
    print('bootstrap_output_cleanup_authorized=true')
    print('bootstrap_output_cleanup_started=false')
    print('controlled_execution_started=false')
    print('timing_execution_authorized=false')
    print('scientific_freeze=false')
    print('next_stage=SA4_membership_density_bootstrap_output_cleanup')
    print(f'report_json={REPORT_JSON.relative_to(ROOT)}')
    print(f'report_md={REPORT_MD.relative_to(ROOT)}')
    print(f'archive_log_dir={ARCHIVE_LOG_DIR.relative_to(ROOT)}')

except Exception as exc:
    print(f'\n[ERROR] {type(exc).__name__}: {exc}')
    traceback.print_exc()
    for path in reversed(created):
        try:
            if path.is_file():
                path.unlink()
        except OSError:
            pass
    try:
        if ARCHIVE_LOG_DIR.is_dir() and not any(ARCHIVE_LOG_DIR.iterdir()):
            ARCHIVE_LOG_DIR.rmdir()
    except OSError:
        pass
    print('[RECOVERY] created_bootstrap_audit_outputs_removed=true')
    raise SystemExit(1)
